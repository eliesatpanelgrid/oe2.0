# -*- coding: utf-8 -*-
"""
_screens.py — CustomIPTVArchiveMakerPro
=============================
All Enigma2 Screen classes, the epgEvent helper, and the auto-build scheduler.

Classes
-------
  epgEvent                        — lightweight EPG event object
  IPTVArchiveEventViewEPGSelect   — event-detail overlay
  iptvArchiveSelection            — main archive EPG list screen
  IPTVFileBrowser                 — portable file-browser dialog
  IPTVChannelMatchDetailScreen    — M3U↔XMLTV match detail viewer
  IPTVProviderTestResultScreen    — scrollable test-result list
  IPTVChannelBrowserScreen        — two-panel bouquet/channel browser
  IPTVAutoBuildDayPicker          — day-of-week picker sub-screen
  IPTVArchivePluginSettings       — plugin-wide settings (MENU key)
  IPTVProviderSettings            — provider list management
  IPTVProviderEditDialog          — add / edit one provider
  IPTVArchiveJumpInput            — minute-input jump dialog
  iptvArchiveSecondInfoBar        — now/next overlay
  iptvArchiveInfoBar              — archive playback InfoBar

Auto-build globals (mutated only within this module)
----------------------------------------------------
  _iptv_open_requested  — True when opened via Extensions menu (not session restore)
  iptvHotKey            — string hot-key name for the plugin
  _auto_build_session   — Enigma2 session saved at WHERE_AUTOSTART
  _auto_build_timer     — eTimer that fires _checkAutoBuild every 60 s
  _auto_build_pending   — True while a headless build is running
  _auto_build_progress  — (done, total, prov_name) tuple updated by the build thread
  _auto_build_listener  — open iptvArchiveSelection that wants progress updates
"""

import os, sys, time, re, traceback, random, socket, base64, json

from . import _, PLUGIN_VERSION
from ._lang import T
from ._epg import (
    iptvLogWrite, currTime, DEBUG, SIGN, HEADERS, XMLTV_HEADERS,
    paramExist, xml_unescape, query_get, _wrapPath,
    _normalizeHttpUrl, _normName, _gunzip,
    loadPluginSettings, savePluginSettings, getEnabledPlayers,
    # loadProviderConfig/saveProviderConfig removed — use loadPlaylistProviderConfig
    loadIntegratedProviders, saveIntegratedProviders,
    _xmltvCacheDir, _clearProviderCache, _testProviderConnection, _testM3UOnly,
    _buildAllChannelCaches, _fetchCustomProvider, _downloadXMLTVToCache,
    _provider_cache, log_file, PLUGIN_DIR,
    _detectMediaPaths, getDataDir,
    PY3, urlparse, parse_qs, parse_qsl, urlencode, unquote,
    STATIC_INFO_DIC, MAX_CUSTOM_PROVIDERS,
)
from ._providers import getArchiveUrl, IPTV_PROVIDERS
from . import _providers as _prov
def has_archive(extinf_line):
    line_lower = extinf_line.lower()
    if 'catchup=' in line_lower:
        match = re.search(r'catchup=["\']([^"\']*)["\']', line_lower)
        if match:
            val = match.group(1).lower()
            try:
                if int(val) == 0:
                    return False
            except ValueError:
                pass
            if val in ('default', 'append', 'shift', 'xtreme', 'xtreme60',
                      'flussonic', 'flussonic-hls', 'flussonic-ts',
                      'stalker', '1', 'true', 'yes', 'on'):
                return True
            if val in ('0', 'false', 'no', 'off', 'disabled', 'none'):
                return False
            try:
                if int(val) > 0:
                    return True
            except ValueError:
                pass
            return True
        else:
            if re.search(r'\bcatchup\b', line_lower):
                return True
    if 'catchup-source=' in line_lower:
        match = re.search(r'catchup-source=["\']([^"\']*)["\']', line_lower)
        if match and match.group(1).strip():
            return True
    if 'catchup-days=' in line_lower:
        match = re.search(r'catchup-days=["\']?(\d+)["\']?', line_lower)
        if match:
            try:
                if int(match.group(1)) > 0:
                    return True
                else:
                    return False
            except ValueError:
                pass
    if 'tvg-rec=' in line_lower:
        match = re.search(r'tvg-rec=["\']([^"\']*)["\']', line_lower)
        if match:
            val = match.group(1).lower()
            try:
                if int(val) == 0:
                    return False
            except ValueError:
                pass
            if val in ('1', 'true', 'yes', 'on'):
                return True
            if val in ('0', 'false', 'no', 'off'):
                return False
            try:
                if int(val) > 0:
                    return True
            except ValueError:
                pass
            return True
        else:
            if re.search(r'\btvg-rec\b', line_lower):
                return True
    if 'archive=' in line_lower:
        match = re.search(r'archive=["\']([^"\']*)["\']', line_lower)
        if match:
            val = match.group(1).lower()
            try:
                if int(val) == 0:
                    return False
            except ValueError:
                pass
            if val in ('1', 'true', 'yes', 'on'):
                return True
            if val in ('0', 'false', 'no', 'off'):
                return False
            try:
                if int(val) > 0:
                    return True
            except ValueError:
                pass
            return True
        else:
            if re.search(r'\barchive\b', line_lower):
                return True
    if 'timeshift=' in line_lower:
        match = re.search(r'timeshift=["\']([^"\']*)["\']', line_lower)
        if match:
            val = match.group(1).lower()
            try:
                if int(val) == 0:
                    return False
            except ValueError:
                pass
            if val in ('1', 'true', 'yes', 'on'):
                return True
            if val in ('0', 'false', 'no', 'off'):
                return False
            try:
                if int(val) > 0:
                    return True
            except ValueError:
                pass
            return True
        else:
            if re.search(r'\btimeshift\b', line_lower):
                return True
    if re.search(r'\btv_archive\b', line_lower) and 'tv_archive=' not in line_lower:
        return True
    return False



try:
    from ._webserver import (IPTVWebInputServer, IPTVChannelBrowserWebServer,
                             WEB_PORT, WEB_CHANNEL_BROWSER_PORT,
                             WEB_XTREAM_BROWSER_PORT,
                             IPTVCustomEPGWebServer, WEB_CUSTOM_EPG_PORT)
    _WEB_INPUT_OK = True
except Exception:
    _WEB_INPUT_OK             = False
    WEB_PORT                  = 1010
    WEB_CHANNEL_BROWSER_PORT  = 1012
    WEB_XTREAM_BROWSER_PORT   = 1013
    IPTVCustomEPGWebServer    = None
    WEB_CUSTOM_EPG_PORT       = 1014


def _parse_xmltv_time(s):
    """Parse an XMLTV timestamp like '20260510140000 +0300'.

    Returns (utc_epoch_int, 'YYYY-MM-DD:HH-MM') or (0, '').
    Uses calendar.timegm() so the result is always a true UTC epoch
    regardless of the receiver's local timezone.
    """
    import calendar as _cal
    import datetime as _dtmod
    s = (s or '').strip()
    if len(s) < 14:
        return 0, ''
    local_str  = s[:14]
    offset_str = s[14:].strip()
    try:
        dt        = _dtmod.datetime.strptime(local_str, '%Y%m%d%H%M%S')
        url_start = dt.strftime('%Y-%m-%d:%H-%M')
        offset_sec = 0
        if len(offset_str) >= 5 and offset_str[0] in ('+', '-'):
            sign       = 1 if offset_str[0] == '+' else -1
            offset_sec = sign * (int(offset_str[1:3]) * 3600 + int(offset_str[3:5]) * 60)
        utc_epoch = _cal.timegm(dt.timetuple()) - offset_sec
        return utc_epoch, url_start
    except Exception:
        return 0, ''


# ---------------------------------------------------------------------------
# Enigma2 imports (stubbed where absent so the module loads on every image)
# ---------------------------------------------------------------------------

from enigma import eServiceReference, eTimer
try:
    from Screens.InputBox import InputBox
    from Components.Input import Input
except Exception:
    InputBox = None
    Input    = None
from ServiceReference import ServiceReference
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
try:
    from Screens.ChoiceBox import ChoiceBox
except ImportError:
    ChoiceBox = None

try:
    from Screens.Standby import Standby as _StandbyScreen
    _HAS_STANDBY = True
except ImportError:
    _StandbyScreen = None
    _HAS_STANDBY   = False

try:
    from Screens.InfoBar import InfoBar
except ImportError:
    InfoBar = None

class _InfoBarStub(object):
    def __init__(self): pass

try:
    from Screens.InfoBarGenerics import InfoBarAudioSelection
except ImportError:
    InfoBarAudioSelection = _InfoBarStub
try:
    from Screens.InfoBarGenerics import InfoBarNotifications
except ImportError:
    InfoBarNotifications = _InfoBarStub
try:
    from Screens.InfoBarGenerics import InfoBarSubtitleSupport
except ImportError:
    InfoBarSubtitleSupport = _InfoBarStub
try:
    from Screens.InfoBarGenerics import InfoBarMenu
except ImportError:
    InfoBarMenu = _InfoBarStub

try:
    from Screens.EpgSelection import EPGSelection
except ImportError:
    try:
        from Screens.EPGSelection import EPGSelection
    except ImportError:
        EPGSelection = Screen

try:
    from Screens.ChannelSelection import SimpleChannelSelection
except ImportError:
    SimpleChannelSelection = None

try:
    from Screens.EventView import EventViewEPGSelect, EventViewBase
except ImportError:
    try:
        from Screens.EventView import EventViewBase
        EventViewEPGSelect = EventViewBase
    except ImportError:
        EventViewBase      = Screen
        EventViewEPGSelect = Screen

from Components.Button import Button
from Components.MenuList import MenuList

try:
    from Components.ScrollLabel import ScrollLabel
except ImportError:
    from Components.Label import Label as ScrollLabel

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.Sources.Boolean import Boolean
from Components.Sources.Event import Event
from Components.config import config
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import (ConfigYesNo, ConfigText, ConfigInteger,
                                ConfigSelection, ConfigClock, ConfigNothing,
                                getConfigListEntry)
try:
    from Tools.Notifications import AddNotification as _AddNotification
except ImportError:
    _AddNotification = None
from Components.FileList import FileList
from Components.GUIComponent import GUIComponent
from Components.Label import Label
from Components.MultiContent import MultiContentEntryText
from enigma import (eListboxPythonMultiContent, eListbox, gFont, gRGB,
                    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER)

# Stub out updateSource() if missing (OpenPLi 9.2 compatibility)
try:
    if not hasattr(Event, 'updateSource'):
        Event.updateSource = lambda self, *a, **kw: None
except Exception:
    pass

try:
    from Tools.HardwareInfo import HardwareInfo
except ImportError:
    class HardwareInfo(object):
        def is_nextgen(self): return True
        def get_machine_name(self): return 'unknown'

try:
    from Tools.Directories import fileExists
except ImportError:
    fileExists = os.path.isfile

from ._epg import xxh32


# ---------------------------------------------------------------------------
# OTT-play gabbarit token — xxhash32 of device MAC address
# ---------------------------------------------------------------------------

def _getGabbarit():
    """Return the gabbarit token for epg.ott-play.com/m3u/ge2.php.
    The token is the xxhash32 integer of the device ethernet MAC address,
    exactly as IPTVarchive generates it.
    """
    mac = ''
    for iface in ('eth0', 'eth1', 'wlan0', 'wlan1'):
        try:
            with open('/sys/class/net/%s/address' % iface) as f:
                _m = f.read().strip().lower()
            if _m and _m != '00:00:00:00:00:00':
                mac = _m
                break
        except Exception:
            pass
    if not mac:
        try:
            import subprocess, re as _re
            out = subprocess.Popen(['ethtool', 'eth0'],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE).communicate()[0]
            m = _re.search(
                r'(?<!:)\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b(?!:)',
                out.decode('utf-8', errors='replace'))
            if m:
                mac = m.group(0).lower()
        except Exception:
            pass
    if not mac:
        return ''
    # Use a fresh xxh32 instance to avoid corrupting the shared module-level singleton
    from ._epg import _xxh32 as _Xxh32Class
    _h = _Xxh32Class()
    _h.__init__(data=mac.encode('utf-8'))
    return str(_h.intdigest())

iptvHotKey           = ''
_iptv_open_requested = False
_auto_build_session  = None
_auto_build_timer    = None
_auto_build_pending       = False
_auto_build_progress      = (0, 0, '')
_auto_build_listener      = None
_auto_build_was_in_standby  = False   # True if build woke the box from soft standby
_auto_build_should_return   = False   # True if build should return to standby when done
_auto_build_standby_counter = -1      # value of standbyCounter at trigger time; -1 = not set
_auto_build_standby_timer   = None    # eTimer kept alive until _do_standby fires
_archive_offset_cache = {}  # (prov_type, prov_id, stream_url) → int; cleared on settings/provider save

# ---------------------------------------------------------------------------
# epgEvent — lightweight event object that satisfies the Enigma2 EPG interface
# ---------------------------------------------------------------------------

class epgEvent(object):
    """Wraps a raw (descr, eventid, btime, duration, title) tuple as an E2 event."""

    def __init__(self, descr, eventid, btime, duration, title):
        self.descr    = descr if descr != '' else T("Description not available")
        self.eventid  = eventid if eventid else random.randint(0, 1000)
        self.btime    = btime
        self.duration = duration
        self.title    = title

    def getEventName(self):          return self.title
    def getShortDescription(self):   return self.descr
    def getExtendedDescription(self):return ''
    def getBeginTime(self):          return self.btime
    def getDuration(self):           return self.duration
    def getBeginTimeString(self):
        return time.strftime("%d.%m, %H:%M", time.localtime(self.btime))
    def getEventId(self):            return self.eventid
    def getGenreData(self):          return None
    def getParentalData(self):       return None
    def getGenreDataList(self):      return None
    def getPdcPil(self):             return 0
    def getRunningStatus(self):      return 4
    def getArchiveBeginTimeString(self):
        return (T('Archive for') +
                time.strftime(' {%w}, %d %B %Y', time.localtime(self.btime)).format(
                    *[T('sunday'), T('monday'), T('tuesday'), T('wednesday'),
                      T('thursday'), T('friday'), T('saturday')]))

# ---------------------------------------------------------------------------
# IPTVArchiveEventViewEPGSelect — event detail overlay
# ---------------------------------------------------------------------------

class IPTVArchiveEventViewEPGSelect(EventViewEPGSelect):
    def __init__(self, session, event, ref,
                 callback=None, singleEPGCB=None, multiEPGCB=None, similarEPGCB=None):
        Screen.__init__(self, session)
        self.skinName = ['iptvArchiveProEventView', 'iptvArchiveEventView', 'EventView']
        EventViewBase.__init__(self, event, ref, callback, similarEPGCB)
        self["key_red"]    = Button('')
        self["key_green"]  = Button('')
        self["key_yellow"] = Button('')
        self["key_blue"]   = Button('')
        self["setupActions"] = ActionMap(["ColorActions"],
            {"cancel": self.cancel, "red": self.cancel,
             "green": self.cancel, "yellow": self.cancel}, -2)

    def cancel(self):
        self.close(True)

# ---------------------------------------------------------------------------
# iptvArchiveSelection — main EPG archive list screen
# ---------------------------------------------------------------------------

class iptvArchiveSelection(EPGSelection):
    __module__ = __name__

    # Complete skin definition — replaces the receiver's EPGSelection skin entirely.
    # This is the only reliable way to remove the MENU/INFO buttons that are
    # hardcoded into the receiver's skin XML and cannot be hidden via code.
    skin = """
        <screen position="0,0" size="1280,720" title=" ">
            <!-- EPG event list fills the top portion of the screen -->
            <widget name="list" position="0,0" size="1280,568"
                    scrollbarMode="showOnDemand"/>

            <!-- Thin separator line -->
            <eLabel position="0,570" size="1280,2" backgroundColor="#aaaaaa"/>

            <!-- Selected event name + begin time -->
            <widget source="Event" render="Label"
                    expression="event.getBeginTimeString() + '  \u2014  ' + event.getEventName() if event else ''"
                    position="10,578" size="1260,36"
                    font="Regular;26" foregroundColor="#ffff00"
                    valign="center" transparent="1"/>

            <!-- Short description -->
            <widget source="Event" render="Label"
                    expression="event.getShortDescription() if event else ''"
                    position="10,618" size="1260,28"
                    font="Regular;20" foregroundColor="#aaaaaa" transparent="1"/>

            <!-- Separator above buttons -->
            <eLabel position="0,650" size="1280,2" backgroundColor="#aaaaaa"/>

            <!-- Colour buttons: RED  GREEN  YELLOW  BLUE  —  no INFO, no MENU -->
            <ePixmap position="10,658"  size="35,25" pixmap="buttons/red.png"    alphaTest="blend"/>
            <widget name="key_red"    position="53,652"   size="255,46" zPosition="1"
                    font="Regular;18" valign="center" transparent="1"/>

            <ePixmap position="340,658" size="35,25" pixmap="buttons/green.png"  alphaTest="blend"/>
            <widget name="key_green"  position="383,652"  size="255,46" zPosition="1"
                    font="Regular;18" valign="center" transparent="1"/>

            <ePixmap position="670,658" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <widget name="key_yellow" position="713,652"  size="255,46" zPosition="1"
                    font="Regular;18" valign="center" transparent="1"/>

            <ePixmap position="1000,658" size="35,25" pixmap="buttons/blue.png"  alphaTest="blend"/>
            <widget name="key_blue"   position="1043,652" size="230,46" zPosition="1"
                    font="Regular;18" valign="center" transparent="1"/>
        </screen>"""

    def __init__(self, session, service=None):
        global _iptv_open_requested
        _was_user_requested  = _iptv_open_requested
        _iptv_open_requested = False
        # Persist so onCreate() — called later by Enigma2's lifecycle without
        # arguments — knows this was a genuine user launch and must try all
        # provider paths including custom XMLTV/M3U providers.
        self._was_user_requested = _was_user_requested

        if not _was_user_requested:
            try:
                Screen.__init__(self, session)
            except Exception:
                pass
            self.onFirstExecBegin.append(self.close)
            return

        if DEBUG:
            iptvLogWrite("\nCustomIPTVArchiveMakerPro v2.04 :: Image: %s" % STATIC_INFO_DIC['imagever'])

        if paramExist(EPGSelection.__init__, 'EPGtype'):
            EPGSelection.__init__(self, session, service, EPGtype='single')
        else:
            EPGSelection.__init__(self, session, service)

        # ---- Force our custom skin so EPGSelection can never overwrite it ----
        # Setting self.skin (instance attr) wins over every class/skinName lookup.
        self.skin = iptvArchiveSelection.skin

        # ---- Strip the INFO/EPG actions from every action map EPGSelection
        #      registered.  OpenPLi's key-hint system reads these maps and
        #      auto-draws a coloured INFO button; removing the entries is the
        #      only reliable way to suppress that button. ----------------------
        for _widget in list(self.values()):
            try:
                _acts = getattr(_widget, 'actions', None)
                if isinstance(_acts, dict):
                    for _key in ('info', 'epg', 'Info', 'EPG', 'showEventInfo'):
                        _acts.pop(_key, None)
            except Exception:
                pass

        self.service        = service
        self.currentService = ServiceReference(service)
        self.oldService     = self.session.nav.getCurrentlyPlayingServiceReference()
        self.noTMBD         = T("The TMBD plugin is not installed!\nPlease install it.")
        self._custom_fetching        = False
        self._build_cancelled        = False
        self._all_events             = []
        self._current_custom_prov_name = ''
        self.skinName = ["iptvArchiveProEPGSelection", "iptvArchiveEPGSelection", "EPGSelection"]

        self["key_red"].setText(T('TMBD Search'))
        self["key_green"].setText(T('Help'))
        self["key_yellow"].setText(T('Add IPTV Workflow'))
        self["key_blue"].setText(T('Channels List'))
        # Blank out key_info / key_epg widgets (belt-and-braces alongside skin)
        for _k in ('key_info', 'key_epg'):
            try:
                self[_k].setText("")
                self[_k].hide()
            except Exception:
                pass
        self.onLayoutFinish.append(self._hideInfoKey)
        try:
            self["Service"].newService(self.service)
        except Exception:
            pass

        self["setupActions"] = ActionMap(
            ["ColorActions", "EPGSelectActions", "SetupActions"],
            {
                "cancel": self.cancel,
                "red":    self.searchTMDB,
                "green":  self.openHelp,
                "yellow": self.openAddWorkflow,
                "blue":   self.blueButtonPressedNoPLi,
            }, -2)
        self["menuActions"] = ActionMap(
            ["InfobarMenuActions"],
            {"mainMenu": self.openPluginSettings}, -2)

        self.onClose.append(self.__onClose)

        global iptvHotKey
        try:
            cfg_str = config.pickle() if hasattr(config, 'pickle') else ''
            for l in cfg_str.split('\n'):
                if ('Plugins/Extensions/CustomIPTVArchiveMakerPro' in l or
                        'Plugins/Extensions/IPTVarchive' in l):
                    iptvHotKey = l.split('=')[0].split('.')[-1]
                    break
        except Exception:
            iptvHotKey = ''

        if DEBUG: iptvLogWrite('iptvHotKey: %s' % iptvHotKey)

        global _auto_build_pending, _auto_build_listener
        if _auto_build_pending:
            _auto_build_listener = self
            self.onFirstExecBegin.append(self._showAutoBuildStatus)

    # ---- auto-build progress display ----

    def _showAutoBuildStatus(self):
        global _auto_build_pending, _auto_build_progress
        if not _auto_build_pending:
            return
        try:
            self["key_green"].setText(T('Help'))
        except Exception:
            pass
        done, total, prov = _auto_build_progress
        if total:
            self._updateBuildProgress(done, total, prov)
        else:
            self.list1item(
                T("Auto-build in progress..."),
                T("Scheduled EPG cache build is running in the background.\n"
                  "Progress will appear here shortly.\n"
                  "All plugin keys remain active."))

    # ---- close / restore ----

    def __onClose(self):
        global _auto_build_listener
        if _auto_build_listener is self:
            _auto_build_listener = None
        # If Streamlink playback was started, the new service IS the intended one —
        # do not restore oldService or it will immediately kill the stream.
        if getattr(self, '_streamlink_exit', False):
            try:
                InfoBar.instance.doShow()
            except Exception:
                pass
            return
        try:
            cs             = self.session.nav.getCurrentlyPlayingServiceReference()
            service_changed = (cs and self.oldService and str(cs) != str(self.oldService))
            if service_changed and self.oldService:
                if hasattr(self.oldService, 'valid') and self.oldService.valid():
                    self.session.nav.playService(self.oldService)
                elif not hasattr(self.oldService, 'valid'):
                    self.session.nav.playService(self.oldService)
        except Exception:
            pass
        try:
            InfoBar.instance.doShow()
        except Exception:
            pass

    def _hideInfoKey(self):
        """Hide the INFO button that EPGSelection base class shows — user cannot remove it any other way."""
        for key in ('key_info', 'key_epg', 'key_menu'):
            try:
                self[key].setText("")
                self[key].hide()
            except Exception:
                pass

    def cancel(self):
        cs = self.session.nav.getCurrentlyPlayingServiceReference()
        if cs and self.oldService and str(cs) != str(self.oldService):
            self.session.openWithCallback(self._exitConfirm, MessageBox,
                T("Stop archive playback and exit CustomIPTVArchiveMakerPro?"), timeout=15, default=False)
        else:
            self.close(True)

    def _exitConfirm(self, confirmed):
        if confirmed:
            self.close(True)
        else:
            self.show()

    # ---- navigation ----

    def OK(self):
        self.eventSelected()

    def searchTMDB(self):
        try:
            from Plugins.Extensions.TMBD.plugin import TMBD
            cs = self["list"].l.getCurrentSelection()
            if not (cs and cs[3]):
                return
            yr = [_y for _y in re.findall(r'\d{4}', cs[0])
                  if '1930' <= _y <= '%s' % time.gmtime().tm_year]
            self.session.open(TMBD, cs[4], yr[-1] if yr else None)
        except ImportError:
            self.session.open(MessageBox, self.noTMBD, type=MessageBox.TYPE_INFO, timeout=10)

    def eventSelected(self):
        cs = self["list"].l.getCurrentSelection()
        if not (cs and cs[3]):
            return
        # Determine provider type and id — used for both the archive time-offset
        # correction and player selection below.
        # _current_custom_prov_name is set by _customProviderDone whenever the
        # async EPG fetch for a custom provider completes; it is non-empty only
        # when the EPG screen is showing data from a custom provider.
        prov_name_custom = getattr(self, '_current_custom_prov_name', '').strip()
        if prov_name_custom:
            prov_type = 'custom'
            prov_id   = prov_name_custom
        elif self.provider and self.provider not in ('undefined', None, ''):
            prov_type = 'integrated'
            prov_id   = self.provider
        else:
            prov_type = 'integrated'
            prov_id   = self.provider or 'undefined'

        # Apply per-provider archive start time offset BEFORE URL construction.
        # Negative offset (e.g. -420 s) shifts start earlier — corrects for a
        # receiver clock that runs fast relative to the IPTV server.
        _stream_url = ''
        try:
            _stream_url = eServiceReference(str(self.currentService)).getPath()
        except Exception:
            pass
        offset = self._getArchiveOffset(prov_type, prov_id, stream_url=_stream_url)
        # For Xtream events, cs[2] is the UTC-epoch display time (_ts_btime).
        # myStartTime must use the original string-derived btime (_str_btime) so
        # that the archive URL fallback and utc= parameters stay identical to v6.3.
        _xt_str_btime = getattr(self, '_xtream_str_btimes', {}).get(cs[2], cs[2])
        _prov.myStartTime       = _xt_str_btime + offset
        _prov.myXtreamEpgOffset = cs[2] - _xt_str_btime
        _prov.myDuration  = cs[3]
        _prov.myTimeStamp = currTime()
        _prov.myStartStr  = getattr(self, '_xtream_start_strs', {}).get(cs[2], '')
        newRef = eServiceReference(str(self.currentService))
        newRef.setPath(getArchiveUrl(
            newRef.getPath(),
            self.currentService.getServiceName().replace(
                SIGN if PY3 else SIGN, '')))
        self._pendingRef   = newRef
        self._pendingEvent = epgEvent(*cs[:5])

        settings = loadPluginSettings()
        # For custom providers pass the playlist provider dict directly so
        # player_override / player_*_on from the playlist config are used
        _prov_data = None
        if prov_type == 'custom' and prov_id:
            try:
                for _pp in loadPlaylistProviderConfig():
                    if _pp.get('name', '').strip() == prov_id and _pp.get('create_archives'):
                        _prov_data = _pp
                        break
            except Exception:
                pass
        enabled = getEnabledPlayers(settings, prov_type, prov_id, prov_data=_prov_data)

        if not enabled:
            self.session.open(
                MessageBox,
                T("No player is selected for this provider.\n"
                  "Open Settings \u2192 Player Selection (Also By Provider)\n"
                  "and enable a player for '%s'.") % (prov_id or prov_type),
                type=MessageBox.TYPE_INFO, timeout=10)
            return

        if len(enabled) == 1:
            self._playByKey(enabled[0], newRef, settings)
        else:
            _labels = {
                'int': T("Plugin Integrated Player"),
                'sl':  T("StreamLinkProxy Player"),
                'rec': T("Receiver (Enigma2) Player"),
            }
            if ChoiceBox is not None:
                self.session.openWithCallback(
                    self._onPlayerKeyChoice,
                    ChoiceBox,
                    title=T("Select Player"),
                    list=[(_labels.get(k, k), k) for k in enabled])
            else:
                self._playByKey(enabled[0], newRef, settings)

    def _onPlayerKeyChoice(self, choice=None):
        if choice is None:
            return
        settings = loadPluginSettings()
        self._playByKey(choice[1], self._pendingRef, settings)

    def _playByKey(self, key, ref, settings):
        if key == 'int':
            self._playNormal(ref)
        elif key == 'sl':
            self._playStreamlink(ref)
        elif key == 'rec':
            self._playReceiver(ref)

    def _playReceiver(self, ref):
        """Play using the Enigma2 native player — no plugin info bar."""
        try:
            self.session.nav.playService(ref)
        except Exception as e:
            if DEBUG:
                iptvLogWrite('_playReceiver playService error: %s' % str(e))
        self.hide()

    def _playNormal(self, ref):
        try:
            self.session.nav.playService(ref)
        except Exception as e:
            if DEBUG: iptvLogWrite('_playNormal playService error: %s' % str(e))
        self.playedEvent = self._pendingEvent
        self.showInfoBar()

    def _playStreamlink(self, ref):
        settings    = loadPluginSettings()
        port        = int(settings.get('streamlink_port', 8088))

        # 1. Verify StreamlinkProxy is actually listening before we try to play.
        try:
            _s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            _s.settimeout(2)
            _conn = _s.connect_ex(('127.0.0.1', port))
            _s.close()
        except Exception:
            _conn = -1
        if _conn != 0:
            iptvLogWrite('StreamlinkProxy not reachable on port %d' % port)
            self.session.open(
                MessageBox,
                T("StreamlinkProxy is not running on port %d.\n"
                  "Start StreamlinkProxy first, then try again.") % port,
                type=MessageBox.TYPE_ERROR, timeout=15)
            return

        # 2. Build the proxy URL.
        #    Correct StreamlinkProxy format: http://HOST:PORT/<STREAM_URL>
        #    The archive URL is placed directly as the path — NOT as a ?url= param.
        #    Quality: if the archive URL already has "?", append &default-stream=best;
        #    otherwise use ?default-stream=best.  If streamlink can't find that quality
        #    it automatically falls back to the best available.
        archive_url = ref.getPath()

        # Streamlink cannot handle raw MPEG-TS streams (.ts) — it requires a website
        # URL or an HLS playlist (.m3u8). For direct .ts archive URLs (e.g. Xtream
        # timeshift) fall back to the integrated player automatically.
        _url_path = archive_url.split('?')[0].split('#')[0]
        if _url_path.endswith('.ts'):
            iptvLogWrite('StreamlinkProxy: direct .ts stream — falling back to integrated player')
            self.session.open(
                MessageBox,
                T("StreamlinkProxy cannot handle direct TS streams.\n"
                  "Playing with the integrated player instead."),
                type=MessageBox.TYPE_INFO, timeout=5)
            self._playNormal(ref)
            return

        sep = '&' if '?' in archive_url else '?'
        proxied_url = 'http://127.0.0.1:%d/%s%sdefault-stream=best' % (
            port, archive_url, sep)

        # 3. Copy the channel's service reference (preserves SID/TSID so Enigma2
        #    can look the channel up by name in the service list), then point
        #    the path at the proxy URL.  Using eServiceReference(4097,0,url)
        #    with zeroed fields causes the skin to show the URL as the name.
        sl_ref = eServiceReference(str(ref))
        sl_ref.setPath(proxied_url)
        iptvLogWrite('StreamlinkProxy URL: %s' % proxied_url)

        # 4. Play and open the info bar so seek / FF / RW controls are available.
        try:
            self.session.nav.playService(sl_ref)
            self.playedEvent = self._pendingEvent
            self._showStreamlinkInfoBar(port)
        except Exception as e:
            iptvLogWrite('_playStreamlink playService error: %s' % str(e))
            self.session.open(
                MessageBox,
                T("StreamlinkProxy playback failed.\nError: %s") % str(e),
                type=MessageBox.TYPE_ERROR, timeout=15)

    def showInfoBar(self):
        if not hasattr(self, 'playedEvent') or self.playedEvent is None:
            return
        self.hide()
        all_evs = self._all_events
        if not all_evs:
            try:
                raw     = self["list"].list or []
                all_evs = sorted([e for e in raw if e and len(e) >= 4 and e[3]],
                                  key=lambda e: e[2])
            except Exception:
                all_evs = []
        self.session.openWithCallback(self._onInfoBarClosed, iptvArchiveInfoBar,
                                      self.playedEvent, str(self.currentService), all_evs)

    def _onInfoBarClosed(self, *args):
        try:
            if self.oldService:
                self.session.nav.playService(self.oldService)
        except Exception:
            pass
        self.show()

    # ---- Streamlink info-bar (same seek controls, proxy-aware seek) ----

    def _showStreamlinkInfoBar(self, port):
        self.hide()
        all_evs = self._all_events
        if not all_evs:
            try:
                raw     = self["list"].list or []
                all_evs = sorted([e for e in raw if e and len(e) >= 4 and e[3]],
                                  key=lambda e: e[2])
            except Exception:
                all_evs = []
        self.session.openWithCallback(
            self._onStreamlinkInfoBarClosed,
            iptvArchiveInfoBar,
            self.playedEvent, str(self.currentService), all_evs,
            streamlink_port=port)

    def _onStreamlinkInfoBarClosed(self, *args):
        # Restore the live service and show the archive screen again —
        # identical behaviour to _onInfoBarClosed so EPG / hotkey presses
        # during Streamlink playback return to the archive list, not the menu.
        try:
            if self.oldService:
                self.session.nav.playService(self.oldService)
        except Exception:
            pass
        self.show()

    def onSelectionChanged(self):
        cs = self["list"].l.getCurrentSelection()
        if cs: self['Event'].newEvent(epgEvent(*cs[:5]))

    def infoKeyPressed(self):
        cs = self["list"].l.getCurrentSelection()
        if cs:
            self.session.open(IPTVArchiveEventViewEPGSelect, epgEvent(*cs[:5]), self.currentService)

    def setService(self, service):
        self.currentService            = service
        self.service                   = eServiceReference(str(service))
        self._custom_fetching          = False
        self._current_custom_prov_name = ''   # clear stale custom-provider name
        self.onCreate(user_initiated=True)

    def channelSelectionCallback(self, *args):
        if args:
            try:
                serviceref, bouquetref = args[:2]
                self.parent            = self
                self.parent.epg_bouquet = bouquetref
            except Exception:
                serviceref = args[0]
            finally:
                self.setService(ServiceReference(serviceref))

    def blueButtonPressedNoPLi(self):
        if paramExist(SimpleChannelSelection.__init__, 'currentBouquet'):
            self.session.openWithCallback(self.channelSelectionCallback,
                                          SimpleChannelSelection, T("Channel Selection"),
                                          currentBouquet=True)
        else:
            self.session.openWithCallback(self.channelSelectionCallback,
                                          SimpleChannelSelection, T("Channel Selection"))

    def openPluginSettings(self):
        self.session.open(IPTVArchivePluginSettings)

    def openHelp(self):
        self.session.open(IPTVHelpMenuScreen)

    # ---- build ----

    def _toggleBuild(self):
        if self._custom_fetching:
            self._build_cancelled = True
            self["key_green"].setText(T('Help'))
            self.list1item(T("Build stopped"),
                           T("Cancelling EPG cache build — already cached channels are saved.\n"
                             "Press Start Build again to resume from where it left off."))
            return
        service = self.currentService
        url     = service.getPath() if service else None
        if not url:
            self.list1item(T("No channel"), T("No IPTV channel selected."))
            return
        self._build_cancelled  = False
        self._custom_fetching  = False
        if self._tryCustomProviders(service, url, build_all=True):
            self["key_green"].setText(T('Help'))
        else:
            self.list1item(T("No providers configured"),
                           T("No enabled providers found.\n"
                             "Use the Yellow button to configure providers."))

    def toggleFakeEvents(self):
        if self["key_green"].getText() == T('Fake Events'):
            self["key_red"].setText("")
            self["key_green"].setText('EPG')
            self["key_yellow"].setText('')
            self.fakeArchiveListLoaded()
        else:
            self["key_red"].setText(T('TMBD Search'))
            self["key_green"].setText(T('Fake Events'))
            self["key_yellow"].setText(T('Gluing titles'))
            self.onCreate()

    def toggleGlueTitles(self):
        if self["key_yellow"].getText() == T('Gluing titles'):
            self["key_green"].setText('')
            self["key_yellow"].setText('EPG')
            self.GlueTitle()
        else:
            self["key_yellow"].setText(T('Gluing titles'))
            self["key_green"].setText(T('Fake Events'))
            self.onCreate()

    def addEvent(self, event):
        if not self.provider:
            return
        if self.provider in ('shura', '1ott'):
            import xml.etree.cElementTree as ET
            return (xml_unescape(event.findtext('text')),
                    int(event.attrib.get('id')),
                    int(event.findtext('start_time')),
                    int(event.findtext('duration')),
                    xml_unescape(event.findtext('name')))
        elif self.provider == 'itv':
            btime    = int(event.get('startTime'))
            duration = int(event.get('stopTime')) - btime
            if btime < currTime():
                return (xml_unescape(event.get('desc')), random.randint(0, 1000),
                        btime, duration, xml_unescape(event.get('title')))
        else:
            btime    = int(event.get('time'))
            duration = int(event.get('time_to')) - btime
            if currTime() - self.days * 86400 < btime < currTime():
                return (xml_unescape(event.get('descr')), random.randint(0, 1000),
                        btime, duration, xml_unescape(event.get('name')))

    def GlueTitle(self):
        self["list"].recalcEntrySize()
        if self.provider is None:
            self.list1item(T("No access to archive"),
                           T("Not IPTV Channel. No access to archive")
                           if not self.currentService.getPath()
                           else T("Unknown IPTV provider. No access to archive"))
            return
        li      = self["list"].list
        l       = self["list"]
        l.list  = []
        pattern = re.compile(r'(х|Х|м|М|x|X|т|Т|T)/(Ф|ф|С|C|с|c)|«|»|"', re.DOTALL)
        conv    = lambda text: pattern.sub('', text).strip()
        for x in sorted(li, key=lambda x: [int(c) if c.isdigit() else c
                                            for c in re.split(r'(\d+)', conv(x[4]))]):
            li      = list(x)
            li[4]   = conv(li[4])
            x       = tuple(li)
            if not any(x[4] in li for li in l.list):
                l.list.append(x)
        l.l.setList(l.list)
        l.selectionChanged()

    def fakeArchiveListLoaded(self):
        self["list"].recalcEntrySize()
        if self.provider is None:
            self.list1item(T("No access to archive"),
                           T("Not IPTV Channel. No access to archive")
                           if not self.currentService.getPath()
                           else T("Unknown IPTV provider. No access to archive"))
            return
        l     = self["list"]
        l.list = []
        li    = self["list"].list
        start = (currTime() // 3600) * 3600
        while start > currTime() - (self.days * 24 * 3600):
            li.append((T('Fake EPG'), random.randint(0, 1000), int(start), 3600,
                       time.strftime("%A, %d.%m, %H:%M", time.localtime(start))))
            start -= 3600
        l.l.setList(l.list)
        l.selectionChanged()

    def archiveListLoaded(self, raw):
        try:
            import json, xml.etree.cElementTree as ET, zlib
            if PY3: raw = raw.decode('utf-8')
            events = {
                'shura': lambda: ET.fromstring(raw).findall('event'),
                '1ott':  lambda: ET.fromstring(raw).findall('event'),
                'itv':   lambda: json.loads(raw).get('res', '' or 'None'),
            }.get(self.provider,
                  lambda: (json.loads(raw).get('epg_data', '' or 'None')
                           if 'epg_data' in raw
                           else json.loads(raw or 'null')))()

            if events:
                l       = self["list"]
                l.list  = sorted([_f for _f in map(self.addEvent, events) if _f],
                                  key=lambda x: x[2], reverse=True)
                if l.list:
                    try:
                        l.recalcEntrySize()
                    except Exception:
                        pass
                    l.l.setList(l.list)
                    l.selectionChanged()
                else:
                    self.list1item(T("No archive"),
                                   T("There are no archive entries for this channel "
                                     "satisfying the conditions of a given search depth"))
            else:
                self.list1item(T("No archive"),
                               T("There are no archive entries for this channel"))
        except Exception:
            self.list1item(T("No archive"), T("EPG data parsing error"))
            if DEBUG: self.saveTraceback()

    def _findEPGImportRefs(self, service, ch_id=None):
        """Scan EPGImporter service-mapping files; return matching eServiceReferences."""
        import xml.etree.cElementTree as ET
        results   = []
        seen_refs = set()
        try:
            chName_lower = service.getServiceName().replace(SIGN, '').strip().lower()
            ch_id_str    = str(ch_id) if ch_id is not None else None
            search_roots = [
                '/etc/epgimport', '/etc/ipgimport',
                '/usr/share/epgimport',
                os.path.expanduser('~/.config/epgimport'),
            ]
            extensions = ('.services', '.xml')
            for root_dir in search_roots:
                if not os.path.isdir(root_dir):
                    continue
                for dirpath, _dirs, filenames in os.walk(root_dir):
                    for fname in filenames:
                        if not fname.lower().endswith(extensions):
                            continue
                        fpath = os.path.join(dirpath, fname)
                        try:
                            tree     = ET.parse(fpath)
                            xml_root = tree.getroot()
                            for ch in xml_root.iter('channel'):
                                ref_text = (ch.text or '').strip()
                                if not ref_text or ref_text in seen_refs:
                                    continue
                                matched = False
                                if ch_id_str:
                                    matched = (ch.get('id') == ch_id_str)
                                else:
                                    matched = ((ch.get('name') or '').strip().lower() == chName_lower)
                                if matched:
                                    seen_refs.add(ref_text)
                                    results.append(eServiceReference(ref_text))
                                    if DEBUG:
                                        iptvLogWrite('EPGImport match in %s: id=%s name=%s -> %s' % (
                                            fpath, ch.get('id', '?'), ch.get('name', '?'), ref_text))
                            if not ch_id_str:
                                for svc in xml_root.iter('service'):
                                    name_el = svc.find('name')
                                    ref_el  = svc.find('serviceref')
                                    if name_el is None or ref_el is None:
                                        continue
                                    name     = (name_el.text or '').strip().lower()
                                    ref_text = (ref_el.text  or '').strip()
                                    if name == chName_lower and ref_text and ref_text not in seen_refs:
                                        seen_refs.add(ref_text)
                                        results.append(eServiceReference(ref_text))
                        except Exception:
                            continue
        except Exception:
            pass
        return results

    def _loadFromEPGCache(self, service, ch_id=None):
        """Query Enigma2's live EPG cache. Returns True if past events were loaded."""
        try:
            from enigma import eEPGCache
            epgcache = eEPGCache.getInstance()
            now      = int(time.time())
            week_ago = now - max(getattr(self, 'days', 7), 1) * 86400

            refs_to_try = [eServiceReference(str(service))]
            ref_str     = str(service)
            parts       = ref_str.split(':')
            if len(parts) > 10:
                refs_to_try.append(eServiceReference(':'.join(parts[:10]) + ':'))
            refs_to_try.extend(self._findEPGImportRefs(service, ch_id=ch_id))

            seen = set()
            for ref in refs_to_try:
                ref_key = str(ref)
                if ref_key in seen:
                    continue
                seen.add(ref_key)
                epgcache.startTimeQuery(ref, week_ago, 1)
                events = []
                while True:
                    ev = epgcache.getNextTimeEntry()
                    if ev is None:
                        break
                    btime = ev.getBeginTime()
                    if btime >= now:
                        break
                    duration = ev.getDuration()
                    if duration <= 0:
                        continue
                    title = ev.getEventName() or ''
                    descr = ev.getShortDescription() or ''
                    events.append((xml_unescape(descr), ev.getEventId(), btime,
                                   duration, xml_unescape(title)))
                if events:
                    l      = self["list"]
                    l.list = sorted(events, key=lambda x: x[2], reverse=True)
                    l.l.setList(l.list)
                    l.selectionChanged()
                    return True
        except Exception:
            pass
        return False

    def _loadXtreamEPG(self, parsed_url, splittedpath):
        """Fetch past EPG for an Xtream channel.

        Strategy:
          1. Resolve epg_channel_id via get_live_streams.
          2. Download /xmltv.php — timestamps carry an explicit UTC offset
             so times are correct for every receiver timezone and every
             server timezone, regardless of how the panel stores them.
          3. Fall back to get_simple_data_table (legacy heuristic) if the
             XMLTV feed is empty or the channel cannot be matched.
        """
        from urllib.request import urlopen, Request as _Request
        import xml.etree.ElementTree as _ET
        try:
            server    = '%s://%s' % (parsed_url.scheme, parsed_url.netloc)
            user      = splittedpath[2]
            pw        = splittedpath[3]
            stream_id = splittedpath[4].split('.')[0]

            # ---- Step 1: resolve epg_channel_id via get_live_streams ----
            epg_channel_id = None
            try:
                streams_url = ('%s/player_api.php?username=%s&password=%s'
                               '&action=get_live_streams' % (server, user, pw))
                resp = urlopen(_Request(streams_url, headers=HEADERS), timeout=15)
                for s in json.loads(resp.read()):
                    if str(s.get('stream_id', '')) == str(stream_id):
                        epg_channel_id = str(s.get('epg_channel_id') or '').strip()
                        break
            except Exception:
                pass

            if not epg_channel_id:
                return self._loadXtreamEPGSimple(parsed_url, splittedpath)

            # ---- Step 2: fetch and parse XMLTV --------------------------
            xmltv_url = ('%s/xmltv.php?username=%s&password=%s'
                         % (server, user, pw))
            resp  = urlopen(_Request(xmltv_url, headers=HEADERS), timeout=30)
            now   = int(time.time())
            events = []
            self._xtream_start_strs = {}
            self._xtream_str_btimes = {}
            for _xev, elem in _ET.iterparse(resp, events=['end']):
                if elem.tag == 'programme' and elem.get('channel') == epg_channel_id:
                    btime, url_start = _parse_xmltv_time(elem.get('start', ''))
                    etime, _         = _parse_xmltv_time(elem.get('stop',  ''))
                    duration = etime - btime
                    if btime and duration > 0 and btime < now:
                        title_el = elem.find('title')
                        desc_el  = elem.find('desc')
                        title = (title_el.text or '').strip() if title_el is not None else ''
                        descr = (desc_el.text  or '').strip() if desc_el  is not None else ''
                        events.append((xml_unescape(descr), 0, btime,
                                       duration, xml_unescape(title)))
                        self._xtream_start_strs[btime] = url_start
                        # btime is a true UTC epoch so _str_btime == btime → offset = 0
                        self._xtream_str_btimes[btime] = btime
                elem.clear()

            if not events:
                return self._loadXtreamEPGSimple(parsed_url, splittedpath)

            l      = self["list"]
            l.list = sorted(events, key=lambda x: x[2], reverse=True)
            l.l.setList(l.list)
            l.selectionChanged()
            self._all_events = sorted(events, key=lambda x: x[2])
            return True

        except Exception as e:
            if DEBUG:
                iptvLogWrite('[Xtream XMLTV] Error: %s' % str(e))
            return self._loadXtreamEPGSimple(parsed_url, splittedpath)

    def _loadXtreamEPGSimple(self, parsed_url, splittedpath):
        """Legacy fallback: fetch EPG via get_simple_data_table API.
        Less accurate than the XMLTV path because start_timestamp is not
        standardised across Xtream panel implementations."""
        from urllib.request import urlopen, Request as _Request
        try:
            server    = '%s://%s' % (parsed_url.scheme, parsed_url.netloc)
            user      = splittedpath[2]
            pw        = splittedpath[3]
            stream_id = splittedpath[4].split('.')[0]
            api_url   = ('%s/player_api.php?username=%s&password=%s'
                         '&action=get_simple_data_table&stream_id=%s'
                         % (server, user, pw, stream_id))
            resp     = urlopen(_Request(api_url, headers=HEADERS), timeout=10)
            raw      = resp.read()
            data     = json.loads(raw)
            listings = data.get('epg_listings', [])
            if not listings:
                return False
            now    = int(time.time())
            events = []
            self._xtream_start_strs  = {}
            self._xtream_str_btimes  = {}
            import datetime as _dtmod
            for item in listings:
                # Archive URL always uses the server's own local-time string so
                # the server receives back exactly what it sent (_url_start).
                # Display time (btime / etime) uses start_timestamp / stop_timestamp
                # which are UTC epochs — timezone-independent, so every receiver
                # shows the correct local time regardless of the server's timezone.
                # Sanity check: if start_timestamp differs from the string-derived
                # time by more than 6 hours, the panel is storing it wrong — fall
                # back to the string method for that item.
                _start_str = (item.get('start') or '').strip()
                _end_str   = (item.get('end') or item.get('stop') or '').strip()
                _url_start = ''
                _str_btime = 0
                try:
                    _sdt       = _dtmod.datetime.strptime(_start_str[:19], '%Y-%m-%d %H:%M:%S')
                    _str_btime = int(_sdt.timestamp())
                    _url_start = _sdt.strftime('%Y-%m-%d:%H-%M')
                except Exception:
                    pass
                _ts_btime = int(item.get('start_timestamp') or 0)
                if _ts_btime and _url_start and abs(_ts_btime - _str_btime) <= 21600:
                    btime = _ts_btime
                elif _str_btime:
                    btime = _str_btime
                else:
                    btime = _ts_btime
                _str_etime = 0
                try:
                    _edt       = _dtmod.datetime.strptime(_end_str[:19], '%Y-%m-%d %H:%M:%S')
                    _str_etime = int(_edt.timestamp())
                except Exception:
                    pass
                _ts_etime = int(item.get('stop_timestamp') or 0)
                if _ts_etime and _str_etime and abs(_ts_etime - _str_etime) <= 21600:
                    etime = _ts_etime
                elif _str_etime:
                    etime = _str_etime
                else:
                    etime = _ts_etime
                duration = etime - btime
                if duration <= 0 or btime >= now:
                    continue
                try:
                    title = base64.b64decode(item.get('title', '')).decode('utf-8', 'replace').strip()
                except Exception:
                    title = (item.get('title') or '').strip()
                try:
                    descr = base64.b64decode(item.get('description', '')).decode('utf-8', 'replace').strip()
                except Exception:
                    descr = (item.get('description') or '').strip()
                events.append((xml_unescape(descr), 0, btime, duration, xml_unescape(title)))
                self._xtream_start_strs[btime] = _url_start
                # Keep the string-derived btime (server local parsed as receiver local)
                # so that myStartTime in eventSelected still uses the original reference
                # for archive URL fallback and utc= parameters — same as v6.3 behaviour.
                self._xtream_str_btimes[btime] = _str_btime if _str_btime else btime
            if not events:
                return False
            l      = self["list"]
            l.list = sorted(events, key=lambda x: x[2], reverse=True)
            l.l.setList(l.list)
            l.selectionChanged()
            # Keep _all_events in sync so showInfoBar always uses THIS channel's
            # events, not stale data from a previously viewed non-Xtream channel.
            self._all_events = sorted(events, key=lambda x: x[2])
            return True
        except Exception as e:
            if DEBUG:
                iptvLogWrite('[Xtream EPG] Error: %s' % str(e))
            return False

    def onCreate(self, firstrun=False, user_initiated=False):
        # If Enigma2 called us without user_initiated (initial lifecycle call)
        # but the screen was opened by the user, treat it as user-initiated and
        # clear the flag so repeat calls (fake events, glue titles) are unaffected.
        if not user_initiated and getattr(self, '_was_user_requested', False):
            user_initiated = True
            self._was_user_requested = False
        # Always clear the custom provider name at the start of every load so
        # that a stale value from a previous channel cannot bleed into the
        # provider-type detection in eventSelected.
        self._current_custom_prov_name = ''
        _prov.myCustomIntProvider = None
        import zlib
        from urllib.request import urlopen, Request as _Request
        try:
            self["list"].recalcEntrySize()
            try:
                if STATIC_INFO_DIC['distro'] == 'openbh' and not HardwareInfo().is_nextgen():
                    self.createTimer.stop()
            except Exception:
                pass
            service = self.currentService
            chName  = service.getServiceName().replace(SIGN, '')
            url     = service.getPath()
            try:
                self["Service"].newService(service.ref)
            except Exception:
                pass
            self.setTitle(T("Custom IPTV Archive Maker Pro (Generated By AI)") + ' - ' + chName)

            if not url:
                try:
                    _live = self.session.nav.getCurrentlyPlayingServiceReference()
                    if _live:
                        _sr  = ServiceReference(_live)
                        _u   = _sr.getPath()
                        if _u:
                            self.currentService = _sr
                            service = _sr
                            url     = _u
                            chName  = _sr.getServiceName().replace(SIGN, '')
                            try:
                                self["Service"].newService(_sr.ref)
                            except Exception:
                                pass
                            self.setTitle(T("Custom IPTV Archive Maker Pro (Generated By AI)") + ' - ' + chName)
                except Exception:
                    pass

            if not url:
                self.list1item(T("No access to archive"),
                               T("Not IPTV Channel. No access to archive"))
                self.provider, self.days = None, 0
                return

            # "Stop All Integrated Providers" gate
            _ps = loadPluginSettings()

            # Pre-detect Xtream BEFORE the gate — Xtream is URL-detected, not a
            # traditional integrated provider, so it must always bypass this gate.
            _pre_split = urlparse(url).path.split('/')
            _is_xtream = (len(_pre_split) >= 5
                          and _pre_split[1] == 'live'
                          and '.' in _pre_split[4])

            if _ps.get('stop_integrated_providers', False) and not _is_xtream:
                if user_initiated and self._tryCustomProviders(service, url):
                    return
                # Also check Type A: custom integrated providers matched by URL fragment.
                # These must still work even when all built-in providers are disabled.
                _stopped_set = set(_ps.get('stopped_provider_tags', []))
                _has_cip = any(
                    _cip.get('enabled', True)
                    and (_cip.get('url_fragment') or '').strip()
                    and (_cip.get('url_fragment') or '').strip() in url
                    and ((_cip.get('tag') or '').strip()
                         or _cip.get('name', '').lower().replace(' ', '-')
                         ) not in _stopped_set
                    for _cip in _ps.get('integrated_providers_custom', [])
                )
                if not _has_cip:
                    self.list1item(
                        T("Integrated providers disabled"),
                        T("'ALL On/Off' is set to OFF in Settings.\n"
                          "Only custom added providers are active for this channel.\n"
                          "Press Yellow to configure a provider, or Green to build the EPG cache."))
                    self.provider, self.days = None, 0
                    return
                # A matching custom integrated provider exists — fall through to
                # the normal detection block below (lines 1270-1289) which will
                # pick it up and set self.provider / _prov.myCustomIntProvider.
            _stopped_tags = _ps.get('stopped_provider_tags', [])

            parsed_url   = urlparse(url)
            params       = dict(parse_qsl(parsed_url.fragment))
            splittedpath = parsed_url.path.split('/')

            # Resolve provider from URL
            self.provider, self.days = IPTV_PROVIDERS[
                next(iter([x for x in list(IPTV_PROVIDERS.keys()) if x in url]), 'undefined')]

            # If no built-in matched, scan user-added custom integrated providers
            if self.provider is None:
                _ps2     = loadPluginSettings()
                _stopped = set(_ps2.get('stopped_provider_tags', []))
                for _cip in _ps2.get('integrated_providers_custom', []):
                    if not _cip.get('enabled', True):
                        continue
                    _cip_tag = (_cip.get('tag') or '').strip() or \
                               _cip.get('name', '').lower().replace(' ', '-')
                    if _cip_tag in _stopped:
                        continue
                    _frag = (_cip.get('url_fragment') or '').strip()
                    if _frag and _frag in url:
                        self.provider           = _cip_tag
                        self.days               = int(_cip.get('days', 7) or 7)
                        _prov.myCustomIntProvider = _cip
                        break

            # Xtream Codes — /live/user/pass/STREAM_ID.ext — detect when no other provider matched
            if self.provider is None and (len(splittedpath) >= 5
                    and splittedpath[1] == 'live'
                    and '.' in splittedpath[4]):
                self.provider = 'xtream'
                self.days     = 7

            if 'sapp_catchup-days' in params:
                self.days = int(params['sapp_catchup-days'])
                if self.provider is None:
                    self.provider = 'flussonic'

            # Individual provider stop check
            # Xtream is URL-detected (not a traditional integrated provider) and
            # always bypasses the stop check.  If a different provider was matched
            # but is stopped AND the URL is Xtream-compatible, fall back to Xtream
            # instead of blocking archive access entirely.
            if self.provider and self.provider != 'xtream' and self.provider in _stopped_tags:
                if _is_xtream:
                    # Stopped provider matched the URL, but this is an Xtream
                    # channel — continue with Xtream rather than blocking.
                    self.provider = 'xtream'
                    self.days     = 7
                else:
                    if user_initiated and self._tryCustomProviders(service, url):
                        return
                    self.list1item(
                        T("Provider stopped"),
                        T("'%s' is individually disabled in Settings.\n"
                          "Go to Settings > All Integrated Providers On/Off to re-enable it.\n"
                          "Press Yellow to configure a custom provider instead.") % self.provider)
                    self.provider, self.days = None, 0
                    return

            if self.provider is None:
                if user_initiated and self._tryCustomProviders(service, url):
                    return
                self.list1item(
                    T("Start Build"),
                    T("No known provider for this channel.\n"
                      "Press the green 'Start Build' button to search your configured providers,\n"
                      "or use Yellow to add a provider."))
                return

            # Try Enigma2 EPG cache first
            _ilook_ch_id = None
            if self.provider in ('ilook', 'edem'):
                # URL: /iptv/CHANNEL_ID/index.m3u8 or /iptv/CHANNEL_ID/playlist.m3u8
                #      /iptv/CHANNEL_ID.m3u8
                #      /iptv/CHANNEL_ID/tracks-v1a1/mono.m3u8
                # Strategy: find 'iptv' in path, then take the next segment
                _hls_finals = ('index', 'playlist', 'chunklist', 'master',
                               'mono', 'stereo', 'video', 'audio')
                try:
                    _iptv_idx = splittedpath.index('iptv')
                    _ch_candidate = splittedpath[_iptv_idx + 1]
                    # If the candidate itself looks like an HLS file, go deeper
                    if _ch_candidate.split('.')[0].lower() in _hls_finals:
                        _ilook_ch_id = splittedpath[_iptv_idx + 2].split('.')[0]
                    else:
                        _ilook_ch_id = _ch_candidate.split('.')[0]
                except (ValueError, IndexError):
                    # Fallback: last segment without extension
                    _ilook_ch_id = splittedpath[-1].split('.')[0] if splittedpath else ''
            if self._loadFromEPGCache(service, ch_id=_ilook_ch_id):
                return

            # Build EPG request per provider
            epgUrl = None
            if _prov.myCustomIntProvider is not None:
                _cip     = _prov.myCustomIntProvider
                _epg_pat = _cip.get('epg_pattern', 'ottp')
                _cip_tag = (_cip.get('tag') or '').strip() or \
                            _cip.get('name', '').lower().replace(' ', '-')
                if _epg_pat == 'ottp':
                    _ch_id = splittedpath[-1].split('.')[0] if splittedpath else ''
                    if 'sapp_tvgid' in params and params['sapp_tvgid']:
                        _ch_id = params['sapp_tvgid']
                    xxh32.__init__(data=_ch_id.encode('utf-8') if isinstance(_ch_id, str) else _ch_id)
                    epgUrl = _Request(
                        'http://epg.ottp.eu.org/%s/epg/%s.json' % (_cip_tag, xxh32.intdigest()),
                        headers=HEADERS)
                elif _epg_pat == 'provider_api':
                    _tmpl = (_cip.get('epg_url_template') or '').strip()
                    if _tmpl:
                        _ch_id = splittedpath[-1].split('.')[0] if splittedpath else ''
                        epgUrl = _Request(_tmpl.replace('{channel_id}', _ch_id), headers=HEADERS)
                if epgUrl is None:
                    if user_initiated and self._tryCustomProviders(service, url):
                        return
                    self.list1item(
                        T("Start Build"),
                        T("No EPG configured for this integrated provider.\n"
                          "Press green 'Start Build' to search your custom providers."))
                    return
            elif self.provider in ('shura', '1ott'):
                epgUrl = _Request(
                    parsed_url._replace(
                        path='/'.join(splittedpath[:3]) + '/epg/archive.xml').geturl(),
                    headers=HEADERS)
            elif self.provider == 'ottclub':
                epgUrl = _Request(
                    'http://spacetv.in/api/channel/%s' % splittedpath[-1].split('.')[0],
                    headers=HEADERS)
            elif self.provider == 'itv':
                data = urlencode({
                    'action': 'epg',
                    'chid':   splittedpath[-2],
                    'name':   chName,
                    'token':  query_get(parsed_url.query, 'token'),
                    'serv':   parsed_url.netloc.split(':')[0],
                }).encode('utf-8')
                epgUrl = _Request('http://api.itv.live/epg.php', data, HEADERS)
            elif self.provider == 'cbilling':
                ch_id = splittedpath[-1].split('.')[0]
                xxh32.__init__(data=ch_id.encode('utf-8') if isinstance(ch_id, str) else ch_id)
                epgUrl = _Request(
                    'http://epg.ottp.eu.org/cbilling/epg/%s.json' % xxh32.intdigest(),
                    headers=HEADERS)
            elif self.provider == 'tvteam':
                epgUrl = _Request(
                    'http://tv.team/%s.json' % (
                        splittedpath[-2] if 'static' not in splittedpath else splittedpath[-1]),
                    headers=HEADERS)
            elif self.provider in ('shara.club', 'ipstream') and 'sapp_tvgid' in params:
                data = urlencode({'type': 'epg', 'ch': params['sapp_tvgid']}).encode('utf-8')
                epgUrl = _Request(
                    '%s://%s/get/' % (parsed_url.scheme,
                                      'api.' + '.'.join(parsed_url.hostname.split('.')[1:])),
                    data, HEADERS)
            elif self.provider in ('ilook', 'edem'):
                ilook_ch_id = (_ilook_ch_id or splittedpath[-1].split('.')[0])
                xxh32.__init__(data=ilook_ch_id.encode('utf-8')
                               if isinstance(ilook_ch_id, str) else ilook_ch_id)
                epgUrl = _Request(
                    'http://epg.ottp.eu.org/it999/epg/%s.json' % xxh32.intdigest(),
                    headers=HEADERS)
            elif (self.provider in ('app-greatiptv', 'iptvx.one', 'only4',
                                    'viplime') and 'sapp_tvgid' in params):
                tvgid = params['sapp_tvgid']
                xxh32.__init__(data=tvgid.encode('utf-8') if isinstance(tvgid, str) else tvgid)
                epgUrl = _Request(
                    'http://epg.ottp.eu.org/%s/epg/%s.json' % (self.provider, xxh32.intdigest()),
                    headers=HEADERS)
            elif self.provider == 'sharavoz' and 'sapp_tvgid' in params:
                from urllib.parse import urlencode as _ue
                _ch_id = params['sapp_tvgid']
                _serv  = parsed_url.netloc.split(':')[0]
                epgUrl = _Request(
                    'https://iptv-content.rv77.pw/api/program?' +
                    _ue({'channel': _ch_id, 'serv': _serv}),
                    headers=HEADERS)
            elif self.provider == 'propg.net' and 'sapp_tvgid' in params:
                import datetime as _dt
                _today = _dt.date.today().strftime('%Y-%m-%d')
                _ch_id = params['sapp_tvgid']
                epgUrl = _Request(
                    'https://epg.propg.net/%s/epg2/%s' % (_ch_id, _today),
                    headers=HEADERS)
            elif self.provider == 'protected-api' and splittedpath:
                import datetime as _dt
                _today = _dt.date.today().strftime('%Y-%m-%d')
                _ch_id = splittedpath[-1].split('.')[0]
                epgUrl = _Request(
                    'http://protected-api.com/epg/%s?date=%s' % (_ch_id, _today),
                    headers=HEADERS)
            elif self.provider == 'gazoni' and 'sapp_tvgid' in params:
                from urllib.parse import urlencode as _ue
                epgUrl = _Request(
                    'http://api.gazoni1.com/get/?' + _ue({'ch': params['sapp_tvgid']}),
                    headers=HEADERS)
            elif 'sapp_tvgid' in params and params['sapp_tvgid']:
                tvgid = params['sapp_tvgid']
                xxh32.__init__(data=tvgid.encode('utf-8') if isinstance(tvgid, str) else tvgid)
                epgUrl = _Request(
                    'http://epg.ottp.eu.org/%s/epg/%s.json' % (self.provider, xxh32.intdigest()),
                    headers=HEADERS)
            elif self.provider == 'tvoetv':
                login  = query_get(parsed_url.query, 'login')
                key    = query_get(parsed_url.query, 'key')
                epgUrl = _Request(
                    'http://46.174.189.2:8091/%s/epg.json?login=%s&key=%s' % (
                        splittedpath[1], login, key),
                    headers=HEADERS)
            elif self.provider == 'zala':
                ch_id  = splittedpath[-1].split('.')[0] if splittedpath else ''
                epgUrl = _Request('https://api.zala.by/v2/epg/%s' % ch_id, headers=HEADERS)
            elif self.provider == 'zabava':
                ch_id  = splittedpath[-1].split('.')[0] if splittedpath else ''
                epgUrl = _Request('https://api.zabava.tv/v2/epg/%s' % ch_id, headers=HEADERS)
            elif self.provider == 'xtream':
                # _loadFromEPGCache() ran first but Enigma2 only keeps current/future events.
                # Call the Xtream API directly for this stream's historical EPG schedule.
                if not self._loadXtreamEPG(parsed_url, splittedpath):
                    self.fakeArchiveListLoaded()
                return
            else:
                # Unknown provider — try ge2.php directly as primary source
                _gabbarit = _getGabbarit()
                if _gabbarit and chName:
                    try:
                        from urllib.parse import urlencode as _ue
                        _ge2_url = ('https://epg.ott-play.com/m3u/ge2.php?' +
                                    _ue({'gabbarit': _gabbarit, 'channel': chName}))
                        _ge2_resp = urlopen(_Request(_ge2_url, headers=HEADERS), timeout=8)
                        _ge2_body = _ge2_resp.read()
                        _ge2_resp.close()
                        if _ge2_body and _ge2_body not in (b'[]', b'{}', b'null', b''):
                            self.archiveListLoaded(_ge2_body)
                            return
                    except Exception:
                        pass
                if user_initiated and self._tryCustomProviders(service, url):
                    return
                self.list1item(
                    T("Start Build"),
                    T("No EPG data found for provider '%s'.\n"
                      "Press the green 'Start Build' button to load EPG from your "
                      "configured providers,\nor use Yellow to configure a provider.") % self.provider)
                return

            try:
                resp = urlopen(epgUrl, timeout=5)
                if DEBUG:
                    iptvLogWrite(self.provider + " ch: " + chName + '\nepgUrl: ' + resp.geturl())
                _epg_body = {
                    'deflate': lambda: zlib.decompress(resp.read(), -zlib.MAX_WBITS),
                    'gzip':    lambda: zlib.decompress(resp.read(), zlib.MAX_WBITS | 16),
                }.get(resp.info().get('Content-Encoding'), lambda: resp.read())()

                # If primary source returned empty, try ge2.php as fallback
                if not _epg_body or _epg_body in (b'[]', b'{}', b'null', b''):
                    raise ValueError('empty response — trying ge2.php fallback')
                self.archiveListLoaded(_epg_body)
            except Exception as e:
                if DEBUG:
                    _err_str = ((e.reason if hasattr(e, 'reason') else None) or
                                (e.code   if hasattr(e, 'code')   else None) or str(e))
                    try:
                        _api_url = epgUrl.get_full_url()
                    except Exception:
                        _api_url = str(epgUrl)
                    iptvLogWrite(self.provider + ' ch: %s\n APIurl: %s\n Error: %s' % (
                        chName, _api_url, _err_str))

                # Fallback: try epg.ott-play.com/m3u/ge2.php
                _gabbarit = _getGabbarit()
                if _gabbarit and chName:
                    try:
                        from urllib.parse import urlencode as _ue
                        _ge2_url = ('https://epg.ott-play.com/m3u/ge2.php?' +
                                    _ue({'gabbarit': _gabbarit, 'channel': chName}))
                        _ge2_resp = urlopen(_Request(_ge2_url, headers=HEADERS), timeout=8)
                        _ge2_body = _ge2_resp.read()
                        _ge2_resp.close()
                        if _ge2_body and _ge2_body not in (b'[]', b'{}', b'null', b''):
                            if DEBUG:
                                iptvLogWrite('[ge2.php fallback] OK for: ' + chName)
                            self.archiveListLoaded(_ge2_body)
                            return
                    except Exception as _ge2_err:
                        if DEBUG:
                            iptvLogWrite('[ge2.php fallback] error: ' + str(_ge2_err)[:80])

                if not self._loadFromEPGCache(service, ch_id=_ilook_ch_id):
                    if not (user_initiated and self._tryCustomProviders(service, url)):
                        if self.provider in ('ilook', 'edem'):
                            self.list1item(
                                T("Start Build"),
                                T("Network EPG server for it999/ilook/edem is unavailable.\n"
                                  "Press green 'Start Build' to load EPG from your "
                                  "configured providers,\nor use Yellow to configure a provider."))
                        else:
                            self.list1item(
                                T("Start Build"),
                                T("Network EPG server unavailable for '%s'.\n"
                                  "Press green 'Start Build' to load EPG from your "
                                  "configured providers,\nor use Yellow to configure a "
                                  "provider.") % self.provider)
            finally:
                try:
                    resp.close()
                except NameError:
                    pass
        except Exception:
            self.list1item(T("Error getting archive"),
                           T("Error generating request URL for receiving EPG archive broadcasts"))
            if DEBUG: self.saveTraceback()

    def list1item(self, title='', descr=''):
        btime = currTime()
        try:
            self["list"].recalcEntrySize()
        except Exception:
            pass
        self["list"].list = []
        self["list"].l.setList(self["list"].list)
        self['Event'].newEvent(epgEvent(descr, random.randint(0, 1000), btime, 0, title))
        self["list"].selectionChanged()

    def _getArchiveOffset(self, prov_type, prov_id, stream_url=''):
        """Return archive start time offset in seconds for this provider/stream.

        Positive = start later (skip into programme).
        Negative = start earlier (fixes a clock that runs fast).

        Lookup order:
          1. Custom providers: matched by name; if stream_hostname is saved,
             offset only applies when the live stream URL hostname contains
             that filter — otherwise 0 and the global fallback is tried.
          2. Integrated providers: keyed by provider tag in archive_offsets.
          3. Global fallback: global_archive_offset setting, used whenever
             no per-provider offset resolves to a non-zero value.

        Results are cached in the module-level _archive_offset_cache dict.
        The cache is cleared by keySave() so changes apply immediately
        without restarting the plugin.
        """
        cache_key = (prov_type, str(prov_id), stream_url)
        if cache_key in _archive_offset_cache:
            return _archive_offset_cache[cache_key]
        offset = 0
        try:
            settings = loadPluginSettings()
            if prov_type == 'custom':
                for p in loadPlaylistProviderConfig():
                    if p.get('create_archives') and p.get('name', '').strip() == prov_id:
                        host_filter = (p.get('stream_hostname', '') or '').strip().lower()
                        if host_filter and stream_url:
                            try:
                                stream_host = (urlparse(stream_url).hostname or '').lower()
                            except Exception:
                                stream_host = ''
                            if host_filter not in stream_host:
                                break
                        offset = int(p.get('time_offset_sec', 0) or 0)
                        break
            else:
                offset = int(
                    settings.get('archive_offsets', {}).get(str(prov_id), 0) or 0)
            if offset == 0:
                offset = int(settings.get('global_archive_offset', 0) or 0)
        except (ValueError, TypeError):
            pass
        _archive_offset_cache[cache_key] = offset
        return offset

    def saveTraceback(self):
        with open(log_file, 'a') as err_file:
            traceback.print_exc(file=err_file)

    def openAddWorkflow(self):
        self.session.open(IPTVAddWorkflow)

    def openProviderSettings(self):
        self.session.openWithCallback(lambda *a: None, IPTVPlaylistProviderSettings)

    def _tryCustomProviders(self, service, url, build_all=False):
        """Start async custom-provider EPG fetch. Returns True if providers exist."""
        providers = [p for p in loadPlaylistProviderConfig()
                     if p.get('enabled') and p.get('create_archives')
                     and (p.get('xmltv_url') or '').strip()]
        if not providers:
            return False
        if self._custom_fetching:
            return True
        self._custom_fetching = True
        chName = self.currentService.getServiceName().replace(SIGN, '').strip()
        if build_all:
            self.list1item(
                T("Building EPG cache..."),
                T("Parsing XMLTV and caching all channels in a single pass.\n"
                  "Progress will appear shortly...\n"
                  "This takes a few minutes the first time — subsequent OK presses will be instant.\n"
                  "All plugin keys remain active."))
        else:
            self.list1item(
                T("Loading EPG..."),
                T("Downloading playlist and EPG data from custom provider.\n"
                  "All plugin keys remain active — you can still navigate."))
        import threading as _threading
        t = _threading.Thread(
            target=self._customProviderThread,
            args=(url, chName, providers, build_all))
        t.daemon = True
        t.start()
        return True

    def _customProviderThread(self, url, channel_name, providers, build_all=False):
        try:
            if build_all:
                def _progress(done, total, prov_name):
                    try:
                        from twisted.internet import reactor
                        reactor.callFromThread(self._updateBuildProgress, done, total, prov_name)
                    except Exception:
                        pass
                result = (_buildAllChannelCaches(
                    providers, url, channel_name,
                    progress_cb=_progress,
                    cancel_check=lambda: self._build_cancelled), None)
            else:
                result = _fetchCustomProvider(url, channel_name, providers)
        except Exception:
            result = (None, None)
        try:
            from twisted.internet import reactor
            reactor.callFromThread(self._customProviderDone, result)
        except Exception:
            self._customProviderDone(result)

    def _updateBuildProgress(self, done, total, prov_name):
        try:
            pct = int(100 * done / total) if total else 0
            self.list1item(
                T("Building EPG cache... %d%%") % pct,
                T("Provider: %s\n"
                  "Channels cached: %d / %d\n"
                  "All plugin keys remain active.") % (prov_name, done, total))
        except Exception:
            pass

    def _customProviderDone(self, result):
        # result is a (events, prov_name) tuple from _fetchCustomProvider
        if isinstance(result, tuple):
            events, prov_name = result
        else:
            events, prov_name = result, None
        self._current_custom_prov_name = prov_name or ''
        self._custom_fetching  = False
        self._build_cancelled  = False
        try:
            self["key_green"].setText(T('Help'))
        except Exception:
            pass
        try:
            if events is False:
                self.list1item(
                    T("Build stopped"),
                    T("EPG cache build was stopped.\n"
                      "All channels cached so far are saved — progress is not lost.\n\n"
                      "Press Green 'Start Build' to resume from where it left off."))
            elif events:
                self._all_events = sorted(events, key=lambda e: e[2])
                now         = currTime()
                _arch_days  = 7
                if prov_name:
                    try:
                        for _pp in loadPlaylistProviderConfig():
                            if (_pp.get('name') or '').strip() == prov_name:
                                _arch_days = int(_pp.get('archive_days', 7) or 7)
                                break
                    except Exception:
                        pass
                cutoff      = now - _arch_days * 86400
                past_events = [e for e in events if e[2] < now and e[2] >= cutoff]
                l           = self["list"]
                l.list      = past_events
                try:
                    l.recalcEntrySize()
                except Exception:
                    pass
                l.l.setList(l.list)
                l.selectionChanged()
            elif events is not None and len(events) == 0:
                self.list1item(
                    T("No archive programme"),
                    T("There is no archive programme for this channel.\n\n"
                      "The EPG cache has been built but contains no programme\n"
                      "data for this channel within the configured archive window.\n\n"
                      "Press Green 'Start Build' to refresh the cache,\n"
                      "or use Yellow to check your provider settings."))
            else:
                self.list1item(
                    T("No EPG found"),
                    T("No matching channel was found in the custom provider's playlist,\n"
                      "or the XMLTV feed has no EPG data for this channel.\n\n"
                      "Press Yellow to open Provider Settings and verify:\n"
                      "  - The M3U/Playlist URL contains this channel's stream URL\n"
                      "  - The XMLTV URL contains programmes for the matching tvg-id\n"
                      "  - The channel's tvg-id in the M3U matches the XMLTV <channel id>"))
        except Exception:
            pass

# ---------------------------------------------------------------------------
# IPTVFileBrowser — portable file-browser dialog
# ---------------------------------------------------------------------------

class IPTVFileBrowser(Screen):
    """Portable file browser using Enigma2's built-in FileList component."""

    def __init__(self, session, startdir='/media/hdd/'):
        Screen.__init__(self, session)
        self.skinName = ["IPTVFileBrowser", "FileBrowser", "Setup"]
        self.setTitle(T("Select Playlist File"))
        if not startdir or not os.path.isdir(startdir):
            for candidate in ('/media/hdd/', '/media/usb/', '/tmp/', '/'):
                if os.path.isdir(candidate):
                    startdir = candidate
                    break
        self["filelist"] = FileList(startdir, showDirectories=True, showFiles=True,
                                    matchingPattern=None, useServiceRef=False)
        self["key_red"]    = Button(T("Cancel"))
        self["key_green"]  = Button(T("Select"))
        self["key_yellow"] = Button("")
        self["key_blue"]   = Button("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self.ok,
                "cancel": self.cancel,
                "red":    self.cancel,
                "green":  self.selectCurrent,
                "up":     self["filelist"].up,
                "down":   self["filelist"].down,
                "left":   self["filelist"].pageUp,
                "right":  self["filelist"].pageDown,
            }, -1)

    def ok(self):
        if self["filelist"].canDescent():
            self["filelist"].descent()
        else:
            self.selectCurrent()

    def selectCurrent(self):
        filepath = None
        curdir   = ''
        try:
            curdir = self["filelist"].getCurrentDirectory() or ''
        except Exception:
            pass
        try:
            fp = self["filelist"].getFilename()
            if fp and isinstance(fp, str):
                if not fp.startswith('/') and curdir:
                    fp = os.path.join(curdir, fp)
                if os.path.isfile(fp):
                    filepath = fp
        except Exception:
            pass
        if not filepath:
            try:
                sel = self["filelist"].getSelection()
                if sel:
                    name = sel[0] if isinstance(sel, (list, tuple)) else str(sel)
                    if name and not name.endswith('/'):
                        candidate = os.path.join(curdir, name) if curdir else name
                        if os.path.isfile(candidate):
                            filepath = candidate
            except Exception:
                pass
        if not filepath:
            try:
                fl  = self["filelist"]
                idx = fl.getSelectedIndex() if hasattr(fl, 'getSelectedIndex') else None
                if idx is not None:
                    lst = fl.list
                    if lst and 0 <= idx < len(lst):
                        entry = lst[idx]
                        name  = entry[0] if isinstance(entry, (list, tuple)) else str(entry)
                        if name and not name.endswith('/'):
                            candidate = os.path.join(curdir, name) if curdir else name
                            if os.path.isfile(candidate):
                                filepath = candidate
            except Exception:
                pass
        if filepath:
            self.close(filepath)

    def cancel(self):
        self.close(None)

# ---------------------------------------------------------------------------
# IPTVChannelMatchDetailScreen — M3U ↔ XMLTV match detail
# ---------------------------------------------------------------------------

class IPTVChannelMatchDetailScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,720" title="Match Details" backgroundColor="#33000000">
            <widget name="content"  position="30,10"  size="1190,635"
                    font="Regular;29" transparent="1" />
            <eLabel position="0,653" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_hint" position="10,660" size="1230,35"
                    font="Regular;24" valign="center" halign="center" transparent="1" />
            <eLabel position="0,719" size="1250,1" backgroundColor="#00aa00"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,720" title="Match Details">
            <widget name="content"  position="30,10"  size="1190,635"
                    font="Regular;29" />
            <eLabel position="0,653" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_hint" position="10,660" size="1230,35"
                    font="Regular;24" valign="center" halign="center" transparent="1" />
            <eLabel position="0,719" size="1250,1" backgroundColor="#00aa00"/>
        </screen>"""
    skin = _SKIN_T

    def __init__(self, session, detail):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        SEP   = '\u2500' * 52
        lines = []
        lines.append(SEP)
        lines.append("  " + T("M3U file data"))
        lines.append(SEP)
        lines.append("  tvg-id    :  " + (detail.get('m3u_tvg_id')   or T("(empty)")))
        lines.append("  tvg-name  :  " + (detail.get('m3u_tvg_name') or T("(empty)")))
        lines.append("  name      :  " + (detail.get('m3u_name')     or T("(empty)")))
        lines.append("  group     :  " + (detail.get('m3u_group')    or T("(empty)")))
        lines.append("")
        tag = detail.get('match_tag')
        lines.append(SEP)
        lines.append("  " + T("Match Result from M3U and XMLTV"))
        lines.append(SEP)
        if tag:
            m3u_from, xmltv_from, final_line = self._buildMatchLines(tag, detail)
            if m3u_from:   lines.append("  " + T("Matched From M3U") + ":   " + m3u_from)
            if xmltv_from: lines.append("  " + T("Matched From XMLTV") + ": " + xmltv_from)
            if final_line: lines.append("  " + final_line)
            lines.append("")
            disp_names = detail.get('xmltv_disp_names') or []
            xmltv_id   = detail.get('xmltv_id') or T("(empty)")
            lines.append(SEP)
            lines.append("  " + T("XMLTV File Data"))
            lines.append("  " + T("id for this channels") + " [%s],  %s(%d)" % (
                xmltv_id, T("Channels Count"), len(disp_names)))
            lines.append(SEP)
            if disp_names:
                for dn in disp_names:
                    lines.append("  \u2022  " + dn)
            else:
                lines.append("  " + T("(none recorded in this XMLTV)"))
        else:
            lines.append("  " + T("STATUS") + "  :  " + T("NO MATCH FOUND IN XMLTV"))
            lines.append("")
            lines.append("  " + T("Looked up these values — none matched:"))
            for val in [detail.get('m3u_tvg_id'), detail.get('m3u_tvg_name'), detail.get('m3u_name')]:
                if val:
                    lines.append("    \u2022  " + val)
        self["content"]  = ScrollLabel('\n'.join(lines))
        self["key_hint"] = Label(
            T("UP/DOWN") + " \u2014 " + T("Scroll") +
            "   |   " + T("OK / EXIT") + " \u2014 " + T("Back to Results"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions"],
            {"cancel": self.close, "ok": self.close,
             "up": self.scrollUp, "down": self.scrollDown}, -2)

    @staticmethod
    def _buildMatchLines(tag, detail):
        if not tag:
            return None, None, None
        inner = tag.strip()
        if inner.startswith('[') and inner.endswith(']'):
            inner = inner[1:-1]
        if ':' not in inner:
            return tag, tag, None
        key, matched_val = inner.split(':', 1)
        key         = key.strip()
        matched_val = matched_val.strip()
        field_vals  = {
            'tvg-id':   detail.get('m3u_tvg_id',   ''),
            'tvg-name': detail.get('m3u_tvg_name', ''),
            'name':     detail.get('m3u_name',     ''),
        }
        if key.startswith('disp~/'):
            field      = key[6:]; is_display = True
        elif key.startswith('disp/'):
            field      = key[5:]; is_display = True
        elif key.endswith('~'):
            field      = key[:-1]; is_display = False
        else:
            field      = key; is_display = False
        src = field_vals.get(field, '') or matched_val
        if is_display:
            m3u_from   = "[disp/%s: [%s]]" % (field, src)
            xmltv_from = "[disp/%s: [%s]]" % (field, src)
            final_line = "Finaly Matched: By Display name M3U [%s],  XMLTV  [%s]" % (src, src)
        else:
            m3u_from   = "[%s [%s]]" % (field, src)
            xmltv_from = "[%s [%s]]" % (field, matched_val)
            final_line = "Finaly Matched: by %s  M3U %s [%s]  XMLTV %s [%s]" % (
                field, field, src, field, matched_val)
        return m3u_from, xmltv_from, final_line

    def scrollUp(self):
        try: self["content"].pageUp()
        except Exception: pass

    def scrollDown(self):
        try: self["content"].pageDown()
        except Exception: pass

# ---------------------------------------------------------------------------
# IPTVProviderTestResultScreen — scrollable matched/unmatched list
# ---------------------------------------------------------------------------

class IPTVProviderTestResultScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,720" title="Channels ID" backgroundColor="#33000000">
            <widget name="summary"      position="10,10"  size="1230,175"
                    font="Regular;28" valign="top" halign="left" transparent="1" />
            <widget name="list_title"   position="10,192" size="1230,38"
                    font="Regular;28" valign="center" halign="left"
                    foregroundColor="#00ccff" transparent="1" />
            <widget name="channel_list" position="10,234" size="1230,413"
                    scrollbarMode="showOnDemand" font="Regular;29" itemHeight="40" transparent="1"/>
            <widget name="key_hint"     position="10,648" size="1230,1"
                    font="Regular;1" transparent="1" />
            <eLabel position="0,653" size="1250,1" backgroundColor="#00aa00"/>
            <ePixmap position="62,673"  size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="432,673" size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="842,673" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <widget name="key_red"    position="105,668" size="290,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="475,668" size="320,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="885,668" size="345,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <eLabel position="0,719" size="1250,1" backgroundColor="#00aa00"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,720" title="Channels ID">
            <widget name="summary"      position="10,10"  size="1230,175"
                    font="Regular;28" valign="top" halign="left" transparent="1" />
            <widget name="list_title"   position="10,192" size="1230,38"
                    font="Regular;28" valign="center" halign="left"
                    foregroundColor="#00ccff" transparent="1" />
            <widget name="channel_list" position="10,234" size="1230,413"
                    scrollbarMode="showOnDemand" font="Regular;29" itemHeight="40" />
            <widget name="key_hint"     position="10,648" size="1230,1"
                    font="Regular;1" />
            <eLabel position="0,653" size="1250,1" backgroundColor="#00aa00"/>
            <ePixmap position="62,673"  size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="432,673" size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="842,673" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <widget name="key_red"    position="105,668" size="290,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="475,668" size="320,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="885,668" size="345,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <eLabel position="0,719" size="1250,1" backgroundColor="#00aa00"/>
        </screen>"""
    skin    = _SKIN_T


    _SORT_ORIGINAL   = 0
    _SORT_BY_NAME    = 1
    _SORT_BY_XMLTV   = 2
    _SORT_MODE_COUNT = 3

    _MODE_MATCHED        = 0   # all matched channels
    _MODE_UNMATCHED      = 1   # all not matched channels
    _MODE_DISP_NAME      = 2   # matched via display-name
    _MODE_DISP_NOT       = 3   # not matched via display-name (= tvg-id matched)
    _MODE_TVG_ID         = 4   # matched via tvg-id exact/norm
    _MODE_TVG_NOT        = 5   # not matched via tvg-id (= display-name matched)
    _MODE_COUNT          = 6   # total number of modes

    def __init__(self, session, result):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._result         = result
        self._list_mode      = self._MODE_MATCHED
        self._sort_mode      = self._SORT_ORIGINAL
        self._selected_urls  = None
        self["summary"]      = Label('')
        self["list_title"]   = Label('')
        self["channel_list"] = MenuList([])
        self["key_red"]      = Label(T("Sort Order"))
        self["key_green"]    = Label(T("Toggle XMLTV vs M3U"))
        self["key_yellow"]   = Label(T("Show Channels"))
        self["key_hint"]     = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"cancel": self.keyClose, "ok": self.showMatchDetail,
             "red": self.cycleSortOrder, "green": self.toggleList,
             "yellow": self.showChannels}, -2)
        self._updateScreen()

    def keyClose(self):
        self.close(self._selected_urls)

    def _getDispNameMatched(self):
        """Channels matched via XMLTV display-name."""
        return [c for c in self._result.get('matched_channels', [])
                if 'disp' in (c.get('match_tag') or '')]

    def _getTvgIdMatched(self):
        """Channels matched via tvg-id (exact/norm)."""
        return [c for c in self._result.get('matched_channels', [])
                if 'disp' not in (c.get('match_tag') or '') and c.get('match_tag')]

    def _getDispNameNotMatched(self):
        """Matched channels that did NOT use display-name (i.e. matched via tvg-id)."""
        return self._getTvgIdMatched()

    def _getTvgIdNotMatched(self):
        """Matched channels that did NOT use tvg-id (i.e. matched via display-name)."""
        return self._getDispNameMatched()

    def _updateScreen(self):
        r  = self._result
        mc = r.get('matched_channels', [])
        uc = r.get('unmatched_channels', [])
        lines = [T("Channels ID: ") + (r.get('prov_name') or ''), ""]
        if r.get('m3u_ok'):
            lines.append("[OK] M3U: %d %s" % (r['m3u_count'], T("channels found")))
        else:
            lines.append("[FAIL] M3U: " + (r.get('m3u_error') or T("unknown error")))
        if r.get('xmltv_ok'):
            lines.append("[OK] XMLTV: %d %s, %d %s" % (
                r['xmltv_ch'], T("channels"), r['xmltv_ev'], T("programmes")))
        else:
            lines.append("[FAIL] XMLTV: " + (r.get('xmltv_error') or T("unknown error")))
        if mc or uc:
            ok_tag = "[OK]" if mc else "[NO]"
            lines.append("%s %d %s, [NO] %d %s" % (
                ok_tag, len(mc), T("matched"), len(uc), T("not matched")))
        self["summary"].setText('\n'.join(lines))

        mode = self._list_mode
        _has_xmltv = r.get('xmltv_ok') and (mc or uc)
        if mode == self._MODE_MATCHED:
            if _has_xmltv:
                channels   = mc
                base_title = T("Matched Channels")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display':      '[%s]  %s' % (
                                                 (ch.get('tvg_id') or '(no tvg-id)'),
                                                 (ch.get('tvg_name') or ch.get('name') or '')),
                             'm3u_tvg_id':   (ch.get('tvg_id') or ''),
                             'm3u_tvg_name': (ch.get('tvg_name') or ''),
                             'm3u_name':     (ch.get('name') or ''),
                             'm3u_group':    (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if (ch.get('tvg_id') or ch.get('name'))]
                base_title = T("Channels (tvg-id)")
        elif mode == self._MODE_UNMATCHED:
            if _has_xmltv:
                channels   = uc
                base_title = T("Not Matched Channels")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display':      '[no tvg-id]  %s' % (ch.get('tvg_name') or ch.get('name') or ''),
                             'm3u_tvg_id':   '', 'm3u_tvg_name': '',
                             'm3u_name':     (ch.get('tvg_name') or ch.get('name') or ''),
                             'm3u_group':    (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if not (ch.get('tvg_id') or '').strip()]
                base_title = T("Channels Without tvg-id")
        elif mode == self._MODE_DISP_NAME:
            if _has_xmltv:
                channels   = self._getDispNameMatched()
                base_title = T("Matched via Display Name")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display': '[%s]  %s' % (
                                            (ch.get('tvg_name') or ch.get('name') or ''),
                                            (ch.get('group_title') or ch.get('group') or '')),
                             'm3u_tvg_id': (ch.get('tvg_id') or ''),
                             'm3u_tvg_name': (ch.get('tvg_name') or ''),
                             'm3u_name': (ch.get('name') or ''),
                             'm3u_group': (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if (ch.get('tvg_name') or ch.get('name'))]
                base_title = T("Channels by Display Name")
        elif mode == self._MODE_DISP_NOT:
            if _has_xmltv:
                channels   = self._getDispNameNotMatched()
                base_title = T("Matched via tvg-id (not Display Name)")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display': '[%s]' % (ch.get('tvg_id') or '(no tvg-id)'),
                             'm3u_tvg_id': (ch.get('tvg_id') or ''),
                             'm3u_tvg_name': (ch.get('tvg_name') or ''),
                             'm3u_name': (ch.get('name') or ''),
                             'm3u_group': (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if (ch.get('tvg_id') or '').strip()]
                base_title = T("Channels With tvg-id")
        elif mode == self._MODE_TVG_ID:
            if _has_xmltv:
                channels   = self._getTvgIdMatched()
                base_title = T("Matched via tvg-id")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display': '[%s]  %s' % (
                                            (ch.get('tvg_id') or ''),
                                            (ch.get('tvg_name') or ch.get('name') or '')),
                             'm3u_tvg_id': (ch.get('tvg_id') or ''),
                             'm3u_tvg_name': (ch.get('tvg_name') or ''),
                             'm3u_name': (ch.get('name') or ''),
                             'm3u_group': (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if (ch.get('tvg_id') or '').strip()]
                base_title = T("Channels With tvg-id")
        else:  # _MODE_TVG_NOT
            if _has_xmltv:
                channels   = self._getTvgIdNotMatched()
                base_title = T("Matched via Display Name (not tvg-id)")
            else:
                raw = r.get('m3u_channels_raw') or []
                channels = [{'display': '[no tvg-id]  %s' % (ch.get('tvg_name') or ch.get('name') or ''),
                             'm3u_tvg_id': '',
                             'm3u_tvg_name': (ch.get('tvg_name') or ''),
                             'm3u_name': (ch.get('name') or ''),
                             'm3u_group': (ch.get('group_title') or ch.get('group') or ''),
                             'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                            for ch in raw if not (ch.get('tvg_id') or '').strip()]
                base_title = T("Channels Without tvg-id")

        channels = self._applySortOrder(channels)
        self._current_channels = channels
        sort_labels = [T("orig.order"), T("by name"), T("by XMLTV id")]
        sort_label  = sort_labels[self._sort_mode % len(sort_labels)]
        title = "\u25ba %s (%d)  \u2014  %s: %s" % (
            base_title, len(channels), T("Sort"), sort_label)
        self["list_title"].setText(title)
        self["channel_list"].setList([
            ch['display'] if isinstance(ch, dict) else ch for ch in channels])

    def _applySortOrder(self, channels):
        if not channels:
            return channels
        try:
            if self._sort_mode == self._SORT_BY_NAME:
                return sorted(channels, key=lambda c: (
                    (c.get('m3u_name') or c.get('m3u_tvg_name') or '').lower()
                    if isinstance(c, dict) else c.lower()))
            elif self._sort_mode == self._SORT_BY_XMLTV:
                return sorted(channels, key=lambda c: (
                    (c.get('xmltv_id') or c.get('m3u_tvg_id') or
                     c.get('m3u_tvg_name') or '').lower()
                    if isinstance(c, dict) else c.lower()))
        except Exception:
            pass
        return channels

    def cycleSortOrder(self):
        self._sort_mode = (self._sort_mode + 1) % self._SORT_MODE_COUNT
        self._updateScreen()

    def showMatchDetail(self):
        channels = getattr(self, '_current_channels', None)
        if channels is None:
            channels = self._result.get('matched_channels', [])
        try:
            idx = self["channel_list"].getSelectedIndex()
        except Exception:
            idx = 0
        if not (0 <= idx < len(channels)):
            return
        detail = channels[idx]
        if isinstance(detail, dict):
            self.session.open(IPTVChannelMatchDetailScreen, detail)

    def toggleList(self):
        self._list_mode = (self._list_mode + 1) % self._MODE_COUNT
        self._updateScreen()

    def showChannels(self):
        raw = self._result.get('m3u_channels_raw') or []
        if not raw:
            self.session.open(MessageBox, T("No M3U channel data available."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        # Close Channels ID — caller (_onChannelsIDClosed) reopens Channel Browser
        self.close(None)

    def downloadPicons(self):
        r         = self._result
        channels  = r.get('m3u_channels_raw') or []
        prov_name = r.get('prov_name') or 'Provider'
        picon_naming = (r.get('picon_naming') or 'display_name').strip()

        # ── 1. Collect logos already in memory from M3U (fast, UI thread) ──
        # Value is (logo_url, channel_url) so reference naming can compute sref.
        m3u_logos = {}
        for ch in channels:
            logo = (ch.get('tvg_logo') or ch.get('tvg-logo') or
                    ch.get('logo', '')).strip()
            if logo:
                name = (ch.get('display') or ch.get('tvg_name') or
                        ch.get('name', '')).strip()
                ch_url = (ch.get('url') or '').strip()
                if name:
                    m3u_logos[name] = (logo, ch_url)

        # ── 2. Find XMLTV URL for this provider (no parsing here) ──────────
        xmltv_url = ''
        for prov in loadPlaylistProviderConfig():
            if prov.get('name', '').strip() == prov_name:
                xmltv_url = (prov.get('xmltv_url') or '').strip()
                break

        if not m3u_logos and not xmltv_url:
            self.session.open(MessageBox,
                T("No picon links found in M3U or XMLTV data."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return

        # ── 3. Build SID map once (needed for reference-number naming) ───────
        sid_map = {}
        if picon_naming == 'reference' and channels:
            import re as _re2
            _sn = _re2.sub(r'[^\w\-]', '_', prov_name.strip()) or 'Provider'
            sid_map = _channel_sid_map(_sn, channels)

        _pb = 'gstplayer'
        _plocation = None
        _pwith_folder = True
        _m3u_src = prov_name
        for _prov in loadPlaylistProviderConfig():
            if _prov.get('name', '').strip() == prov_name:
                _pb           = (_prov.get('playback_with') or 'gstplayer').strip()
                _plocation    = _prov.get('picon_location') or None
                _pwith_folder = bool(_prov.get('picon_with_folder', True))
                _m3u_src      = (_prov.get('m3u_source') or prov_name).strip()
                break
        picon_stype = {'gst_player': '5001', 'exteplayer3': '5002', 'dvb': '1'}.get(_pb, '4097')
        import zlib as _zlib_dp
        _prov_ns = '%08X' % (_zlib_dp.crc32(_m3u_src.encode('utf-8', 'replace')) & 0xFFFFFFFF)

        # ── 4. All heavy work (XMLTV parse + downloads) goes to background ─
        self["key_blue"].setText(T("Downloading..."))
        import threading
        t = threading.Thread(
            target=self._piconThread,
            args=(prov_name, m3u_logos, xmltv_url, picon_naming, sid_map,
                  picon_stype, _plocation, _pwith_folder, _prov_ns))
        t.daemon = True
        t.start()

    def _piconThread(self, prov_name, m3u_logos, xmltv_url='',
                     picon_naming='display_name', sid_map=None,
                     picon_stype='4097', picon_location=None, picon_with_folder=True,
                     prov_ns=None):
        import re as _re
        safe_name = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
        _ploc = picon_location or getDataDir()
        if _ploc in ('enigma2_picon',): _ploc = '/usr/share/enigma2/picon'
        elif _ploc in ('plugin_dir', ''): _ploc = getDataDir()
        if picon_with_folder:
            folder = os.path.join(_ploc, '%s_Picons' % safe_name)
        else:
            folder = _ploc
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
        except Exception:
            pass

        try:
            from twisted.internet import reactor as _reactor
        except Exception:
            _reactor = None

        # ── Source selection: M3U first, XMLTV only when M3U has no logos ────
        # Parse XMLTV only when the M3U playlist contained no logo URLs.
        # Parsing a 200 MB XMLTV for icons when the M3U already has them is
        # wasteful and slow even in a background thread.
        xmltv_logos = {}
        if not m3u_logos and xmltv_url:
            try:
                import xml.etree.ElementTree as _ET
                import gzip as _gz
                if xmltv_url.lower().startswith(('http://', 'https://')):
                    xmltv_path = _downloadXMLTVToCache(xmltv_url, prov_name, copy_to_epg_dir=False)
                else:
                    xmltv_path = xmltv_url
                if xmltv_path and os.path.isfile(xmltv_path):
                    _fh = open(xmltv_path, 'rb')
                    _magic = _fh.read(2); _fh.seek(0)
                    _src = (_gz.GzipFile(fileobj=_fh) if _magic == b'\x1f\x8b' else _fh)
                    try:
                        # In XMLTV all <channel> elements appear BEFORE the first
                        # <programme> element.  Stop as soon as we see <programme>
                        # so we never read the huge programme body (747K entries).
                        for event, elem in _ET.iterparse(_src,
                                                         events=('start', 'end')):
                            if event == 'start' and elem.tag == 'programme':
                                break
                            if event == 'end' and elem.tag == 'channel':
                                icon = elem.find('icon')
                                icon_url = (icon.get('src', '')
                                            if icon is not None else '').strip()
                                if icon_url:
                                    for dn in elem.findall('display-name'):
                                        dn_text = (dn.text or '').strip()
                                        if dn_text:
                                            xmltv_logos[dn_text] = icon_url
                                elem.clear()
                    except Exception:
                        pass
                    _fh.close()
            except Exception:
                pass

        # ── Use M3U logos if available, otherwise fall back to XMLTV ────────
        # m3u_logos values are (logo_url, ch_url); xmltv_logos are plain strings.
        # Normalise so all_logos is {name: (logo_url, ch_url_or_empty)}.
        if m3u_logos:
            all_logos = m3u_logos
        else:
            all_logos = {k: (v, '') for k, v in xmltv_logos.items()}

        if not all_logos:
            if _reactor:
                _reactor.callFromThread(self._piconNoLogos)
            else:
                self._piconNoLogos()
            return

        total      = len(all_logos)
        downloaded = 0
        failed     = 0
        if PY3:
            from urllib.request import urlopen, Request as _Req
        else:
            from urllib2 import urlopen, Request as _Req

        for display_name, logo_info in all_logos.items():
            logo_url, ch_url = (logo_info if isinstance(logo_info, tuple)
                                else (logo_info, ''))
            try:
                if (picon_naming == 'reference' and ch_url
                        and sid_map and ch_url in sid_map):
                    sid_hex, _ = sid_map[ch_url]
                    safe_file = '%s_0_1_%s_1_1_%s_0_0_0' % (picon_stype, sid_hex.upper(), prov_ns if prov_ns else 'CCCC0000')
                else:
                    safe_file = re.sub(
                        r'[^\w\- ]', '_',
                        (display_name or '').strip()) or 'channel'
                save_path = os.path.join(folder, safe_file + '.png')
                req  = _Req(logo_url, headers={'User-Agent': 'Mozilla/5.0'})
                resp = urlopen(req, timeout=10)
                data = resp.read()
                resp.close()
                with open(save_path, 'wb') as f:
                    f.write(data)
                downloaded += 1
            except Exception:
                failed += 1
            done = downloaded + failed
            # Update progress label every 25 files (and always on the last one)
            if _reactor and (done % 25 == 0 or done == total):
                _reactor.callFromThread(self._piconProgress, done, total)

        if _reactor:
            _reactor.callFromThread(self._piconDone, downloaded, failed, folder)
        else:
            self._piconDone(downloaded, failed, folder)

    def _piconProgress(self, done, total):
        try:
            pct = int(done * 100 / total) if total else 0
            self["key_blue"].setText(u"\u2193 %d / %d  (%d%%)" % (done, total, pct))
        except Exception:
            pass

    def _piconNoLogos(self):
        try:
            self["key_blue"].setText(T("Download Picons"))
        except Exception:
            pass
        self.session.open(MessageBox,
            T("No picon links found in M3U or XMLTV data."),
            type=MessageBox.TYPE_INFO, timeout=4)

    def _piconDone(self, downloaded, failed, folder):
        try:
            self["key_blue"].setText(T("Download Picons"))
        except Exception:
            pass
        self.session.open(MessageBox,
            T("Picon download complete.\n"
              "Downloaded: %d  |  Failed: %d\n"
              "Saved to: %s") % (downloaded, failed, folder),
            type=MessageBox.TYPE_INFO, timeout=10)

# ---------------------------------------------------------------------------
# IPTVChannelBrowserScreen — two-panel bouquet/channel browser
# ---------------------------------------------------------------------------

class IPTVChannelBrowserScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1376,828" title="" backgroundColor="#33000000">
            <widget name="bouquet_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="channel_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="bouquet_list"  position="11,71"  size="662,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" transparent="1"/>
            <widget name="channel_list"  position="684,71" size="681,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" transparent="1"/>
            <widget name="key_web"    position="11,725"   size="1354,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="470,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="813,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1157,776" size="204,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1376,828" title="">
            <widget name="bouquet_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="channel_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="bouquet_list"  position="11,71"  size="662,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" />
            <widget name="channel_list"  position="684,71" size="681,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" />
            <widget name="key_web"    position="11,725"   size="1354,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="470,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="813,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_blue"   position="1157,776" size="204,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, channels, saved_selection=None, test_result=None):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T('Channel Browser'))
        self._test_result  = test_result
        self._test_prov    = None  # set by caller via attribute after open
        self._loading_xmltv = False
        self._focus_left   = True
        self._groups_order = []
        self._groups_map   = {}
        for ch in (channels or []):
            grp = (ch.get('group_title') or ch.get('group') or '').strip() or T('(no group)')
            if grp not in self._groups_map:
                self._groups_map[grp] = []
                self._groups_order.append(grp)
            self._groups_map[grp].append(ch)

        # Checked state — all selected by default; restored from saved selection if provided
        self._bouquet_checked = {grp: True for grp in self._groups_order}
        self._channel_checked = {}
        for grp, chs in self._groups_map.items():
            for ch in chs:
                self._channel_checked[(grp, (ch.get('url') or '').strip())] = True
        if saved_selection is not None:
            # saved_selection is a dict with 'selected' and 'known' URL sets.
            # Legacy format: plain list of selected URLs.
            if isinstance(saved_selection, dict):
                _sel   = set(saved_selection.get('selected') or [])
                _known = set(saved_selection.get('known')    or [])
            else:
                # Legacy plain list — treat all as both selected and known
                _sel   = set(saved_selection)
                _known = set(saved_selection)
            for grp, chs in self._groups_map.items():
                for ch in chs:
                    url = (ch.get('url') or '').strip()
                    if url in _known:
                        # Previously seen channel — use saved state
                        self._channel_checked[(grp, url)] = (url in _sel)
                    # else: new channel not in known — stays True (default)
                self._bouquet_checked[grp] = any(
                    self._channel_checked.get((grp, (ch.get('url') or '').strip()), False)
                    for ch in chs
                )

        self["bouquet_title"] = Label('')
        self["channel_title"] = Label('')
        self["bouquet_list"]  = MenuList([], enableWrapAround=True)
        self["channel_list"]  = MenuList([], enableWrapAround=True)
        self["key_red"]       = Label(T("Select All"))
        self["key_green"]     = Label(T("Switch Panel"))
        self["key_yellow"]    = Label(T("Channels ID"))
        self["key_blue"]      = Label(T("Save"))
        self._all_selected    = True
        self["key_hint"]      = Label(
            T("OK") + u" \u2014 " + T("Toggle") +
            u"   |   " + T("GREEN") + u" \u2014 " + T("Switch Panel") +
            u"   |   " + T("RED") + u" \u2014 " + T("Select All") + u"/" + T("Deselect All") +
            u"   |   " + T("YELLOW") + u" \u2014 " + T("Channels ID") +
            u"   |   " + T("BLUE") + u" \u2014 " + T("Save") +
            u"   |   " + T("EXIT") + u" \u2014 " + T("Cancel"))
        self["key_web"]       = Label('')
        self._ch_web_server   = None
        self._ch_web_timer    = None
        if _WEB_INPUT_OK:
            try:
                from ._epg import loadPluginSettings as _lps
                _is_ru = _lps().get('ui_language', 'ENG') == 'RUS'
            except Exception:
                _is_ru = False
            self._ch_web_server = IPTVChannelBrowserWebServer(WEB_CHANNEL_BROWSER_PORT)
            _checked_urls = set(
                url for (grp, url), v in self._channel_checked.items() if v
            )
            _ok, _ip, _port = self._ch_web_server.start(
                channels or [], is_ru=_is_ru, selected_urls=_checked_urls)
            if _ok:
                _url = u'http://%s:%d' % (_ip, _port)
                self["key_web"].setText(
                    T("PC Channel Browser: open  %s  in your browser") % _url)
                self._ch_web_timer = eTimer()
                try:
                    self._ch_web_timer.timeout.connect(self._pollWebInput)
                except Exception:
                    self._ch_web_timer.callback.append(self._pollWebInput)
                self._ch_web_timer.start(500, False)
            else:
                self["key_web"].setText(T("PC Channel Browser: not available"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {"cancel": self.keyCancel, "ok": self.keyOk,
             "red":    self.keyToggleSelectAll, "green": self.toggleWindow,
             "yellow": self.keyShowChannelsID,  "blue": self.keyAddSelected,
             "up": self.navUp, "down": self.navDown,
             "left": self.navLeft, "right": self.navRight}, -2)
        self._raw_channels = list(channels or [])
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()

    # ---- rendering helpers ----

    def _bouquetLabel(self, grp):
        chk = u'\u2713' if self._bouquet_checked.get(grp, True) else u' '
        total = len(self._groups_map[grp])
        checked = sum(
            1 for ch in self._groups_map[grp]
            if self._channel_checked.get((grp, (ch.get('url') or '').strip()), True)
        )
        count_str = u'(%d/%d)' % (checked, total) if checked < total else u'(%d)' % total
        return u'[%s] %s  %s' % (chk, grp, count_str)

    def _channelLabel(self, grp, ch):
        url  = (ch.get('url') or '').strip()
        name = (ch.get('tvg_name') or ch.get('name') or '').strip()
        chk  = u'\u2713' if self._channel_checked.get((grp, url), True) else u' '
        return u'[%s] %s' % (chk, name)

    def _refreshBouquetList(self):
        self["bouquet_list"].setList(
            [self._bouquetLabel(grp) for grp in self._groups_order])

    def _currentGroup(self):
        try:
            idx = self["bouquet_list"].getSelectedIndex()
        except Exception:
            idx = 0
        if 0 <= idx < len(self._groups_order):
            return idx, self._groups_order[idx]
        return 0, None

    def _updateChannelList(self, restore_idx=None):
        _, grp = self._currentGroup()
        if grp is None:
            self["channel_list"].setList([])
            return
        entries = [self._channelLabel(grp, ch) for ch in self._groups_map[grp]]
        self["channel_list"].setList(entries)
        if restore_idx is not None and restore_idx > 0:
            try:
                self["channel_list"].instance.moveSelectionTo(restore_idx)
            except Exception:
                try:
                    for _ in range(restore_idx):
                        self["channel_list"].down()
                except Exception:
                    pass
        else:
            try:
                self["channel_list"].instance.moveSelection(
                    self["channel_list"].instance.moveTop)
            except Exception:
                pass

    def _updateTitles(self):
        _, grp    = self._currentGroup()
        ch_count  = len(self._groups_map.get(grp, []))
        sel_b     = sum(1 for g in self._groups_order if self._bouquet_checked.get(g, True))
        sel_ch    = sum(1 for v in self._channel_checked.values() if v)
        if self._focus_left:
            self["bouquet_title"].setText(
                u'\u25ba ' + T("Bouquets") + u'  (%d/%d)' % (sel_b, len(self._groups_order)))
            self["channel_title"].setText(
                u'   ' + T("Channels") +
                (u': ' + grp if grp else u''))
        else:
            self["bouquet_title"].setText(
                u'   ' + T("Bouquets") + u'  (%d/%d)' % (sel_b, len(self._groups_order)))
            self["channel_title"].setText(
                u'\u25ba ' + T("Channels") +
                (u': ' + grp if grp else u''))

    # ---- key handlers ----

    def toggleWindow(self):
        self._focus_left = not self._focus_left
        self._updateTitles()

    def keyOk(self):
        if self._focus_left:
            _, grp = self._currentGroup()
            if grp is not None:
                new_state = not self._bouquet_checked.get(grp, True)
                self._bouquet_checked[grp] = new_state
                for ch in self._groups_map.get(grp, []):
                    self._channel_checked[(grp, (ch.get('url') or '').strip())] = new_state
                self._refreshBouquetList()
                self._updateChannelList()
                self._updateTitles()
        else:
            _, grp = self._currentGroup()
            if grp is None:
                return
            try:
                ch_idx = self["channel_list"].getSelectedIndex()
            except Exception:
                ch_idx = 0
            chs = self._groups_map.get(grp, [])
            if 0 <= ch_idx < len(chs):
                url = (chs[ch_idx].get('url') or '').strip()
                key = (grp, url)
                self._channel_checked[key] = not self._channel_checked.get(key, True)
                self._updateChannelList(restore_idx=ch_idx)
                self._refreshBouquetList()
                self._updateTitles()

    def keyToggleSelectAll(self):
        self._all_selected = not self._all_selected
        for grp in self._groups_order:
            self._bouquet_checked[grp] = self._all_selected
            for ch in self._groups_map.get(grp, []):
                self._channel_checked[(grp, (ch.get('url') or '').strip())] = self._all_selected
        try:
            self["key_red"].setText(T("Deselect All") if self._all_selected else T("Select All"))
        except Exception:
            pass
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()

    def keyShowChannelsID(self):
        result = self._test_result
        if result is None:
            raw = self._raw_channels
            result = {
                'prov_name': '', 'm3u_ok': bool(raw), 'm3u_count': len(raw),
                'xmltv_ok': False, 'xmltv_ch': 0, 'xmltv_ev': 0,
                'm3u_channels_raw': raw, 'matched_channels': [],
                'unmatched_channels': [
                    {'display':      '[%s]  %s' % (
                                         (ch.get('tvg_id') or '(no tvg-id)'),
                                         (ch.get('tvg_name') or ch.get('name') or '')),
                     'm3u_tvg_id':   (ch.get('tvg_id') or ''),
                     'm3u_tvg_name': (ch.get('tvg_name') or ''),
                     'm3u_name':     (ch.get('name') or ''),
                     'm3u_group':    (ch.get('group_title') or ch.get('group') or ''),
                     'match_tag': None, 'xmltv_id': None, 'xmltv_disp_names': []}
                    for ch in raw if (ch.get('tvg_id') or ch.get('name'))],
            }
        # If M3U-only result, load XMLTV in background before opening Channels ID
        if isinstance(result, dict) and result.get('m3u_only'):
            self["key_yellow"].setText(T("Please wait..."))
            self._loading_xmltv = True
            import threading as _thr
            t = _thr.Thread(target=self._xmltvLoadThread, args=(result,))
            t.daemon = True
            t.start()
        else:
            # XMLTV already loaded — close immediately
            self._stopWebServer()
            self.close(('show_channels_id', result))

    def _xmltvLoadThread(self, partial_result):
        """Load XMLTV in background while staying in Channel Browser."""
        try:
            full_result = _testProviderConnection(
                getattr(self, '_test_prov', partial_result))
            if not full_result.get('m3u_channels_raw'):
                full_result['m3u_channels_raw'] = partial_result.get('m3u_channels_raw', [])
            full_result['picon_naming'] = partial_result.get('picon_naming', 'off')
        except Exception as e:
            full_result = dict(partial_result)
            full_result['xmltv_error'] = str(e)[:120]
            full_result.pop('m3u_only', None)
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(self._xmltvLoadDone, full_result)
        except Exception:
            self._xmltvLoadDone(full_result)

    def _xmltvLoadDone(self, result):
        """XMLTV loaded — update test_result and close to open Channels ID."""
        self._loading_xmltv = False
        self._test_result = result  # update so toggle back uses full result
        self["key_yellow"].setText(T("Channels ID"))
        self._stopWebServer()
        self.close(('show_channels_id', result))

    def keyAddSelected(self):
        self._stopWebServer()
        selected = set()
        for grp in self._groups_order:
            if not self._bouquet_checked.get(grp, True):
                continue
            for ch in self._groups_map.get(grp, []):
                url = (ch.get('url') or '').strip()
                if url and self._channel_checked.get((grp, url), True):
                    selected.add(url)
        self.close(('save', selected))

    def keyCancel(self):
        self._stopWebServer()
        self.close(('cancel', None))

    # ---- web server helpers ----

    def _stopWebServer(self):
        if self._ch_web_timer is not None:
            try:
                self._ch_web_timer.stop()
            except Exception:
                pass
            self._ch_web_timer = None
        if self._ch_web_server is not None:
            self._ch_web_server.stop()
            self._ch_web_server = None

    def _pollWebInput(self):
        if self._ch_web_server is None:
            return
        result = self._ch_web_server.poll()
        if result is not None:
            self._applyWebSelection(result)

    def _applyWebSelection(self, selected_urls):
        url_set = set(selected_urls)
        for grp in self._groups_order:
            grp_has_sel = False
            for ch in self._groups_map[grp]:
                url = (ch.get('url') or '').strip()
                checked = url in url_set
                self._channel_checked[(grp, url)] = checked
                if checked:
                    grp_has_sel = True
            self._bouquet_checked[grp] = grp_has_sel
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()
        self["key_web"].setText(T("Selection received from PC browser"))

    # ---- navigation ----

    def _moveList(self, lst, direction):
        try:
            if   direction == 'up':       lst.up()
            elif direction == 'down':     lst.down()
            elif direction == 'pageup':   lst.pageUp()
            elif direction == 'pagedown': lst.pageDown()
        except Exception:
            pass

    def navUp(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'up')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'up')
        self._updateTitles()

    def navDown(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'down')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'down')
        self._updateTitles()

    def navLeft(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'pageup')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'pageup')
        self._updateTitles()

    def navRight(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'pagedown')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'pagedown')
        self._updateTitles()

# ---------------------------------------------------------------------------
# Auto-build scheduler
# ---------------------------------------------------------------------------

def _autoBuildWake():
    # Wake the box from soft standby if needed.
    # Does NOT decide whether to return to standby — that is _auto_build_should_return's job.
    global _auto_build_was_in_standby
    _auto_build_was_in_standby = False
    try:
        import Screens.Standby as _sb_mod
        if _sb_mod.inStandby:
            _auto_build_was_in_standby = True
            _sb_mod.inStandby.Power()
            iptvLogWrite('[AutoBuild] Receiver woken from standby for scheduled build')
        else:
            iptvLogWrite('[AutoBuild] Receiver was already active — no wake needed')
    except Exception as e:
        iptvLogWrite('[AutoBuild] Wake error: %s' % str(e))


def _autoBuildReturnStandby(session=None):
    # Called when build finishes and auto_build_standby is ON.
    # Runs on the Enigma2 main thread (via reactor.callFromThread in _autoBuildThread).
    # Uses eTimer for the 5-second delay — the native Enigma2 way, avoids callLater
    # closure issues that caused _do_standby() to never fire.
    # session is passed explicitly from _autoBuildThread to avoid module-global
    # visibility issues when called from a background thread context.
    global _auto_build_should_return, _auto_build_standby_counter, _auto_build_standby_timer

    if not _auto_build_should_return:
        iptvLogWrite('[AutoBuild] Return-to-standby skipped — not requested for this build')
        return

    # Reset flags before we act
    _auto_build_should_return   = False
    counter_at_trigger          = _auto_build_standby_counter
    _auto_build_standby_counter = -1

    # Fall back to module global if session not passed (defensive)
    if session is None:
        session = _auto_build_session

    def _do_standby():
        global _auto_build_standby_timer
        _auto_build_standby_timer = None   # release the timer reference
        try:
            import Screens.Standby as _sb_mod

            # Already in standby — nothing to do
            if _sb_mod.inStandby:
                iptvLogWrite('[AutoBuild] Already in standby — skipping return')
                return

            # If standbyCounter increased since trigger, the user put the box
            # into standby and back out again manually — respect their choice
            try:
                from Components.config import config as _cfg
                current_counter = _cfg.misc.standbyCounter.value
                if counter_at_trigger >= 0 and current_counter > counter_at_trigger:
                    iptvLogWrite('[AutoBuild] Return-to-standby cancelled — '
                                 'user cycled standby manually during build '
                                 '(counter %d -> %d)' % (counter_at_trigger, current_counter))
                    return
            except Exception as e:
                iptvLogWrite('[AutoBuild] standbyCounter check error: %s' % str(e))

            # Don't go to standby if a recording is running
            try:
                import NavigationInstance as _ni
                if _ni.instance.getRecordings():
                    iptvLogWrite('[AutoBuild] Return-to-standby skipped — recording in progress')
                    return
            except Exception as e:
                iptvLogWrite('[AutoBuild] recordings check error: %s' % str(e))

            # Use Notifications.AddNotification — the correct Enigma2 way to trigger
            # standby without needing a session object (same approach as EPGImport).
            try:
                import Screens.Standby as _sb2
                if _AddNotification is not None:
                    _AddNotification(_sb2.Standby)
                    iptvLogWrite('[AutoBuild] Receiver returned to standby')
                else:
                    # Fallback: try session.open if Notifications unavailable
                    _active_session = session or _auto_build_session
                    if _active_session:
                        _active_session.open(_sb2.Standby)
                        iptvLogWrite('[AutoBuild] Receiver returned to standby (fallback)')
                    else:
                        iptvLogWrite('[AutoBuild] Return-to-standby failed — no session available')
            except Exception as e:
                iptvLogWrite('[AutoBuild] Return-to-standby failed: %s' % str(e))
        except Exception as e:
            iptvLogWrite('[AutoBuild] Return-to-standby failed: %s' % str(e))

    # Use eTimer — the native Enigma2 deferred call on the main loop.
    # Keep the timer in a module-level variable so it is not garbage-collected
    # before it fires (local variables go out of scope immediately).
    iptvLogWrite('[AutoBuild] Scheduling return to standby in 5 seconds (eTimer)...')
    try:
        _auto_build_standby_timer = eTimer()
        try:
            _auto_build_standby_timer.timeout.connect(_do_standby)
        except AttributeError:
            _auto_build_standby_timer.callback.append(_do_standby)
        _auto_build_standby_timer.start(5000, True)   # True = single-shot
    except Exception as e:
        iptvLogWrite('[AutoBuild] eTimer setup failed (%s) — calling directly' % str(e))
        _do_standby()


def _autoBuildThread(providers, settings):
    global _auto_build_pending, _auto_build_progress

    def _progress(done, total, prov_name):
        global _auto_build_progress, _auto_build_listener
        _auto_build_progress = (done, total, prov_name)
        listener = _auto_build_listener
        if listener is not None:
            try:
                from twisted.internet import reactor
                reactor.callFromThread(listener._updateBuildProgress, done, total, prov_name)
            except Exception:
                pass

    try:
        if settings.get('auto_build_clear_cache', False):
            clear_idxs = set(settings.get('auto_build_clear_providers', []))
            all_provs  = [p for p in loadPlaylistProviderConfig() if p.get('create_archives')]
            for idx, p in enumerate(all_provs):
                if idx in clear_idxs:
                    pname = (p.get('name') or '').strip() or ('Provider %d' % (idx + 1))
                    _clearProviderCache(pname)
                    iptvLogWrite('[AutoBuild] Cache cleared for provider: %s' % pname)
        _buildAllChannelCaches(providers, '', '', progress_cb=_progress,
                               cancel_check=lambda: False)
    except Exception:
        pass
    finally:
        _auto_build_pending  = False
        _auto_build_progress = (0, 0, '')

    go_standby = settings.get('auto_build_standby', False)
    _sess = _auto_build_session
    try:
        from twisted.internet import reactor
        reactor.callFromThread(_onAutoBuildComplete, go_standby, _sess)
    except Exception:
        _onAutoBuildComplete(go_standby, _sess)


def _onAutoBuildComplete(go_standby, session=None):
    global _auto_build_listener
    listener             = _auto_build_listener
    _auto_build_listener = None
    if listener is not None:
        try:
            listener["key_green"].setText(T('Help'))
        except Exception:
            pass
        try:
            listener.list1item(
                T("Auto-build complete"),
                T("Scheduled EPG cache build finished.\n"
                  "Press OK on any programme to play it from the archive."))
        except Exception:
            try:
                listener['help_label'].setText(T('EPG cache build complete.'))
            except Exception:
                pass
    if go_standby:
        _autoBuildReturnStandby(session)


def _triggerAutoBuild(settings):
    global _auto_build_pending, _auto_build_should_return, _auto_build_standby_counter
    if _auto_build_pending:
        return
    providers = [p for p in loadPlaylistProviderConfig()
                 if p.get('enabled') and p.get('create_archives')
                 and (p.get('xmltv_url') or '').strip()]
    if not providers:
        return
    _auto_build_pending = True

    if settings.get('auto_build_standby', False):
        # Wake the box if it was in soft standby — _auto_build_was_in_standby
        # is set inside _autoBuildWake() so we know whether we actually woke it.
        _autoBuildWake()

        # Only return to standby if the box was in standby when the build triggered.
        # If it was already active, leave it alone when the build finishes.
        _auto_build_should_return = _auto_build_was_in_standby

        # Snapshot standbyCounter now. If it has increased by the time the
        # build finishes, the user cycled standby manually and we cancel the return.
        try:
            from Components.config import config as _cfg
            _auto_build_standby_counter = _cfg.misc.standbyCounter.value
            iptvLogWrite('[AutoBuild] standbyCounter at trigger: %d' % _auto_build_standby_counter)
        except Exception:
            _auto_build_standby_counter = -1
    else:
        _auto_build_should_return   = False
        _auto_build_standby_counter = -1

    import threading as _threading
    t = _threading.Thread(target=_autoBuildThread, args=(providers, settings))
    t.daemon = True
    t.start()


def _checkAutoBuild():
    global _auto_build_pending
    if _auto_build_pending:
        return
    settings = loadPluginSettings()
    if not settings.get('auto_build_enabled', False):
        return
    now          = time.localtime()
    enabled_days = settings.get('auto_build_days', list(range(7)))
    if now.tm_wday not in enabled_days:
        return
    target_h = int(settings.get('auto_build_time_h', 3))
    target_m = int(settings.get('auto_build_time_m', 0))
    if now.tm_hour != target_h or now.tm_min != target_m:
        return
    iptvLogWrite('[AutoBuild] Schedule matched — triggering headless build')
    _triggerAutoBuild(settings)


def _startAutoBuildTimer(session):
    global _auto_build_timer, _auto_build_session
    if session is not None:
        _auto_build_session = session
    if _auto_build_timer is None:
        _auto_build_timer = eTimer()
        try:
            _auto_build_timer.timeout.connect(_checkAutoBuild)
        except AttributeError:
            _auto_build_timer.callback.append(_checkAutoBuild)
    _auto_build_timer.start(60000, False)


def autostart(reason, session=None, **kwargs):
    """WHERE_AUTOSTART callback — start or stop the auto-build timer."""
    global _auto_build_timer
    if reason == 0:
        _startAutoBuildTimer(session)
    elif reason == 1:
        if _auto_build_timer is not None:
            try:
                _auto_build_timer.stop()
            except Exception:
                pass

# ---------------------------------------------------------------------------
# IPTVStopProvidersScreen
# ---------------------------------------------------------------------------

class IPTVStopProvidersScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="640,540"
                title="Stop Integrated Providers" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="600,450"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="36"
                    transparent="1" />
            <ePixmap position="70,488"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="360,488" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,483" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="403,483" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="640,540"
                title="Stop Integrated Providers">
            <widget name="config" position="20,20" size="600,450"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="36" />
            <ePixmap position="70,488"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="360,488" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,483" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="403,483" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    _INTEGRATED_TAGS = sorted(set(v[0] for v in IPTV_PROVIDERS.values() if v[0]))

    def __init__(self, session, master_stop, stopped_tags):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._master_cfg = ConfigYesNo(default=not bool(master_stop))
        self._tag_cfgs   = [(tag, ConfigYesNo(default=(tag not in stopped_tags)))
                             for tag in self._INTEGRATED_TAGS]
        entries  = [getConfigListEntry(T("ALL On/Off"), self._master_cfg)]
        entries += [getConfigListEntry(tag, cfg) for tag, cfg in self._tag_cfgs]
        ConfigListScreen.__init__(self, entries, session=session)
        self.setTitle(T("ALL On/Off"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keySave(self):
        stopped = [tag for tag, cfg in self._tag_cfgs if not cfg.value]
        self.close((not self._master_cfg.value, stopped))


# ---------------------------------------------------------------------------
# IPTVClearProvidersScreen
# ---------------------------------------------------------------------------

class IPTVClearProvidersScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="640,420"
                title="Clear Providers Cache Before Build" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="600,330"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    transparent="1" />
            <ePixmap position="70,368"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="360,368" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,363" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="403,363" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="640,420"
                title="Clear Providers Cache Before Build">
            <widget name="config" position="20,20" size="600,330"
                    scrollbarMode="showOnDemand" font="Regular;26" />
            <ePixmap position="70,368"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="360,368" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,363" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="403,363" size="220,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, clear_indices):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        all_provs   = [p for p in loadPlaylistProviderConfig() if p.get('create_archives')]
        self._named = [(i, p) for i, p in enumerate(all_provs)
                       if (p.get('name') or '').strip()]
        self._cfgs  = [(i, ConfigYesNo(default=(i in clear_indices)))
                       for i, _p in self._named]
        entries = [getConfigListEntry(p.get('name', '').strip(), cfg)
                   for (i, p), (_i, cfg) in zip(self._named, self._cfgs)]
        if not entries:
            entries = [getConfigListEntry(
                T("No providers configured"), ConfigYesNo(default=False))]
        ConfigListScreen.__init__(self, entries, session=session)
        self.setTitle(T("Clear Providers Cache Before Build"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keySave(self):
        indices = [i for (i, _p), (_i, cfg) in zip(self._named, self._cfgs) if cfg.value]
        self.close(indices)


# ---------------------------------------------------------------------------
# IPTVAutoBuildDayPicker
# ---------------------------------------------------------------------------

class IPTVAutoBuildDayPicker(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="560,380"
                title="Auto Build - Choose Days" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="520,280"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    transparent="1" />
            <ePixmap position="50,318"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="275,318" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="93,313"  size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="318,313" size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="560,380"
                title="Auto Build - Choose Days">
            <widget name="config" position="20,20" size="520,280"
                    scrollbarMode="showOnDemand" font="Regular;26" />
            <ePixmap position="50,318"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="275,318" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="93,313"  size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="318,313" size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    _DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday",
                  "Friday", "Saturday", "Sunday"]

    def __init__(self, session, enabled_days):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._day_cfgs = [ConfigYesNo(default=(i in enabled_days)) for i in range(7)]
        entries = [getConfigListEntry(T(d), self._day_cfgs[i])
                   for i, d in enumerate(self._DAY_NAMES)]
        ConfigListScreen.__init__(self, entries, session=session)
        self.setTitle(T("Auto Build - Choose Days"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keySave(self):
        self.close([i for i, c in enumerate(self._day_cfgs) if c.value])

# ---------------------------------------------------------------------------
# IPTVGlobalOffsetDialog
# ---------------------------------------------------------------------------

class IPTVGlobalOffsetDialog(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="560,280"
                title="Global Archive Offset" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="520,180"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    transparent="1" />
            <ePixmap position="50,218"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="275,218" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="93,213"  size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="318,213" size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="560,280"
                title="Global Archive Offset">
            <widget name="config" position="20,20" size="520,180"
                    scrollbarMode="showOnDemand" font="Regular;26" />
            <ePixmap position="50,218"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="275,218" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="93,213"  size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="318,213" size="160,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, sign, abs_sec):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._sign_cfg = ConfigSelection(choices=['+', '-'], default=sign)
        self._abs_cfg  = ConfigInteger(default=abs_sec, limits=(0, 99999))
        entries = [
            getConfigListEntry(T("Archive Start Offset  +/-"),   self._sign_cfg),
            getConfigListEntry(T("Archive Start Offset  (sec)"), self._abs_cfg),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self.setTitle(T("Global Archive Offset"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keySave(self):
        self.close((self._sign_cfg.value, self._abs_cfg.value))


# ---------------------------------------------------------------------------
# _IPTVColorHelpScreen — base class for all color-capable help screens
#
# HOW TO CHANGE COLORS:
#   Each subclass defines COLOR_* constants at the top.
#   Change the hex value there — nothing else needs touching.
#
#   COLOR_HEADER   : section title line          (default yellow  #ffcc00)
#   COLOR_OPTION   : option / field name line    (default white   #ffffff)
#   COLOR_DESC     : description text line       (default grey    #aaaaaa)
#   COLOR_SUBOPT   : indented sub-option name    (default lblue   #88ccff)
#   COLOR_SUBDESC  : indented sub-option desc    (default lgrey   #cccccc)
#   COLOR_SEP      : separator line              (default dgrey   #555555)
#
# ENTRY FORMAT in _SECTIONS:
#   Each entry is a tuple:  (kind, text, description)
#     kind = "header"   → section title block  (COLOR_HEADER)
#     kind = "option"   → normal option        (COLOR_OPTION + COLOR_DESC)
#     kind = "suboption"→ indented sub-option  (COLOR_SUBOPT + COLOR_SUBDESC)
#
# The list is built at __init__ time so T() translations are always live.
# ---------------------------------------------------------------------------



class _IPTVColorHelpScreen(Screen):
    # ── color constants — edit these to restyle the screen ──────────────────
    #   To change a color: edit the hex string below.  DO NOT rename constants.
    #
    #   COLOR_HEADER  : option / section title row        → yellow  #ffcc00
    #   COLOR_DESC    : description text rows             → white   #ffffff
    #   COLOR_SUBOPT  : sub-option name row               → green   #00cc00
    #   COLOR_SUBDESC : sub-option description rows       → white   #ffffff
    # ────────────────────────────────────────────────────────────────────────
    COLOR_HEADER  = "#ffcc00"
    COLOR_DESC    = "#ffffff"
    COLOR_SUBOPT  = "#00cc00"
    COLOR_SUBDESC = "#ffffff"

    _SECTIONS = []
    _TITLE    = "Help"

    _VISIBLE_LINES = 22   # lines visible in the 636px area at font size 22 (~29px/line)
    _PAGE          = 10   # lines moved per page key

    # max chars per line before hard-wrapping — calibrated for Regular;22 in 1240px
    _MAX_CHARS_DESC = 105   # white description lines (4-space indent)
    _MAX_CHARS_SUB  = 100   # sub-option desc lines   (9-space indent)

    @staticmethod
    def _wrap(text, max_chars, indent):
        """
        Split text into lines of at most max_chars chars, preserving word boundaries.
        Continuation lines get the same indent as the first.
        Returns a list of strings.
        """
        words  = text.split()
        lines  = []
        current = indent
        for word in words:
            if current == indent:
                candidate = indent + word
            else:
                candidate = current + u" " + word
            if len(candidate) <= max_chars:
                current = candidate
            else:
                if current != indent:
                    lines.append(current)
                current = indent + word
        if current != indent:
            lines.append(current)
        return lines if lines else [indent]

    _SKIN_T = """
        <screen position="center,center" size="1280,700" title="Help" backgroundColor="#33000000">
            <widget name="col_desc" position="20,10" size="1240,610"
                    zPosition="1"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#ffffff" transparent="1"/>
            <widget name="col_head" position="20,10" size="1240,610"
                    zPosition="2"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="col_sub"  position="20,10" size="1240,610"
                    zPosition="3"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#00cc00" transparent="1"/>
            <widget name="scrollbar" position="20,626" size="1240,20"
                    font="Regular;16" valign="center" halign="left"
                    foregroundColor="#555555" transparent="1"/>
            <eLabel position="0,650" size="1280,2" backgroundColor="#555555"/>
            <widget name="hint" position="20,658" size="1060,34"
                    font="Regular;20" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
            <ePixmap position="1160,658" size="35,25"
                     pixmap="buttons/blue.png" alphaTest="blend"/>
            <widget name="key_blue" position="1196,655" size="100,34"
                    zPosition="4" font="Regular;18" valign="center"
                    halign="left" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1280,700" title="Help">
            <widget name="col_desc" position="20,10" size="1240,610"
                    zPosition="1"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#ffffff" transparent="1"/>
            <widget name="col_head" position="20,10" size="1240,610"
                    zPosition="2"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="col_sub"  position="20,10" size="1240,610"
                    zPosition="3"
                    font="Regular;22" valign="top" halign="left"
                    foregroundColor="#00cc00" transparent="1"/>
            <widget name="scrollbar" position="20,626" size="1240,20"
                    font="Regular;16" valign="center" halign="left"
                    foregroundColor="#555555" transparent="1"/>
            <eLabel position="0,650" size="1280,2" backgroundColor="#555555"/>
            <widget name="hint" position="20,658" size="1060,34"
                    font="Regular;20" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
            <ePixmap position="1160,658" size="35,25"
                     pixmap="buttons/blue.png" alphaTest="blend"/>
            <widget name="key_blue" position="1196,655" size="100,34"
                    zPosition="4" font="Regular;18" valign="center"
                    halign="left" transparent="1"/>
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._lines_h, self._lines_d, self._lines_s = self._buildLines()
        self._total  = len(self._lines_h)
        self._offset = 0
        self["col_head"] = Label(u"")
        self["col_desc"] = Label(u"")
        self["col_sub"]  = Label(u"")
        self["scrollbar"] = Label(u"")
        self["key_blue"] = Button(T("Close"))
        self["hint"]     = Label(
            u"\u25b2\u25bc  " + T("Scroll line") +
            u"   |   LEFT/RIGHT \u2014 " + T("Page") +
            u"   |   BLUE / EXIT \u2014 " + T("Close"))
        self["helpActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {"ok":     self.close,
             "cancel": self.close,
             "blue":   self.close,
             "up":     self._lineUp,
             "down":   self._lineDown,
             "left":   self._pageUp,
             "right":  self._pageDown}, -2)
        self.setTitle(T(self._TITLE))
        self._render()

    def _render(self):
        end = self._offset + self._VISIBLE_LINES
        h = u"\n".join(self._lines_h[self._offset:end])
        d = u"\n".join(self._lines_d[self._offset:end])
        s = u"\n".join(self._lines_s[self._offset:end])
        self["col_head"].setText(h)
        self["col_desc"].setText(d)
        self["col_sub"].setText(s)
        # scrollbar: show position as filled blocks
        max_off = max(1, self._total - self._VISIBLE_LINES)
        bar_w   = 60
        filled  = int(round(bar_w * self._offset / max_off)) if max_off > 0 else 0
        filled  = max(0, min(bar_w, filled))
        arrow   = u""  if self._offset > 0 else u""
        arrow_d = u"  \u25bc more" if end < self._total else u""
        pos_pct = int(100 * self._offset / max_off) if max_off > 0 else 100
        self["scrollbar"].setText(
            u"\u25a0" * filled + u"\u25a1" * (bar_w - filled) +
            u"  %d%%" % pos_pct + arrow_d)

    def _lineUp(self):
        if self._offset > 0:
            self._offset -= 1
            self._render()

    def _lineDown(self):
        if self._offset < self._total - self._VISIBLE_LINES:
            self._offset += 1
            self._render()

    def _pageUp(self):
        self._offset = max(0, self._offset - self._PAGE)
        self._render()

    def _pageDown(self):
        self._offset = min(
            max(0, self._total - self._VISIBLE_LINES),
            self._offset + self._PAGE)
        self._render()

    def _buildLines(self):
        """
        Build three parallel line lists of equal length.
        Every position has a value in exactly one list; the other two are empty.
        Text is word-wrapped to _MAX_CHARS so each logical line = one rendered line,
        preventing the three Label widgets from drifting out of sync.

        h = yellow header lines
        d = white description lines
        s = green sub-option name lines
        """
        h, d, s = [], [], []

        def row(hv=u"", dv=u"", sv=u""):
            h.append(hv)
            d.append(dv)
            s.append(sv)

        for entry in self._SECTIONS:
            kind = entry[0]

            if kind == "option":
                _, name, text = entry
                row()                                           # blank spacer
                row(hv=u"\u25b6  " + T(name))                  # yellow title
                for line in self._wrap(T(text), self._MAX_CHARS_DESC, u"    "):
                    row(dv=line)                               # white desc

            elif kind == "suboption":
                _, name, text = entry
                row(sv=u"      \u25ab " + T(name))              # green name
                for line in self._wrap(T(text), self._MAX_CHARS_SUB, u"         "):
                    row(dv=line)                               # white desc

        return h, d, s


# ---------------------------------------------------------------------------
# IPTVSettingsHelpScreen — "Main Settings Help"
#   opened from the Help Menu (green button on main screen)
#   and still reachable from Blue inside Settings window
#
# TO CHANGE A COLOR: edit the COLOR_* constant below.
# DO NOT rename the COLOR_* constants — _IPTVColorHelpScreen reads them.
# ---------------------------------------------------------------------------

class IPTVSettingsHelpScreen(_IPTVColorHelpScreen):
    # ── colors ───────────────────────────────────────────────────────────────
    COLOR_HEADER  = 0xFFFFCC00   # option / section title   → yellow
    COLOR_DESC    = 0xFFFFFFFF   # description text         → white
    COLOR_SUBOPT  = 0xFF00CC00   # sub-option name          → green
    COLOR_SUBDESC = 0xFFFFFFFF   # sub-option description   → white

    _TITLE = "Main Settings Help"

    # (kind, name [, description])
    # kind: "option" | "suboption"
    # "option"    → yellow title line + separator, then white description lines
    # "suboption" → green name line, then white description lines
    _SECTIONS = [
        ("option",    "Skin Type",
                      "Choose between Transparent and Regular window style. "
                      "Transparent: all plugin windows show a semi-transparent background "
                      "so the live TV is visible through the menus. "
                      "Regular: all plugin windows use a solid opaque background. "
                      "After changing this setting close and reopen the plugin to apply"),

        ("option",    "Player Selection (Also By Provider)",
                      "Press OK to open the player configuration screen. "
                      "Activate or deactivate available players and set per-provider player preferences"),

        ("option",    "Archive Time Offset (By Provider)",
                      "Press OK to set the archive start offset in seconds for each integrated provider. "
                      "Negative values start the archive earlier (e.g. -420 corrects a 7-minute clock drift). "
                      "Positive values start later"),

        ("option",    "Global Archive Offset",
                      "A fallback offset applied to all providers that have no per-provider offset set. "
                      "Use + to start later, - to start earlier"),

        ("option",    "Working Directory Location",
                      "Selects where EPG cache files, XMLTV cache and uploaded M3U files are stored. "
                      "Two folders are always created regardless of your choice. "
                      "First: /etc/CustomIPTVArchiveMakerPro — this is fixed and never changes. "
                      "It holds the plugin settings file (iptv_archive_settings.json), "
                      "the custom providers config (iptv_archive_custom_providers.json) and the log file. "
                      "Second: CustomIPTVArchiveMakerPro inside whichever path you select here — "
                      "for example if you choose /media/hdd the folder /media/hdd/CustomIPTVArchiveMakerPro is created. "
                      "This second folder holds all EPG cache files, XMLTV data and build output. "
                      "If you select /etc both folders are the same single location. "
                      "Use /media/hdd or a USB path to keep large cache files off the internal flash storage"),

        ("option",    "Stop All Integrated Providers",
                      "Press OK to open the integrated provider manager. "
                      "Use this to enable or disable individual built-in operators"),

        ("option",    "Cached Files Parse Type",
                      "Controls how EPG data is fetched and stored. Three modes are available"),
        ("suboption", "Bulk",
                      "One-pass XMLTV parse — all channels for a provider are cached together in a single operation. "
                      "Fastest mode. Recommended when using Create Archives"),
        ("suboption", "Single Channel — On Demand",
                      "One channel is fetched and cached only when you press it. "
                      "Useful for large providers where you only watch a few channels"),
        ("suboption", "M3U Playlist Only",
                      "No XMLTV is fetched and no archive EPG is generated. "
                      "Only playlist channel data is used"),
        ("suboption", "  Find Archives Data From Other Providers",
                      "Sub-option of Bulk/Single modes. "
                      "When your stream owner has no EPG archive data, the plugin searches all other active providers "
                      "for matching archive data. Player selection still follows the original stream owner"),

        ("option",    "Log File",
                      "Enable or disable writing a plugin activity log to disk. "
                      "Useful for diagnosing build or EPG problems"),

        ("option",    "Auto Start Build",
                      "Enable the scheduled automatic EPG cache build. "
                      "When enabled the following sub-options appear"),
        ("suboption", "Choose Days",
                      "Press OK to select which days of the week the automatic build runs. "
                      "You can pick any combination from Monday to Sunday"),
        ("suboption", "Start Time for Start Build",
                      "Set the clock time (HH:MM) at which the automatic build starts each selected day"),
        ("suboption", "Start Build in StandBy",
                      "When enabled the receiver wakes from standby to run the build, "
                      "then returns to standby automatically when the build finishes"),
        ("suboption", "Clear Providers Cached Files Before Build",
                      "Press OK to select which providers have their cache files deleted "
                      "before each automatic build runs. "
                      "Forces a completely fresh fetch for those providers"),
    ]


# ---------------------------------------------------------------------------
# IPTVProviderHelpScreen — "Add/Edit Provider Help"
#   opened from the Help Menu (green button on main screen)
#
# TO CHANGE A COLOR: edit the COLOR_* constant below.
# DO NOT rename the COLOR_* constants — _IPTVColorHelpScreen reads them.
# ---------------------------------------------------------------------------

class IPTVProviderHelpScreen(_IPTVColorHelpScreen):
    # ── colors ───────────────────────────────────────────────────────────────
    COLOR_HEADER  = 0xFFFFCC00   # option / section title   → yellow
    COLOR_DESC    = 0xFFFFFFFF   # description text         → white
    COLOR_SUBOPT  = 0xFF00CC00   # sub-option name          → green
    COLOR_SUBDESC = 0xFFFFFFFF   # sub-option description   → white

    _TITLE = "Add/Edit Provider Help"

    # (kind, name [, description])
    # kind: "option" | "suboption"
    # "option"    → yellow title line + separator, then white description lines
    # "suboption" → green name line, then white description lines
    _SECTIONS = [
        ("option",    "Enabled",
                      "Activates or deactivates this provider entirely. "
                      "When set to No the provider is ignored by all builds and archive lookups"),

        ("option",    "Provider Name",
                      "The display name for this provider shown in all provider lists and menus. "
                      "Choose a short recognisable name"),

        ("option",    "XMLTV URL / Local File",
                      "The source of EPG data for this provider. "
                      "Enter a remote http/https URL or a full local file path on the receiver. "
                      "This file is parsed to build the archive EPG cache"),

        ("option",    "M3U URL / M3U Playlist",
                      "The channel list source for this provider. "
                      "Enter a remote http/https URL pointing to an M3U playlist "
                      "or a full local path to an M3U file already on the receiver. "
                      "Press Yellow to browse the receiver filesystem for a local file"),

        ("option",    "Create EPG File",
                      "Controls whether an EPG file is generated and how channels are matched to EPG entries. "
                      "Three options are available"),
        ("suboption", "Off",
                      "No EPG file is generated for this provider"),
        ("suboption", "By Display Name",
                      "EPG entries are matched to channels using the channel display name from the M3U"),
        ("suboption", "By tvg-id",
                      "EPG entries are matched using the tvg-id tag embedded in the M3U playlist. "
                      "More reliable when display names differ between the playlist and the XMLTV source"),

        ("option",    "Bouquet Creation Strategy",
                      "Determines how Enigma2 bouquets are created from this provider's channel list. "
                      "Four strategies are available"),
        ("suboption", "Same in Playlist",
                      "Mirrors the bouquet and group structure exactly as it appears in the M3U playlist"),
        ("suboption", "Bouquet for All Channels",
                      "Creates one single flat bouquet containing all channels from this provider"),
        ("suboption", "Bouquets for All Channels and Groups",
                      "Creates one bouquet per group found in the M3U, plus one bouquet with all channels"),
        ("suboption", "Bouquet with Provider Name and Sub-Bouquets",
                      "Creates a top-level bouquet named after the provider, "
                      "with group sub-bouquets nested inside it"),

        ("option",    "Playback With",
                      "Sets the default player used to play channels from this provider. "
                      "Available options are GStreamer Player, GstPlayer, ExtEplayer3, and DVB. "
                      "Can be overridden per-provider in the archive section below"),

        ("option",    "Channels Ordering By",
                      "Controls the order in which channels appear in the bouquet. "
                      "Three options are available"),
        ("suboption", "Use Provider Order",
                      "Keeps channels in the exact order they appear in the M3U playlist"),
        ("suboption", "Alphabetically",
                      "Sorts all channels A to Z by display name"),
        ("suboption", "User Defined",
                      "Preserves a manually sorted bouquet order. "
                      "New channels added on subsequent updates are placed according to the sub-option below"),
        ("suboption", "  Update M3U Playlist Only  —  New Channels on Top / Bottom",
                      "Visible only when User Defined is selected. "
                      "New channels discovered in the M3U are inserted at the top or bottom "
                      "of the bouquet without disturbing your existing sorted order"),

        ("option",    "Download Picons",
                      "Enables automatic downloading of channel logo images (picons). "
                      "When set to Yes four sub-options appear"),
        ("suboption", "Naming",
                      "Controls how picon files are named on disk. "
                      "With Display Name uses the channel name. "
                      "With Reference Number uses the Enigma2 service reference"),
        ("suboption", "Mounted Points",
                      "Selects the storage location where picon files are saved. "
                      "The dropdown lists all detected media paths on the receiver"),
        ("suboption", "With Folder",
                      "When enabled picons are saved inside a subfolder rather than directly in the picon directory"),
        ("suboption", "Create Symlink",
                      "Creates a symbolic link alongside each picon file. "
                      "Useful when Enigma2 resolves picon paths differently depending on skin or configuration"),

        ("option",    "Custom EPG File",
                      "Controls whether custom EPG assignments are merged into the provider EPG file. "
                      "When ON: after pressing Create Playlist the custom EPG assignments made in the "
                      "Custom EPG screen are merged into the provider channels XML file. "
                      "Channels assigned to EPG IDs from other sources will show EPG from those sources. "
                      "When OFF: custom EPG assignments are ignored and any existing custom EPG block "
                      "is removed from the EPG sources file"),

        ("option",    "Clean Bouquets",
                      "When set to Yes, all Channels/Bouquets of this provider are removed from the receiver. "
                      "After clicking save, but the provider settings remain. "
                      "This is a one-time action applied on save, not a permanent toggle"),

        ("option",    "Create Provider Archives",
                      "Enables archive and catchup functionality for this provider. "
                      "When set to Yes six sub-options appear"),

        ("suboption", u"Create Archive Markers ( ▶ )",
                      "When set to Yes, a ▶ marker is added before the channel name in the bouquet "
                      "for every channel that has archive support. "
                      "This gives a quick visual indication of which channels have catchup available "
                      "without needing to open the archive player"),

        ("suboption", "Archive Days (1-7)",
                      "How many days back the archive is available for this provider. "
                      "Enter a number from 1 to 7"),
        ("suboption", "TTL Days For Cached Files",
                      "How long cached EPG files for this provider are kept on disk before being refreshed. "
                      "Press OK to choose: Default keeps files for 7 days. "
                      "Custom lets you set any number of days"),
        ("suboption", "Archive Start Offset (+/- sec)",
                      "Press OK to open the offset dialog. "
                      "Enter a time correction in seconds applied when starting archive playback. "
                      "Positive values start the archive later, negative values start earlier. "
                      "You can also enter a stream hostname so the offset only applies "
                      "to streams served from that specific host"),
        ("suboption", "Player Override (Provider-Specific)",
                      "When enabled, overrides the global player setting for archive playback "
                      "from this provider only. "
                      "Three player sub-options then appear"),
        ("suboption", "  Player: Integrated",
                      "Use the built-in integrated archive player for this provider"),
        ("suboption", "  Player: StreamLink",
                      "Use StreamLink to resolve and play archive streams for this provider"),
        ("suboption", "  Player: Receiver",
                      "Use the receiver's native DVB player for archive streams from this provider"),
        ("suboption", "Clear Cache on Save",
                      "When set to Yes, all cached EPG files for this provider are deleted immediately "
                      "when you press Save. "
                      "The next build will fetch everything fresh from the source"),
    ]


# ---------------------------------------------------------------------------
# IPTVHelpMenuScreen — opened by GREEN "Help" button on the main screen.
#   Shows a two-item menu.  OK opens the chosen help screen.
# ---------------------------------------------------------------------------

class IPTVHelpMenuScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="700,280"
                title="Help" backgroundColor="#33000000">
            <widget name="menu" position="30,30" size="640,160"
                    scrollbarMode="showNever"
                    font="Regular;30" itemHeight="70" transparent="1"/>
            <eLabel position="0,202" size="700,2" backgroundColor="#555555"/>
            <widget name="hint" position="30,214" size="640,46"
                    font="Regular;18" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="700,280"
                title="Help">
            <widget name="menu" position="30,30" size="640,160"
                    scrollbarMode="showNever"
                    font="Regular;30" itemHeight="70"/>
            <eLabel position="0,202" size="700,2" backgroundColor="#555555"/>
            <widget name="hint" position="30,214" size="640,46"
                    font="Regular;18" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
        </screen>"""
    skin    = _SKIN_T


    _ITEMS = [
        ("Main Settings Help",    "settings"),
        ("Add/Edit Provider Help", "provider"),
    ]

    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("Help"))
        self["menu"] = MenuList([(T(lbl), key) for lbl, key in self._ITEMS])
        self["hint"] = Label(u"OK \u2014 " + T("Open") +
                             u"   |   EXIT \u2014 " + T("Close"))
        self["hmActions"] = ActionMap(
            ["OkCancelActions", "DirectionActions"],
            {"ok":     self._keyOk,
             "cancel": self.close,
             "up":     lambda: self["menu"].up(),
             "down":   lambda: self["menu"].down()}, -1)

    def _keyOk(self):
        sel = self["menu"].getCurrent()
        if not sel:
            return
        key = sel[1]
        if key == "settings":
            self.session.open(IPTVSettingsHelpScreen)
        elif key == "provider":
            self.session.open(IPTVProviderHelpScreen)


# ---------------------------------------------------------------------------
# IPTVProviderPerPlayerScreen — per-provider ON/OFF list for one player type
# ---------------------------------------------------------------------------

_ALL_INTEGRATED_TAGS = sorted(set(v[0] for v in IPTV_PROVIDERS.values() if v[0]))


class IPTVProviderPerPlayerScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="640,560"
                title="Provider Player Settings" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="600,480"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40"
                    transparent="1" />
            <ePixmap position="70,508"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="370,508" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,503" size="230,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="413,503" size="230,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="640,560"
                title="Provider Player Settings">
            <widget name="config" position="20,20" size="600,480"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" />
            <ePixmap position="70,508"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="370,508" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,503" size="230,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="413,503" size="230,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, prov_type, current_cfg, default_on):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        if prov_type == 'custom':
            names = [p.get('name', '').strip()
                     for p in loadPlaylistProviderConfig()
                     if p.get('create_archives') and p.get('name', '').strip()]
            title = T("Custom Added Providers")
        else:
            names = _ALL_INTEGRATED_TAGS
            title = T("Integrated Providers")
        self.setTitle(title)
        self._cfgs = [(name, ConfigYesNo(default=bool(
                            current_cfg.get(str(name), default_on))))
                      for name in names]
        entries = [getConfigListEntry(name, cfg) for name, cfg in self._cfgs]
        if not entries:
            entries = [getConfigListEntry(T("(none configured)"),
                                          ConfigYesNo(default=False))]
        ConfigListScreen.__init__(self, entries, session=session)
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.keySave, "green": self.keySave,
             "cancel": lambda: self.close(None), "red": lambda: self.close(None)}, -2)

    def keySave(self):
        self.close({name: cfg.value for name, cfg in self._cfgs})


# ---------------------------------------------------------------------------
# IPTVPlayerSelectionScreen — master player config with collapsible sections
# ---------------------------------------------------------------------------

class IPTVPlayerSelectionScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="760,580"
                title="Player Selection (Also By Provider)" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="720,500"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40"
                    transparent="1" />
            <ePixmap position="70,528"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="420,528" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,523" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="463,523" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="760,580"
                title="Player Selection (Also By Provider)">
            <widget name="config" position="20,20" size="720,500"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" />
            <ePixmap position="70,528"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="420,528" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,523" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="463,523" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, player_config):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._cfg = dict(player_config)
        self.setTitle(T("Player Selection (Also By Provider)"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))

        # ── Global master switches ──────────────────────────────────────────
        self._cfg_int = ConfigYesNo(default=bool(self._cfg.get('int_on', True)))
        self._cfg_sl  = ConfigYesNo(default=bool(self._cfg.get('sl_on',  False)))
        self._cfg_rec = ConfigYesNo(default=bool(self._cfg.get('rec_on', False)))
        self._cfg_sl_port = ConfigInteger(
            default=int(self._cfg.get('sl_port', 8088)), limits=(1, 65535))

        # ── Xtream Media dedicated toggles (one per player) ─────────────────
        self._cfg_int_xtream = ConfigYesNo(default=bool(self._cfg.get('int_xtream_on', True)))
        self._cfg_sl_xtream  = ConfigYesNo(default=bool(self._cfg.get('sl_xtream_on',  True)))
        self._cfg_rec_xtream = ConfigYesNo(default=bool(self._cfg.get('rec_xtream_on', False)))

        # ── Integrated providers: sentinel labels → open per-tag sub-screen ─
        # Custom providers follow the global master switch only — no sub-row.
        self._int_int_ref = self._sl_int_ref = self._rec_int_ref = None

        ConfigListScreen.__init__(self, [], session=session)
        self["settingsActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions"],
            {"ok": self.keyOK, "save": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

        self._cfg_int.addNotifier(self._rebuild, initial_call=False)
        self._cfg_sl.addNotifier(self._rebuild,  initial_call=False)
        self._cfg_rec.addNotifier(self._rebuild, initial_call=False)
        self._rebuild()

    def _intCountLabel(self, player_key):
        per     = self._cfg.get('%s_integrated' % player_key, {})
        names   = _ALL_INTEGRATED_TAGS
        default = False
        if not names:
            return T("(none configured)")
        on = sum(1 for n in names if per.get(str(n), default))
        return T("%d of %d enabled") % (on, len(names))

    def _sentinel(self, label):
        return ConfigSelection(choices=[label], default=label)

    def _rebuild(self, *args):
        entries = [getConfigListEntry(T("Plugin Integrated Player"), self._cfg_int)]
        if self._cfg_int.value:
            self._int_int_ref = self._sentinel(self._intCountLabel('int'))
            entries.append(
                getConfigListEntry(T("  Integrated Providers"), self._int_int_ref))
        else:
            self._int_int_ref = None

        entries.append(getConfigListEntry(T("StreamLinkProxy Player"), self._cfg_sl))
        if self._cfg_sl.value:
            self._sl_int_ref = self._sentinel(self._intCountLabel('sl'))
            entries += [
                getConfigListEntry(T("  StreamLinkProxy Port"), self._cfg_sl_port),
                getConfigListEntry(T("  Integrated Providers"), self._sl_int_ref),
            ]
        else:
            self._sl_int_ref = None

        entries.append(getConfigListEntry(T("Receiver (Enigma2) Player"), self._cfg_rec))
        if self._cfg_rec.value:
            self._rec_int_ref = self._sentinel(self._intCountLabel('rec'))
            entries.append(
                getConfigListEntry(T("  Integrated Providers"), self._rec_int_ref))
        else:
            self._rec_int_ref = None

        # ── Xtream Media toggles — always visible, independent of parent ─────
        entries.append(getConfigListEntry(T("Xtream: Integrated Player"), self._cfg_int_xtream))
        entries.append(getConfigListEntry(T("Xtream: StreamLink Player"),  self._cfg_sl_xtream))
        entries.append(getConfigListEntry(T("Xtream: Receiver Player"),    self._cfg_rec_xtream))

        self["config"].setList(entries)

    def keyOK(self):
        cur = self["config"].getCurrent()
        if cur is None:
            ConfigListScreen.keyOK(self)
            return
        ref = cur[1]
        # Only the integrated-provider sentinel rows open a sub-screen.
        # Custom rows are plain ConfigYesNo and are toggled by ConfigListScreen.
        for player_key, int_ref in [
            ('int', self._int_int_ref),
            ('sl',  self._sl_int_ref),
            ('rec', self._rec_int_ref),
        ]:
            if int_ref is not None and ref is int_ref:
                self._openIntSub(player_key)
                return
        ConfigListScreen.keyOK(self)

    def _openIntSub(self, player_key):
        cfg_key = '%s_integrated' % player_key
        current = self._cfg.get(cfg_key, {})
        self.session.openWithCallback(
            lambda result, k=cfg_key: self._onSubClosed(result, k),
            IPTVProviderPerPlayerScreen, 'integrated', current, False)

    def _onSubClosed(self, result, cfg_key):
        if result is not None:
            self._cfg[cfg_key] = result
        self._rebuild()

    def keySave(self):
        self._cfg['int_on']        = self._cfg_int.value
        self._cfg['sl_on']         = self._cfg_sl.value
        self._cfg['rec_on']        = self._cfg_rec.value
        self._cfg['sl_port']       = self._cfg_sl_port.value
        self._cfg['int_xtream_on'] = self._cfg_int_xtream.value
        self._cfg['sl_xtream_on']  = self._cfg_sl_xtream.value
        self._cfg['rec_xtream_on'] = self._cfg_rec_xtream.value
        self.close(self._cfg)


# ---------------------------------------------------------------------------
# IPTVArchiveOffsetScreen — per-integrated-provider archive start time offset
# ---------------------------------------------------------------------------

class IPTVArchiveOffsetScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="900,620"
                title="Archive Time Offset" backgroundColor="#33000000">
            <widget name="config" position="10,10" size="880,530"
                    scrollbarMode="showOnDemand" font="Regular;24"
                    transparent="1" />
            <widget name="hint" position="10,545" size="880,34"
                    font="Regular;18" halign="center" foregroundColor="#aaaaaa"
                    transparent="1" />
            <ePixmap position="72,590"  size="35,25" pixmap="buttons/red.png"   alphaTest="blend" />
            <ePixmap position="384,590" size="35,25" pixmap="buttons/green.png" alphaTest="blend" />
            <widget name="key_red"   position="115,584" size="230,40" zPosition="1"
                    font="Regular;18" valign="center" halign="left" transparent="1" />
            <widget name="key_green" position="427,584" size="230,40" zPosition="1"
                    font="Regular;18" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="900,620"
                title="Archive Time Offset">
            <widget name="config" position="10,10" size="880,530"
                    scrollbarMode="showOnDemand" font="Regular;24" />
            <widget name="hint" position="10,545" size="880,34"
                    font="Regular;18" halign="center" foregroundColor="#aaaaaa"
                    transparent="1" />
            <ePixmap position="72,590"  size="35,25" pixmap="buttons/red.png"   alphaTest="blend" />
            <ePixmap position="384,590" size="35,25" pixmap="buttons/green.png" alphaTest="blend" />
            <widget name="key_red"   position="115,584" size="230,40" zPosition="1"
                    font="Regular;18" valign="center" halign="left" transparent="1" />
            <widget name="key_green" position="427,584" size="230,40" zPosition="1"
                    font="Regular;18" valign="center" halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, current_offsets):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("Archive Time Offset (seconds, per integrated provider)"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self["hint"]      = Label(T("Negative = start earlier  (e.g. -420 corrects a 7-minute clock drift)"))

        self._offsets = dict(current_offsets)
        # Two rows per provider tag: sign (+/-) then absolute value in seconds
        _tags = sorted(set(tag for tag, _ in IPTV_PROVIDERS.values() if tag))
        self._tag_sign_cfgs = {}
        self._tag_abs_cfgs  = {}
        entries = []
        for tag in _tags:
            raw      = int(self._offsets.get(tag, 0) or 0)
            sign_cfg = ConfigSelection(choices=['+', '-'],
                                       default='+' if raw >= 0 else '-')
            abs_cfg  = ConfigInteger(default=abs(raw), limits=(0, 99999))
            self._tag_sign_cfgs[tag] = sign_cfg
            self._tag_abs_cfgs[tag]  = abs_cfg
            entries.append(getConfigListEntry(T("%s  +/-") % tag,      sign_cfg))
            entries.append(getConfigListEntry(T("%s  sec") % tag,       abs_cfg))

        ConfigListScreen.__init__(self, entries, session=session)
        self["settingsActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions"],
            {"ok": self.keyOK, "save": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keyOK(self):
        ConfigListScreen.keyOK(self)

    def keySave(self):
        result = {}
        for tag in self._tag_sign_cfgs:
            abs_val = self._tag_abs_cfgs[tag].value
            sign    = self._tag_sign_cfgs[tag].value
            val     = abs_val if sign == '+' else -abs_val
            if val != 0:
                result[tag] = val
        self.close(result)


# ---------------------------------------------------------------------------
# IPTVArchivePluginSettings
# ---------------------------------------------------------------------------

class IPTVArchivePluginSettings(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="1036,564"
                title="Custom IPTV MakerPro Settings" backgroundColor="#33000000">
            <widget name="config" position="30,30" size="970,437"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="36" transparent="1" />
            <widget name="description" position="30,485" size="970,34"
                    font="Regular;20" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1" />
            <!-- Green / Yellow / Red / Blue across the 1036 px window -->
            <eLabel position="0,518" size="1036,1" backgroundColor="#00aa00"/>
            <eLabel position="0,563" size="1036,1" backgroundColor="#00aa00"/>
            <ePixmap position="72,528"  size="35,25"
                     pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="302,528" size="35,25"
                     pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="580,528" size="35,25"
                     pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="840,528" size="35,25"
                     pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_green"  position="115,523" size="165,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_yellow" position="345,523" size="210,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"    position="623,523" size="190,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_blue"   position="883,523" size="146,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1036,564"
                title="Custom IPTV MakerPro Settings">
            <widget name="config" position="30,30" size="970,437"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="36" />
            <widget name="description" position="30,485" size="970,34"
                    font="Regular;20" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1" />
            <!-- Green / Yellow / Red / Blue across the 1036 px window -->
            <eLabel position="0,518" size="1036,1" backgroundColor="#00aa00"/>
            <eLabel position="0,563" size="1036,1" backgroundColor="#00aa00"/>
            <ePixmap position="72,528"  size="35,25"
                     pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="302,528" size="35,25"
                     pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="580,528" size="35,25"
                     pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="840,528" size="35,25"
                     pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_green"  position="115,523" size="165,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" />
            <widget name="key_yellow" position="345,523" size="210,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" />
            <widget name="key_red"    position="623,523" size="190,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" />
            <widget name="key_blue"   position="883,523" size="146,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" />
        </screen>"""
    skin    = _SKIN_T


    _PARSE_TYPES = [
        ('bulk',   "Bulk — All Channels at Once"),
        ('single', "Single Channel — On Demand"),
        ('m3u',    "M3U Playlist Only"),
    ]

    _DAY_SHORT = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._settings           = loadPluginSettings()
        self._enabled_days       = list(self._settings.get('auto_build_days', list(range(7))))
        self._clear_prov_indices = list(self._settings.get('auto_build_clear_providers', []))
        self._stop_master        = bool(self._settings.get('stop_integrated_providers', False))
        self._stopped_tags       = list(self._settings.get('stopped_provider_tags', []))
        self._days_cfg_ref       = None
        self._stop_int_cfg_ref   = None
        self._clear_cfg_ref      = None

        self._player_cfg         = dict(self._settings.get('player_config', {}))
        self._player_cfg_ref     = None
        self._archive_offsets    = dict(self._settings.get('archive_offsets', {}))
        self._archive_offset_ref = None
        _media_paths       = _detectMediaPaths()
        _saved_work_dir    = self._settings.get('work_dir', '/etc')
        if _saved_work_dir not in _media_paths:
            _media_paths.insert(0, _saved_work_dir)
        self._cfg_work_dir = ConfigSelection(
            choices=[(p, p) for p in _media_paths],
            default=_saved_work_dir)
        _saved_parse = self._settings.get('parse_type', 'bulk')
        _pt_choices  = [(v, T(l)) for v, l in self._PARSE_TYPES]
        _pt_default  = _saved_parse if any(v == _saved_parse for v, _ in _pt_choices) else 'bulk'
        self._cfg_parse_type = ConfigSelection(choices=_pt_choices, default=_pt_default)
        self._cfg_fallback_epg = ConfigYesNo(
            default=bool(self._settings.get('fallback_providers_epg', True)))
        self._cfg_auto     = ConfigYesNo(default=self._settings.get('auto_build_enabled', False))
        _h = int(self._settings.get('auto_build_time_h', 3))
        _m = int(self._settings.get('auto_build_time_m', 0))
        self._cfg_time     = ConfigClock(default=int(time.mktime((2000, 1, 1, _h, _m, 0, 0, 0, -1))))
        self._cfg_standby  = ConfigYesNo(default=self._settings.get('auto_build_standby', False))
        self._cfg_language = ConfigSelection(
            choices=['ENG', 'RUS'],
            default=self._settings.get('ui_language', 'ENG'))
        self._cfg_skin_type = ConfigSelection(
            choices=[('transparent', T('Transparent')),
                     ('regular',     T('Regular'))],
            default=self._settings.get('skin_type', 'transparent'))
        _raw_global = int(self._settings.get('global_archive_offset', 0) or 0)
        self._global_offset_sign = '+' if _raw_global >= 0 else '-'
        self._global_offset_abs  = abs(_raw_global)

        ConfigListScreen.__init__(self, [], session=session)
        self.setTitle(T("Custom IPTV MakerPro Settings") + "  v" + PLUGIN_VERSION)
        self["key_green"]   = Button(T("Save"))
        self["key_yellow"]  = Button(T("Refresh"))
        self["key_red"]     = Button(T("Cancel"))
        self["key_blue"]    = Button(T("Settings Help"))
        self["description"] = Label("")

        self["settingsActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions"],
            {"ok": self.keyOK, "save": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close,
             "yellow": self.keyRefreshCaches,
             "blue": self.keyHelp}, -2)

        self._cfg_auto.addNotifier(self._rebuildList, initial_call=False)
        self._rebuildList()

    def _daysLabel(self):
        d = sorted(self._enabled_days)
        if not d:        return T("No days selected")
        if len(d) == 7:  return T("Every day")
        return ",  ".join(self._DAY_SHORT[i] for i in d)

    def _stopIntLabel(self):
        if self._stop_master:
            return T("All Integrated Providers: OFF")
        if self._stopped_tags:
            return T("%d stopped") % len(self._stopped_tags)
        return T("All Integrated Providers: ON")

    def _clearLabel(self):
        n = len(self._clear_prov_indices)
        return (T("%d providers") % n) if n else T("None selected")

    def _offsetLabel(self):
        n = sum(1 for v in self._archive_offsets.values() if v != 0)
        return (T("%d providers with offset") % n) if n else T("None set")

    def _playerLabel(self):
        cfg   = self._player_cfg
        parts = []
        if cfg.get('int_on', True):
            parts.append(T("Integrated"))
        if cfg.get('sl_on', False):
            parts.append(T("Streamlink"))
        if cfg.get('rec_on', False):
            parts.append(T("Receiver"))
        return ", ".join(parts) if parts else T("(none active)")

    def _globalOffsetLabel(self):
        sign = getattr(self, '_global_offset_sign', '+')
        sec  = getattr(self, '_global_offset_abs',  0)
        return '%s%d sec' % (sign, sec)

    def _rebuildList(self, element=None):
        days_cfg       = ConfigSelection(choices=[self._daysLabel()],          default=self._daysLabel())
        stop_int_cfg   = ConfigSelection(choices=[self._stopIntLabel()],        default=self._stopIntLabel())
        clear_cfg      = ConfigSelection(choices=[self._clearLabel()],          default=self._clearLabel())
        player_cfg     = ConfigSelection(choices=[self._playerLabel()],         default=self._playerLabel())
        offset_cfg     = ConfigSelection(choices=[self._offsetLabel()],         default=self._offsetLabel())
        global_off_cfg = ConfigSelection(choices=[self._globalOffsetLabel()],   default=self._globalOffsetLabel())
        self._days_cfg_ref       = days_cfg
        self._stop_int_cfg_ref   = stop_int_cfg
        self._clear_cfg_ref      = clear_cfg
        self._player_cfg_ref     = player_cfg
        self._archive_offset_ref = offset_cfg
        self._global_offset_ref  = global_off_cfg
        _log_enabled = bool(self._settings.get('log_enabled', True))
        self._cfg_log = ConfigYesNo(default=_log_enabled)
        _Y = "#ffcc00"
        entries = [
            getConfigListEntry(T("Skin Type"),                                                                  self._cfg_skin_type,        None, _Y),
            # Language entry hidden — plugin follows system language automatically
            getConfigListEntry(T("Player Selection (Also By Provider)"),                               player_cfg,                 None, _Y),
            getConfigListEntry(T("Archive Time Offset (By Provider)"),                                 offset_cfg,            None, _Y),
            getConfigListEntry(T("Global Archive Offset  (%s)") % self._globalOffsetLabel(),           global_off_cfg,        None, _Y),
            getConfigListEntry(T("Working Directory Location"),                                        self._cfg_work_dir,    None, _Y),
            getConfigListEntry(T("All Integrated Providers"),                                           stop_int_cfg,          None, _Y),
            getConfigListEntry(T("Cached Files Parse Type"),                                           self._cfg_parse_type,  None, _Y),
            getConfigListEntry(T("  Find Archives Data From Other Providers"),                         self._cfg_fallback_epg),
            getConfigListEntry(T("Log File"),                                                          self._cfg_log,         None, _Y),
            getConfigListEntry(T("Auto Start Build"),                                                  self._cfg_auto,        None, _Y),
        ]
        if self._cfg_auto.value:
            entries += [
                getConfigListEntry(T("  Choose Days  (%s)") % self._daysLabel(), days_cfg),
                getConfigListEntry(T("  Start Time for Start Build"),             self._cfg_time),
                getConfigListEntry(T("  Start Build in StandBy"),                 self._cfg_standby),
                getConfigListEntry(
                    T("  Clear Providers Cached Files Before Build"),             clear_cfg),
            ]
        self["config"].setList(entries)
        self._updateDescription()

    def _updateDescription(self, *args):
        cur = self["config"].getCurrent()
        if not cur:
            self["description"].setText(""); return
        cfg = cur[1]
        if cfg is self._player_cfg_ref:
            self["description"].setText(T("Press OK to configure which players are active and per-provider settings"))
        elif cfg is self._archive_offset_ref:
            self["description"].setText(T("Press OK to set the archive start offset in seconds per integrated provider (negative = start earlier, e.g. -420 corrects a 7-minute clock drift)"))
        elif cfg is getattr(self, '_global_offset_ref', None):
            self["description"].setText(T("Global offset applied when no per-provider offset is set (+ = start later,  - = start earlier)"))
        elif cfg is getattr(self, '_cfg_log', None):
            self["description"].setText(T("Enable or disable writing a log file for this plugin"))
        elif cfg is self._cfg_work_dir:
            self["description"].setText(T("Where EPG cache and XMLTV files are stored.  Settings always stay in /etc.  Press Blue for help."))
        elif cfg is self._stop_int_cfg_ref:
            self["description"].setText(T("Press OK to manage which built-in operators are active"))
        elif cfg is self._cfg_parse_type:
            self["description"].setText(T("Bulk: one-pass XMLTV parse, all channels cached at once — fastest, use with Start Build.  Single: one channel fetched on demand each press.  M3U: no XMLTV, no archive EPG — playlist data only."))
        elif cfg is getattr(self, '_cfg_fallback_epg', None):
            self["description"].setText(T("A provider is matched to your channel by URL — it recognises the stream URL and is confirmed as the stream owner. If enabled and the stream owner has no EPG data, the plugin searches other providers for archive data — player selection still follows the stream owner"))
        elif cfg is self._cfg_auto:
            self["description"].setText(T("Enable scheduled automatic EPG cache build"))
        elif cfg is self._days_cfg_ref:
            self["description"].setText(T("Press OK to select which days of the week the build runs"))
        elif cfg is self._cfg_time:
            self["description"].setText(T("Set the time (HH:MM) when the automatic build starts"))
        elif cfg is self._cfg_standby:
            self["description"].setText(T("Wake from standby to build,  then return to standby when done"))
        elif cfg is self._clear_cfg_ref:
            self["description"].setText(T("Press OK to select which providers' cache files are cleared before each build"))
        elif cfg is getattr(self, '_cfg_language', None):
            self["description"].setText(T("Select language for all plugin menus and messages (ENG or RUS)"))
        else:
            self["description"].setText("")

    def keyHelp(self):
        self.session.open(IPTVSettingsHelpScreen)

    def keyOK(self):
        cur = self["config"].getCurrent()
        if cur and cur[1] is self._player_cfg_ref:
            self.session.openWithCallback(
                self._onPlayerSelectionClosed,
                IPTVPlayerSelectionScreen, dict(self._player_cfg))
            return
        if cur and cur[1] is self._archive_offset_ref:
            self.session.openWithCallback(
                self._onArchiveOffsetClosed,
                IPTVArchiveOffsetScreen, dict(self._archive_offsets))
            return
        if cur and cur[1] is self._global_offset_ref:
            self.session.openWithCallback(
                self._onGlobalOffsetClosed,
                IPTVGlobalOffsetDialog,
                self._global_offset_sign, self._global_offset_abs)
            return
        if cur and cur[1] is self._days_cfg_ref:
            self.session.openWithCallback(self._onDayPickerClosed,
                                          IPTVAutoBuildDayPicker, list(self._enabled_days))
            return
        if cur and cur[1] is self._stop_int_cfg_ref:
            self.session.openWithCallback(self._onStopProvidersClosed,
                                          IPTVStopProvidersScreen,
                                          self._stop_master, list(self._stopped_tags))
            return
        if cur and cur[1] is self._clear_cfg_ref:
            self.session.openWithCallback(self._onClearProvidersClosed,
                                          IPTVClearProvidersScreen,
                                          list(self._clear_prov_indices))
            return
        ConfigListScreen.keyOK(self)
        self._updateDescription()

    def _onPlayerSelectionClosed(self, result=None):
        if result is not None:
            self._player_cfg = result
        self._rebuildList()

    def _onArchiveOffsetClosed(self, result=None):
        if result is not None:
            self._archive_offsets = result
        self._rebuildList()

    def _onGlobalOffsetClosed(self, result=None):
        if result is not None:
            self._global_offset_sign, self._global_offset_abs = result
        self._rebuildList()

    def _onDayPickerClosed(self, selected=None):
        if selected is not None:
            self._enabled_days = selected
        self._rebuildList()

    def _onStopProvidersClosed(self, result=None):
        if result is not None:
            self._stop_master, self._stopped_tags = result
        self._rebuildList()

    def _onClearProvidersClosed(self, result=None):
        if result is not None:
            self._clear_prov_indices = result
        self._rebuildList()

    def keyRefreshCaches(self):
        try:
            _provider_cache.clear()
        except Exception:
            pass
        self.session.open(
            MessageBox,
            T("In-memory cache cleared.\n"
              "The next time you open an archive programme guide,\n"
              "data will be re-read from the cached files on disk."),
            type=MessageBox.TYPE_INFO, timeout=5)

    def keySave(self):
        _old_lang = self._settings.get('ui_language', 'ENG')
        self._settings['player_config']              = dict(self._player_cfg)
        self._settings['archive_offsets']            = dict(self._archive_offsets)
        self._settings['log_enabled']                = getattr(self, '_cfg_log', ConfigYesNo(default=True)).value
        self._settings['work_dir']                   = self._cfg_work_dir.value
        self._settings['stop_integrated_providers']  = self._stop_master
        self._settings['stopped_provider_tags']      = list(self._stopped_tags)
        self._settings['parse_type']                 = self._cfg_parse_type.value
        self._settings['fallback_providers_epg']     = self._cfg_fallback_epg.value
        self._settings['auto_build_enabled']         = self._cfg_auto.value
        self._settings['auto_build_days']            = list(self._enabled_days)
        _th, _tm = self._cfg_time.value
        self._settings['auto_build_time_h']          = _th
        self._settings['auto_build_time_m']          = _tm
        self._settings['auto_build_standby']         = self._cfg_standby.value
        self._settings['auto_build_clear_cache']     = len(self._clear_prov_indices) > 0
        self._settings['auto_build_clear_providers'] = list(self._clear_prov_indices)
        self._settings['ui_language']                = self._cfg_language.value
        _old_skin = self._settings.get('skin_type', 'transparent')
        self._settings['skin_type']                  = self._cfg_skin_type.value
        self._settings['global_archive_offset'] = (
            self._global_offset_abs if self._global_offset_sign == '+' else -self._global_offset_abs)
        savePluginSettings(self._settings)
        _archive_offset_cache.clear()
        _lang_changed = (_old_lang != self._cfg_language.value)
        _skin_changed = (_old_skin != self._cfg_skin_type.value)
        if _lang_changed or _skin_changed:
            self.session.openWithCallback(
                lambda _ret: self.close(),
                MessageBox,
                T("Settings changed. Please close and reopen the plugin to apply."),
                type=MessageBox.TYPE_INFO,
                timeout=6)
        else:
            self.close()



# ===========================================================================
# CustomEPGScreen — Custom EPG source manager (ported from JediEPGXtream)
# ===========================================================================

# ---------------------------------------------------------------------------
# CustomEPGHelpScreen — "EPG Module Help"
#   opened from Blue button in CustomEPGScreen when cursor is in Bouquets list
# ---------------------------------------------------------------------------

class CustomEPGHelpScreen(_IPTVColorHelpScreen):
    COLOR_HEADER  = 0xFFFFCC00
    COLOR_DESC    = 0xFFFFFFFF
    COLOR_SUBOPT  = 0xFF00CC00
    COLOR_SUBDESC = 0xFFFFFFFF

    _TITLE = "EPG Module Help"

    _SECTIONS = [
        ("option", "Editing the EPG program.",
                   "The ability to add a TV program from any EPG link to a selected channel from a given provider. "
                   "It also has a web interface, which works quickly; the plugin can be a bit slow. "
                   "If \"Custom EPG\" is enabled in the provider settings, then after clicking the red \"Create Playlist\" button, "
                   "all changes will be saved to the XML file for epgimport. "
                   "If \"Custom EPG\" is disabled, it will function as usual, without any changes."),

        ("option", "",
                   "Working files are created in the folder CustomIPTVArchiveMakerPro\\Custom EPG Sources. "
                   "From there, changes are made to the XML file for epgimport at /etc/epgimport and /etc/epgimport/CustomIPTV. "
                   "After changes, the names of the EPGs from which the changes were made will appear in the "
                   "/etc/epgimport/CustomIPTV.sources.xml file. "
                   "These names must be enabled in the epgimport plugin for the TV programs to appear."),

        ("option", "",
                   "This function's window is opened from the provider list menu by clicking the EPG button on the selected "
                   "provider for the channel you want to change. "
                   "After opening the window, the program will automatically download and process the EPG link for this provider. "
                   "You can also add other EPG links there, but after adding them, you will need to click the "
                   "yellow button to download and process the file."),

        ("option", "",
                   "The \"EPG Selection\" section displays only the channels of the selected source in the \"EPG Sources\" section. "
                   "The functions of the colored buttons change depending on the section where the cursor is currently located, "
                   "offering many filtering and sorting options."),

        ("option", "",
                   "The channel recognition feature displays up to 40 options, if that's the case. "
                   "Be careful and select the desired channel to assign to the channel you've selected. "
                   "For example, if the channel recognition feature doesn't find the channel you're looking for, "
                   "but you're sure the EPG source has it, you can use your preferred sorting and channel display mode "
                   "in the \"EPG Selection\" section, manually find the channel, and apply the assignments to the selected channel. "
                   "The green \"Show Assigned\" button opens a new window displaying the results with all the changes you've made."),
    ]


class CustomEPGSummaryScreen(Screen):
    """Read-only summary of all assigned EPG channels for a provider."""

    _SKIN_T = """<screen position="center,center" size="1536,816"
                 title="" backgroundColor="#33000000">
        <widget name="title_lbl" position="10,10"  size="1516,40"
                font="Regular;29" valign="center" foregroundColor="#ffcc00" transparent="1"/>
        <widget name="hdr_num"   position="10,56"  size="55,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_ch"    position="70,56"  size="480,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_epg"   position="570,56" size="560,32"
                font="Regular;27" valign="center" halign="left" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_src"   position="1140,56" size="386,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget source="rows" render="Listbox" enableWrapAround="1"
                position="10,96" size="1516,672"
                secondForegroundColor="#aaaaaa" secondBackgroundColor="#00000000"
                backgroundColor="#00000000" transparent="1">
            <convert type="TemplatedMultiContent">
                {"template": [
                    MultiContentEntryText(pos=(0,0),   size=(55,49),  font=0, color=0x00ffffff, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                    MultiContentEntryText(pos=(60,0),  size=(490,49), font=0, color=0x00e8e8e8, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                    MultiContentEntryText(pos=(560,0), size=(560,49), font=0, color=0x00ffcc00, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=2),
                    MultiContentEntryText(pos=(1130,0), size=(386,49), font=0, color=0x0087ceeb, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=3)],
                 "fonts": [gFont("Regular",26)],
                 "itemHeight": 49, "scrollbarMode": "showOnDemand"}
            </convert>
        </widget>
        <!-- Info bar: two green lines with Exit + Bouquet name between -->
        <eLabel position="0,767"  size="1536,2" backgroundColor="#00aa00"/>
        <eLabel position="0,815"  size="1536,2" backgroundColor="#00aa00"/>
        <widget name="key_red"       position="10,771"  size="140,42"
                font="Regular;26" valign="center" halign="left" transparent="1"/>
        <widget name="bouquet_label"  position="155,771" size="125,42"
                font="Regular;26" valign="center" halign="right"
                foregroundColor="#e94560" transparent="1"/>
        <widget name="bouquet_val"    position="283,771" size="360,42"
                font="Regular;26" valign="center" halign="left"
                foregroundColor="#ffcc00" transparent="1"/>
        <widget name="epgname_label"  position="660,771" size="235,42"
                font="Regular;26" valign="center" halign="right"
                foregroundColor="#e94560" transparent="1"/>
        <widget name="epgname_val"    position="898,771" size="630,42"
                font="Regular;26" valign="center" halign="left"
                foregroundColor="#ffcc00" transparent="1"/>
        <!-- Hide theme hotkey buttons -->
        <widget name="key_yellow" position="-200,0" size="1,1" transparent="1"/>
        <widget name="key_blue" position="-200,0" size="1,1" transparent="1"/>
    </screen>"""
    _SKIN_R = """<screen position="center,center" size="1536,816"
                 title="" backgroundColor="#1a1a2e">
        <widget name="title_lbl" position="10,10"  size="1516,40"
                font="Regular;29" valign="center" foregroundColor="#ffcc00" transparent="1"/>
        <widget name="hdr_num"   position="10,56"  size="20,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_ch"    position="36,56"  size="514,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_epg"   position="570,56" size="560,32"
                font="Regular;27" valign="center" halign="left" foregroundColor="#e94560" transparent="1"/>
        <widget name="hdr_src"   position="1140,56" size="386,32"
                font="Regular;27" valign="center" foregroundColor="#e94560" transparent="1"/>
        <widget source="rows" render="Listbox" enableWrapAround="1"
                position="10,96" size="1516,672"
                secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                backgroundColor="#1a1a2e">
            <convert type="TemplatedMultiContent">
                {"template": [
                    MultiContentEntryText(pos=(0,0),   size=(55,49),  font=0, color=0x00ffffff, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                    MultiContentEntryText(pos=(60,0),  size=(490,49), font=0, color=0x00e8e8e8, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                    MultiContentEntryText(pos=(560,0), size=(560,49), font=0, color=0x00ffcc00, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=2),
                    MultiContentEntryText(pos=(1130,0), size=(386,49), font=0, color=0x0087ceeb, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=3)],
                 "fonts": [gFont("Regular",26)],
                 "itemHeight": 49, "scrollbarMode": "showOnDemand"}
            </convert>
        </widget>
        <!-- Info bar: two green lines with Exit + Bouquet name between -->
        <eLabel position="0,767"  size="1536,2" backgroundColor="#00aa00"/>
        <eLabel position="0,815"  size="1536,2" backgroundColor="#00aa00"/>
        <widget name="key_red"       position="10,771"  size="140,42"
                font="Regular;26" valign="center" halign="left" transparent="1"/>
        <widget name="bouquet_label"  position="155,771" size="125,42"
                font="Regular;26" valign="center" halign="right"
                foregroundColor="#e94560" transparent="1"/>
        <widget name="bouquet_val"    position="283,771" size="360,42"
                font="Regular;26" valign="center" halign="left"
                foregroundColor="#ffcc00" transparent="1"/>
        <widget name="epgname_label"  position="660,771" size="235,42"
                font="Regular;26" valign="center" halign="right"
                foregroundColor="#e94560" transparent="1"/>
        <widget name="epgname_val"    position="898,771" size="630,42"
                font="Regular;26" valign="center" halign="left"
                foregroundColor="#ffcc00" transparent="1"/>
        <!-- Hide theme hotkey buttons -->
        <widget name="key_yellow" position="-200,0" size="1,1" transparent="1"/>
        <widget name="key_blue" position="-200,0" size="1,1" transparent="1"/>
    </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, provider_name, rows, epg_json=None, save_cb=None, nav_cb=None, build_xml_cb=None):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T('EPG Assignments') + ': ' + provider_name)
        self._rows = rows
        self._provider = provider_name
        self._epg_json = epg_json or {'Sources': [], 'Bouquets': []}
        self._save_cb     = save_cb
        self._nav_cb      = nav_cb
        self._build_xml_cb = build_xml_cb
        self['title_lbl'] = Label(T('EPG Assignments') + ': ' + provider_name)
        self['hdr_num']   = Label('#')
        self['hdr_ch']    = Label(T('Channel'))
        self['hdr_epg']   = Label(T('EPG Assigned'))
        self['hdr_src']   = Label(T('EPG Source'))
        self['rows'] = __import__('Components.Sources.List', fromlist=['List']).List([])
        self['key_red']    = Button(T('Exit'))
        self['key_yellow'] = Label('')
        self['key_blue']   = Label('')
        self['bouquet_label']  = Label(T('Bouquets') + ':')
        self['bouquet_val']    = Label('')
        self['epgname_label']  = Label(T('EPG Display Name') + ':')
        self['epgname_val']    = Label('')
        self['actions'] = ActionMap(['OkCancelActions'],
            {'cancel': self.close, 'ok': self._keyNavigate}, -1)
        self.onLayoutFinish.append(self._build)
        self['rows'].onSelectionChanged.append(self._onRowChanged)

    def _keyNavigate(self):
        cur = self['rows'].getCurrent()
        if not cur or len(cur) < 5: self.close(); return
        ch_name = cur[1]; bq_name = cur[4]
        if self._nav_cb:
            self._nav_cb(bq_name, ch_name)
        self.close()

    def _onRowChanged(self):
        cur = self['rows'].getCurrent()
        if cur and len(cur) >= 6:
            self['bouquet_val'].setText(cur[4])
            self['epgname_val'].setText(cur[5] if cur[5] else cur[2])
        else:
            self['bouquet_val'].setText('')
            self['epgname_val'].setText('')

    def _build(self):
        items = []
        for idx, (ch, epgid, src, bq, epgdisp) in enumerate(self._rows, 1):
            items.append(('%d.' % idx, ch, epgid, src, bq, epgdisp))
        self['rows'].setList(items)
        self._onRowChanged()


class CustomEPGScreen(Screen):
    """Custom EPG source manager — uses Components.Sources.List exactly like JediEPGXtream."""

    _SKIN_T = """
        <screen position="center,center" size="1536,816"
                title="Edit/Create Custom EPG" backgroundColor="#33000000">
            <!-- Column headers -->
            <widget name="lbl_bouquet" position="12,12"   size="288,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_channel" position="312,12"  size="360,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_source"  position="684,12"  size="228,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_epg"     position="924,12"  size="600,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <!-- Lists — source= + render=Listbox + TemplatedMultiContent -->
            <widget source="list1" render="Listbox" enableWrapAround="1"
                    position="12,54" size="288,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(269,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list2" render="Listbox" enableWrapAround="1"
                    position="312,54" size="360,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(341,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list3" render="Listbox" enableWrapAround="1"
                    position="684,54" size="228,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(209,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                        MultiContentEntryText(pos=(8,0), size=(209,36), font=0,
                            color=0x0000cc00, color_sel=0x0000ff00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list4" render="Listbox" enableWrapAround="1"
                    position="924,54" size="600,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(581,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <!-- Status bar -->
            <widget name="status" position="12,706" size="1158,57"
                    font="Regular;29" valign="center" foregroundColor="#ffcc00" transparent="1"/>
            <!-- Web URL label (always visible) -->
            <widget name="web_url" position="684,706" size="840,57"
                    font="Regular;29" valign="center" halign="right"
                    foregroundColor="#ffcc00" transparent="1"/>
            <!-- Button bar -->
            <ePixmap position="40,774"  size="42,30" pixmap="buttons/red.png"    alphaTest="blend"/>
            <ePixmap position="431,774" size="42,30" pixmap="buttons/green.png"  alphaTest="blend"/>
            <ePixmap position="822,774" size="42,30" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="1213,774" size="42,30" pixmap="buttons/blue.png"   alphaTest="blend"/>
            <eLabel position="0,763" size="1536,1" backgroundColor="#00aa00"/>
            <eLabel position="0,815" size="1536,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="82,768"  size="300,42"
                    font="Regular;25" valign="center" halign="left" transparent="1"/>
            <widget name="key_green"  position="473,768" size="300,42"
                    font="Regular;25" valign="center" halign="left" transparent="1"/>
            <widget name="key_yellow" position="864,768" size="300,42"
                    font="Regular;25" valign="center" halign="left" transparent="1"/>
            <widget name="key_blue"   position="1255,768" size="300,42"
                    font="Regular;25" valign="center" halign="left" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1536,816"
                title="Edit/Create Custom EPG">
            <!-- Column headers -->
            <widget name="lbl_bouquet" position="12,12"   size="288,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_channel" position="312,12"  size="360,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_source"  position="684,12"  size="228,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <widget name="lbl_epg"     position="924,12"  size="600,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
            <!-- Lists — source= + render=Listbox + TemplatedMultiContent -->
            <widget source="list1" render="Listbox" enableWrapAround="1"
                    position="12,54" size="288,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(269,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list2" render="Listbox" enableWrapAround="1"
                    position="312,54" size="360,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(341,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list3" render="Listbox" enableWrapAround="1"
                    position="684,54" size="228,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(209,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                        MultiContentEntryText(pos=(8,0), size=(209,36), font=0,
                            color=0x0000cc00, color_sel=0x0000ff00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <widget source="list4" render="Listbox" enableWrapAround="1"
                    position="924,54" size="600,642"
                    foregroundColor="#ffffff" backgroundColor="#000000"
                    foregroundColorSelected="#ffcc00" backgroundColorSelected="#2a2a2a"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#000000"
                    transparent="1" scrollbarMode="showOnDemand">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(8,0), size=(581,36), font=0,
                            color=0x00ffffff, color_sel=0x00ffcc00,
                            flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 36, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
            <!-- Status bar -->
            <widget name="status" position="12,706" size="1158,57"
                    font="Regular;29" valign="center" foregroundColor="#ffcc00" transparent="1"/>
            <!-- Web URL label (always visible) -->
            <widget name="web_url" position="684,706" size="840,57"
                    font="Regular;29" valign="center" halign="right"
                    foregroundColor="#ffcc00" transparent="1"/>
            <!-- Button bar -->
            <ePixmap position="40,774"  size="42,30" pixmap="buttons/red.png"    alphaTest="blend"/>
            <ePixmap position="431,774" size="42,30" pixmap="buttons/green.png"  alphaTest="blend"/>
            <ePixmap position="822,774" size="42,30" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="1213,774" size="42,30" pixmap="buttons/blue.png"   alphaTest="blend"/>
            <eLabel position="0,763" size="1536,1" backgroundColor="#00aa00"/>
            <eLabel position="0,815" size="1536,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="82,768"  size="300,42"
                    font="Regular;25" valign="center" halign="left"/>
            <widget name="key_green"  position="473,768" size="300,42"
                    font="Regular;25" valign="center" halign="left"/>
            <widget name="key_yellow" position="864,768" size="300,42"
                    font="Regular;25" valign="center" halign="left"/>
            <widget name="key_blue"   position="1255,768" size="300,42"
                    font="Regular;25" valign="center" halign="left"/>
        </screen>"""
    skin    = _SKIN_T


    # ------------------------------------------------------------------
    # Tuple formats (matching JediEPGXtream buildList* exactly):
    #   list1: (display_name, has_sub, bpath, level)          text=field[0]
    #   list2: (display_name, sref, chname, epgid)            text=field[0]
    #   list3: (white_name, green_name, name, url)             text=field[0/1], name=field[2], url=field[3]
    #   list4: (epg_id, is_match)                             text=field[0]
    # ------------------------------------------------------------------

    def __init__(self, session, provider=None):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.session         = session
        self._provider       = provider or {}
        self._provider_name  = (self._provider.get('name') or '').strip()
        self._xmltv_url      = (self._provider.get('xmltv_url') or '').strip()
        self._is_xtream      = bool(self._provider.get('xtream_url'))
        self._epg_json       = {'Sources': [], 'Bouquets': []}
        self._activeList     = None
        self._web_server     = None
        self._showMode       = 0       # 0=Show Name, 1=Show ID, 2=Show Name&ID
        self._sortById       = True    # Blue toggle in list4
        self._raw_epgdata    = []      # (epg_id, display_name) pairs from txt
        self._bq_timer       = None    # debounce timer for bouquet scroll
        self._ch_timer       = None    # debounce timer for channel scroll
        self._channels_cache = {}      # bpath -> list2 data cache
        self._downloading    = False   # True while background download runs
        self._updating_list2 = False   # True while list2 is being refreshed from list1
        self._updating_list3 = False   # True while list3 is being refreshed
        self._active_source  = None    # name of source selected with OK in list3

        self['lbl_bouquet'] = Label(T('Bouquets'))
        self['lbl_channel'] = Label(T('Channels'))
        self['lbl_source']  = Label(T('EPG Sources'))
        self['lbl_epg']     = Label(T('EPG Selection'))
        self['status']      = Label('')
        self['web_url']     = Label('')
        self['key_red']     = Label(T('Exit'))
        self['key_green']   = Label('')
        self['key_yellow']  = Label('')
        self['key_blue']    = Label('')

        # Use Components.Sources.List — same as JediEPGXtream
        from Components.Sources.List import List as _SrcList
        self.list1 = []; self.list2 = []; self.list3 = []; self.list4 = []
        self['list1'] = _SrcList(self.list1, enableWrapAround=True)
        self['list2'] = _SrcList(self.list2, enableWrapAround=True)
        self['list3'] = _SrcList(self.list3, enableWrapAround=True)
        self['list4'] = _SrcList(self.list4, enableWrapAround=True)

        self['list1'].onSelectionChanged.append(self._onBouquetChanged)
        self['list2'].onSelectionChanged.append(self._onChannelChanged)
        self['list4'].onSelectionChanged.append(self._onEpgChanged)
        self['list3'].onSelectionChanged.append(self._onSourceChanged)

        self['actions'] = ActionMap(
            ['SetupActions', 'DirectionActions', 'ColorActions',
             'MenuActions', 'MoviePlayerActions'],
            {
                'ok':         self._keyOk,
                'back':       self._keyExit,
                'cancel':     self._keyExit,
                'red':        self._keyExit,
                'green':      self._keyGreen,
                'yellow':     self._keyYellow,
                'blue':       self._keyBlue,
                'left':       self._goLeft,
                'right':      self._goRight,
                'up':         self._goUp,
                'down':       self._goDown,
                'channelUp':  self._pageUp,
                'channelDown':self._pageDown,
            }, -1)

        self.onFirstExecBegin.append(self._onStart)
        self.onLayoutFinish.append(self._layoutFinished)
        self.onClose.append(self._stopWebServer)

    # ------------------------------------------------------------------
    # Enable/disable — JediEPGXtream exact path: master.master.instance
    # (Components.Sources.List has renderer chain: List->Renderer->instance)
    # ------------------------------------------------------------------

    def _enableList(self, lst):
        try:
            lst.master.master.instance.setSelectionEnable(1)
        except Exception:
            pass

    def _disableList(self, lst):
        try:
            lst.master.master.instance.setSelectionEnable(0)
        except Exception:
            pass

    def _setActiveList(self, lst):
        """Only used on initial layout. For navigation use _goLeft/_goRight."""
        self._enableList(self['list1'])
        self._disableList(self['list2'])
        self._disableList(self['list3'])
        self._disableList(self['list4'])
        self._activeList = lst
        self._updateKeys()

    def _layoutFinished(self):
        self._enableList(self['list1'])
        self._disableList(self['list2'])
        self._disableList(self['list3'])
        self._disableList(self['list4'])
        self._activeList = self['list1']
        self._updateKeys()

    # ------------------------------------------------------------------
    # Context-sensitive key labels
    # ------------------------------------------------------------------

    def _updateKeys(self):
        al = self._activeList
        if al is self['list1']:
            self['key_green'].setText(T('Show Assigned'))
            self['key_yellow'].setText('')
            self['key_blue'].setText(T('EPG Module Help'))
        elif al is self['list2']:
            cur = self['list2'].getCurrent()
            if cur and cur[0].startswith('─'): cur = None
            has_epg = bool(cur[3]) if cur and len(cur) > 3 else False
            self['key_green'].setText(T('Unassign EPG') if has_epg else '')
            self['key_yellow'].setText(self._showModeLabel())
            self['key_blue'].setText(T('Unassign All'))
        elif al is self['list3']:
            self['key_green'].setText(T('Add Source'))
            self['key_yellow'].setText(T('Update Source'))
            self['key_blue'].setText(T('Delete Source'))
        elif al is self['list4']:
            self['key_green'].setText(T('Assign EPG'))
            self['key_yellow'].setText(self._showModeLabel())
            self['key_blue'].setText(T('Sort by Name') if self._sortById else T('Sort by ID'))

    # ------------------------------------------------------------------
    # Paths and storage
    # ------------------------------------------------------------------

    def _getWorkDir(self):
        import os
        base = getDataDir()
        d = os.path.join(base, 'Custom EPG Sources')
        if not os.path.isdir(d):
            try: os.makedirs(d)
            except Exception: d = base
        return d

    def _getJsonFile(self):
        import os, re as _re
        name = self._provider_name or 'default'
        # Use same sanitizer as _generateEpgImportFile so merge always finds this file
        safe = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', name.strip()))).strip('_-') or 'default'
        return os.path.join(self._getWorkDir(), safe + '_customepg.json')

    def _getSourcesFile(self):
        import os
        return os.path.join(self._getWorkDir(), 'epg_sources.txt')

    # ------------------------------------------------------------------
    # Web server
    # ------------------------------------------------------------------

    def _onWebChannelsChanged(self, bpath):
        """Called from web after assign/unassign — reload JSON and refresh channels."""
        try:
            import json, os
            jf = self._getJsonFile()
            if os.path.isfile(jf):
                with open(jf) as f:
                    self._epg_json = json.load(f)
            # Fill epg_display_name for any web assignments missing it
            _workdir = self._getWorkDir()
            _migrated = False
            for _b in self._epg_json.get('Bouquets', []):
                for _ch in _b.get('channel', []):
                    if _ch.get('epgid') and not _ch.get('epg_display_name'):
                        _src = _ch.get('sourcename', '').strip()
                        _eid = _ch.get('epgid', '').strip()
                        _txt = os.path.join(_workdir, _src + '.txt')
                        if os.path.isfile(_txt):
                            try:
                                with open(_txt) as _tf:
                                    for _line in _tf:
                                        if _line.startswith(_eid + '|'):
                                            _ch['epg_display_name'] = _line.strip().split('|', 1)[1]
                                            _migrated = True
                                            break
                            except Exception:
                                pass
            if _migrated:
                self._saveJson()
        except Exception:
            pass
        def _do_refresh():
            if bpath and bpath in self._channels_cache:
                del self._channels_cache[bpath]
            cur1 = self['list1'].getCurrent()
            if cur1 and not cur1[1]:
                self._getChannels(cur1[2])
        try:
            from twisted.internet import reactor
            reactor.callFromThread(_do_refresh)
        except Exception:
            _do_refresh()

    def _onWebSourcesChanged(self):
        """Called from web thread when source is added/deleted — refresh list3."""
        import json, os
        jf = self._getJsonFile()
        if os.path.isfile(jf):
            try:
                with open(jf) as f:
                    self._epg_json = json.load(f)
            except Exception:
                self._epg_json = {'Sources': [], 'Bouquets': []}
        else:
            self._epg_json = {'Sources': [], 'Bouquets': []}
        try:
            from twisted.internet import reactor
            reactor.callFromThread(self._getSources)
        except Exception:
            self._getSources()

    def _startWebServer(self):
        if IPTVCustomEPGWebServer is None:
            return
        try:
            self._web_server = IPTVCustomEPGWebServer(WEB_CUSTOM_EPG_PORT)
            ok, ip, port = self._web_server.start(
                provider                  = self._provider,
                workdir                   = self._getWorkDir(),
                json_file                 = self._getJsonFile(),
                sources_file              = self._getSourcesFile(),
                refresh_callback          = self._onWebSourcesChanged,
                channel_refresh_callback  = self._onWebChannelsChanged,
            )
            if ok:
                self['web_url'].setText('Web: http://' + ip + ':' + str(port))
        except Exception as e:
            self['status'].setText(T('Web error: ') + str(e)[:60])

    def _stopWebServer(self):
        if self._web_server:
            try: self._web_server.stop()
            except Exception: pass
            self._web_server = None

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _onStart(self):
        import json, os
        jf = self._getJsonFile()
        if os.path.isfile(jf):
            try:
                with open(jf) as f:
                    self._epg_json = json.load(f)
            except Exception:
                self._epg_json = {'Sources': [], 'Bouquets': []}
        else:
            self._epg_json = {'Sources': [], 'Bouquets': []}

        # Migrate existing assignments: fill epg_display_name from .txt files
        _migrated = False
        _workdir = self._getWorkDir()
        for _b in self._epg_json.get('Bouquets', []):
            for _ch in _b.get('channel', []):
                if _ch.get('epgid') and not _ch.get('epg_display_name'):
                    _src = _ch.get('sourcename', '').strip()
                    _eid = _ch.get('epgid', '').strip()
                    _txt = os.path.join(_workdir, _src + '.txt')
                    if os.path.isfile(_txt):
                        try:
                            with open(_txt) as _tf:
                                for _line in _tf:
                                    if _line.startswith(_eid + '|'):
                                        _ch['epg_display_name'] = _line.strip().split('|', 1)[1]
                                        _migrated = True
                                        break
                        except Exception:
                            pass
        if _migrated:
            self._saveJson()

        if self._xmltv_url:
            src_name = (self._provider_name or 'provider').replace(' ', '_')
            sf = self._getSourcesFile()
            existing_lines = []
            if os.path.isfile(sf):
                with open(sf) as f:
                    existing_lines = [l.rstrip('\n') for l in f if l.strip()]
            # Migrate old 1-step safe name → new 3-step safe name in sources file
            import re as _re_cepg
            _old_src_name = _re_cepg.sub(r'[^\w]', '_', (self._provider_name or 'provider').strip()).strip('_')
            if _old_src_name != src_name:
                _wdir_mig = self._getWorkDir()
                _sf_changed = False
                _new_lines = []
                for _sl in existing_lines:
                    _parts = _sl.split(' ', 1)
                    if len(_parts) == 2 and _parts[0] == _old_src_name and _parts[1] == self._xmltv_url:
                        _new_lines.append('%s %s' % (src_name, _parts[1]))
                        _sf_changed = True
                    else:
                        _new_lines.append(_sl)
                # Rename old .txt → new .txt
                _old_txt = os.path.join(_wdir_mig, _old_src_name + '.txt')
                _new_txt = os.path.join(_wdir_mig, src_name + '.txt')
                if os.path.isfile(_old_txt) and not os.path.isfile(_new_txt):
                    try:
                        os.rename(_old_txt, _new_txt)
                    except Exception:
                        pass
                if _sf_changed:
                    try:
                        with open(sf, 'w') as _f:
                            _f.write('\n'.join(_new_lines) + '\n')
                        existing_lines = _new_lines
                    except Exception:
                        pass
            # Add provider's own entry only if exact name+url combo not already present
            _own_entry = any(
                l.split(' ', 1) == [src_name, self._xmltv_url]
                for l in existing_lines if ' ' in l
            )
            if not _own_entry:
                with open(sf, 'a') as f:
                    f.write('%s %s\n' % (src_name, self._xmltv_url))

        self._getBouquets()

    # ------------------------------------------------------------------
    # Bouquet loading
    # ------------------------------------------------------------------

    def _getBouquets(self):
        import os
        self.list1 = []
        prov_lc = self._provider_name.lower() if self._provider_name else ''
        skip = ('userbouquet.abm', '#SERVICE 1:519', 'userbouquet.favourites',
                'userbouquet.LastScanned', '_vod_', '_series_')

        def _load(match_prov=True):
            result = []
            if not os.path.isfile('/etc/enigma2/bouquets.tv'): return result
            with open('/etc/enigma2/bouquets.tv') as f:
                for line in f:
                    if not (line.startswith('#SERVICE') and 'FROM BOUQUET' in line): continue
                    if any(t in line for t in skip): continue
                    try:
                        bpath = line.split('"')[1::2][0]
                        bname = ''; has_sub = False
                        with open('/etc/enigma2/' + bpath) as bf:
                            for bl in bf:
                                if '#NAME' in bl: bname = ' '.join(bl.split()[1:])
                                if 'subbouquet' in bl: has_sub = True
                        if not bname: continue
                        if match_prov and prov_lc:
                            import re as _re
                            # Use anchored prefix match so "IPTV Gomel-Sat" does not
                            # pick up "IPTV Gomel-Sat (Xtream)" bouquet files.
                            safe_prov = _safe_prov_name(self._provider_name).lower()
                            bpath_lc  = bpath.lower()
                            file_match = (bpath_lc.startswith('userbouquet.' + safe_prov + '_') or
                                          bpath_lc.startswith('subbouquet.'  + safe_prov + '_') or
                                          bpath_lc.startswith('userbouquet.' + safe_prov + '.') or
                                          bpath_lc.startswith('subbouquet.'  + safe_prov + '.'))
                            # Exclude if a longer safe_name also matches (longest-match wins)
                            if file_match:
                                try:
                                    _all_safes = [
                                        _safe_prov_name(p.get('name', '')).lower()
                                        for p in (list(loadPlaylistProviderConfig()) +
                                                  list(loadXtreamProviderConfig()))
                                    ]
                                    for _other in _all_safes:
                                        if _other != safe_prov and _other and (
                                            bpath_lc.startswith('userbouquet.' + _other + '_') or
                                            bpath_lc.startswith('userbouquet.' + _other + '.') or
                                            bpath_lc.startswith('subbouquet.'  + _other + '_') or
                                            bpath_lc.startswith('subbouquet.'  + _other + '.')) and                                                 len(_other) > len(safe_prov):
                                            file_match = False
                                            break
                                except Exception:
                                    pass
                            # Exact match: bname must equal provider name or
                            # start with it followed by ' - ' (sub-section separator).
                            bname_lc   = bname.lower()
                            name_match = (bname_lc == prov_lc or
                                          bname_lc.startswith(prov_lc + ' - '))
                            if not name_match and not file_match: continue
                        disp = bname.partition(' - ')[-1] if ' - ' in bname else bname
                        # tuple: (display_name, has_sub, bpath, level)
                        result.append((disp, has_sub, bpath, 'Level1'))
                    except Exception: pass
            return result

        self.list1 = _load(True) or _load(False)
        self['list1'].setList(self.list1)
        title = T('Edit/Create Custom EPG')
        if self._provider_name: title += T(' For: ') + self._provider_name
        self.setTitle(title)
        if self.list1:
            first_real = next((b for b in self.list1 if not b[1]), self.list1[0])
            if not first_real[1]:
                self._getChannels(first_real[2])
        self._getSources()
        if self._xmltv_url:
            self._autoLoadProviderSource()
        self._startWebServer()

    def _getSubBouquets(self, parent_path):
        import os
        self.list1 = []
        try:
            with open('/etc/enigma2/' + parent_path) as f:
                for line in f:
                    if not line.startswith('#SERVICE'): continue
                    try:
                        bpath = line.split('"')[1::2][0]
                        bname = ''
                        with open('/etc/enigma2/' + bpath) as bf:
                            for bl in bf:
                                if '#NAME' in bl:
                                    bname = ' '.join(bl.split()[1:])
                                    if ' - ' in bname: bname = bname.partition(' - ')[-1]
                                    break
                        if bname:
                            # tuple: (display_name, False, bpath, 'Level2')
                            self.list1.append((bname, False, bpath, 'Level2'))
                    except Exception: pass
        except Exception: pass
        self['list1'].setList(self.list1)
        if self.list1:
            self._getChannels(self.list1[0][2])

    def _getChannels(self, bpath):
        import os
        self.list2 = []
        full = '/etc/enigma2/' + bpath
        if not os.path.isfile(full):
            self['list2'].setList(self.list2)
            return
        bq_entry = next((b for b in self._epg_json.get('Bouquets', [])
                         if b['bouquet'] == bpath), None)
        chname = ''; sref = ''
        with open(full) as f:
            for line in f:
                line = line.rstrip('\n')
                if line.startswith('#SERVICE'):
                    if 'FROM BOUQUET' in line: chname = ''; sref = ''; continue
                    # Keep full service reference including URL
                    sref = line.split(' ', 1)[-1].strip()
                    parts = line.split(':')
                    desc = parts[-1].strip() if len(parts) > 10 else ''
                    chname = desc if desc and 'http' not in desc and '%' not in desc else ''
                elif line.startswith('#DESCRIPTION'):
                    chname = line.replace('#DESCRIPTION', '', 1).lstrip(' ').lstrip('~#-<^').strip()
                if sref and chname:
                    epgid = ''
                    if bq_entry:
                        for jc in bq_entry.get('channel', []):
                            if jc['description'] == chname.strip(): epgid = jc['epgid']; break
                    disp = chname.strip() + ('  [' + epgid + ']' if epgid else '')
                    # tuple: (display_name, sref, chname, epgid)
                    _sref = sref.strip()
                    if self._is_xtream:
                        _parts = _sref.split(':')
                        if _parts[0] == '4097' and len(_parts) >= 11:
                            _sref = '1:' + ':'.join(_parts[1:10]) + ':http%3a//example.m3u8'
                    self.list2.append((disp, _sref, chname.strip(), epgid))
                    chname = ''; sref = ''
        # Float assigned channels to top, unassigned below, with divider
        assigned   = [ch for ch in self.list2 if ch[3]]
        unassigned = [ch for ch in self.list2 if not ch[3]]
        assigned.sort(key=lambda x: x[0].lower())
        unassigned.sort(key=lambda x: x[0].lower())
        if assigned and unassigned:
            self.list2 = assigned + [('─' * 28, '', '', '')] + unassigned
        else:
            self.list2 = assigned + unassigned
        self._updating_list2 = True
        self['list2'].setList(self.list2)
        self._updating_list2 = False
        if self._activeList is not self['list2']:
            self._disableList(self['list2'])
        # Cache the result
        if bpath:
            self._channels_cache[bpath] = self.list2

    def _refreshList3(self):
        """Rebuild list3 display tuples with green highlight for active source.
        Tuple: (white_name, green_name, name, url)
        text[0]=white display, text[1]=green display
        Fields [2]=name [3]=url used for all logic.
        """
        tagged = []
        for n, u in self.list3:
            if n == self._active_source:
                tagged.append(('', n, n, u))   # green
            else:
                tagged.append((n, '', n, u))   # white
        self._updating_list3 = True
        self['list3'].setList(tagged)
        self._updating_list3 = False

    def _getSources(self):
        import os
        self.list3 = []
        sf = self._getSourcesFile()
        if os.path.isfile(sf):
            with open(sf) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'): continue
                    if ' ' in line:
                        n, u = line.split(' ', 1)
                        # tuple: (name, url)
                        self.list3.append((n.strip(), u.strip()))
        self._refreshList3()
        # Auto-select provider source
        if self._xmltv_url and self.list3:
            for idx, src in enumerate(self.list3):
                if src[1] == self._xmltv_url:
                    self._active_source = src[0]
                    self._refreshList3()
                    self['list3'].setIndex(idx); break

    def _getMatchList(self, source_name):
        import os
        self.list4 = []
        txt = os.path.join(self._getWorkDir(), source_name + '.txt')
        if not os.path.isfile(txt) or os.stat(txt).st_size == 0:
            self['list4'].setList([])
            if self._activeList is not self['list4']:
                self._disableList(self['list4'])
            self['status'].setText(T('Press Yellow to download and parse source'))
            return

        # Parse id|display_name format (new) or plain id (legacy)
        raw = []   # [(epg_id, display_name), ...]
        with open(txt) as f:
            for line in f:
                s = line.strip()
                if not s: continue
                if '|' in s:
                    epg_id, _sep, disp = s.partition('|')
                    raw.append((epg_id.strip(), disp.strip()))
                else:
                    raw.append((s, ''))
        self._raw_epgdata = raw

        cur2 = self['list2'].getCurrent()
        # Use raw chname (field 2); if empty fall back to display name
        # stripped of any '  [epgid]' suffix (handles channels with no #DESCRIPTION)
        if cur2 and len(cur2) > 2 and cur2[2]:
            ch_name = cur2[2]
        elif cur2:
            ch_name = cur2[0].split('  [')[0].strip()
        else:
            ch_name = ''

        matched_raw, rest_raw = self._matchEpgData(raw, ch_name)

        self._buildList4Display(matched_raw, rest_raw)
        self['status'].setText(self._active_source or '')

    def _matchEpgData(self, raw, ch_name):
        """Match channel name against EPG data.

        _showNames=False (Hide Names):
            Exact JediEPGXtream logic — fuzz.token_sort_ratio cutoff 40
            matching channel display name against EPG IDs.
            Fallback: difflib.get_close_matches cutoff 0.20.

        _showNames=True (Show Names):
            Strict substring match against display_name field.
            Priority: exact > startswith > contains.
        """
        if not ch_name:
            return [], list(raw)

        if self._showMode == 1:  # Show ID — fuzzy against EPG IDs
            # ── JediEPGXtream-based logic with raised threshold ─────────
            epgids = [r[0].lower().strip() for r in raw]
            namelist = []
            try:
                from fuzzywuzzy import fuzz, process
                matchlist = process.extract(ch_name, epgids, limit=42,
                                            scorer=fuzz.token_sort_ratio)
                namelist = [m[0] for m in matchlist if m[1] >= 55]
            except Exception:
                from difflib import get_close_matches
                q = ch_name.lower().lstrip('~#-<^').replace(' ', '')
                namelist = get_close_matches(q, epgids, n=42, cutoff=0.40)

            # Also add substring matches not caught by fuzzy
            q_low = ch_name.lower().strip()
            for eid_low in epgids:
                if eid_low not in namelist:
                    if q_low in eid_low or eid_low in q_low:
                        namelist.append(eid_low)

            matched_set = set(namelist)
            matched_raw = [(eid, dn) for eid, dn in raw if eid.lower().strip() in matched_set]
            rest_raw    = [(eid, dn) for eid, dn in raw if eid.lower().strip() not in matched_set]
            return matched_raw, rest_raw

        else:  # Show Name (0) or Show Name&ID (2) — substring against display names
            # ── Show Names: match display_name ────────────────────────
            # Normalize: remove parentheses, lowercase
            import re as _re
            # Words that are qualifiers/suffixes - not part of the core name
            QUAL = {'hd', 'sd', 'fhd', '4k', 'uhd', 'orig', 'am', 'de', 'uk',
                    'us', 'ru', 'fr', 'it', 'pl', 'il', 'ua', 'by', 'kz',
                    'plus', 'int', 'tv', 'the'}

            def _norm(s):
                # Strip all punctuation except spaces — handles Матч! vs Матч
                s2 = _re.sub(r'[()]', '', s).lower().strip()
                s2 = _re.sub(r'[^\w\s]', ' ', s2)  # punctuation -> space
                return _re.sub(r'\s+', ' ', s2).strip()

            def _core(s):
                """Remove qualifier words to get core channel name."""
                words = _norm(s).split()
                # Keep all words up to the last non-qualifier word
                core = []
                for w in words:
                    if w not in QUAL:
                        core.append(w)
                return ' '.join(core) if core else _norm(s)

            q_full = _norm(ch_name)
            q_core = _core(ch_name)

            exact = []; starts = []; contains = []; core_match = []; rest = []
            for eid, dn in raw:
                t_full = _norm(dn if dn else eid)
                t_core = _core(dn if dn else eid)

                if t_full == q_full:
                    exact.append((eid, dn))
                elif t_full.startswith(q_full) or q_full.startswith(t_full):
                    starts.append((eid, dn))
                elif q_full in t_full or t_full in q_full:
                    contains.append((eid, dn))
                elif q_core and t_core and (q_core == t_core or
                     t_core.startswith(q_core) or q_core.startswith(t_core) or
                     q_core in t_core or t_core in q_core):
                    core_match.append((eid, dn))
                else:
                    rest.append((eid, dn))
            return exact + starts + contains + core_match, rest

    def _buildList4Display(self, matched_raw, rest_raw):
        """Build self.list4 tuples from (id, display_name) pairs.
        Tuple format: (display_text, is_match, epg_id, display_name)
        text=0 for TemplatedMultiContent
        """
        def _fmt(epg_id, disp):
            if self._showMode == 0:   return disp if disp else epg_id  # Show Name
            elif self._showMode == 1: return epg_id                    # Show ID
            else:                     return (epg_id + '  |  ' + disp) if disp else epg_id  # Name&ID

        def _natural(s):
            import re as _re
            return [int(t) if t.isdigit() else t.lower()
                    for t in _re.split(r'(\d+)', s)]

        def _sort_key(pair):
            eid, dn = pair
            if self._sortById:
                return _natural(eid)
            return _natural(dn if dn else eid)

        matched_sorted = sorted(matched_raw, key=_sort_key)
        rest_sorted    = sorted(rest_raw,    key=_sort_key)

        self.list4 = []
        for eid, dn in matched_sorted:
            self.list4.append((_fmt(eid, dn), True, eid, dn))
        if matched_sorted:
            self.list4.append(('─' * 30, False, '', ''))
        for eid, dn in rest_sorted:
            self.list4.append((_fmt(eid, dn), False, eid, dn))
        self['list4'].setList(self.list4)
        # Re-disable list4 after setList if it's not the active list
        # (setList resets the widget state, losing the disabled selection)
        if self._activeList is not self['list4']:
            self._disableList(self['list4'])

    def _rebuildList4(self):
        """Rebuild list4 with current _showMode/_sortById settings."""
        if not self._raw_epgdata:
            return
        cur2 = self['list2'].getCurrent()
        # Use raw chname (field 2); if empty fall back to display name
        # stripped of any '  [epgid]' suffix (handles channels with no #DESCRIPTION)
        if cur2 and len(cur2) > 2 and cur2[2]:
            ch_name = cur2[2]
        elif cur2:
            ch_name = cur2[0].split('  [')[0].strip()
        else:
            ch_name = ''
        matched_raw, rest_raw = self._matchEpgData(self._raw_epgdata, ch_name)
        self._buildList4Display(matched_raw, rest_raw)

    def _autoLoadProviderSource(self):
        import os
        src_name = (self._provider_name or 'provider').replace(' ', '_')
        txt = os.path.join(self._getWorkDir(), src_name + '.txt')
        if os.path.isfile(txt) and os.stat(txt).st_size > 0:
            self._getMatchList(src_name)
        else:
            self['status'].setText(T('Downloading provider EPG source...'))
            self._downloading = True
            import threading
            t = threading.Thread(target=self._downloadAndParse,
                                 args=(src_name, self._xmltv_url), daemon=True)
            t.start()

    # ------------------------------------------------------------------
    # Selection change callbacks
    # ------------------------------------------------------------------

    def _onBouquetChanged(self):
        if self._downloading: return
        cur = self['list1'].getCurrent()
        # Always show bouquet name in status when scrolling list1
        if cur and cur[0] and not cur[0].startswith('─'):
            self['status'].setText(cur[0])
        if not cur or cur[1]: return
        bpath = cur[2]
        # Use cache if available (like JediEPGXtream — immediate, no debounce)
        if bpath in self._channels_cache:
            self.list2 = self._channels_cache[bpath]
            self._updating_list2 = True
            self['list2'].setList(self.list2)
            self._updating_list2 = False
            if self._activeList is not self['list2']:
                self._disableList(self['list2'])
        else:
            self._getChannels(bpath)

    def _onChannelChanged(self):
        if self._downloading: return
        self._updateKeys()
        cur2 = self['list2'].getCurrent()
        # Show assignment info in status bar — only when list2 is active
        if self._activeList is not self['list2']:
            pass  # skip status update when list2 not active
        elif cur2 and not cur2[0].startswith('─') and len(cur2) > 3 and cur2[3]:
            # Channel has an assigned EPG — show source details from JSON
            sref  = cur2[1]
            epgid = cur2[3]
            src_name = ''
            try:
                for jb in self._epg_json.get('Bouquets', []):
                    for jc in jb.get('channel', []):
                        if jc.get('serviceid', '').strip() == sref.strip():
                            src_name = (jc.get('sourcename', '') or
                                       jc.get('source', '')).replace('_', ' ')
                            break
                    if src_name:
                        break
            except Exception:
                pass
            if src_name:
                self['status'].setText(T('EPG Source: ') + src_name + '  |  ' + T('EPG ID: ') + epgid)
            else:
                self['status'].setText(T('EPG ID: ') + epgid)
        elif self._activeList is self['list2']:
            # Show channel name for unassigned (list2 must be active)
            if cur2 and not cur2[0].startswith('─'):
                self['status'].setText(cur2[0].split('  [')[0].strip())
            else:
                self['status'].setText('')
        # Only run matching if list2 is the active list and not being refreshed from list1
        if self._updating_list2:
            return

    def _runGetMatchList(self):
        cur3 = self['list3'].getCurrent()
        if cur3: self._getMatchList(cur3[2])

    def _onEpgChanged(self):
        if self._downloading: return
        """Show current EPG entry info in status bar — only when list4 is active."""
        if self._activeList is not self['list4']:
            return
        cur4 = self['list4'].getCurrent()
        if cur4 and not cur4[0].startswith('─') and len(cur4) > 2 and cur4[2]:
            eid = cur4[2]; dn = cur4[3] if len(cur4) > 3 else ''
            if dn:
                self['status'].setText('EPG: ' + eid + '  |  ' + dn)
            else:
                self['status'].setText('EPG: ' + eid)
        else:
            self['status'].setText('')

    def _onSourceChanged(self):
        if self._downloading: return
        if self._updating_list3: return
        cur3 = self['list3'].getCurrent()
        if cur3 and cur3[2]:
            self._active_source = cur3[2]
            self._refreshList3()
            self._getMatchList(cur3[2])

    # ------------------------------------------------------------------
    # Navigation — JediEPGXtream exact pattern
    # ------------------------------------------------------------------

    def _goLeft(self):
        """JediEPGXtream: going left ONLY disables current list. Previous stays enabled."""
        al = self._activeList
        if not al.getCurrent():
            return
        if al is self['list4']:
            self._disableList(self['list4'])
            self._activeList = self['list3']
        elif al is self['list3']:
            self._disableList(self['list3'])
            self._activeList = self['list2']
        elif al is self['list2']:
            self._disableList(self['list2'])
            self._activeList = self['list1']
        elif al is self['list1']:
            cur = self['list1'].getCurrent()
            if cur and cur[3] == 'Level2':
                self._getBouquets()
            elif cur and cur[1]:  # folder — clear channels
                self.list2 = []
                self['list2'].setList(self.list2)
        self._updateKeys()

    def _goRight(self):
        """JediEPGXtream: going right ONLY enables new list. Previous stays enabled."""
        al = self._activeList
        if not al.getCurrent():
            return
        if al is self['list1']:
            cur = self['list1'].getCurrent()
            if cur[1]:
                # Folder bouquet — drill into subbouquets
                self._getSubBouquets(cur[2])
                self['list1'].setIndex(0)
            else:
                # Real bouquet — move focus to channels
                self._enableList(self['list2'])
                self._activeList = self['list2']
                self['list2'].setIndex(0)
        elif al is self['list2']:
            self._enableList(self['list3'])
            self._activeList = self['list3']
            # Load EPG IDs for currently selected source
            if not self._downloading:
                cur3 = self['list3'].getCurrent()
                if cur3:
                    self._getMatchList(cur3[2])
        elif al is self['list3']:
            cur4 = self['list4'].getCurrent()
            if cur4 and not cur4[0].startswith('─'):
                self._enableList(self['list4'])
                self._activeList = self['list4']
                # Jump to already-assigned EPG if any, otherwise top
                if not self._moveToAssigned():
                    self['list4'].setIndex(0)
        self._updateKeys()

    def _goUp(self):
        """Exact JediEPGXtream: instance.moveSelection(instance.moveUp), recurse on divider."""
        if not self._activeList.getCurrent():
            return
        inst = self._activeList.master.master.instance
        inst.moveSelection(inst.moveUp)
        for _skip_list in [self['list4'], self['list2']]:
            if self._activeList is _skip_list:
                cur = _skip_list.getCurrent()
                if cur and cur[0].startswith('─'):
                    self._goUp()
                break

    def _goDown(self):
        """Exact JediEPGXtream: instance.moveSelection(instance.moveDown), recurse on divider."""
        if not self._activeList.getCurrent():
            return
        inst = self._activeList.master.master.instance
        inst.moveSelection(inst.moveDown)
        for _skip_list in [self['list4'], self['list2']]:
            if self._activeList is _skip_list:
                cur = _skip_list.getCurrent()
                if cur and cur[0].startswith('─'):
                    self._goDown()
                break

    def _pageUp(self):
        """JediEPGXtream: pageUp then goDown if landed on divider."""
        if not self._activeList.getCurrent():
            return
        inst = self._activeList.master.master.instance
        inst.moveSelection(inst.pageUp)
        for _skip_list in [self['list4'], self['list2']]:
            if self._activeList is _skip_list:
                cur = _skip_list.getCurrent()
                if cur and cur[0].startswith('─'):
                    self._goDown()
                break

    def _pageDown(self):
        """JediEPGXtream: pageDown then goDown if landed on divider."""
        if not self._activeList.getCurrent():
            return
        inst = self._activeList.master.master.instance
        inst.moveSelection(inst.pageDown)
        for _skip_list in [self['list4'], self['list2']]:
            if self._activeList is _skip_list:
                cur = _skip_list.getCurrent()
                if cur and cur[0].startswith('─'):
                    self._goDown()
                break

    def _moveToAssigned(self):
        """If current channel has an assigned EPG ID, scroll list4 to it.
        Returns True if found and jumped, False otherwise."""
        cur2 = self['list2'].getCurrent()
        if not cur2 or not cur2[3]:
            return False
        assigned = cur2[3]
        for idx, item in enumerate(self.list4):
            epg_id = item[2] if len(item) > 2 else item[0]
            if epg_id == assigned:
                self['list4'].setIndex(idx)
                return True
        return False

    # ------------------------------------------------------------------
    # Key handlers
    # ------------------------------------------------------------------

    def _keyOk(self):
        if self._downloading: return
        al = self._activeList
        if al is self['list1']:
            cur = self['list1'].getCurrent()
            if not cur: return
            if cur[1]: self._getSubBouquets(cur[2]); self._setActiveList(self['list1'])
            else:
                self._enableList(self['list2'])
                self._activeList = self['list2']
                self._updateKeys()
        elif al is self['list2']:
            # OK on channel: run matching using active source, stay on list2
            cur3 = self['list3'].getCurrent()
            if cur3 and cur3[2]:
                self._getMatchList(cur3[2])
        elif al is self['list3']:
            self._goRight()
        elif al is self['list4']:
            self._doAssignEPG()

    def _keyGreen(self):
        al = self._activeList
        if al is self['list1']: self._showAssigned()
        elif al is self['list2']: self._unassignEPG()
        elif al is self['list3']: self._keyAddSource()
        elif al is self['list4']: self._doAssignEPG()

    def _keyYellow(self):
        al = self._activeList
        if al is self['list3']:
            self._keyUpdateSource()
        elif al is self['list4']:
            self._showMode = (self._showMode + 1) % 3
            self._rebuildList4()
            self._updateKeys()
        elif al is self['list2'] or al is self['list1']:
            self._showMode = (self._showMode + 1) % 3
            cur3 = self['list3'].getCurrent()
            if cur3:
                self._getMatchList(cur3[2])
            self._updateKeys()

    def _showModeLabel(self):
        """Return Yellow key label showing next mode (what pressing Yellow will switch to)."""
        if self._showMode == 0:   return T('Show by ID')
        elif self._showMode == 1: return T('Show Name&ID')
        else:                     return T('Show by Name')

    def _buildAndClearCache(self):
        """Called by summary screen after unassign — rebuild XML and clear cache."""
        self._buildXMLFiles()
        self._channels_cache.clear()

    def _navigateToChannel(self, bq_name, ch_name):
        """Navigate list1 to bouquet and list2 to channel after OK in summary."""
        for idx, item in enumerate(self.list1):
            if item[0] == bq_name:
                self['list1'].setIndex(idx)
                bpath = item[2]
                # Clear cache so list2 reloads fresh
                self._channels_cache.pop(bpath, None)
                self._getChannels(bpath)
                # Find and highlight channel in list2
                for cidx, ch in enumerate(self.list2):
                    if ch[0] == ch_name:
                        self['list2'].setIndex(cidx)
                        break
                self._enableList(self['list2'])
                self._activeList = self['list2']
                self._updateKeys()
                return

    def _showAssigned(self):
        """Show all assigned EPG channels for this provider in a summary window."""
        import json, os
        jf = self._getJsonFile()
        rows = []
        if os.path.isfile(jf):
            try:
                with open(jf) as f:
                    data = json.load(f)
                for b in data.get('Bouquets', []):
                    bpath = b.get('bouquet', '')
                    # Read bouquet display name from #NAME line
                    bq_name = ''
                    try:
                        with open('/etc/enigma2/' + bpath) as _bf:
                            for _bl in _bf:
                                if '#NAME' in _bl:
                                    bq_name = ' '.join(_bl.split()[1:]); break
                    except Exception:
                        bq_name = bpath.replace('userbouquet.', '').replace('.tv', '').replace('_', ' ')
                    for ch in b.get('channel', []):
                        rows.append((
                            ch.get('description', ''),
                            ch.get('epgid', ''),
                            ch.get('sourcename', ch.get('source', '')).replace('_', ' '),
                            bq_name,
                            ch.get('epg_display_name', ''),
                        ))
            except Exception:
                pass
        if not rows:
            self['status'].setText(T('No EPG assignments yet'))
            return
        prov = self._provider_name or 'Provider'
        self.session.open(CustomEPGSummaryScreen, prov, rows,
            epg_json=self._epg_json,
            save_cb=self._saveJson,
            nav_cb=self._navigateToChannel,
            build_xml_cb=self._buildAndClearCache)

    def _keyBlue(self):
        al = self._activeList
        if al is self['list1']:
            self.session.open(CustomEPGHelpScreen)
        elif al is self['list2']:
            self._unassignAll()
        elif al is self['list3']:
            self._keyDeleteSource()
        elif al is self['list4']:
            self._sortById = not self._sortById
            self._rebuildList4()
            self._updateKeys()

    def _doAssignEPG(self):
        cur1 = self['list1'].getCurrent(); cur2 = self['list2'].getCurrent()
        cur3 = self['list3'].getCurrent(); cur4 = self['list4'].getCurrent()
        if not (cur1 and cur2 and cur3 and cur4): return
        if cur4[0].startswith('─'): return
        bpath = cur1[2]; chname = cur2[2]; sref = cur2[1]
        src_name = cur3[2]; src_url = cur3[3]
        # list4 tuple: (display_text, is_match, epg_id, display_name)
        epg_id = cur4[2] if len(cur4) > 2 and cur4[2] else cur4[0]
        epg_display = cur4[3] if len(cur4) > 3 and cur4[3] else ''
        if not any(s['name']==src_name and s['source']==src_url for s in self._epg_json['Sources']):
            self._epg_json['Sources'].append({'name':src_name,'source':src_url})
        b_entry = next((b for b in self._epg_json['Bouquets'] if b['bouquet']==bpath), None)
        new_ch = {'serviceid':sref,'description':chname,'epgid':epg_id,'epg_display_name':epg_display,'source':src_url,'sourcename':src_name}
        if b_entry is None:
            self._epg_json['Bouquets'].append({'bouquet':bpath,'channel':[new_ch]})
        else:
            ce = next((c for c in b_entry['channel'] if c['serviceid']==sref), None)
            if ce: ce.update(new_ch)
            else: b_entry['channel'].append(new_ch)
        self._saveJson(); self._buildXMLFiles()
        self._channels_cache.pop(bpath, None)  # invalidate cache
        self._getChannels(bpath)
        self['status'].setText(T('EPG assigned: ') + epg_id)
        # Scroll list2 to the just-assigned channel
        for idx, item in enumerate(self.list2):
            if item[1] == sref:
                self['list2'].setIndex(idx)
                break
        # Return focus to list2, keep list1 highlighted
        self._disableList(self['list4'])
        self._disableList(self['list3'])
        self._enableList(self['list1'])
        self._enableList(self['list2'])
        self._activeList = self['list2']
        self._updateKeys()

    def _unassignEPG(self):
        cur1 = self['list1'].getCurrent(); cur2 = self['list2'].getCurrent()
        if not (cur1 and cur2): return
        bpath = cur1[2]; sref = cur2[1]; chname = cur2[2]
        for jb in self._epg_json.get('Bouquets', []):
            if jb['bouquet'] == bpath:
                jb['channel'] = [c for c in jb['channel']
                                  if not (c['serviceid']==sref and c['description']==chname)]
                if not jb['channel']: self._epg_json['Bouquets'].remove(jb)
                break
        self._pruneUnusedSources()
        self._saveJson(); self._buildXMLFiles()
        self._channels_cache.pop(bpath, None)  # invalidate cache
        self._getChannels(bpath)
        self['status'].setText(T('EPG unassigned: ') + chname)
        self._updateKeys()

    def _unassignAll(self):
        cur1 = self['list1'].getCurrent()
        if not cur1: return
        bpath = cur1[2]
        self._epg_json['Bouquets'] = [b for b in self._epg_json.get('Bouquets',[]) if b['bouquet']!=bpath]
        self._pruneUnusedSources()
        self._saveJson(); self._buildXMLFiles()
        self._channels_cache.pop(bpath, None)  # invalidate cache
        self._getChannels(bpath)
        self['status'].setText(T('All EPG assignments removed'))
        self._updateKeys()

    def _keyAddSource(self):
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._onAddSourceName, VirtualKeyBoard,
                title=T('Enter Source Name (no spaces):'), text='')
        except Exception:
            self.session.openWithCallback(self._onAddSourceName, InputBox,
                title=T('Enter Source Name (no spaces):'), text='', maxSize=False, type=Input.TEXT)

    def _onAddSourceName(self, name):
        if not name: return
        self._pending_src_name = name.strip().replace(' ', '_')
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._onAddSourceURL, VirtualKeyBoard,
                title=T('Enter Source URL (http://...):'), text='http://')
        except Exception:
            self.session.openWithCallback(self._onAddSourceURL, InputBox,
                title=T('Enter Source URL (http://...):'), text='', maxSize=False, type=Input.TEXT)

    def _onAddSourceURL(self, url):
        if not url: return
        name = getattr(self, '_pending_src_name', 'source')
        with open(self._getSourcesFile(), 'a') as f:
            f.write('%s %s\n' % (name, url.strip()))
        self._getSources()
        self['status'].setText(T('Source added: ') + name)

    def _keyDeleteSource(self):
        cur3 = self['list3'].getCurrent()
        if not cur3: return
        import os
        name, url = cur3[2], cur3[3]
        sf = self._getSourcesFile()
        if os.path.isfile(sf):
            with open(sf) as f: lines = f.readlines()
            with open(sf, 'w') as f:
                for line in lines:
                    if not (name in line and url in line): f.write(line)
        txt = os.path.join(self._getWorkDir(), name + '.txt')
        if os.path.isfile(txt): os.remove(txt)
        jf = self._getJsonFile()
        if os.path.isfile(jf): os.remove(jf)
        self._epg_json = {'Sources': [], 'Bouquets': []}
        self._getSources(); self.list4 = []; self['list4'].setList(self.list4)
        self['status'].setText(T('Source deleted: ') + name)

    def _keyUpdateSource(self):
        cur3 = self['list3'].getCurrent()
        if not cur3: self['status'].setText(T('Select a source first')); return
        name, url = cur3[2], cur3[3]
        self['status'].setText(T('Downloading: ') + name + ' ...')
        self._downloading = True
        import threading
        t = threading.Thread(target=self._downloadAndParse, args=(name, url), daemon=True)
        t.start()

    def _downloadAndParse(self, name, url):
        import os, gzip, shutil
        workdir = self._getWorkDir()
        dest = os.path.join(workdir, name + '.tmp')
        try:
            import urllib.request
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l)', 'Accept': '*/*'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                with open(dest, 'wb') as fd: shutil.copyfileobj(resp, fd, 65536)
        except Exception as e:
            self._callFromThread(self['status'].setText, T('Download failed: ') + str(e)[:60]); return

        # Detect format by magic bytes — URL extension is unreliable
        try:
            with open(dest, 'rb') as _mf: _magic = _mf.read(6)
        except Exception as e:
            self._callFromThread(self['status'].setText, T('Download failed: ') + str(e)[:60]); return

        xml_file = os.path.join(workdir, name + '.xml')
        try:
            if _magic[:2] == b'\x1f\x8b':
                # gzip
                with gzip.open(dest, 'rb') as src, open(xml_file, 'wb') as dst: shutil.copyfileobj(src, dst, 65536)
                os.remove(dest)
            elif _magic[:6] == b'\xfd7zXZ\x00' or url.endswith('.xz'):
                # xz
                import lzma
                with lzma.open(dest, 'rb') as src, open(xml_file, 'wb') as dst: shutil.copyfileobj(src, dst, 65536)
                os.remove(dest)
            else:
                # plain XML or unknown — use as-is
                os.rename(dest, xml_file)
        except Exception as e:
            self._callFromThread(self['status'].setText, T('Decompress failed: ') + str(e)[:60]); return

        import re
        # Parse channel blocks — store ALL display-names, one entry per display-name
        pat_id   = re.compile(r'<channel[^>]+id="([^"]+)"')
        pat_name = re.compile(r'<display-name[^>]*>([^<]+)</display-name>')
        entries = []  # list of (id, display_name) — one per display-name
        seen    = set()  # deduplicate (id, display_name) pairs
        cur_id  = None
        cur_has_names = False
        with open(xml_file, 'r', errors='replace') as f:
            for line in f:
                m_id = pat_id.search(line)
                if m_id:
                    cur_id = m_id.group(1).strip()
                    cur_has_names = False
                m_name = pat_name.search(line)
                if m_name and cur_id:
                    dn = m_name.group(1).strip()
                    # Strip [color] / [tag] artifacts from display-name
                    import re as _re
                    dn = _re.sub(r'\[.*?\]', '', dn).strip()
                    if not dn:
                        continue
                    key = (cur_id, dn)
                    if key not in seen:
                        entries.append(key)
                        seen.add(key)
                        cur_has_names = True
                if '</channel>' in line:
                    # If channel had no display-names, add bare id entry
                    if cur_id and not cur_has_names:
                        key = (cur_id, '')
                        if key not in seen:
                            entries.append(key)
                            seen.add(key)
                    cur_id = None
                    cur_has_names = False
        # Sort by id then display_name
        entries.sort(key=lambda x: (x[0].lower(), x[1].lower()))
        txt = os.path.join(workdir, name + '.txt')
        with open(txt, 'w') as f:
            for eid, dn in entries:
                f.write(eid + '|' + dn + '\n')
        try: os.remove(xml_file)
        except Exception: pass

        self._callFromThread(self['status'].setText,
                             T('Done: ') + str(len(entries)) + T(' EPG entries'))
        self._downloading = False
        self._callFromThread(self._getMatchList, name)

    def _callFromThread(self, fn, *args):
        try:
            from twisted.internet import reactor
            reactor.callFromThread(fn, *args)
        except Exception: fn(*args)

    def _pruneUnusedSources(self):
        """Remove Sources entries not referenced by any remaining channel assignment."""
        used = set()
        for b in self._epg_json.get('Bouquets', []):
            for ch in b.get('channel', []):
                if ch.get('sourcename'): used.add(ch['sourcename'])
        self._epg_json['Sources'] = [
            s for s in self._epg_json.get('Sources', [])
            if s.get('name') in used
        ]

    def _saveJson(self):
        import json, os
        data = self._epg_json
        self._pruneUnusedSources()
        # Skip only if nothing to save AND file does not exist yet
        if not data.get('Sources') and not data.get('Bouquets'):
            if not os.path.isfile(self._getJsonFile()):
                return
        with open(self._getJsonFile(), 'w') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def _buildXMLFiles(self):
        import os
        workdir = self._getWorkDir()
        src_file = os.path.join(workdir, 'custom_epg.sources.xml')
        ch_file  = os.path.join(workdir, 'custom_epg_channels.xml')
        with open(src_file, 'w') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n<sources>\n')
            f.write('<sourcecat sourcecatname="Custom EPG">\n')
            for src in self._epg_json.get('Sources', []):
                f.write('<source type="gen_xmltv" nocheck="1" channels="%s">\n' % ch_file)
                # Label source as 'ProviderName-CustomEPG' in the XML
                src_label = (self._provider_name + '-CustomEPG') if self._provider_name else src['name']
                f.write('<description>%s</description>\n<url><![CDATA[%s]]></url>\n</source>\n'
                        % (src_label, src['source']))
            f.write('</sourcecat>\n</sources>\n')
        with open(ch_file, 'w') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n<channels>\n')
            for bouquet in self._epg_json.get('Bouquets', []):
                for ch in bouquet.get('channel', []):
                    sref    = ch['serviceid']
                    name    = ch['description'].replace('<','').replace('>','').replace('&','and')
                    disp    = (ch.get('epg_display_name') or '').replace('<','').replace('>','').replace('&','and').strip()
                    comment = ('%s | -> %s' % (name, disp)) if disp else name
                    f.write('<channel id="%s">%s</channel> <!-- %s -->\n'
                            % (ch['epgid'], sref, comment))
            f.write('</channels>\n')

    def _keyExit(self):
        self._saveJson()
        self._buildXMLFiles()
        self.close()



# ---------------------------------------------------------------------------
# IPTVArchiveOffsetDialog — popup for Archive Start Offset + Hostname Filter
# ---------------------------------------------------------------------------

class IPTVArchiveOffsetDialog(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="820,280"
                title="Archive Start Offset">
            <widget name="config" position="20,20" size="780,195"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="46" />
            <ePixmap position="70,238"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="480,238" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,233" size="300,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="523,233" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""

    def __init__(self, session, sign, abs_val, hostname):
        Screen.__init__(self, session)
        self.setTitle(T("Archive Start Offset (+/- sec)"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self._cfg_sign     = ConfigSelection(
            choices=[('+', '+'), ('-', '-')],
            default=sign if sign in ('+', '-') else '+')
        self._cfg_abs      = ConfigInteger(
            default=max(0, min(3600, int(abs_val or 0))), limits=(0, 99999))
        self._cfg_hostname = ConfigText(
            default=(hostname or '').strip(), fixed_size=False)
        ConfigListScreen.__init__(self, [
            getConfigListEntry(T("Offset"),                           self._cfg_sign),
            getConfigListEntry(T("Offset (sec)"),                     self._cfg_abs),
            getConfigListEntry(T("Hostname Filter From Stream URL"),   self._cfg_hostname),
        ], session=session)
        self["offsetActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions", "DirectionActions"],
            {"ok": self.keyOK, "save": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)

    def keyOK(self):
        ConfigListScreen.keyOK(self)

    def keySave(self):
        self.close((self._cfg_sign.value,
                    self._cfg_abs.value,
                    self._cfg_hostname.value.strip()))

# ---------------------------------------------------------------------------
# [IPTVProviderSettings and IPTVProviderEditDialog merged into
#  IPTVPlaylistProviderSettings / IPTVPlaylistProviderEditDialog]
# ---------------------------------------------------------------------------


class IPTVProviderTTLScreen(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="700,260"
                title="TTL Days For Cached Files">
            <widget name="config" position="20,20" size="660,170"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" />
            <ePixmap position="70,218"  size="35,25"
                     pixmap="buttons/green.png" alphaTest="blend" />
            <ePixmap position="420,218" size="35,25"
                     pixmap="buttons/red.png"   alphaTest="blend" />
            <widget name="key_green" position="113,213" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
            <widget name="key_red"   position="463,213" size="270,35"
                    zPosition="1" font="Regular;24" valign="center"
                    halign="left" transparent="1" />
        </screen>"""

    def __init__(self, session, ttl_custom, ttl_days):
        Screen.__init__(self, session)
        self.setTitle(T("TTL Days For Cached Files (Insert Available Archives Days Number)"))
        self["key_green"] = Button(T("Save"))
        self["key_red"]   = Button(T("Cancel"))
        self._cfg_custom = ConfigYesNo(default=bool(ttl_custom))
        self._cfg_days   = ConfigInteger(
            default=max(1, min(7, int(ttl_days or 7))), limits=(1, 7))
        ConfigListScreen.__init__(self, [], session=session)
        self["ttlActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions"],
            {"ok": self.keyOK, "save": self.keySave, "green": self.keySave,
             "cancel": self.close, "red": self.close}, -2)
        self._cfg_custom.addNotifier(self._rebuild, initial_call=False)
        self._rebuild()

    def _rebuild(self, *args):
        entries = [getConfigListEntry(T("Custom TTL"), self._cfg_custom)]
        if self._cfg_custom.value:
            entries.append(
                getConfigListEntry(T("  TTL Days (1-7)"), self._cfg_days))
        self["config"].setList(entries)

    def keyOK(self):
        ConfigListScreen.keyOK(self)

    def keySave(self):
        self.close((self._cfg_custom.value, self._cfg_days.value))

# ---------------------------------------------------------------------------
# IPTVProviderEditDialog — add / edit one provider
# ---------------------------------------------------------------------------


MAX_PLAYLIST_PROVIDERS = 50
MAX_XTREAM_PROVIDERS   = 50


def loadPlaylistProviderConfig():
    cfg_path = '/etc/CustomIPTVArchiveMakerPro/CustomIPTVPlaylist_providers.json'
    _old_path = '/etc/CustomIPTVPlaylist_providers.json'
    if not os.path.isfile(cfg_path) and os.path.isfile(_old_path):
        try:
            import shutil as _sh
            _sh.copy2(_old_path, cfg_path)
        except Exception:
            pass
    _empty = {
        'enabled': False, 'name': '', 'xmltv_url': '', 'm3u_source': '',
        'epg_parse_type': 'off', 'bouquet_strategy': 'same_playlist',
        'playback_with': 'gstplayer',
        'channel_order': 'provider', 'picon_naming': 'off',
        'xtream_show_live': True, 'xtream_show_vod': True,
        'xtream_show_series': True, 'xtream_output': 'ts',
        'xtream_strategy': 'same_as_provider', 'xtream_picon': 'off',
        'clean_bouquets': False,
        'update_playlist_mode': 'off',
    }
    default = [dict(_empty) for _ in range(MAX_PLAYLIST_PROVIDERS)]
    try:
        import json
        with open(cfg_path, 'r') as _f:
            data = json.load(_f)
        if not isinstance(data, list):
            return default
        for item in data:
            for k, v in _empty.items():
                item.setdefault(k, v)
        while len(data) < MAX_PLAYLIST_PROVIDERS:
            data.append(dict(_empty))
        return data[:MAX_PLAYLIST_PROVIDERS]
    except Exception:
        return default


def savePlaylistProviderConfig(data):
    cfg_path = '/etc/CustomIPTVArchiveMakerPro/CustomIPTVPlaylist_providers.json'
    try:
        _d = os.path.dirname(cfg_path)
        if _d and not os.path.isdir(_d):
            os.makedirs(_d)
    except Exception:
        pass
    try:
        import json
        with open(cfg_path, 'w') as _f:
            json.dump(data[:MAX_PLAYLIST_PROVIDERS], _f, indent=2)
        return True
    except Exception as e:
        iptvLogWrite('[Playlist] Failed to save playlist providers: %s' % str(e))
        return False


# ---------------------------------------------------------------------------
# Xtream-only provider config — separate from playlist providers
# ---------------------------------------------------------------------------


def loadXtreamProviderConfig():
    cfg_path = '/etc/CustomIPTVArchiveMakerPro/CustomIPTVXtream_providers.json'
    _old_path = '/etc/CustomIPTVXtream_providers.json'
    if not os.path.isfile(cfg_path) and os.path.isfile(_old_path):
        try:
            import shutil as _sh
            _sh.copy2(_old_path, cfg_path)
        except Exception:
            pass
    _empty = {
        'enabled': False, 'name': '',
        'xtream_type': 'user_pass',
        'xtream_url': '', 'xtream_username': '', 'xtream_password': '',
        'xtream_token': '',
        'xtream_output': 'm3u8', 'xtream_strategy': 'same_as_provider',
        'xtream_picon': 'off',
        'xtream_picon_location': 'enigma2_picon',
        'xtream_picon_symlink': False,
        'xtream_show_live': True, 'xtream_show_vod': True,
        'xtream_show_series': True,
        'playback_with': 'gstplayer',
        'clean_bouquets': False,
        'selected_stream_ids': [],
        'channel_order': 'provider',
        'update_playlist_mode': 'off',
        'xtream_picon_with_folder': True,
        'xtream_live_type': '4097',
        'xtream_vod_type': '4097',
        'xtream_series_type': '4097',
    }
    default = [dict(_empty) for _ in range(MAX_XTREAM_PROVIDERS)]
    try:
        import json
        with open(cfg_path, 'r') as _f:
            data = json.load(_f)
        if not isinstance(data, list):
            return default
        for item in data:
            for k, v in _empty.items():
                item.setdefault(k, v)
            item['xtream_enabled'] = True
        while len(data) < MAX_XTREAM_PROVIDERS:
            data.append(dict(_empty))
        return data[:MAX_XTREAM_PROVIDERS]
    except Exception:
        return default


def saveXtreamProviderConfig(data):
    cfg_path = '/etc/CustomIPTVArchiveMakerPro/CustomIPTVXtream_providers.json'
    try:
        _d = os.path.dirname(cfg_path)
        if _d and not os.path.isdir(_d):
            os.makedirs(_d)
    except Exception:
        pass
    try:
        import json
        with open(cfg_path, 'w') as _f:
            json.dump(data[:MAX_XTREAM_PROVIDERS], _f, indent=2)
        return True
    except Exception as e:
        iptvLogWrite('[Xtream] Failed to save Xtream providers: %s' % str(e))
        return False


def _get_enigma2_lang():
    try:
        import Components.Language as _CL
        lc = _CL.language.getLanguage()
        code = lc[:2].lower()
        return {'ru': 'RUS', 'de': 'DEU', 'fr': 'FRA', 'es': 'ESP', 'it': 'ITA', 'pl': 'POL', 'tr': 'TUR', 'uk': 'UKR'}.get(code, 'ENG')
    except Exception:
        return 'ENG'

def _parseM3UPlaylist(source):
    content = ''
    if source.startswith('http://') or source.startswith('https://'):
        try:
            import urllib.request as _ur
            req = _ur.Request(_normalizeHttpUrl(source), headers=HEADERS)
            with _ur.urlopen(req, timeout=20) as _r:
                raw = _r.read()
            raw     = _gunzip(raw)
            decoded = None
            for enc in ('utf-8-sig', 'utf-8', 'cp1251', 'latin-1'):
                try:
                    decoded = raw.decode(enc)
                    break
                except (UnicodeDecodeError, LookupError):
                    decoded = None
            content = decoded if decoded is not None else raw.decode('utf-8', errors='replace')
        except Exception as e:
            iptvLogWrite('[Playlist] M3U download error: %s' % str(e))
            return []
    else:
        try:
            with open(source, 'r', encoding='utf-8', errors='replace') as _f:
                content = _f.read()
        except Exception as e:
            iptvLogWrite('[Playlist] M3U read error: %s' % str(e))
            return []
    channels = []
    lines    = content.splitlines()
    i        = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('#EXTINF:'):
            info   = line
            tvg_id = ''
            group  = ''
            logo   = ''
            name   = ''
            m = re.search(r'tvg-id="([^"]*)"',    info)
            if m: tvg_id = m.group(1)
            m = re.search(r'group-title="([^"]*)"', info)
            if m:
                g = m.group(1).strip()
                group = g[:1].upper() + g[1:] if g else g
            m = re.search(r'tvg-logo="([^"]*)"',   info)
            if m: logo   = m.group(1)
            m = re.search(r',(.+)$',               info)
            if m: name   = m.group(1).strip()
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or lines[j].strip().startswith('#')):
                skipped = lines[j].strip()
                if skipped.startswith('#EXTGRP:') and not group:
                    g = skipped[len('#EXTGRP:'):].strip()
                    group = g[:1].upper() + g[1:] if g else g
                j += 1
            url = lines[j].strip() if j < len(lines) else ''
            if url and not url.startswith('#'):
                channels.append({'name': name, 'group': group or 'General',
                                 'tvg_id': tvg_id, 'logo': logo, 'url': url,
                                 'has_archive': has_archive(info)})
                i = j + 1
                continue
        i += 1
    return channels


def _updateBouquetsTv(bouquet_refs):
    bouquets_tv = '/etc/enigma2/bouquets.tv'
    try:
        with open(bouquets_tv, 'r', encoding='utf-8', errors='replace') as _f:
            existing = _f.read()
    except Exception:
        existing = '#NAME User bouquets (TV)\n'
    lines = existing.splitlines(keepends=True)
    added = []
    for fname, ref in bouquet_refs:
        if fname not in existing:
            lines.append(ref + '\n')
            added.append(fname)
            iptvLogWrite('[Playlist] bouquets.tv: adding ref for %s' % fname)
    if added:
        try:
            with open(bouquets_tv, 'w', encoding='utf-8') as _f:
                _f.writelines(lines)
            iptvLogWrite('[Playlist] bouquets.tv: updated, added %d new refs' % len(added))
        except Exception as e:
            iptvLogWrite('[Playlist] Failed to update bouquets.tv: %s' % str(e))
    else:
        iptvLogWrite('[Playlist] bouquets.tv: no new refs needed')


def _channel_sid_map(safe_name, channels):
    import zlib
    try:
        from urllib.parse import urlsplit as _usp
    except ImportError:
        from urlparse import urlsplit as _usp

    def _sid_identity(u):
        """Strip query/fragment for stable SID — token rotation must not change SID."""
        try:
            s = _usp(u)
            return '%s://%s%s' % (s.scheme, s.netloc, s.path)
        except Exception:
            return u

    result   = {}
    used_ids = set()
    _ident_to_sid = {}  # identity → already-assigned sid_hex, so same path = same SID
    for ch in channels:
        try:
            url = (ch.get('url') or '').strip()
            if not url or url in result:
                continue
            ident = _sid_identity(url)
            if ident in _ident_to_sid:
                # Same channel path seen before (token rotated) — reuse SID
                result[url] = _ident_to_sid[ident]
                continue
            # CRC16 of the path-only identity — stable across token rotations.
            if isinstance(ident, bytes):
                id_bytes = ident
            else:
                id_bytes = ident.encode('utf-8', 'replace')
            sid = zlib.crc32(id_bytes) & 0xFFFF
            while sid in used_ids:
                sid = (sid + 1) & 0xFFFF
            used_ids.add(sid)
            sid_entry = ('%X' % sid, '1')
            result[url] = sid_entry
            _ident_to_sid[ident] = sid_entry
        except Exception:
            pass
    return result



def _migrateSafeName(provider):
    """Rename files when provider name changed or safe_name formula changed."""
    import re as _re_mig, os as _os_mig, json as _json_mig

    prov_name = (provider.get('name') or 'Provider').strip()
    new_safe  = _re_mig.sub(r'_+', '_', _re_mig.sub(r'[^\w\-]', '', _re_mig.sub(r'\s+', '_', prov_name))).strip('_-') or 'Provider'

    # Use _safe_name_at_last_create as the authoritative old safe_name
    _stored_safe = (provider.get('_safe_name_at_last_create') or '').strip()
    _prev_name   = (provider.get('_name_at_last_create') or '').strip()

    if _stored_safe and _stored_safe != new_safe:
        # Stored safe differs — either renamed or formula changed
        candidates = [_stored_safe]
    elif _prev_name and _prev_name != prov_name:
        # Renamed but no stored safe (old install) — compute from previous name
        _old_3 = _re_mig.sub(r'_+', '_', _re_mig.sub(r'[^\w\-]', '', _re_mig.sub(r'\s+', '_', _prev_name))).strip('_-') or 'Provider'
        _old_1 = _re_mig.sub(r'[^\w]', '_', _prev_name).strip('_') or 'Provider'
        candidates = list(dict.fromkeys([_old_3, _old_1]))
    else:
        # No rename — formula migration only (old 1-step → new 3-step)
        _old_1 = _re_mig.sub(r'[^\w]', '_', prov_name).strip('_') or 'Provider'
        candidates = [_old_1]

    candidates = [s for s in candidates if s != new_safe]
    if not candidates:
        return

    for old_safe in candidates:
        _migrateSafeNameFiles(old_safe, new_safe, provider, prov_name)


def _migrateSafeNameFiles(old_safe, new_safe, provider, prov_name):
    """Perform the actual file renames for old_safe → new_safe."""
    import re as _re_mig, os as _os_mig, json as _json_mig
    import re as _re_comb

    iptvLogWrite('[Migration] "%s": old=%r → new=%r' % (prov_name, old_safe, new_safe))

    enigma2 = '/etc/enigma2'
    epg_dir = '/etc/epgimport/CustomIPTV'
    epg_src = '/etc/epgimport'

    # 1+2: Rename userbouquet/subbouquet .tv files
    # Longest-match protection: skip files owned by another provider whose
    # safe_name starts with old_safe and is longer
    _mig_other_safes = []
    try:
        for _mp in (list(loadPlaylistProviderConfig()) + list(loadXtreamProviderConfig())):
            _mpn = (_mp.get('name') or '').strip()
            if not _mpn:
                continue
            # Use stored safe_name if available — most reliable
            _stored_safe = (_mp.get('_safe_name_at_last_create') or '').strip()
            _mps3 = _re_mig.sub(r'_+', '_', _re_mig.sub(r'[^\w\-]', '', _re_mig.sub(r'\s+', '_', _mpn))).strip('_-')
            _mps1 = _re_mig.sub(r'[^\w]', '_', _mpn).strip('_')
            for _mps in ([_stored_safe] if _stored_safe else []) + [_mps3, _mps1]:
                if _mps and _mps not in _mig_other_safes and _mps != new_safe and _mps != old_safe:
                    if _mps.startswith(old_safe) and len(_mps) > len(old_safe):
                        _mig_other_safes.append(_mps)
    except Exception as _mig_e:
        iptvLogWrite('[Migration] _mig_other_safes error: %s' % _mig_e)

    iptvLogWrite('[Migration] _mig_other_safes=%r old_safe=%r' % (_mig_other_safes, old_safe))

    def _mig_other_owns(fname):
        for _mos in _mig_other_safes:
            if fname.startswith('userbouquet.' + _mos) or fname.startswith('subbouquet.' + _mos):
                return True
        return False

    try:
        for fname in sorted(_os_mig.listdir(enigma2)):
            if fname.startswith('userbouquet.%s' % old_safe) or fname.startswith('subbouquet.%s' % old_safe):
                if _mig_other_owns(fname):
                    iptvLogWrite('[Migration] skipped %s — belongs to another provider' % fname)
                    continue
                try:
                    _os_mig.rename(_os_mig.path.join(enigma2, fname),
                                   _os_mig.path.join(enigma2, fname.replace(old_safe, new_safe, 1)))
                    iptvLogWrite('[Migration] renamed %s' % fname)
                except Exception as _e:
                    iptvLogWrite('[Migration] rename failed %s: %s' % (fname, _e))
    except Exception as _e:
        iptvLogWrite('[Migration] enigma2 scan error: %s' % _e)

    # 3: Patch bouquets.tv line content — only lines belonging to this provider
    _btv = _os_mig.path.join(enigma2, 'bouquets.tv')
    try:
        with open(_btv, 'r', encoding='utf-8', errors='replace') as _f:
            _btv_lines = _f.readlines()
        _btv_changed = False
        _btv_new = []
        for _bl in _btv_lines:
            # Use 'in' check for bouquets.tv lines — they start with #SERVICE,
            # not 'userbouquet.', so startswith would always fail
            _btv_other_owned = any(
                ('userbouquet.' + _mos) in _bl or ('subbouquet.' + _mos) in _bl
                for _mos in _mig_other_safes
            )
            if old_safe in _bl and not _btv_other_owned:
                _btv_new.append(_bl.replace(old_safe, new_safe))
                _btv_changed = True
            else:
                _btv_new.append(_bl)
        if _btv_changed:
            with open(_btv, 'w', encoding='utf-8') as _f:
                _f.writelines(_btv_new)
            iptvLogWrite('[Migration] patched bouquets.tv')
    except Exception as _e:
        iptvLogWrite('[Migration] bouquets.tv patch failed: %s' % _e)

    # 1-content: Patch FROM BOUQUET lines inside renamed userbouquet files
    try:
        for fname in _os_mig.listdir(enigma2):
            if fname.startswith('userbouquet.%s' % new_safe):
                _fp = _os_mig.path.join(enigma2, fname)
                try:
                    with open(_fp, 'r', encoding='utf-8', errors='replace') as _f:
                        _data = _f.read()
                    import re as _re_nc
                    _data_new = _data.replace(old_safe, new_safe)
                    _data_new = _re_nc.sub(
                        r'(?m)^(#NAME ).*$',
                        r'\g<1>' + prov_name,
                        _data_new)
                    if _data_new != _data:
                        with open(_fp, 'w', encoding='utf-8') as _f:
                            _f.write(_data_new)
                        iptvLogWrite('[Migration] patched FROM BOUQUET in %s' % fname)
                except Exception as _e:
                    iptvLogWrite('[Migration] FROM BOUQUET patch failed %s: %s' % (fname, _e))
    except Exception as _e:
        iptvLogWrite('[Migration] userbouquet content scan error: %s' % _e)

    # 4: Rename + patch CustomIPTV_{old}.sources.xml
    _old_sx = _os_mig.path.join(epg_src, 'CustomIPTV_%s.sources.xml' % old_safe)
    _new_sx = _os_mig.path.join(epg_src, 'CustomIPTV_%s.sources.xml' % new_safe)
    if _os_mig.path.isfile(_old_sx):
        try:
            with open(_old_sx, 'r', encoding='utf-8', errors='replace') as _f:
                _sx = _f.read()
            with open(_new_sx, 'w', encoding='utf-8') as _f:
                _f.write(_sx.replace(old_safe, new_safe))
            _os_mig.remove(_old_sx)
            iptvLogWrite('[Migration] renamed+patched CustomIPTV_%s.sources.xml' % old_safe)
        except Exception as _e:
            iptvLogWrite('[Migration] sources.xml failed: %s' % _e)

    # 4b: Remove old provider block from global CustomIPTV.sources.xml
    _combined = '/etc/epgimport/CustomIPTV.sources.xml'
    if _os_mig.path.isfile(_combined):
        try:
            with open(_combined, 'r', encoding='utf-8', errors='replace') as _f:
                _comb = _f.read()
            # Remove all blocks whose marker starts with old_safe
            # e.g. BEGIN:IPTV_Ilook_TV555 AND BEGIN:IPTV_Ilook_TV555_customepg_*
            _comb_changed = False
            for _bm in _re_comb.findall(r'<!-- BEGIN:(' + _re_comb.escape(old_safe) + r'[^\s]*?) -->', _comb):
                _bt = '<!-- BEGIN:%s -->' % _bm
                _et = '<!-- END:%s -->'   % _bm
                if _bt in _comb and _et in _comb:
                    _comb = _re_comb.sub(
                        r'\s*' + _re_comb.escape(_bt) + r'.*?' + _re_comb.escape(_et),
                        '', _comb, flags=_re_comb.DOTALL)
                    _comb_changed = True
                    iptvLogWrite('[Migration] removed old block %s from CustomIPTV.sources.xml' % _bm)
            if _comb_changed:
                with open(_combined, 'w', encoding='utf-8') as _f:
                    _f.write(_comb)
        except Exception as _e:
            iptvLogWrite('[Migration] CustomIPTV.sources.xml cleanup failed: %s' % _e)

    # 5: Rename {old}.xml channels file
    _old_cx = _os_mig.path.join(epg_dir, '%s.xml' % old_safe)
    _new_cx = _os_mig.path.join(epg_dir, '%s.xml' % new_safe)
    if _os_mig.path.isfile(_old_cx):
        try:
            _os_mig.rename(_old_cx, _new_cx)
            iptvLogWrite('[Migration] renamed %s.xml in epgimport' % old_safe)
        except Exception as _e:
            iptvLogWrite('[Migration] channels.xml rename failed: %s' % _e)

    # 6: Rename and patch bouquet names inside _customepg.json
    try:
        _wdir = _os_mig.path.join(getDataDir(), 'Custom EPG Sources')
        _old_jp = _os_mig.path.join(_wdir, '%s_customepg.json' % old_safe)
        _new_jp = _os_mig.path.join(_wdir, '%s_customepg.json' % new_safe)
        _src_jp = _old_jp if _os_mig.path.isfile(_old_jp) else (_new_jp if _os_mig.path.isfile(_new_jp) else None)
        if _src_jp:
            with open(_src_jp, 'r', encoding='utf-8') as _f:
                _jd = _json_mig.load(_f)
            for _bq in _jd.get('Bouquets', []):
                if old_safe in (_bq.get('bouquet') or ''):
                    _bq['bouquet'] = _bq['bouquet'].replace(old_safe, new_safe)
            with open(_new_jp, 'w', encoding='utf-8') as _f:
                _json_mig.dump(_jd, _f, ensure_ascii=False, indent=2)
            if _src_jp != _new_jp and _os_mig.path.isfile(_src_jp):
                _os_mig.remove(_src_jp)
            iptvLogWrite('[Migration] renamed+patched %s_customepg.json → %s_customepg.json' % (old_safe, new_safe))
    except Exception as _e:
        iptvLogWrite('[Migration] customepg.json patch failed: %s' % _e)

    # 6a: Scan ALL json files in Custom EPG Sources — patch Sources[].name matching old_safe
    try:
        _wdir_all = _os_mig.path.join(getDataDir(), 'Custom EPG Sources')
        for _jfname in _os_mig.listdir(_wdir_all):
            if not _jfname.endswith('.json'):
                continue
            _jfpath = _os_mig.path.join(_wdir_all, _jfname)
            try:
                with open(_jfpath, 'r', encoding='utf-8') as _f:
                    _jfall = _json_mig.load(_f)
                _jchanged = False
                for _src in _jfall.get('Sources', []):
                    if (_src.get('name') or '') == old_safe:
                        _src['name'] = new_safe
                        _jchanged = True
                if _jchanged:
                    with open(_jfpath, 'w', encoding='utf-8') as _f:
                        _json_mig.dump(_jfall, _f, ensure_ascii=False, indent=2)
                    iptvLogWrite('[Migration] patched Sources name in %s' % _jfname)
            except Exception as _je:
                iptvLogWrite('[Migration] json scan failed %s: %s' % (_jfname, _je))
    except Exception as _e:
        iptvLogWrite('[Migration] Custom EPG Sources scan error: %s' % _e)

    # 6b: Patch epg_sources.txt entry + rename provider .txt file
    try:
        _wdir_cepg = _os_mig.path.join(getDataDir(), 'Custom EPG Sources')
        _sf = _os_mig.path.join(_wdir_cepg, 'epg_sources.txt')
        # Compute txt-formula names (replace spaces only, keeps hyphens/parens)
        _old_txt_base = provider.get('_name_at_last_create') or prov_name
        _old_txt_key  = _old_txt_base.replace(' ', '_')
        _new_txt_key  = prov_name.replace(' ', '_')
        if _os_mig.path.isfile(_sf):
            with open(_sf, 'r', encoding='utf-8', errors='replace') as _f:
                _sf_lines = _f.readlines()
            _new_sf_lines = []
            _sf_changed = False
            for _sl in _sf_lines:
                _parts = _sl.rstrip('\n').split(' ', 1)
                if len(_parts) == 2 and _parts[0] in (old_safe, _old_txt_key):
                    _new_sf_lines.append('%s %s\n' % (_new_txt_key, _parts[1]))
                    _sf_changed = True
                else:
                    _new_sf_lines.append(_sl)
            if _sf_changed:
                with open(_sf, 'w', encoding='utf-8') as _f:
                    _f.writelines(_new_sf_lines)
                iptvLogWrite('[Migration] patched epg_sources.txt')
        # Rename .txt file — try both safe-formula and txt-formula old names
        _new_txt = _os_mig.path.join(_wdir_cepg, _new_txt_key + '.txt')
        for _old_key in list(dict.fromkeys([_old_txt_key, old_safe])):
            _old_txt = _os_mig.path.join(_wdir_cepg, _old_key + '.txt')
            if _os_mig.path.isfile(_old_txt) and not _os_mig.path.isfile(_new_txt):
                _os_mig.rename(_old_txt, _new_txt)
                iptvLogWrite('[Migration] renamed %s.txt → %s.txt' % (_old_key, _new_txt_key))
                break
    except Exception as _e:
        iptvLogWrite('[Migration] epg_sources/txt patch failed: %s' % _e)

    # 7: Rename {old}_Picons/ directory
    _picon_with_folder = provider.get('picon_with_folder', provider.get('xtream_picon_with_folder', True)) not in ('0', 'false', 'False', 'no', '', False, 0)
    if _picon_with_folder:
        _ploc = provider.get('picon_location') or provider.get('xtream_picon_location') or 'plugin_dir'
        if _ploc == 'enigma2_picon':
            _ploc = '/usr/share/enigma2/picon'
        elif _ploc in ('plugin_dir', ''):
            _ploc = getDataDir()
        _old_pd = _os_mig.path.join(_ploc, '%s_Picons' % old_safe)
        _new_pd = _os_mig.path.join(_ploc, '%s_Picons' % new_safe)
        if _os_mig.path.isdir(_old_pd) and not _os_mig.path.exists(_new_pd):
            try:
                _os_mig.rename(_old_pd, _new_pd)
                iptvLogWrite('[Migration] renamed %s_Picons/' % old_safe)
                # Update symlinks in /usr/share/enigma2/picon/ that point to old folder
                _sym_dir = '/usr/share/enigma2/picon'
                try:
                    for _sf in _os_mig.listdir(_sym_dir):
                        _sl = _os_mig.path.join(_sym_dir, _sf)
                        if _os_mig.path.islink(_sl):
                            _tgt = _os_mig.readlink(_sl)
                            if _old_pd in _tgt:
                                _new_tgt = _tgt.replace(_old_pd, _new_pd, 1)
                                try:
                                    _os_mig.remove(_sl)
                                    _os_mig.symlink(_new_tgt, _sl)
                                except Exception:
                                    pass
                except Exception:
                    pass
                iptvLogWrite('[Migration] updated symlinks %s_Picons/ → %s_Picons/' % (old_safe, new_safe))
            except Exception as _e:
                iptvLogWrite('[Migration] Picons dir rename failed: %s' % _e)

    # 8: Rename {old}_Extream_picon/ directory
    if _picon_with_folder and provider.get('xtream_enabled'):
        _old_xd = _os_mig.path.join(_ploc, '%s_Extream_picon' % old_safe)
        _new_xd = _os_mig.path.join(_ploc, '%s_Extream_picon' % new_safe)
        if _os_mig.path.isdir(_old_xd) and not _os_mig.path.exists(_new_xd):
            try:
                _os_mig.rename(_old_xd, _new_xd)
                iptvLogWrite('[Migration] renamed %s_Extream_picon/' % old_safe)
            except Exception as _e:
                iptvLogWrite('[Migration] Extream_picon dir rename failed: %s' % _e)

    # 9+10+11: Archives — only if create_archives enabled
    _create_archives = provider.get('create_archives', False) not in ('0', 'false', 'False', 'no', '', False, 0)
    if _create_archives:
        _ddir = getDataDir()
        _old_cf = _os_mig.path.join(_ddir, old_safe)
        _new_cf = _os_mig.path.join(_ddir, new_safe)
        if _os_mig.path.isdir(_old_cf) and not _os_mig.path.exists(_new_cf):
            try:
                _os_mig.rename(_old_cf, _new_cf)
                iptvLogWrite('[Migration] renamed EPG cache folder %s/' % old_safe)
            except Exception as _e:
                iptvLogWrite('[Migration] EPG cache folder rename failed: %s' % _e)
        try:
            for fname in _os_mig.listdir(_ddir):
                if fname.startswith('%s_xmltv_' % old_safe) and (fname.endswith('.xml') or fname.endswith('.xml.gz')):
                    try:
                        _os_mig.rename(_os_mig.path.join(_ddir, fname),
                                       _os_mig.path.join(_ddir, fname.replace(old_safe, new_safe, 1)))
                        iptvLogWrite('[Migration] renamed xmltv file %s' % fname)
                    except Exception as _e:
                        iptvLogWrite('[Migration] xmltv rename failed %s: %s' % (fname, _e))
        except Exception as _e:
            iptvLogWrite('[Migration] xmltv files scan error: %s' % _e)
        _esrc_dir = _os_mig.path.join(_ddir, 'IPTVPlaylistCreator', 'EPG_SourceFiles')
        try:
            for fname in _os_mig.listdir(_esrc_dir):
                if fname.startswith('%s_EPG_Source' % old_safe):
                    try:
                        _os_mig.rename(_os_mig.path.join(_esrc_dir, fname),
                                       _os_mig.path.join(_esrc_dir, fname.replace(old_safe, new_safe, 1)))
                        iptvLogWrite('[Migration] renamed EPG source file %s' % fname)
                    except Exception as _e:
                        iptvLogWrite('[Migration] EPG source rename failed %s: %s' % (fname, _e))
        except Exception:
            pass


def _buildPlaylistBouquets(provider, channels):
    import re as _re
    import zlib as _zlib_bpb
    _migrateSafeName(provider)
    prov_name = (provider.get('name') or 'Provider').strip()
    safe_name = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
    strategy  = provider.get('bouquet_strategy', 'same_playlist')
    playback  = provider.get('playback_with', 'gstplayer')
    order     = provider.get('channel_order', 'provider')
    enigma2   = '/etc/enigma2'

    if order == 'alphabetical':
        channels = sorted(channels, key=lambda c: c.get('name', '').lower())
    # 'user_defined' → keep M3U order, same as 'provider' (no sort)

    stype = {'gst_player': '5001', 'exteplayer3': '5002', 'dvb': '1'}.get(playback, '4097')
    _m3u_src = (provider.get('m3u_source') or provider.get('name') or safe_name).strip()
    _prov_ns = '%08X' % (_zlib_bpb.crc32(_m3u_src.encode('utf-8', 'replace')) & 0xFFFFFFFF)

    try:
        from urllib.parse import quote as _quote
    except ImportError:
        from urllib import quote as _quote

    try:
        _sid_map = _channel_sid_map(safe_name, channels)
    except Exception:
        _sid_map = {}

    def _svc(url, name):
        _url = (url or '').strip()
        sid_hex, _ = _sid_map.get(_url, ('1', '1'))
        # Only encode ':' so the service ref fields split correctly.
        # '/' '?' '&' '=' are kept as-is — matches the proven working format.
        try:
            _safe = _url.replace(':', '%3a')
        except Exception:
            _safe = _url
        return '#SERVICE %s:0:1:%s:1:1:%s:0:0:0:%s' % (stype, sid_hex, _prov_ns, _safe)

    def _write_bouquet(bouquet_name, ch_list):
        cap_name = bouquet_name[:1].upper() + bouquet_name[1:] if bouquet_name else bouquet_name
        b_safe   = _re.sub(r'[^\w]', '_', cap_name).strip('_') or 'Bouquet'
        fname    = 'userbouquet.%s_%s.tv' % (safe_name, b_safe)
        lines    = ['#NAME %s\n' % cap_name]
        for ch in ch_list:
            try:
                lines.append(_svc(ch['url'], ch['name']) + '\n')
                lines.append('#DESCRIPTION %s\n' % ch.get('name', ''))
            except Exception:
                pass
        try:
            import io as _io
            _lines_u = [l.decode('utf-8', 'replace') if isinstance(l, bytes) else l
                        for l in lines]
            with _io.open(os.path.join(enigma2, fname), 'w', encoding='utf-8') as _wf:
                _wf.writelines(_lines_u)
            ref = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % fname
            iptvLogWrite('[Playlist] Written bouquet: %s' % fname)
            return fname, ref
        except Exception as e:
            iptvLogWrite('[Playlist] Bouquet write error %s: %s' % (fname, str(e)))
            return None, None

    created = []

    if strategy == 'same_playlist':
        groups = {}
        for ch in channels:
            g = ch.get('group', 'General') or 'General'
            groups.setdefault(g, []).append(ch)
        for gname, gchs in groups.items():
            fn, ref = _write_bouquet(gname, gchs)
            if fn:
                created.append((fn, ref))

    elif strategy == 'all_channels':
        fn, ref = _write_bouquet('All-%s' % prov_name, channels)
        if fn:
            created.append((fn, ref))

    elif strategy == 'all_and_groups':
        groups = {}
        for ch in channels:
            g = ch.get('group', 'General') or 'General'
            groups.setdefault(g, []).append(ch)
        for gname, gchs in groups.items():
            fn, ref = _write_bouquet(gname, gchs)
            if fn:
                created.append((fn, ref))
        fn, ref = _write_bouquet('All-%s' % prov_name, channels)
        if fn:
            created.append((fn, ref))

    elif strategy == 'parent_sub':
        groups = {}
        for ch in channels:
            g = ch.get('group', 'General') or 'General'
            groups.setdefault(g, []).append(ch)
        sub_refs = []
        for gname, gchs in groups.items():
            cap_g    = gname[:1].upper() + gname[1:] if gname else gname
            g_safe   = _re.sub(r'[^\w]', '_', cap_g).strip('_') or 'Group'
            sub_fname = 'subbouquet.%s__%s.tv' % (safe_name, g_safe)
            sub_lines = ['#NAME %s\n' % cap_g]
            for ch in gchs:
                try:
                    sub_lines.append(_svc(ch['url'], ch['name']) + '\n')
                    sub_lines.append('#DESCRIPTION %s\n' % ch.get('name', ''))
                except Exception:
                    pass
            try:
                import io as _io
                _sub_lines_u = [l.decode('utf-8', 'replace') if isinstance(l, bytes) else l
                                for l in sub_lines]
                with _io.open(os.path.join(enigma2, sub_fname), 'w', encoding='utf-8') as _wf:
                    _wf.writelines(_sub_lines_u)
                sub_ref = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % sub_fname
                sub_refs.append(sub_ref)
                iptvLogWrite('[Playlist] Written sub-bouquet: %s' % sub_fname)
            except Exception as e:
                iptvLogWrite('[Playlist] Sub-bouquet write error %s: %s' % (sub_fname, str(e)))
        parent_name  = prov_name
        parent_fname = 'userbouquet.%s_parent.tv' % safe_name
        parent_lines = ['#NAME %s\n' % parent_name]
        for sub_ref in sub_refs:
            parent_lines.append(sub_ref + '\n')
        try:
            with open(os.path.join(enigma2, parent_fname), 'w') as _wf:
                _wf.writelines(parent_lines)
            parent_ref = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % parent_fname
            iptvLogWrite('[Playlist] Written parent bouquet: %s' % parent_fname)
            created = [(parent_fname, parent_ref)]
        except Exception as e:
            iptvLogWrite('[Playlist] Parent bouquet write error: %s' % str(e))

    _updateBouquetsTv(created)
    _updateLamedb(safe_name, prov_name, channels, _sid_map, prov_ns=_prov_ns)

    # reloadBouquets must run on the Enigma2 main thread — calling eDVBDB
    # directly from a background thread causes a race condition that can
    # crash Enigma2.  reactor.callFromThread queues the call safely.
    def _do_reload_build():
        try:
            from enigma import eDVBDB
            eDVBDB.getInstance().reloadBouquets()
            iptvLogWrite('[Playlist] Enigma2 bouquets reloaded')
        except Exception as e:
            iptvLogWrite('[Playlist] Bouquet reload error: %s' % str(e))
    try:
        from twisted.internet import reactor as _reactor
        _reactor.callFromThread(_do_reload_build)
    except Exception:
        _do_reload_build()

    return len(created)


def _updatePlaylistBouquets(prov, channels, mode):
    """Update existing bouquet .tv files in-place, preserving DreamboxEdit order.

    channels — already-filtered channel list from the fresh M3U.
    mode     — 'top' or 'bottom': where new channels are inserted inside each bouquet.
    Returns  (n_bouquets_changed, error_string, bouquet_stats,
              new_channels_list, deleted_info_list).
    new_channels_list  — list of channel dicts that are brand-new (added this run).
    deleted_info_list  — list of (display_name, url) for channels removed this run.
    """
    _migrateSafeName(prov)
    import re as _re
    import io as _io
    import zlib as _zlib_upb

    prov_name = (prov.get('name') or 'Provider').strip()
    safe_name = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
    playback  = prov.get('playback_with', 'gstplayer')
    stype     = {'gst_player': '5001', 'exteplayer3': '5002', 'dvb': '1'}.get(playback, '4097')
    enigma2   = '/etc/enigma2'
    _m3u_src_upb = (prov.get('m3u_source') or prov.get('name') or safe_name).strip()
    _prov_ns = '%08X' % (_zlib_upb.crc32(_m3u_src_upb.encode('utf-8', 'replace')) & 0xFFFFFFFF)

    # ── URL identity helper — strips query string for token-stable comparison ──
    # tv.team and similar providers rotate the ?token=... on every M3U fetch.
    # We match channels by their path (scheme+host+path) and only use the full
    # URL when writing the actual service reference so playback still works.
    try:
        from urllib.parse import urlsplit as _urlsplit
    except ImportError:
        from urlparse import urlsplit as _urlsplit

    def _url_identity(u):
        """Return scheme+host+path, dropping query and fragment."""
        try:
            s = _urlsplit(u)
            return '%s://%s%s' % (s.scheme, s.netloc, s.path)
        except Exception:
            return u

    # URL → channel dict from fresh M3U (full URL as key)
    new_by_url = {}
    for ch in channels:
        url = (ch.get('url') or '').strip()
        if url:
            new_by_url[url] = ch

    # identity → full URL, for fresh M3U channels
    new_identity_to_url = {}
    for url in new_by_url:
        ident = _url_identity(url)
        new_identity_to_url[ident] = url

    # ── 1. Find existing bouquet files for this provider ──────────────────────
    bouquet_fnames = []
    try:
        for fname in sorted(os.listdir(enigma2)):
            if (_bouquet_file_belongs_to(fname, safe_name)
                    and fname.endswith('.tv')):
                bouquet_fnames.append(fname)
    except Exception:
        pass

    if not bouquet_fnames:
        # No existing bouquets — fall back to full build
        n = _buildPlaylistBouquets(prov, channels)
        return n, '', {}, [], []

    # ── 2. Parse each bouquet; record all URLs currently present ──────────────
    # bouquet_data[fname] = list of (raw_line, decoded_url_or_None)
    existing_urls      = set()   # full URLs stored in bouquet files
    existing_identities = set()  # identity (no query) of those URLs
    bouquet_data  = {}
    for fname in bouquet_fnames:
        fpath = os.path.join(enigma2, fname)
        rows  = []
        try:
            with _io.open(fpath, 'r', encoding='utf-8', errors='replace') as _f:
                for raw in _f:
                    raw  = raw.rstrip('\r\n')
                    url  = None
                    if raw.startswith('#SERVICE'):
                        try:
                            parts = raw.split(':', 10)
                            if len(parts) == 11:
                                candidate = (parts[10].strip()
                                             .replace('%3a', ':').replace('%3A', ':'))
                                if '://' in candidate:
                                    url = candidate
                                    existing_urls.add(url)
                                    existing_identities.add(_url_identity(url))
                        except Exception:
                            pass
                    rows.append((raw, url))
        except Exception:
            pass
        bouquet_data[fname] = rows

    # ── 3. Diff: new channels, deleted channels (identity-based) ──────────────
    all_new_identities = set(_url_identity(u) for u in new_by_url)
    new_identities     = all_new_identities - existing_identities   # genuinely new
    deleted_identities = existing_identities - all_new_identities   # genuinely gone

    # full URLs for genuinely new channels — ordered by M3U position
    _seen_new = set()
    new_urls  = []
    for _ch in channels:
        _u = (_ch.get('url') or '').strip()
        if _u and _url_identity(_u) in new_identities and _u not in _seen_new:
            new_urls.append(_u)
            _seen_new.add(_u)
    # full URLs in bouquet files that are genuinely gone (identity not in fresh M3U)
    deleted_urls = set(u for u in existing_urls if _url_identity(u) in deleted_identities)

    # token_refreshed: old full URL → new full URL, for channels whose path
    # is the same but token changed — we will rewrite these lines in place.
    token_refreshed = {}  # old_full_url → new_full_url
    for old_url in existing_urls:
        ident = _url_identity(old_url)
        if ident in new_identity_to_url:
            new_url = new_identity_to_url[ident]
            if new_url != old_url:
                token_refreshed[old_url] = new_url

    # Collect new channel dicts (returned to caller for selective picon download)
    new_channels_list = [new_by_url[u] for u in new_urls]
    # Will be populated during bouquet patching (step 6)
    deleted_info_list = []   # list of (display_name, url)

    # ── [UserDefined] Diff summary log ────────────────────────────────────────
    iptvLogWrite('[UserDefined] M3U channels: %d, Bouquet channels: %d, New: %d, Deleted: %d, Token-refreshed: %d'
                 % (len(new_by_url), len(existing_urls), len(new_urls), len(deleted_urls), len(token_refreshed)))
    if deleted_urls:
        for _u in list(deleted_urls)[:3]:
            iptvLogWrite('[UserDefined] DELETED URL sample: %s' % _u)
    if new_urls:
        for _u in list(new_urls)[:3]:
            iptvLogWrite('[UserDefined] NEW URL sample: %s' % _u)
    if token_refreshed:
        _sample = list(token_refreshed.items())[:1]
        iptvLogWrite('[UserDefined] Token-refresh sample: %s -> %s' % _sample[0])

    # ── 4. SID map (deterministic CRC) for new channels ───────────────────────
    _sid_map = _channel_sid_map(safe_name, channels)

    def _svc_line(ch):
        url      = (ch.get('url') or '').strip()
        safe_url = url.replace(':', '%3a')
        sid_hex, _ = _sid_map.get(url, ('1', '1'))
        return '#SERVICE %s:0:1:%s:1:1:%s:0:0:0:%s' % (stype, sid_hex, _prov_ns, safe_url)

    # ── 5. Map new channels to the bouquet that matches their group-title ──────
    def _group_safe(g):
        cap = g[:1].upper() + g[1:] if g else g
        return _re.sub(r'[^\w]', '_', cap).strip('_') or 'Bouquet'

    # Detect parent_sub strategy: it has a _parent.tv file containing sub-bouquet refs
    parent_fname  = 'userbouquet.%s_parent.tv' % safe_name
    is_parent_sub = parent_fname in bouquet_data

    new_for_bouquet = {}   # fname → [ch, ...]
    ungrouped_new   = []   # (group_name, ch) for groups with no existing bouquet

    # Build fallback map: group_safe_name → actual filename
    # Handles old position-number format: subbouquet.SAFE__N__GROUP.tv
    # e.g. subbouquet.TvTeam_2__1__Federal_Федеральные.tv
    # Maps 'Federal_Федеральные' → that filename so new channels can find it.
    _fallback_fname = {}  # group_safe → fname
    for _fn in bouquet_data:
        # Match: (userbouquet|subbouquet).SAFE_(N_)?GROUP.tv
        # Strip prefix and .tv suffix, then extract group part
        for _pfx in ('subbouquet.%s__' % safe_name,
                     'userbouquet.%s_' % safe_name):
            if _fn.startswith(_pfx) and _fn.endswith('.tv'):
                _stem = _fn[len(_pfx):-3]  # e.g. '1__Federal_Федеральные' or 'Federal_Федеральные'
                # Strip leading position number: N__ prefix
                _no_num = _re.sub(r'^\d+__', '', _stem)
                if _no_num and _no_num not in _fallback_fname:
                    _fallback_fname[_no_num] = _fn
                # Also index without stripping (for exact matches)
                if _stem and _stem not in _fallback_fname:
                    _fallback_fname[_stem] = _fn
                break

    for url in new_urls:
        ch    = new_by_url[url]
        g     = (ch.get('group') or ch.get('group_title') or 'General').strip() or 'General'
        # Try standard naming patterns first:
        #   same_playlist / all_and_groups → userbouquet.<safe>_<group>.tv
        #   parent_sub                     → subbouquet.<safe>__<group>.tv  (double __)
        fname1 = 'userbouquet.%s_%s.tv'  % (safe_name, _group_safe(g))
        fname2 = 'subbouquet.%s__%s.tv'  % (safe_name, _group_safe(g))
        _gs = _group_safe(g)
        if fname1 in bouquet_data:
            new_for_bouquet.setdefault(fname1, []).append(ch)
        elif fname2 in bouquet_data:
            new_for_bouquet.setdefault(fname2, []).append(ch)
        elif _gs in _fallback_fname:
            # Fallback: match by group name against position-number filenames
            # e.g. subbouquet.TvTeam_2__4__Movies_Кино.tv matched by 'Movies_Кино'
            new_for_bouquet.setdefault(_fallback_fname[_gs], []).append(ch)
        else:
            ungrouped_new.append((g, ch))

    # ── 6. Patch each existing bouquet file ────────────────────────────────────
    # Build URL → has_archive lookup from fresh M3U channels
    _markers_enabled = bool(prov.get('create_archive_markers', False))
    _url_has_archive = {}
    for _hac in channels:
        _hurl = (_hac.get('url') or '').strip()
        if _hurl:
            _url_has_archive[_hurl] = _hac.get('has_archive', False)
            try:
                _hs = _url_identity(_hurl)
                _url_has_archive[_hs] = _hac.get('has_archive', False)
            except Exception:
                pass

    updated_count = 0
    bouquet_stats = {}
    for fname, rows in bouquet_data.items():
        new_rows              = []
        skip_desc             = False
        _removing             = False
        _removing_url         = None
        changed               = False
        removed_in_file       = 0
        removed_names_in_file = []
        display_name          = fname
        token_refreshed_in_file = 0
        _last_svc_url         = None
        for raw, url in rows:
            if raw.startswith('#NAME') and display_name == fname:
                display_name = raw[5:].strip() or fname
            if skip_desc:
                skip_desc = False
                if not raw.startswith('#SERVICE'):
                    if _removing:
                        ch_name = raw.replace('#DESCRIPTION ', '', 1).strip()
                        removed_names_in_file.append(ch_name)
                        if _removing_url:
                            deleted_info_list.append((ch_name, _removing_url))
                        _removing     = False
                        _removing_url = None
                    changed = True
                    continue
                _removing     = False
                _removing_url = None
            if url is not None and url in deleted_urls:
                skip_desc        = True
                _removing        = True
                _removing_url    = url
                changed          = True
                removed_in_file += 1
                continue
            # Token refresh: same channel path, new token — rewrite the line in place
            if url is not None and url in token_refreshed:
                new_url = token_refreshed[url]
                new_ch  = new_by_url.get(new_url)
                if new_ch:
                    new_rows.append(_svc_line(new_ch))
                    token_refreshed_in_file += 1
                    changed = True
                    continue
            if raw.startswith('#DESCRIPTION ') and _last_svc_url is not None:
                _raw_name = raw.replace('#DESCRIPTION ', '', 1).replace('▶ ', '').replace('▶', '').strip()
                _arc = _markers_enabled and _url_has_archive.get(_last_svc_url, _url_has_archive.get(_url_identity(_last_svc_url), False))
                _new_raw = '#DESCRIPTION ▶ ' + _raw_name if _arc else '#DESCRIPTION ' + _raw_name
                if _new_raw != raw:
                    changed = True
                new_rows.append(_new_raw)
            else:
                if url is not None:
                    _last_svc_url = url
                new_rows.append(raw)

        # Insert new channels at top or bottom — M3U order, nothing else changed
        new_chs = new_for_bouquet.get(fname) or []
        if new_chs:
            changed   = True
            svc_lines = []
            for ch in new_chs:
                svc_lines.append(_svc_line(ch))
                svc_lines.append('#DESCRIPTION %s' % (ch.get('name') or ''))
            if mode == 'top':
                insert_at = 0
                for j, l in enumerate(new_rows):
                    if l.startswith('#NAME'):
                        insert_at = j + 1
                        break
                new_rows = new_rows[:insert_at] + svc_lines + new_rows[insert_at:]
            else:
                new_rows.extend(svc_lines)

        # Check if sub-bouquet is now empty (no real channel #SERVICE lines)
        # Note: check regardless of 'changed' — file may already be empty from
        # a previous run but still referenced in the parent bouquet
        _is_sub    = fname.startswith('subbouquet.')
        _real_svcs = sum(1 for l in new_rows
                         if l.startswith('#SERVICE') and '1:7:1:' not in l)
        if _is_sub and _real_svcs == 0:
            # Sub-bouquet is empty — delete file and remove FROM BOUQUET ref from parent
            # Record in bouquet_stats so M3U Update Info shows the removed bouquet/channels
            bouquet_stats[display_name] = {
                'added':          0,
                'removed':        removed_in_file,
                'added_names':    [],
                'removed_names':  removed_names_in_file,
                'bouquet_deleted': True,
            }
            try:
                os.remove(os.path.join(enigma2, fname))
                iptvLogWrite('[Playlist Update] Deleted empty sub-bouquet: %s' % fname)
                _ref = 'FROM BOUQUET "%s"' % fname
                for _pfname in list(bouquet_data.keys()):
                    if not _pfname.startswith('userbouquet.'):
                        continue
                    # Read fresh from disk — not from stale bouquet_data snapshot
                    _pfpath = os.path.join(enigma2, _pfname)
                    try:
                        with _io.open(_pfpath, 'r', encoding='utf-8') as _pf:
                            _plines = _pf.read().splitlines()
                    except Exception:
                        continue
                    _new_plines = [l for l in _plines if _ref not in l]
                    if len(_new_plines) != len(_plines):
                        try:
                            with _io.open(_pfpath, 'w', encoding='utf-8') as _pf:
                                _pf.write('\n'.join(_new_plines) + '\n')
                            iptvLogWrite('[Playlist Update] Removed ref to %s from %s'
                                         % (fname, _pfname))
                        except Exception as _pe:
                            iptvLogWrite('[Playlist Update] Parent write error: %s' % str(_pe))
            except Exception as _de:
                iptvLogWrite('[Playlist Update] Delete error %s: %s' % (fname, str(_de)))
        elif changed:
            try:
                with _io.open(os.path.join(enigma2, fname), 'w', encoding='utf-8') as _f:
                    _f.write('\n'.join(new_rows) + '\n')
                updated_count += 1
                bouquet_stats[display_name] = {
                    'added':         len(new_chs),
                    'removed':       removed_in_file,
                    'added_names':   [ch.get('name', '') for ch in new_chs],
                    'removed_names': removed_names_in_file,
                }
                _reasons = []
                if removed_in_file:
                    _reasons.append('-%d removed' % removed_in_file)
                if new_chs:
                    _reasons.append('+%d added' % len(new_chs))
                if token_refreshed_in_file:
                    _reasons.append('%d token-refreshed' % token_refreshed_in_file)
                if changed and not removed_in_file and not new_chs and not token_refreshed_in_file:
                    _reasons.append('orphaned #DESCRIPTION line')
                iptvLogWrite('[Playlist Update] Patched bouquet: %s — %s'
                             % (fname, ', '.join(_reasons) or 'unknown reason'))
            except Exception as e:
                iptvLogWrite('[Playlist Update] Write error %s: %s' % (fname, str(e)))

    # ── 7. Create new bouquet files for groups that had no existing bouquet ────
    # Build M3U group order for correct insertion position in parent file
    _m3u_group_order = []
    _seen_grp = set()
    for _ch in channels:
        _g = (_ch.get('group') or _ch.get('group_title') or 'General').strip() or 'General'
        if _g not in _seen_grp:
            _m3u_group_order.append(_g)
            _seen_grp.add(_g)

    newly_created = []
    by_group = {}
    for g, ch in ungrouped_new:
        by_group.setdefault(g, []).append(ch)
    for g, chs in by_group.items():
        cap    = g[:1].upper() + g[1:] if g else g
        g_safe = _group_safe(g)
        # parent_sub → subbouquet with double __ ; other strategies → userbouquet
        if is_parent_sub:
            fname = 'subbouquet.%s__%s.tv' % (safe_name, g_safe)
        else:
            fname = 'userbouquet.%s_%s.tv'  % (safe_name, g_safe)
        lines = ['#NAME %s' % cap]
        for ch in chs:
            lines.append(_svc_line(ch))
            lines.append('#DESCRIPTION %s' % (ch.get('name') or ''))
        try:
            with _io.open(os.path.join(enigma2, fname), 'w', encoding='utf-8') as _f:
                _f.write('\n'.join(lines) + '\n')
            ref = ('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet'
                   % fname)
            if is_parent_sub:
                # Insert the sub-bouquet reference at the correct M3U position
                # in the parent bouquet file rather than always appending.
                try:
                    parent_fpath = os.path.join(enigma2, parent_fname)
                    with _io.open(parent_fpath, 'r', encoding='utf-8') as _pf:
                        _parent_lines = _pf.read().splitlines()
                    # Find which groups come after this group in M3U order
                    try:
                        _this_pos = _m3u_group_order.index(g)
                    except ValueError:
                        _this_pos = len(_m3u_group_order)
                    _groups_after = set(_m3u_group_order[_this_pos + 1:])
                    # Find first line in parent that references a group coming after
                    _insert_at = None
                    for _pi, _pl in enumerate(_parent_lines):
                        if 'FROM BOUQUET' not in _pl:
                            continue
                        # Extract filename from FROM BOUQUET "..." reference
                        try:
                            _ref_fname = _pl.split('"')[1]
                        except Exception:
                            continue
                        # Map ref filename back to group name
                        for _ag in _groups_after:
                            _ag_safe = _group_safe(_ag)
                            if ('__%s.tv' % _ag_safe in _ref_fname or
                                    '_%s.tv' % _ag_safe in _ref_fname):
                                _insert_at = _pi
                                break
                        if _insert_at is not None:
                            break
                    if _insert_at is not None:
                        _parent_lines.insert(_insert_at, ref)
                    else:
                        _parent_lines.append(ref)
                    with _io.open(parent_fpath, 'w', encoding='utf-8') as _pf:
                        _pf.write('\n'.join(_parent_lines) + '\n')
                    iptvLogWrite('[Playlist Update] Inserted sub-ref for %s at pos %s'
                                 % (fname, str(_insert_at) if _insert_at is not None else 'end'))
                except Exception as _pe:
                    iptvLogWrite('[Playlist Update] Parent ref error: %s' % str(_pe))
            else:
                newly_created.append((fname, ref))
            updated_count += 1
            bouquet_stats[cap] = {
                'added':         len(chs),
                'removed':       0,
                'added_names':   [ch.get('name', '') for ch in chs],
                'removed_names': [],
            }
            iptvLogWrite('[Playlist Update] Created new bouquet: %s' % fname)
        except Exception as e:
            iptvLogWrite('[Playlist Update] Create error %s: %s' % (fname, str(e)))

    if newly_created:
        _updateBouquetsTv(newly_created)

    # ── 8. Update lamedb for all channels ─────────────────────────────────────
    _updateLamedb(safe_name, prov_name, channels, _sid_map, prov_ns=_prov_ns)

    # ── 9. Reload Enigma2 channel list ────────────────────────────────────────
    # Must run on the Enigma2 main thread — see _buildPlaylistBouquets for details.
    def _do_reload_update():
        try:
            from enigma import eDVBDB
            eDVBDB.getInstance().reloadBouquets()
            iptvLogWrite('[Playlist Update] Enigma2 bouquets reloaded')
        except Exception as e:
            iptvLogWrite('[Playlist Update] Bouquet reload error: %s' % str(e))
    try:
        from twisted.internet import reactor as _reactor
        _reactor.callFromThread(_do_reload_update)
    except Exception:
        _do_reload_update()

    return updated_count, '', bouquet_stats, new_channels_list, deleted_info_list


def _deletePicons(prov_name, deleted_info, picon_naming, picon_location, picon_symlink, picon_stype='4097', picon_with_folder=True, prov_ns=None):
    """Delete picon files (and their symlinks) for channels removed during a
    'User Defined' update.

    deleted_info — list of (display_name, url) tuples for removed channels.
    Returns the number of picon files actually deleted from disk.
    """
    import re as _re
    import zlib as _zlib

    if not deleted_info:
        return 0

    safe_name = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
    # picon_location is now an actual path; legacy keyword migration
    if picon_location in ('enigma2_picon',):
        picon_location = '/usr/share/enigma2/picon'
    elif picon_location in ('plugin_dir', ''):
        picon_location = getDataDir()
    if picon_with_folder:
        folder = os.path.join(picon_location, '%s_Picons' % safe_name)
    else:
        folder = picon_location
    symlink_dir = '/usr/share/enigma2/picon'

    deleted_count = 0
    for display_name, url in deleted_info:
        try:
            if picon_naming == 'reference' and url:
                try:
                    from urllib.parse import urlsplit as _usp_del
                except ImportError:
                    from urlparse import urlsplit as _usp_del
                try:
                    _s_del = _usp_del(url)
                    _ident_del = '%s://%s%s' % (_s_del.scheme, _s_del.netloc, _s_del.path)
                except Exception:
                    _ident_del = url
                try:
                    url_bytes = _ident_del.encode('utf-8', 'replace')
                except Exception:
                    url_bytes = _ident_del.encode('utf-8', 'ignore')
                sid      = _zlib.crc32(url_bytes) & 0xFFFF
                safe_file = '%s_0_1_%s_1_1_%s_0_0_0' % (picon_stype, '%X' % sid, prov_ns if prov_ns else 'CCCC0000')
            else:
                safe_file = _re.sub(r'[^\w\- ]', '_',
                                    (display_name or '').strip()) or 'channel'
            fname = safe_file + '.png'
            fpath = os.path.join(folder, fname)
            if os.path.isfile(fpath):
                try:
                    os.remove(fpath)
                    deleted_count += 1
                    iptvLogWrite('[Picon Delete] Removed: %s' % fname)
                except Exception as _e:
                    iptvLogWrite('[Picon Delete] Error removing %s: %s'
                                 % (fname, str(_e)))
            if picon_symlink:
                lpath = os.path.join(symlink_dir, fname)
                if os.path.lexists(lpath):
                    try:
                        os.remove(lpath)
                        iptvLogWrite('[Picon Delete] Removed symlink: %s' % fname)
                    except Exception as _e:
                        iptvLogWrite('[Picon Delete] Error removing symlink %s: %s'
                                     % (fname, str(_e)))
        except Exception:
            pass
    return deleted_count


def _removeCustomEpgFromSources(safe_name):
    """Remove all custom EPG blocks for this provider from CustomIPTV.sources.xml."""
    import re as _re
    combined = '/etc/epgimport/CustomIPTV.sources.xml'
    try:
        with open(combined, 'r') as f:
            content = f.read()
    except Exception:
        return
    # Remove any block whose BEGIN tag starts with safe_name + '_customepg_'
    pattern = r'\s*<!-- BEGIN:%s_customepg_[^-].*?-->.*?<!-- END:%s_customepg_[^-].*?-->' % (
        _re.escape(safe_name), _re.escape(safe_name))
    new_content = _re.sub(pattern, '', content, flags=_re.DOTALL)
    if new_content != content:
        try:
            with open(combined, 'w') as f:
                f.write(new_content)
            iptvLogWrite('[CustomEPG] Removed custom EPG blocks for %s from %s' % (safe_name, combined))
        except Exception as e:
            iptvLogWrite('[CustomEPG] Remove error: %s' % str(e))


def _mergeCustomEpgIntoChannelsFile(safe_name, channels_path, prov_name=''):
    """After Create Playlist writes channels_path, merge CustomEPG assignments
    into the same file:
    - Find lines whose service reference matches a custom-assigned channel
    - Replace their id= with the custom EPG ID
    Then add the custom source URLs to CustomIPTV.sources.xml.
    """
    import json, os, re as _re

    # Find the workdir for Custom EPG Sources
    workdir = None
    for base in [getDataDir(), '/etc/enigma2/epgimport']:
        d = os.path.join(base, 'Custom EPG Sources')
        if os.path.isdir(d):
            workdir = d
            break
    if not workdir:
        workdir = os.path.join(getDataDir(), 'Custom EPG Sources')

    # Both _generateEpgImportFile and _getJsonFile now use the same sanitizer
    # re.sub(r'[^\w]', '_', name) so safe_name always matches JSON filename directly
    json_file = os.path.join(workdir, safe_name + '_customepg.json')
    if not os.path.isfile(json_file):
        iptvLogWrite('[CustomEPG] No JSON file found: %s' % json_file)
        return
    try:
        with open(json_file) as f:
            epg_data = json.load(f)
    except Exception as e:
        iptvLogWrite('[CustomEPG] JSON read error: %s' % str(e))
        return

    # Build map: sref -> (custom_epg_id, source_url)
    # sref stored in JSON is the full service reference.
    # Normalise any 4097: srefs to 1:...:http%3a//example.m3u8
    # so assignments made before the Xtream sref fix still match.
    def _norm_sref(s):
        # Only convert Xtream-style srefs: 4097: type with a real URL
        # (stored before the Xtream sref fix). The placeholder
        # http%3a//example.m3u8 is already correct and needs no conversion.
        # Regular provider 4097: srefs with real URLs must stay as-is.
        parts = s.split(':')
        if parts[0] == '4097' and len(parts) >= 11:
            url_part = parts[10] if len(parts) > 10 else ''
            # Only convert if it's a real URL (not already a placeholder)
            if url_part and 'example.m3u8' not in url_part and '/live/' in url_part:
                return '1:' + ':'.join(parts[1:10]) + ':http%3a//example.m3u8'
        return s
    sref_map = {}
    for bouquet in epg_data.get('Bouquets', []):
        for ch in bouquet.get('channel', []):
            sref = _norm_sref(ch.get('serviceid', '').strip())
            epgid = ch.get('epgid', '').strip()
            src_url = ch.get('source', '').strip()
            src_name = ch.get('sourcename', '').strip()
            epg_disp = ch.get('epg_display_name', '').strip()
            if sref and epgid:
                sref_map[sref] = (epgid, src_url, src_name, epg_disp)

    if not sref_map:
        return

    # Read the channels file
    # If file is missing or has no <channel> lines, write directly from JSON
    lines = []
    _file_has_channels = False
    if os.path.isfile(channels_path):
        try:
            with open(channels_path, 'r') as f:
                lines = f.readlines()
            _file_has_channels = any('<channel ' in l for l in lines)
        except Exception:
            lines = []

    if not _file_has_channels:
        # File missing or empty — write directly from JSON assignments
        ch_lines = ['<?xml version="1.0" encoding="utf-8"?>\n', '<channels>\n']
        replaced_sources = {}
        for sref_key, (epgid, src_url, src_name, epg_disp) in sref_map.items():
            # Find channel description from JSON for the comment
            _desc = ''
            for _bq in epg_data.get('Bouquets', []):
                for _ch in _bq.get('channel', []):
                    if _norm_sref(_ch.get('serviceid', '')) == sref_key:
                        _desc = _ch.get('description', '')
                        break
                if _desc:
                    break
            epg_esc  = epgid.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
            name_esc = _desc.replace('--', '-').replace('>', '-')
            ch_lines.append('  <channel id="%s">%s</channel><!-- %s -->\n' % (epg_esc, sref_key, name_esc))
            if src_url:
                replaced_sources[src_url] = src_name
        ch_lines.append('</channels>\n')
        try:
            import os as _os2
            _os2.makedirs(_os2.path.dirname(channels_path), exist_ok=True)
            with open(channels_path, 'w') as _cf:
                _cf.writelines(ch_lines)
            iptvLogWrite('[CustomEPG] Created channels XML from JSON: %s (%d channels)' % (channels_path, len(ch_lines) - 2))
        except Exception as e:
            iptvLogWrite('[CustomEPG] Create from JSON error: %s' % str(e))
        # Add sources even when writing from scratch
        for src_url, src_name in replaced_sources.items():
            src_label = src_name.replace('_', ' ').strip()
            _updateCombinedSourcesFile(
                safe_name + '_customepg_' + src_name.replace(' ', '_'),
                ('%s (%s-CustomEPG)' % (prov_name, src_label)) if src_label else ('%s (Custom EPG)' % prov_name) if prov_name else 'Custom EPG',
                channels_path,
                src_url)
        return

    # For each line, check if service reference matches a custom assignment
    # Line format: <channel id="ID">SREF</channel><!-- NAME -->
    pat = _re.compile(r'(<channel id=")[^"]*(">[^<]*</channel>.*)')
    new_lines = []
    replaced_sources = {}  # src_url -> src_name for sources to add

    for line in lines:
        m = pat.search(line)
        if m:
            # Extract the sref from the line content between > and </channel>
            inner = line[m.start():]
            # sref is between "> and </channel>
            sref_m = _re.search(r'">([^<]+)</channel>', inner)
            if sref_m:
                line_sref = sref_m.group(1).strip()
                if line_sref in sref_map:
                    epgid, src_url, src_name, epg_disp = sref_map[line_sref]
                    epg_esc = epgid.replace('&','&amp;').replace('"','&quot;').replace('<','&lt;').replace('>','&gt;')
                    new_line = pat.sub(r'\g<1>' + epg_esc + r'\g<2>', line)
                    if epg_disp:
                        _safe_disp = epg_disp.replace('--', '-').replace('>', '-')
                        def _update_comment(mc, _d=_safe_disp):
                            orig = mc.group(1).strip()
                            if ' | -> ' in orig:
                                orig = orig.split(' | -> ')[0].strip()
                            return '<!-- %s | -> %s -->' % (orig, _d)
                        new_line = _re.sub(r'<!--\s*(.*?)\s*-->', _update_comment, new_line)
                    new_lines.append(new_line)
                    if src_url:
                        replaced_sources[src_url] = src_name
                    iptvLogWrite('[CustomEPG] Replaced sref %s -> id=%s' % (line_sref[:40], epgid))
                    continue
        new_lines.append(line)

    # Append any assigned channels from JSON that were not found in the XML
    _already_written = set()
    for _line in new_lines:
        _sm = _re.search(r'">([^<]+)</channel>', _line)
        if _sm:
            _already_written.add(_sm.group(1).strip())
    for sref_key, (epgid, src_url, src_name, epg_disp) in sref_map.items():
        if sref_key not in _already_written:
            _desc = ''
            for _bq in epg_data.get('Bouquets', []):
                for _ch in _bq.get('channel', []):
                    if _norm_sref(_ch.get('serviceid', '')) == sref_key:
                        _desc = _ch.get('description', '')
                        break
                if _desc:
                    break
            epg_esc  = epgid.replace('&','&amp;').replace('"','&quot;').replace('<','&lt;').replace('>','&gt;')
            name_esc = _desc.replace('--', '-').replace('>', '-') if _desc else sref_key[:30]
            _disp_esc = epg_disp.replace('--', '-').replace('>', '-') if epg_disp else ''
            _comment  = ('%s | -> %s' % (name_esc, _disp_esc)) if _disp_esc else name_esc
            # Insert before </channels>
            for _i in range(len(new_lines)-1, -1, -1):
                if '</channels>' in new_lines[_i]:
                    new_lines.insert(_i, '  <channel id="%s">%s</channel> <!-- %s -->\n' % (epg_esc, sref_key, _comment))
                    break
            if src_url:
                replaced_sources[src_url] = src_name
            iptvLogWrite('[CustomEPG] Appended missing assignment: %s -> %s' % (sref_key[:40], epgid))

    # Write back
    try:
        with open(channels_path, 'w') as f:
            f.writelines(new_lines)
        iptvLogWrite('[CustomEPG] Merged %d custom EPG assignments into %s' % (len(replaced_sources), channels_path))
    except Exception as e:
        iptvLogWrite('[CustomEPG] Merge write error: %s' % str(e))
        return

    # Add custom source URLs to CustomIPTV.sources.xml
    for src_url, src_name in replaced_sources.items():
        # Restore spaces (stored with _ in epg_sources.txt) for readable label
        src_label = src_name.replace('_', ' ').strip()
        _updateCombinedSourcesFile(
            safe_name + '_customepg_' + src_name.replace(' ', '_'),
            ('%s (%s-CustomEPG)' % (prov_name, src_label)) if src_label else ('%s (Custom EPG)' % prov_name) if prov_name else 'Custom EPG',
            channels_path,
            src_url)


def _updateCombinedSourcesFile(safe_name, prov_name, channels_path, xmltv_url):
    import re as _re
    combined = '/etc/epgimport/CustomIPTV.sources.xml'
    begin    = '<!-- BEGIN:%s -->' % safe_name
    end_tag  = '<!-- END:%s -->'   % safe_name
    try:
        with open(combined, 'r') as _f:
            content = _f.read()
    except Exception:
        content = ('<?xml version="1.0" encoding="utf-8"?>\n'
                   '<sources>\n'
                   '  <sourcecat sourcecatname="CustomIPTV">\n'
                   '  </sourcecat>\n'
                   '</sources>\n')
    content = _re.sub(
        r'\s*' + _re.escape(begin) + r'.*?' + _re.escape(end_tag),
        '', content, flags=_re.DOTALL)
    if xmltv_url and channels_path and prov_name:
        # Normalise URL scheme to lowercase — EPGImport is case-sensitive and
        # will reject "Http://..." as a non-existent file instead of a URL.
        try:
            from _epg import _normalizeHttpUrl
            xmltv_url = _normalizeHttpUrl(xmltv_url)
        except Exception:
            colon = xmltv_url.find('://')
            if colon > 0:
                xmltv_url = xmltv_url[:colon].lower() + xmltv_url[colon:]
        entry = (
            '\n    %s\n'
            '    <source type="gen_xmltv" nocheck="1" offset="0000" channels="%s">\n'
            '      <description>%s</description>\n'
            '      <url><![CDATA[%s]]></url>\n'
            '    </source>\n'
            '    %s'
        ) % (begin, channels_path, prov_name, xmltv_url, end_tag)
        content = content.replace('  </sourcecat>', entry + '\n  </sourcecat>')
    try:
        with open(combined, 'w') as _f:
            _f.write(content)
        iptvLogWrite('[Playlist] EPG combined sources updated: %s' % combined)
    except Exception as e:
        iptvLogWrite('[Playlist] EPG combined sources write error: %s' % str(e))


def _updateLamedb(safe_name, prov_name, channels, sid_map,
                  remove_sids=None, prov_ns=None):
    """Write/update lamedb entries for this provider's IPTV channels.

    Service refs now use SID = CRC32(URL), TSID=NID=NS=0 — the standard
    'pure IPTV' format that DreamboxEdit recognises and allows full editing.

    Our entries are identified by their SID values (passed via sid_map or
    remove_sids), so only our channels are ever touched.

    remove_sids  — optional set of SID hex strings to purge (used when
                   deleting a provider whose bouquets have already been read).
    """
    import zlib
    # Also remove any leftover transponder entries written by older builds
    # (those used NID=EC, TSID=CRC32(safe_name)).
    old_tsid_hex = '%X' % (zlib.crc32(safe_name.encode('utf-8', 'replace')) & 0xFFFF)

    enigma2_dir = '/etc/enigma2'
    path5 = os.path.join(enigma2_dir, 'lamedb5')
    path4 = os.path.join(enigma2_dir, 'lamedb')
    try:
        if os.path.exists(path5):
            _updateLamedbN(path5, 5, prov_name, channels, sid_map,
                           old_tsid_hex, remove_sids, prov_ns)
        else:
            _updateLamedbN(path4, 4, prov_name, channels, sid_map,
                           old_tsid_hex, remove_sids, prov_ns)
    except Exception as e:
        iptvLogWrite('[Playlist] lamedb update error: %s' % str(e))


def _updateLamedbN(path, ver, prov_name, channels, sid_map,
                   old_tsid_hex, remove_sids, prov_ns=None):
    """Shared lamedb writer for v4 and v5.

    Entries are written as SID:0:0:0 (TSID=NID=NS=0) — the pure-IPTV
    format that DreamboxEdit handles as a proper URI service with full
    editing support (play, URL, provider, etc.).
    """
    import re as _re
    _ns = prov_ns if prov_ns else 'CCCC0000'
    EMPTY4 = 'eDVB services /4/\ntransponders\n\nend\nservices\n\nend\n'
    EMPTY5 = 'eDVB services /5/\ntransponders\n\nend\nservices\n\nend\n'
    EMPTY  = EMPTY5 if ver == 5 else EMPTY4

    # Build the complete SID set to remove: current channels + explicit list.
    sid_set = set()
    for url, (sh, _) in (sid_map or {}).items():
        sid_set.add(sh.upper())
    for sh in (remove_sids or set()):
        sid_set.add(sh.upper())

    try:
        with open(path, 'r') as _f:
            raw = _f.read()
    except Exception:
        raw = EMPTY

    if 'transponders' not in raw or 'services' not in raw:
        raw = EMPTY

    # Use (?!.*\ntransponders) to prevent cross-section matching
    tp_m = _re.search(r'transponders\n(.*?)\nend', raw, _re.DOTALL)
    sv_m = _re.search(r'services\n((?:(?!\ntransponders).)*?)\nend', raw, _re.DOTALL)
    if not tp_m or not sv_m:
        raw  = EMPTY
        tp_m = _re.search(r'transponders\n(.*?)\nend', raw, _re.DOTALL)
        sv_m = _re.search(r'services\n((?:(?!\ntransponders).)*?)\nend', raw, _re.DOTALL)
    # Safety: if still None after EMPTY fallback, abort gracefully
    if not tp_m or not sv_m:
        iptvLogWrite('[Playlist] lamedb%d: could not parse structure, skipping' % ver)
        return

    # ── strip old entries ───────────────────────────────────────────────────
    if ver == 5:
        def _strip5(body, prefix, by_tsid=False):
            lines, result, i = body.split('\n'), [], 0
            while i < len(lines):
                line = lines[i]
                if line.startswith(prefix + ':'):
                    parts = line[len(prefix) + 1:].split('/')
                    # by_tsid: transponder cleanup (old EC:TSID format)
                    # else: service cleanup by SID
                    match = (by_tsid
                             and len(parts) >= 2
                             and parts[1].upper() == old_tsid_hex.upper())
                    match = match or (not by_tsid
                                      and len(parts) >= 1
                                      and parts[0].upper() in sid_set)
                    # Also remove legacy EC-format service entries
                    # (NID = parts[2] = 'EC') regardless of sid_set.
                    match = match or (not by_tsid
                                      and len(parts) >= 3
                                      and parts[2].upper() == 'EC')
                    if match:
                        i += 1
                        while i < len(lines) and lines[i].strip() != '/':
                            i += 1
                        i += 1
                        continue
                result.append(line)
                i += 1
            return '\n'.join(result)
        tp_body = _strip5(tp_m.group(1), 't', by_tsid=True)
        # Regex pre-pass: wipe EC-format entries before line-counting strip.
        # Handles any line-count or encoding variations in the lamedb5 format.
        # lamedb5 service entry: s:SID/TSID/EC/NS\nName\np:...\n/
        _sv_raw = _re.sub(
            r'(?i)s:[0-9a-f]+/[0-9a-f]+/EC/[^\n]*\n[^\n]*\n[^\n]*/\n?',
            '', sv_m.group(1))
        sv_body = _strip5(_sv_raw, 's', by_tsid=False)
    else:
        def _strip_tp4(body):
            # Remove legacy transponder entries: NID:TSID (NID=EC, TSID=old_tsid)
            lines, result, skip = body.split('\n'), [], False
            for line in lines:
                s = line.strip()
                if s and not s.startswith('\t') and ':' in s:
                    parts = s.split(':')
                    skip = (len(parts) == 2
                            and parts[0].upper() == 'EC'
                            and parts[1].upper() == old_tsid_hex.upper())
                    if skip:
                        continue
                elif skip and line.startswith('\t'):
                    continue
                else:
                    skip = False
                result.append(line)
            return '\n'.join(result)

        def _strip_sv4(body):
            # Remove service entries whose SID (field 0) is in sid_set,
            # OR whose NID (field 2) is EC — the legacy marker written by
            # older plugin builds that is never used by real DVB services.
            # Format: SID:TSID:NID:NS  then 2 more lines (name, provider)
            lines, result, i = body.split('\n'), [], 0
            while i < len(lines):
                line  = lines[i]
                parts = line.split(':')
                if (len(parts) >= 4
                        and _re.match(r'^[0-9A-Fa-f]+$', parts[0].strip())):
                    by_sid = parts[0].strip().upper() in sid_set
                    by_ec  = parts[2].strip().upper() == 'EC'
                    if by_sid or by_ec:
                        i += 3
                        continue
                result.append(line)
                i += 1
            return '\n'.join(result)

        tp_body = _strip_tp4(tp_m.group(1))
        # Regex pre-pass: wipe EC-format entries before line-counting strip.
        # Handles any line-count or encoding variations in the lamedb4 format.
        # lamedb4 service entry: SID:TSID:EC:NS\nName\np:...\n
        _sv_raw = _re.sub(
            r'(?i)[0-9a-f]+:[0-9a-f]+:EC:[^\n]*\n[^\n]*\n[^\n]*\n?',
            '', sv_m.group(1))
        sv_body = _strip_sv4(_sv_raw)

    # ── build new entries (SID:0:0:0 format) ───────────────────────────────
    new_sv = ''
    if channels and sid_map:
        prov_s = (prov_name or 'IPTV').replace(',', ' ').replace('/', ' ')
        blocks = []
        for ch in channels:
            url = (ch.get('url') or '').strip()
            if not url or url not in sid_map:
                continue
            sid_h, _ = sid_map[url]
            name = (ch.get('name') or 'Channel').replace('\n', ' ')
            if ver == 5:
                blocks.append('s:%s/1/1/%s\n%s\np:%s,f:0,n:0,N:0,\n/' % (
                    sid_h.upper(), _ns, name, prov_s))
            else:
                blocks.append('%s:1:1:%s\n%s\np:%s,f:0' % (
                    sid_h.upper(), _ns, name, prov_s))
        new_sv = '\n'.join(blocks)

    def _join(existing, new):
        e = existing.strip('\n')
        n = new.strip('\n')
        if e and n:
            return e + '\n' + n
        return e or n

    sv_final = _join(sv_body, new_sv)
    tp_final = tp_body.strip('\n')  # transponders section: keep as-is (no new entries)

    hdr_end = raw.find('transponders')
    out = (raw[:hdr_end]
           + 'transponders\n'
           + (tp_final + '\n' if tp_final.strip() else '')
           + 'end\nservices\n'
           + (sv_final + '\n' if sv_final.strip() else '')
           + 'end\n')
    try:
        # Write atomically: write to a temp file first, then rename.
        # On Linux, os.rename() is atomic — Enigma2 always reads either the
        # old complete file or the new complete file, never a half-written one.
        _tmp = path + '.tmp'
        with open(_tmp, 'w') as _f:
            _f.write(out)
        os.rename(_tmp, path)
        n_ch = len([c for c in channels
                    if (c.get('url') or '').strip() in sid_map])
        iptvLogWrite('[Playlist] lamedb%d updated (%d channels, SID:1:1:CCCC0000 format)'
                     % (ver, n_ch))
    except Exception as e:
        iptvLogWrite('[Playlist] lamedb%d write error: %s' % (ver, str(e)))


def _lookupXmltvChannelIds(xmltv_source, prov_name, channels, strict=False):
    """Parse only the <channel> section of an XMLTV file and return
    {m3u_channel_url: xmltv_channel_id} so the EPG channels XML uses the
    real XMLTV channel id (e.g. 'ch1485', '2249') instead of the M3U
    tvg-id or display name.

    Matching priority:
      1. xmltv channel id (case-insensitive) == M3U tvg-id
      2. XMLTV <display-name> (case-insensitive) == M3U tvg-id or channel name
         (skipped when strict=True)

    strict=True is used for Xtream providers where epg_channel_id from
    get_live_streams IS the XMLTV channel id.  A display-name fallback would
    risk matching the wrong channel when a bad epg_channel_id is returned by
    the Xtream panel, producing wrong EPG in the Enigma2 channel list.
    With strict=True, channels whose epg_channel_id does not exactly match
    any XMLTV channel id are simply omitted — showing no EPG is better than
    showing EPG from a completely different channel.
    """
    import xml.etree.ElementTree as _ET
    import gzip as _gz

    if not xmltv_source:
        return {}

    def _norm_id(s):
        """Return normalised variants of a channel id for fuzzy matching.
        Strips common prefixes ('ch', 'tvg_', 'tvg-') so that
        M3U tvg-id='tvg_2010' can match XMLTV id='ch2010' via numeric '2010'."""
        s = s.strip().lower()
        variants = {s}
        for pfx in ('tvg_', 'tvg-', 'ch'):
            if s.startswith(pfx):
                variants.add(s[len(pfx):])
        return variants

    tvgid_to_urls = {}
    name_to_urls  = {}
    for ch in channels:
        url    = (ch.get('url')    or '').strip()
        tvg_id = (ch.get('tvg_id') or '').strip()
        name   = (ch.get('name')   or '').strip()
        if not url:
            continue
        if tvg_id:
            for v in _norm_id(tvg_id):
                tvgid_to_urls.setdefault(v, []).append(url)
        if name:
            name_to_urls.setdefault(name.lower(), []).append(url)

    if not tvgid_to_urls and not name_to_urls:
        return {}

    xmltv_path = None
    if xmltv_source.lower().startswith(('http://', 'https://')):
        try:
            xmltv_path = _downloadXMLTVToCache(xmltv_source, prov_name or 'tmp')
        except Exception:
            return {}
    else:
        xmltv_path = xmltv_source

    if not xmltv_path or not os.path.isfile(xmltv_path):
        return {}

    url_to_xmltvid = {}
    _fh = None
    try:
        _fh  = open(xmltv_path, 'rb')
        _magic = _fh.read(2); _fh.seek(0)
        _src = (_gz.GzipFile(fileobj=_fh) if _magic == b'\x1f\x8b' else _fh)
        try:
            for _ev, elem in _ET.iterparse(_src, events=('start', 'end')):
                if _ev == 'start' and elem.tag == 'programme':
                    break
                if _ev == 'end' and elem.tag == 'channel':
                    xmltv_id = (elem.get('id') or '').strip()
                    if not xmltv_id:
                        elem.clear()
                        continue
                    matched_urls = set()
                    # 1. xmltv channel id matches M3U tvg-id (with prefix normalisation)
                    for xv in _norm_id(xmltv_id):
                        for url in tvgid_to_urls.get(xv, []):
                            matched_urls.add(url)
                    # 2. XMLTV display-name matches M3U tvg-id or channel name.
                    # Skipped in strict mode (Xtream): epg_channel_id IS the XMLTV
                    # channel id so a display-name fallback would risk matching the
                    # wrong channel when the Xtream panel has bad epg_channel_id data.
                    if not matched_urls and not strict:
                        for dn in elem.findall('display-name'):
                            dn_low = (dn.text or '').strip().lower()
                            if not dn_low:
                                continue
                            for url in tvgid_to_urls.get(dn_low, []):
                                matched_urls.add(url)
                            for url in name_to_urls.get(dn_low, []):
                                matched_urls.add(url)
                    for url in matched_urls:
                        if url not in url_to_xmltvid:
                            url_to_xmltvid[url] = xmltv_id
                    elem.clear()
        except Exception:
            pass
    except Exception:
        pass
    finally:
        try:
            if _fh:
                _fh.close()
        except Exception:
            pass

    iptvLogWrite('[Playlist] XMLTV id lookup: matched %d of %d channels'
                 % (len(url_to_xmltvid), len(channels)))
    return url_to_xmltvid


def _generateEpgImportFile(provider, channels, strict_id_match=False):
    import re as _re
    import zlib as _zlib_epg
    prov_name      = (provider.get('name') or 'Provider').strip()
    safe_name      = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
    epg_dir        = '/etc/epgimport/CustomIPTV'
    epg_parse_type = (provider.get('epg_parse_type') or 'off').strip()
    xmltv_url      = (provider.get('xmltv_url') or '').strip()
    playback       = provider.get('playback_with', 'gstplayer')
    # Service type in the EPG channels XML must match the bouquet service type
    # so EPGImport can normalise and match the two references.  EPGImport strips
    # the URL portion when comparing, so only type+SID+TSID+NID+NS need to match.
    stype = {'gst_player': '5001', 'exteplayer3': '5002', 'dvb': '1'}.get(playback, '4097')
    _m3u_src_epg = (provider.get('m3u_source') or provider.get('name') or safe_name).strip()
    _prov_ns_epg = '%08X' % (_zlib_epg.crc32(_m3u_src_epg.encode('utf-8', 'replace')) & 0xFFFFFFFF)
    try:
        os.makedirs(epg_dir)
    except OSError:
        pass

    channels_path = os.path.join(epg_dir, '%s.xml' % safe_name)
    sources_path  = os.path.join('/etc/epgimport', 'CustomIPTV_%s.sources.xml' % safe_name)

    _sid_map = _channel_sid_map(safe_name, channels)

    # Resolve real XMLTV channel ids by parsing the XMLTV source when available.
    # This maps each M3U stream URL to the actual <channel id="..."> value
    # used in the XMLTV file (e.g. "146", "ch884") so programmes can be matched.
    xmltv_id_map = {}
    if xmltv_url:
        xmltv_id_map = _lookupXmltvChannelIds(xmltv_url, prov_name, channels,
                                              strict=strict_id_match)

    # --- File 1: channels mapping (safe_name.xml) ---
    # Service reference must exactly match the userbouquet service reference
    # (minus the URL part which EPGImport ignores when scanning the service list).
    # channel id uses the real XMLTV channel id when found; falls back to the
    # tvg-id or display name according to the user's epg_parse_type setting.
    ch_lines = ['<?xml version="1.0" encoding="utf-8"?>\n', '<channels>\n']
    for ch in channels:
        url = (ch.get('url') or '').strip()
        if not url:
            continue
        name   = ch.get('name', '')
        tvg_id = ch.get('tvg_id', '')
        if epg_parse_type == 'tvg_id':
            fallback_id = tvg_id or name
        else:
            fallback_id = name or tvg_id
        if not fallback_id:
            continue
        # Determine the channel id to write:
        # - If an XMLTV source is configured, only include channels that were
        #   actually matched in the XMLTV file.  Unmatched channels are skipped
        #   entirely — writing them with a raw tvg-id / name that doesn't exist
        #   in the XMLTV file produces a useless line and confuses EPGImport.
        # - If no XMLTV source is configured, write all channels using the
        #   M3U fallback id so the file can still be used with other sources.
        if xmltv_url:
            ch_id = xmltv_id_map.get(url)
            if not ch_id:
                continue
        else:
            ch_id = fallback_id
        prebuilt_sref = (ch.get('sref') or '').strip()
        if prebuilt_sref:
            # Xtream channels carry the exact service reference already built
            # by _buildXtreamBouquets (stream_type:0:1:b1:b2:unique_ref:...).
            # Using it verbatim guarantees the EPG channels file matches the
            # bouquet entry, which is what EPGImport compares against.
            sref = prebuilt_sref
        else:
            sid_hex, _ = _sid_map.get(url, ('0', '0'))
            url_base = url.split('?')[0].split('#')[0]
            sref = '%s:0:1:%s:1:1:%s:0:0:0:%s' % (
                stype, sid_hex, _prov_ns_epg, url_base.replace(':', '%3a'))
        epg_esc  = ch_id.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
        name_esc = name.replace('--', '-').replace('>', '-')
        ch_lines.append('  <channel id="%s">%s</channel><!-- %s -->\n' % (epg_esc, sref, name_esc))
    ch_lines.append('</channels>\n')
    try:
        with open(channels_path, 'w') as _cf:
            _cf.writelines(ch_lines)
        iptvLogWrite('[Playlist] EPG channels file written: %s (%d channels)' % (channels_path, len(ch_lines) - 2))
        if provider.get('custom_epg_enabled', True):
            _mergeCustomEpgIntoChannelsFile(safe_name, channels_path, prov_name)
        else:
            # Remove any leftover custom EPG block from sources.xml
            _removeCustomEpgFromSources(safe_name)
    except Exception as e:
        iptvLogWrite('[Playlist] EPG channels write error: %s' % str(e))
        return

    # --- File 2: combined sources file (/etc/epgimport/CustomIPTV.sources.xml) ---
    if not xmltv_url:
        iptvLogWrite('[Playlist] No XMLTV URL configured — combined sources entry not written')
        return
    _updateCombinedSourcesFile(safe_name, prov_name, channels_path, xmltv_url)


def _generateXtreamEpgFiles(safe_name, prov_name, epg_channels, xmltv_url):
    """Generate EPGImport channel-map and sources files for an Xtream provider.

    Writes ALL live channels that have a non-empty tvg_id/epg_channel_id
    directly — without XMLTV pre-verification.  This mirrors the approach used
    by BouquetMakerXtream and ensures EPG files are always created regardless
    of the epg_parse_type setting.
    """
    epg_dir = '/etc/epgimport/CustomIPTV'
    try:
        os.makedirs(epg_dir)
    except OSError:
        pass
    channels_path = os.path.join(epg_dir, '%s.xml' % safe_name)
    ch_lines = ['<?xml version="1.0" encoding="utf-8"?>\n', '<channels>\n']
    written = 0
    for ch in epg_channels:
        epg_ch_id = (ch.get('tvg_id') or '').strip()
        sref      = (ch.get('sref')   or '').strip()
        if not epg_ch_id or not sref:
            continue
        name_esc = (ch.get('name') or '').replace('--', '-').replace('>', '-')
        epg_esc  = (epg_ch_id.replace('&', '&amp;').replace('"', '&quot;')
                              .replace('<', '&lt;').replace('>', '&gt;'))
        ch_lines.append('  <channel id="%s">%s</channel><!-- %s -->\n' % (
            epg_esc, sref, name_esc))
        written += 1
    ch_lines.append('</channels>\n')
    try:
        with open(channels_path, 'w') as _cf:
            _cf.writelines(ch_lines)
        iptvLogWrite('[Xtream] EPG channels file written: %s (%d channels)' % (
            channels_path, written))
        _mergeCustomEpgIntoChannelsFile(safe_name, channels_path, prov_name)
    except Exception as e:
        iptvLogWrite('[Xtream] EPG channels write error: %s' % str(e))
        return
    if xmltv_url:
        _updateCombinedSourcesFile(safe_name, prov_name, channels_path, xmltv_url)


def _safe_prov_name(name):
    """Return the filesystem-safe provider name (same formula used for bouquet filenames)."""
    import re as _re
    return _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', (name or '').strip()))).strip('_-') or 'Provider'


def _bouquet_file_belongs_to(fname, safe_name, _all_safe_names=None):
    """Return True only if fname is a bouquet file owned by the provider with safe_name.
    Uses longest-match: if another provider's safe_name is a longer prefix match
    for this file, that provider owns it instead.
    _all_safe_names: optional list of all known safe_names (loaded automatically if None).
    """
    import re as _re
    # File must start with userbouquet.<safe_name>_ or subbouquet.<safe_name>_
    if not _re.match(r'(?:userbouquet|subbouquet)\.%s[_\.]' % _re.escape(safe_name), fname):
        return False
    # Load all known safe_names to apply longest-match
    if _all_safe_names is None:
        try:
            _all_safe_names = [
                _safe_prov_name(p.get('name', ''))
                for p in (list(loadPlaylistProviderConfig()) + list(loadXtreamProviderConfig()))
            ]
        except Exception:
            _all_safe_names = []
    # Check if any OTHER safe_name is a longer match for this file
    for _other in _all_safe_names:
        if _other == safe_name or not _other:
            continue
        if (_re.match(r'(?:userbouquet|subbouquet)\.%s[_\.]' % _re.escape(_other), fname)
                and len(_other) > len(safe_name)):
            return False  # another provider has a longer (more specific) match
    return True


def _checkProviderNameConflict(new_name, skip_playlist_idx=None, skip_xtream_idx=None,
                               skip_playlist_name=None, skip_xtream_name=None):
    """Return conflicting provider name string if new_name collides, else None.
    Checks both playlist and Xtream config since both share the /etc/enigma2/ namespace.
    skip_*_idx:  index of the provider being edited (skip self-comparison by index).
    skip_*_name: name of the provider being edited (skip self-comparison by name)."""
    new_safe = _safe_prov_name(new_name)
    if not new_safe or new_safe == 'Provider':
        return None
    _skip_pl_safe = _safe_prov_name(skip_playlist_name) if skip_playlist_name else None
    _skip_xt_safe = _safe_prov_name(skip_xtream_name)   if skip_xtream_name   else None
    try:
        for i, p in enumerate(loadPlaylistProviderConfig()):
            if skip_playlist_idx is not None and i == skip_playlist_idx:
                continue
            existing = _safe_prov_name(p.get('name', ''))
            if _skip_pl_safe and existing == _skip_pl_safe:
                continue
            if existing and existing == new_safe:
                return p.get('name', existing)
    except Exception:
        pass
    try:
        for i, p in enumerate(loadXtreamProviderConfig()):
            if skip_xtream_idx is not None and i == skip_xtream_idx:
                continue
            existing = _safe_prov_name(p.get('name', ''))
            if _skip_xt_safe and existing == _skip_xt_safe:
                continue
            if existing and existing == new_safe:
                return p.get('name', existing)
    except Exception:
        pass
    return None


def _deletePlaylistProviderFiles(prov_name):
    import re as _re
    safe_name   = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'provider'
    enigma2_dir = '/etc/enigma2'
    deleted     = 0

    # Extract SIDs from bouquet files BEFORE deleting them so lamedb can
    # be cleaned up correctly (SID = CRC32(URL), identified from service refs).
    remove_sids = set()
    try:
        for fname in os.listdir(enigma2_dir):
            if (_bouquet_file_belongs_to(fname, safe_name)
                    and fname.endswith('.tv')):
                try:
                    with open(os.path.join(enigma2_dir, fname), 'r') as _bf:
                        for _line in _bf:
                            _m = _re.match(
                                r'#SERVICE\s+\d+:\d+:\d+:([0-9A-Fa-f]+):',
                                _line)
                            if _m:
                                remove_sids.add(_m.group(1).upper())
                except Exception:
                    pass
    except Exception:
        pass

    try:
        for fname in os.listdir(enigma2_dir):
            is_user = _bouquet_file_belongs_to(fname, safe_name) and fname.startswith('userbouquet.') and fname.endswith('.tv')
            is_sub  = _bouquet_file_belongs_to(fname, safe_name) and fname.startswith('subbouquet.')  and fname.endswith('.tv')
            if is_user or is_sub:
                try:
                    os.remove(os.path.join(enigma2_dir, fname))
                    deleted += 1
                    iptvLogWrite('[Playlist] Deleted bouquet: %s' % fname)
                except Exception as e:
                    iptvLogWrite('[Playlist] Could not delete %s: %s' % (fname, str(e)))
    except Exception as e:
        iptvLogWrite('[Playlist] Error scanning enigma2 dir: %s' % str(e))

    bouquets_tv = os.path.join(enigma2_dir, 'bouquets.tv')
    try:
        with open(bouquets_tv, 'r') as _f:
            lines = _f.readlines()
        lines = [l for l in lines if safe_name not in l]
        with open(bouquets_tv, 'w') as _f:
            _f.writelines(lines)
    except Exception as e:
        iptvLogWrite('[Playlist] Could not update bouquets.tv: %s' % str(e))

    epg_dir = '/etc/epgimport/CustomIPTV'
    try:
        for fname in os.listdir(epg_dir):
            if _bouquet_file_belongs_to(fname, safe_name):
                try:
                    os.remove(os.path.join(epg_dir, fname))
                    deleted += 1
                    iptvLogWrite('[Playlist] Deleted EPG file: %s' % fname)
                except Exception as e:
                    iptvLogWrite('[Playlist] Could not delete %s: %s' % (fname, str(e)))
    except Exception:
        pass

    _updateCombinedSourcesFile(safe_name, '', '', '')
    try:
        old_src = os.path.join('/etc/epgimport', 'CustomIPTV_%s.sources.xml' % safe_name)
        if os.path.exists(old_src):
            os.remove(old_src)
            deleted += 1
    except Exception:
        pass

    _updateLamedb(safe_name, '', [], {}, remove_sids=remove_sids)

    try:
        from enigma import eDVBDB
        eDVBDB.getInstance().reloadBouquets()
    except Exception:
        pass

    return deleted


# ---------------------------------------------------------------------------
# _last_xtream_update_info — stores last Xtream update detail for recall screen
_last_xtream_update_info = []

def _save_xtream_update_info(data):
    global _last_xtream_update_info
    try:
        if isinstance(data, list) and data:
            _last_xtream_update_info = data
    except Exception:
        _last_xtream_update_info = []

def _clear_xtream_update_info():
    global _last_xtream_update_info
    _last_xtream_update_info = []

# _last_m3u_update_info — stores last M3U update detail for recall screen
# Persisted to disk so info survives receiver reboots.
# ---------------------------------------------------------------------------

_last_m3u_update_info    = []
_M3U_UPDATE_INFO_FILE    = '/etc/CustomIPTVArchiveMakerPro/m3u_update_info.json'


def _load_m3u_update_info():
    global _last_m3u_update_info
    try:
        import json as _j
        with open(_M3U_UPDATE_INFO_FILE, 'r', encoding='utf-8') as _f:
            data = _j.load(_f)
            if isinstance(data, list):
                _last_m3u_update_info = data
    except Exception:
        _last_m3u_update_info = []


def _save_m3u_update_info(lines):
    try:
        import json as _j
        with open(_M3U_UPDATE_INFO_FILE, 'w', encoding='utf-8') as _f:
            _j.dump(lines, _f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _clear_m3u_update_info():
    global _last_m3u_update_info
    _last_m3u_update_info = []
    try:
        if os.path.exists(_M3U_UPDATE_INFO_FILE):
            os.remove(_M3U_UPDATE_INFO_FILE)
    except Exception:
        pass


# Load persisted info at module import so it survives reboots
_load_m3u_update_info()


# ---------------------------------------------------------------------------
# IPTVUpdateInfoScreen — scrollable M3U update info (key 1 recall)
# Font ~60% larger than original; window widened to avoid line cutoff.
# Blue = clear info from RAM and disk.
# ---------------------------------------------------------------------------

class IPTVUpdateInfoScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,700"
                title="M3U Update Info" backgroundColor="#33000000">
            <widget name="scroll_text" position="10,10" size="1230,586"
                    font="Regular;32" halign="left" valign="top"
                    transparent="1" />
            <eLabel position="0,602" size="1250,2" backgroundColor="#555555"/>
            <ePixmap position="40,618"  size="35,25" pixmap="buttons/red.png"  alphaTest="blend" />
            <ePixmap position="960,618" size="35,25" pixmap="buttons/blue.png" alphaTest="blend" />
            <widget name="key_exit"  position="83,614"  size="350,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" transparent="1" />
            <widget name="key_clear" position="1003,614" size="230,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,700"
                title="M3U Update Info">
            <widget name="scroll_text" position="10,10" size="1230,586"
                    font="Regular;32" halign="left" valign="top" />
            <eLabel position="0,602" size="1250,2" backgroundColor="#555555"/>
            <ePixmap position="40,618"  size="35,25" pixmap="buttons/red.png"  alphaTest="blend" />
            <ePixmap position="960,618" size="35,25" pixmap="buttons/blue.png" alphaTest="blend" />
            <widget name="key_exit"  position="83,614"  size="350,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" />
            <widget name="key_clear" position="1003,614" size="230,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" />
        </screen>"""

    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("M3U Update Info"))
        global _last_m3u_update_info
        lines = _last_m3u_update_info
        text = ('\n'.join(lines) if lines
                else T("No M3U update info available yet.\n"
                       "Run 'Start Create' with 'User Defined' order first."))
        self["scroll_text"] = ScrollLabel(text)
        self["key_exit"]    = Button(T("Exit"))
        self["key_clear"]   = Button(T("Clear Info"))
        self["infoNavActions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {"cancel": self.close, "ok": self.close,
             "blue":  self.keyClear,
             "up":    self._scrollUp,   "down":  self._scrollDown,
             "left":  self._scrollUp,   "right": self._scrollDown}, -1)

    def keyClear(self):
        _clear_m3u_update_info()
        self["scroll_text"].setText(
            T("No M3U update info available yet.\n"
              "Run 'Start Create' with 'User Defined' order first."))

    def _scrollUp(self):
        try:
            self["scroll_text"].pageUp()
        except Exception:
            pass

    def _scrollDown(self):
        try:
            self["scroll_text"].pageDown()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# IPTVXtreamUpdateInfoScreen — scrollable Xtream update info (key 1 recall)
# ---------------------------------------------------------------------------

class IPTVXtreamUpdateInfoScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,700"
                title="Xtream Playlist Update Info" backgroundColor="#33000000">
            <widget name="scroll_text" position="10,10" size="1230,586"
                    font="Regular;32" halign="left" valign="top"
                    transparent="1" />
            <eLabel position="0,602" size="1250,2" backgroundColor="#555555"/>
            <ePixmap position="40,618"  size="35,25" pixmap="buttons/red.png"  alphaTest="blend" />
            <ePixmap position="960,618" size="35,25" pixmap="buttons/blue.png" alphaTest="blend" />
            <widget name="key_exit"  position="83,614"  size="350,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" transparent="1" />
            <widget name="key_clear" position="1003,614" size="230,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,700"
                title="Xtream Playlist Update Info">
            <widget name="scroll_text" position="10,10" size="1230,586"
                    font="Regular;32" halign="left" valign="top" />
            <eLabel position="0,602" size="1250,2" backgroundColor="#555555"/>
            <ePixmap position="40,618"  size="35,25" pixmap="buttons/red.png"  alphaTest="blend" />
            <ePixmap position="960,618" size="35,25" pixmap="buttons/blue.png" alphaTest="blend" />
            <widget name="key_exit"  position="83,614"  size="350,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" />
            <widget name="key_clear" position="1003,614" size="230,40"
                    zPosition="1" font="Regular;32" valign="center" halign="left" />
        </screen>"""

    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("Xtream Playlist Update Info"))
        global _last_xtream_update_info
        lines = _last_xtream_update_info
        text = ('\n'.join(lines) if lines
                else T("No Xtream update info available yet.\n"
                       "Run 'Start Create' with 'User Defined' order first."))
        self["scroll_text"] = ScrollLabel(text)
        self["key_exit"]    = Button(T("Exit"))
        self["key_clear"]   = Button(T("Clear Info"))
        self["infoNavActions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {"cancel": self.close, "ok": self.close,
             "blue":  self.keyClear,
             "up":    self._scrollUp,   "down":  self._scrollDown,
             "left":  self._scrollUp,   "right": self._scrollDown}, -1)

    def keyClear(self):
        _clear_xtream_update_info()
        self["scroll_text"].setText(
            T("No Xtream update info available yet.\n"
              "Run 'Start Create' with 'User Defined' order first."))

    def _scrollUp(self):
        try: self["scroll_text"].pageUp()
        except Exception: pass

    def _scrollDown(self):
        try: self["scroll_text"].pageDown()
        except Exception: pass


# ---------------------------------------------------------------------------
# IPTVPlaylistProviderSettings — playlist provider list management
# ---------------------------------------------------------------------------

class IPTVPlaylistProviderSettings(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,690"
                title="IPTV Playlist Creator" backgroundColor="#33000000">
            <widget name="help_label" position="20,60"  size="360,545"
                    font="Regular;22" valign="top" halign="left"
                    transparent="1" />
            <eLabel position="383,0" size="1,623" backgroundColor="#ffffff"/>
            <widget name="list_header" position="525,60" size="706,44"
                    font="Regular;30" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="config" position="525,109" size="706,475"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="46" transparent="1"/>
            <ePixmap position="72,643"  size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,643"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,643"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,643" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,623" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,638"  size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="427,638"  size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="739,638"  size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1051,638" size="185,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,690"
                title="IPTV Playlist Creator">
            <widget name="help_label" position="20,60"  size="360,545"
                    font="Regular;22" valign="top" halign="left"
                    transparent="1" />
            <eLabel position="383,0" size="1,623" backgroundColor="#ffffff"/>
            <widget name="list_header" position="525,60" size="706,44"
                    font="Regular;30" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="config" position="525,109" size="706,475"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="46" />
            <ePixmap position="72,643"  size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,643"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,643"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,643" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,623" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,638"  size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_green"  position="427,638"  size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_yellow" position="739,638"  size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_blue"   position="1051,638" size="185,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._providers_raw = loadPlaylistProviderConfig()
        self._testing       = False
        self._creating      = False
        self._edit_idx      = None
        self._cfg_entries   = []
        ConfigListScreen.__init__(self, [], session=session)
        self._test_idx = None
        self._build_running   = False
        self._build_cancelled = False
        self.setTitle(T("IPTV Archives Bouquets/Playlist Creator Settings"))
        self["list_header"] = Label(T("Configured Playlists"))
        self["help_label"]  = Label(
            "\u2191\u2193  \u2014  " + T("Navigate")                    + "\n" +
            "\u25c4\u25ba / OK  \u2014  " + T("Toggle ON/OFF")           + "\n" +
            T("Red")    + "  \u2014  " + T("Create Playlist")            + "\n" +
            T("Green")  + "  \u2014  " + T("Create Archives")            + "\n" +
            T("Yellow") + "  \u2014  " + T("Edit Provider")              + "\n" +
            T("Blue")   + "  \u2014  " + T("Select Bouquets")              + "\n" +
            T("Exit")   + "  \u2014  " + T("Close")                      + "\n" +
            T("EPG")   + "  \u2014  " + T("Make Custom EPG")              + "\n" +
            "1  \u2014  " + T("Show M3U Update Info")                    + "\n\n" +
            T("RED: build bouquets\nGREEN: build archives\nfor selected provider."))
        self["key_red"]    = Button(T("Create Playlist"))
        self["key_green"]  = Button(T("Create Archives"))
        self["key_yellow"] = Button(T("Edit Provider"))
        self["key_blue"]   = Button(T("Select Bouquets"))
        self["pl_actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions",
             "EPGSelectActions", "MediaPlayerActions", "InfobarEPGActions"],
            {"cancel": self.keyClose, "ok": self.keyToggleEnabled,
             "save": self.keyToggleEnabled,
             "red": self.keyStartCreate, "green": self.keyCreateArchives,
             "yellow": self.keyEdit,
             "blue": self.keyTest,
             "epg": self.keyCustomEPG,
             "showEventInfo": self.keyCustomEPG}, -2)
        try:
            self["pl_info_actions"] = ActionMap(
                ["NumberActions"],
                {"1": self.keyShowUpdateInfo}, -2)
        except Exception:
            pass
        self._refreshList()

    def _buildEntries(self):
        entries           = []
        self._cfg_entries = []
        for i, p in enumerate(self._providers_raw):
            name = (p.get('name') or '').strip()
            url  = (p.get('m3u_source') or p.get('xmltv_url') or '').strip()
            if not name and not url:
                continue
            strat  = p.get('bouquet_strategy', 'same_playlist')
            _arch  = T(' [A]') if p.get('create_archives') else ''
            label  = '%s  [%s]%s' % (name or T('(unnamed)'), strat.replace('_', ' ').title(), _arch)
            cfg_en = ConfigYesNo(default=bool(p.get('enabled')))
            def _make_save(raw_idx):
                def _save(el):
                    self._providers_raw[raw_idx]['enabled'] = el.value
                    savePlaylistProviderConfig(self._providers_raw)
                return _save
            cfg_en.addNotifier(_make_save(i), initial_call=False)
            entries.append(getConfigListEntry(label, cfg_en))
            self._cfg_entries.append((i, cfg_en))
        self._add_new_sentinel = ConfigYesNo(default=False)
        entries.append(getConfigListEntry(T('[+ Add New Provider]'), self._add_new_sentinel))
        return entries

    def _refreshList(self):
        entries = self._buildEntries()
        if not entries:
            entries = [getConfigListEntry(
                T('No playlists configured — press Green to add.'),
                ConfigYesNo(default=False))]
            self._cfg_entries = []
        self["config"].setList(entries)

        # Hook into AutoBuild progress if a headless build is already running
        global _auto_build_pending, _auto_build_listener
        if _auto_build_pending:
            _auto_build_listener = self
            self.onFirstExecBegin.append(self._showAutoBuildStatus)

    def _showAutoBuildStatus(self):
        global _auto_build_pending, _auto_build_progress
        if not _auto_build_pending:
            return
        done, total, prov = _auto_build_progress
        if total:
            self._updateBuildProgress(done, total, prov)
        else:
            try:
                self['help_label'].setText(
                    T('Scheduled EPG cache build is running in the background...'))
            except Exception:
                pass

    def _updateBuildProgress(self, done, total, prov_name):
        try:
            pct = int(100 * done / total) if total else 0
            self['help_label'].setText(
                T('Building EPG cache... %d%%') % pct + '\n' +
                T('Provider: %s') % prov_name + '\n' +
                T('Channels cached: %d / %d') % (done, total))
        except Exception:
            pass



    def _selectedIndex(self):
        try:
            list_idx = self["config"].getCurrentIndex()
            if 0 <= list_idx < len(self._cfg_entries):
                return self._cfg_entries[list_idx][0]
        except Exception:
            pass
        return None

    def keyToggleEnabled(self):
        try:
            cur = self["config"].getCurrent()
            if cur and hasattr(self, '_add_new_sentinel') and cur[1] is self._add_new_sentinel:
                self.keyAdd()
                return
        except Exception:
            pass
        idx = self._selectedIndex()
        if idx is None:
            return
        p = self._providers_raw[idx]
        if not (p.get('name') or p.get('m3u_source') or p.get('xmltv_url')):
            return
        p['enabled'] = not bool(p.get('enabled'))
        savePlaylistProviderConfig(self._providers_raw)
        self._refreshList()

    def keyAdd(self):
        for i, p in enumerate(self._providers_raw):
            if not (p.get('name') or p.get('m3u_source') or p.get('xmltv_url')):
                self._edit_idx = i
                self.session.openWithCallback(
                    self._onEditDone, IPTVPlaylistProviderEditDialog, {}, False)
                return
        self.session.open(MessageBox,
            T("Maximum of %d providers reached.\nDelete one before adding another.")
            % MAX_PLAYLIST_PROVIDERS,
            type=MessageBox.TYPE_INFO, timeout=5)

    def keyEdit(self):
        idx = self._selectedIndex()
        if idx is None:
            return
        self._edit_idx = idx
        self.session.openWithCallback(
            self._onEditDone, IPTVPlaylistProviderEditDialog,
            dict(self._providers_raw[idx]), True)

    def _onEditDone(self, data):
        if data is not None and self._edit_idx is not None:
            _empty = {'enabled': False, 'name': '', 'xmltv_url': '', 'm3u_source': '',
                      'epg_parse_type': 'off', 'bouquet_strategy': 'same_playlist',
                      'playback_with': 'gstplayer',
                      'channel_order': 'provider', 'picon_naming': 'off',
                      'picon_location': 'plugin_dir', 'picon_symlink': False,
                      'update_playlist_mode': 'off',
                      'xtream_show_live': True, 'xtream_show_vod': True,
                      'xtream_show_series': True, 'xtream_output': 'ts',
                      'clean_bouquets': False,
                      'create_archives': False, 'archive_channel_id': '',
                      'archive_days': 7, 'time_offset_sec': 0,
                      'stream_hostname': '', 'player_override': False,
                      'player_int_on': True, 'player_sl_on': False,
                      'player_rec_on': False, 'cache_ttl_custom': False,
                      'cache_ttl_days': 7}
            if data.get('_delete'):
                prov_name = (self._providers_raw[self._edit_idx].get('name') or '').strip()
                self._providers_raw[self._edit_idx] = dict(_empty)
                savePlaylistProviderConfig(self._providers_raw)
                if prov_name:
                    _deletePlaylistProviderFiles(prov_name)
            else:
                # Carry the last-create name forward so a rename followed by
                # Create still cleans up the old-name files correctly.
                old = self._providers_raw[self._edit_idx]
                prev = (old.get('_name_at_last_create') or old.get('name') or '').strip()
                if prev:
                    data.setdefault('_name_at_last_create', prev)
                # Preserve the saved Channel Browser selection — it is not part
                # of the edit-dialog form and must be carried forward explicitly.
                old_sel = old.get('selected_channels')
                if old_sel is not None:
                    data.setdefault('selected_channels', old_sel)
                self._providers_raw[self._edit_idx] = data
                savePlaylistProviderConfig(self._providers_raw)
        self._refreshList()

    def keyStartCreate(self):
        if self._creating:
            self.session.open(MessageBox, T("Build already running, please wait."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov = self._providers_raw[idx]
        if not prov.get('enabled', False):
            self.session.open(MessageBox, T("Provider is disabled. Enable it first."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        m3u = (prov.get('m3u_source') or '').strip()
        if not m3u and not prov.get('xtream_enabled'):
            self.session.open(MessageBox, T("No M3U URL or file set for this provider."),
                              type=MessageBox.TYPE_INFO, timeout=4)
            return
        self._creating = True
        self["key_red"].setText(T("Creating..."))
        import threading as _thr
        t = _thr.Thread(target=self._createThread, args=(dict(prov), idx))
        t.daemon = True
        t.start()

    def _createThread(self, prov, idx=None):
        result = {'ok': False, 'bouquets': 0, 'error': '', 'picons': None,
                  '_idx': idx, '_prov_name': ''}
        try:
            from twisted.internet import reactor as _r
        except Exception:
            _r = None
        try:
            prov_name = (prov.get('name') or '').strip()
            result['_prov_name'] = prov_name
            # Delete files for the previous name if the provider was renamed
            prev_name   = (prov.get('_name_at_last_create') or '').strip()
            update_mode = (prov.get('update_playlist_mode') or 'off').strip()
            # Safety: if channel_order is user_defined but update_mode is still
            # 'off' (stale save from previous Provider Order config), treat it
            # as 'top' so existing bouquets are never deleted on first switch.
            if prov.get('channel_order', 'provider') == 'user_defined' and update_mode == 'off':
                update_mode = 'top'
            if prev_name and prev_name != prov_name:
                pass  # _migrateSafeName renames old files to new name
            if prov_name and update_mode == 'off':
                _deletePlaylistProviderFiles(prov_name)
            if prov.get('xtream_enabled'):
                # Level 3 full Xtream API: Live / VOD / Series via player_api.php
                n, err, _xt_ms = _buildXtreamBouquets(prov, _reactor=_r,
                                                       _progress_cb=self._piconProgressCreate)
                if err:
                    result['error'] = err
                else:
                    result['bouquets'] = n
                    result['ok'] = True
            else:
                channels = _parseM3UPlaylist(prov.get('m3u_source', ''))
                if not channels:
                    result['error'] = T("M3U returned no channels.")
                else:
                    # Auto-save all channels as selection if none saved yet —
                    # same as opening Channel Browser and pressing Save with all checked
                    _saved_sel = prov.get('selected_channels') or []
                    if isinstance(_saved_sel, dict):
                        selected_urls = set(_saved_sel.get('selected') or [])
                    else:
                        selected_urls = set(_saved_sel)
                    _all_channels = channels[:]  # keep full list before filtering
                    if not selected_urls:
                        # No selection saved yet — auto-initialize with all channels
                        _all_urls = [(ch.get('url') or '').strip() for ch in channels
                                     if (ch.get('url') or '').strip()]
                        prov['selected_channels'] = {'selected': _all_urls, 'known': _all_urls}
                        result['_auto_selected_channels'] = prov['selected_channels']
                        selected_urls = set(_all_urls)
                    if selected_urls:
                        channels = [ch for ch in channels
                                    if (ch.get('url') or '').strip() in selected_urls]
                    if not channels and selected_urls:
                        # Saved selection is completely stale (e.g. after reinstall
                        # or token rotation) — auto-reinitialize with all fresh channels
                        _all_urls = [(ch.get('url') or '').strip() for ch in _all_channels
                                     if (ch.get('url') or '').strip()]
                        prov['selected_channels'] = {'selected': _all_urls, 'known': _all_urls}
                        result['_auto_selected_channels'] = prov['selected_channels']
                        channels = _all_channels
                    if not channels:
                        result['error'] = T("No channels remain after applying"
                                            " selection filter.\nUse Channel Browser"
                                            " to save a selection first.")
                    else:
                        if update_mode in ('top', 'bottom'):
                            n, _uerr, _ustats, _new_chs, _del_info = \
                                _updatePlaylistBouquets(prov, channels, update_mode)
                            if _uerr:
                                result['error'] = _uerr
                            else:
                                result['bouquets']      = n
                                result['ok']            = True
                                result['_is_update']    = True
                                result['_update_stats'] = _ustats
                                if selected_urls:
                                    for _ch in _all_channels:
                                        _url = (_ch.get('url') or '').strip()
                                        if _url and _url not in selected_urls:
                                            _del_info.append((_ch.get('name') or '', _url))
                        else:
                            _new_chs  = []
                            _del_info = []
                            n = _buildPlaylistBouquets(prov, channels)
                            result['bouquets'] = n
                            result['ok']       = True
                        if result['ok']:
                            if (prov.get('epg_parse_type') or 'off') != 'off':
                                _generateEpgImportFile(prov, channels)
                            picon_naming      = (prov.get('picon_naming') or 'off').strip()
                            picon_location    = (prov.get('picon_location') or 'plugin_dir')
                            picon_symlink     = bool(prov.get('picon_symlink', False))
                            picon_with_folder = bool(prov.get('picon_with_folder', True))
                            _pb = (prov.get('playback_with') or 'gstplayer').strip()
                            picon_stype = {'gst_player': '5001', 'exteplayer3': '5002', 'dvb': '1'}.get(_pb, '4097')
                            if picon_naming and picon_naming != 'off':
                                import re as _re2
                                _safe = _re2.sub(r'[^\w\-]', '_',
                                                 prov_name.strip()) or 'Provider'
                                import zlib as _zlib_ns
                                _m3u_src_ns = (prov.get('m3u_source') or prov.get('name') or prov_name).strip()
                                _prov_ns_pic = '%08X' % (_zlib_ns.crc32(_m3u_src_ns.encode('utf-8', 'replace')) & 0xFFFFFFFF)
                                _pl = picon_location
                                if _pl in ('enigma2_picon',): _pl = '/usr/share/enigma2/picon'
                                elif _pl in ('plugin_dir', ''): _pl = getDataDir()
                                if picon_with_folder:
                                    _picon_folder = os.path.join(_pl, '%s_Picons' % _safe)
                                else:
                                    _picon_folder = _pl
                                # Determine which channels need picons downloaded.
                                if update_mode in ('top', 'bottom'):
                                    try:
                                        _folder_has = (
                                            os.path.isdir(_picon_folder) and
                                            any(f.endswith('.png')
                                                for f in os.listdir(_picon_folder)))
                                    except Exception:
                                        _folder_has = False
                                    if not _folder_has:
                                        # Folder missing/empty → full recovery
                                        _picon_channels = channels
                                    else:
                                        # Folder has files → new channels
                                        # + any existing channel whose picon is absent
                                        import zlib as _zlib
                                        _new_urls = set(
                                            (ch.get('url') or '').strip()
                                            for ch in _new_chs)
                                        _existing_chs = [
                                            ch for ch in channels
                                            if (ch.get('url') or '').strip()
                                            not in _new_urls]
                                        _missing_chs = []
                                        for _ch in _existing_chs:
                                            _ch_url  = (_ch.get('url')  or '').strip()
                                            _ch_name = (_ch.get('name') or '').strip()
                                            try:
                                                if picon_naming == 'reference' and _ch_url:
                                                    # Hash identity (path only, no token/query)
                                                    # to match _channel_sid_map which also strips
                                                    # the token — stable across token rotations.
                                                    try:
                                                        from urllib.parse import urlsplit as _usp_ec
                                                    except ImportError:
                                                        from urlparse import urlsplit as _usp_ec
                                                    try:
                                                        _s_ec = _usp_ec(_ch_url)
                                                        _ident_ec = '%s://%s%s' % (_s_ec.scheme, _s_ec.netloc, _s_ec.path)
                                                    except Exception:
                                                        _ident_ec = _ch_url
                                                    _sid = (_zlib.crc32(
                                                        _ident_ec.encode('utf-8', 'replace'))
                                                        & 0xFFFF)
                                                    _sfn = ('%s_0_1_%s_1_1_%s'
                                                            '_0_0_0.png' % (picon_stype, '%X' % _sid, _prov_ns_pic))
                                                else:
                                                    _sfn = (_re2.sub(
                                                        r'[^\w\- ]', '_', _ch_name)
                                                        + '.png') if _ch_name else None
                                                if (_sfn and not os.path.isfile(
                                                        os.path.join(_picon_folder, _sfn))):
                                                    _missing_chs.append(_ch)
                                            except Exception:
                                                pass
                                        _picon_channels = _new_chs + _missing_chs
                                else:
                                    _picon_channels = channels
                                # Delete picons for removed channels first
                                _picons_deleted = 0
                                _was_renamed = bool(prev_name and prev_name != prov_name)
                                if update_mode in ('top', 'bottom') and _del_info and not _was_renamed:
                                    _picons_deleted = _deletePicons(
                                        prov_name, _del_info,
                                        picon_naming, picon_location,
                                        picon_symlink, picon_stype,
                                        picon_with_folder,
                                        prov_ns=_prov_ns_pic)
                                # Skipped = channels that already have their picon
                                # on disk (total minus what we pass to the downloader)
                                _picons_skipped = (
                                    len(channels) - len(_picon_channels)
                                    if update_mode in ('top', 'bottom')
                                    else 0)
                                _picons_result = self._runPiconDownload(
                                    prov_name, _picon_channels,
                                    (prov.get('xmltv_url') or '').strip(),
                                    picon_naming, _r,
                                    picon_location=picon_location,
                                    picon_symlink=picon_symlink,
                                    picon_stype=picon_stype,
                                    picon_with_folder=picon_with_folder,
                                    prov_ns=_prov_ns_pic)
                                if _picons_result:
                                    _picons_result['skipped'] = _picons_skipped
                                    _picons_result['deleted'] = _picons_deleted
                                elif _picons_deleted:
                                    # No logos to download but picons were deleted —
                                    # create a minimal result so M3U Update Info shows it
                                    _picons_result = {
                                        'downloaded': 0,
                                        'failed':     0,
                                        'skipped':    _picons_skipped,
                                        'deleted':    _picons_deleted,
                                        'folder':     '',
                                    }
                                iptvLogWrite('[UserDefined][Picon] downloaded: %d  failed: %d  skipped: %d  deleted: %d'
                                             % (_picons_result.get('downloaded', 0) if _picons_result else 0,
                                                _picons_result.get('failed',     0) if _picons_result else 0,
                                                _picons_skipped,
                                                _picons_deleted))
                                result['picons'] = _picons_result
        except Exception as e:
            result['error'] = str(e)
        if _r:
            _r.callFromThread(self._createDone, result)
        else:
            self._createDone(result)

    def _runPiconDownload(self, prov_name, channels, xmltv_url,
                         picon_naming='display_name', _reactor=None,
                         picon_location='plugin_dir', picon_symlink=False,
                         picon_stype='4097', picon_with_folder=True, prov_ns=None):
        """Download picons in the create background thread; updates key_red progress."""
        import re as _re
        _picon_naming = (picon_naming or 'display_name').strip()
        safe_name = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
        # picon_location is now an actual path; legacy keyword migration
        if picon_location in ('enigma2_picon',):
            picon_location = '/usr/share/enigma2/picon'
        elif picon_location in ('plugin_dir', ''):
            picon_location = getDataDir()
        if picon_with_folder:
            folder = os.path.join(picon_location, '%s_Picons' % safe_name)
        else:
            folder = picon_location
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
        except Exception:
            pass

        # Build {name: (logo_url, ch_url)} from M3U channel list
        # Also build tvg-id → (name, stream_url) for XMLTV icon matching below
        m3u_logos   = {}
        m3u_tvg_ids = {}   # tvg_id (lower) → (display_name, stream_url)
        for ch in channels:
            logo    = (ch.get('logo') or '').strip()
            name    = (ch.get('name') or '').strip()
            ch_url  = (ch.get('url') or '').strip()
            tvg_id  = (ch.get('tvg_id') or '').strip().lower()
            if tvg_id:
                m3u_tvg_ids[tvg_id] = (name, ch_url)
            if logo and name:
                m3u_logos[name] = (logo, ch_url)

        all_logos = dict(m3u_logos)

        # For channels without tvg-logo in M3U, look up icon from XMLTV by tvg-id.
        # This runs regardless of whether m3u_logos is empty or not —
        # so channels with tvg-logo use M3U URL while others use XMLTV icon.
        if xmltv_url:
            # Build set of channel names already covered by M3U logos
            _covered_names = set(m3u_logos.keys())
            # Build tvg-id → [(name, ch_url), ...] for channels WITHOUT tvg-logo
            # Use a list so multiple channels sharing the same tvg-id all get picons
            _need_icon = {}  # tvg_id_lower → [(name, ch_url), ...]
            for ch in channels:
                _name   = (ch.get('name') or '').strip()
                _ch_url = (ch.get('url') or '').strip()
                _tvg_id = (ch.get('tvg_id') or '').strip().lower()
                _logo   = (ch.get('logo') or '').strip()
                if _tvg_id and not _logo and _name not in _covered_names:
                    _need_icon.setdefault(_tvg_id, []).append((_name, _ch_url))
            if _need_icon:
                try:
                    import xml.etree.ElementTree as _ET
                    import gzip as _gz
                    if xmltv_url.lower().startswith(('http://', 'https://')):
                        xmltv_path = _downloadXMLTVToCache(xmltv_url, prov_name,
                                                           copy_to_epg_dir=True)
                    else:
                        xmltv_path = xmltv_url
                    if xmltv_path and os.path.isfile(xmltv_path):
                        _fh = open(xmltv_path, 'rb')
                        _magic = _fh.read(2); _fh.seek(0)
                        _src = (_gz.GzipFile(fileobj=_fh) if _magic == b'\x1f\x8b' else _fh)
                        try:
                            for _ev, elem in _ET.iterparse(_src, events=('start', 'end')):
                                if _ev == 'start' and elem.tag == 'programme':
                                    break
                                if _ev == 'end' and elem.tag == 'channel':
                                    _xid = (elem.get('id') or '').strip().lower()
                                    _ch_list = _need_icon.get(_xid)
                                    if _ch_list:
                                        icon = elem.find('icon')
                                        _icon_url = (icon.get('src', '')
                                                     if icon is not None else '').strip()
                                        if (_icon_url.startswith(('http://', 'https://'))
                                                and '.' in _icon_url.split('/')[-1]):
                                            for _m3u_name, _m3u_url in _ch_list:
                                                all_logos[_m3u_name] = (_icon_url, _m3u_url)
                                    elem.clear()
                        except Exception:
                            pass
                        _fh.close()
                except Exception:
                    pass

        if not all_logos:
            return None

        # Build SID map for reference-number naming
        sid_map = {}
        if _picon_naming == 'reference' and channels:
            sid_map = _channel_sid_map(safe_name, channels)

        if PY3:
            from urllib.request import urlopen, Request as _Req
        else:
            from urllib2 import urlopen, Request as _Req

        total                = len(all_logos)
        downloaded           = 0
        failed               = 0
        newly_downloaded_files = set()   # track filenames saved in this run
        for display_name, logo_info in all_logos.items():
            logo_url, ch_url = (logo_info if isinstance(logo_info, tuple)
                                else (logo_info, ''))
            try:
                if (_picon_naming == 'reference' and ch_url
                        and sid_map and ch_url in sid_map):
                    sid_hex, _ = sid_map[ch_url]
                    safe_file = '%s_0_1_%s_1_1_%s_0_0_0' % (picon_stype, sid_hex.upper(), prov_ns if prov_ns else 'CCCC0000')
                else:
                    safe_file = re.sub(r'[^\w\- ]', '_',
                                       (display_name or '').strip()) or 'channel'
                fname_png = safe_file + '.png'
                save_path = os.path.join(folder, fname_png)
                req  = _Req(logo_url, headers={'User-Agent': 'Mozilla/5.0'})
                resp = urlopen(req, timeout=10)
                data = resp.read()
                resp.close()
                with open(save_path, 'wb') as _f:
                    _f.write(data)
                newly_downloaded_files.add(fname_png)
                downloaded += 1
            except Exception:
                failed += 1
            done = downloaded + failed
            if _reactor and (done % 25 == 0 or done == total):
                _reactor.callFromThread(self._piconProgressCreate, done, total)
        if picon_symlink:
            _symlink_dir = '/usr/share/enigma2/picon'
            try:
                if not os.path.isdir(_symlink_dir):
                    os.makedirs(_symlink_dir)
            except Exception:
                pass
            # If symlink folder is missing or empty, re-symlink ALL files in
            # the picon folder (auto-recovery).  Otherwise only symlink the
            # files that were downloaded in this run.
            try:
                _symlink_dir_empty = not any(
                    f.endswith('.png') for f in os.listdir(_symlink_dir))
            except Exception:
                _symlink_dir_empty = True
            if _symlink_dir_empty:
                try:
                    _files_to_link = [f for f in os.listdir(folder)
                                      if f.endswith('.png')]
                except Exception:
                    _files_to_link = []
            else:
                _files_to_link = list(newly_downloaded_files)
            try:
                for _fname in _files_to_link:
                    _src = os.path.join(folder, _fname)
                    _dst = os.path.join(_symlink_dir, _fname)
                    if os.path.isfile(_src):
                        if os.path.lexists(_dst):
                            try:
                                os.remove(_dst)
                            except Exception:
                                pass
                        try:
                            os.symlink(_src, _dst)
                        except Exception:
                            pass
            except Exception:
                pass
        return {'downloaded': downloaded, 'failed': failed, 'folder': folder}

    def _piconProgressCreate(self, done, total):
        try:
            pct = int(done * 100 / total) if total else 0
            self["key_red"].setText(u"\u2193 %d / %d  (%d%%)" % (done, total, pct))
        except Exception:
            pass

    def _createDone(self, result):
        self._creating = False
        self["key_red"].setText(T("Create Playlist"))
        if result.get('ok'):
            # Record the name used so a future rename can clean up these files
            idx       = result.get('_idx')
            prov_name = result.get('_prov_name', '')
            if idx is not None and prov_name:
                try:
                    self._providers_raw[idx]['_name_at_last_create'] = prov_name
                    import re as _re_slc
                    self._providers_raw[idx]['_safe_name_at_last_create'] = _re_slc.sub(r'_+', '_', _re_slc.sub(r'[^\w\-]', '', _re_slc.sub(r'\s+', '_', prov_name))).strip('_-')
                    # If selection was auto-initialized, persist it now on main thread
                    if result.get('_auto_selected_channels'):
                        self._providers_raw[idx]['selected_channels'] = result['_auto_selected_channels']
                    savePlaylistProviderConfig(self._providers_raw)
                except Exception:
                    pass
            if result.get('_is_update'):
                _stats = result.get('_update_stats') or {}
                # ── Build detailed recall info ──────────────────────────────
                global _last_m3u_update_info
                _info_lines = []
                _total_added    = sum(v.get('added',   0) for v in _stats.values())
                _total_removed  = sum(v.get('removed', 0) for v in _stats.values())
                _total_bq_del   = sum(1 for v in _stats.values() if v.get('bouquet_deleted'))
                picons          = result.get('picons')
                _picons_removed = (picons.get('deleted', 0) if picons else 0)
                _line1 = (T("Channels Added") + ' (%d)   ' % _total_added +
                          T("Channels Removed") + ' (%d)' % _total_removed)
                if _total_bq_del:
                    _line1 += '   ' + T("Bouquets Removed") + ' (%d)' % _total_bq_del
                _info_lines.append(_line1)
                _info_lines.append(
                    T("Picons Downloaded") + ' (%d)   ' % (picons.get('downloaded', 0) if picons else 0) +
                    T("Picons Removed") + ' (%d)' % _picons_removed)
                _info_lines.append('')
                for _bn, _bc in sorted(_stats.items()):
                    if _bc.get('bouquet_deleted'):
                        _info_lines.append(T("Bouquet Removed") + ':  ' + _bn)
                _info_lines.append('')
                for _bn, _bc in sorted(_stats.items()):
                    for _cn in _bc.get('added_names', []):
                        _info_lines.append('%s:  +%s  %s' % (_bn, _cn, T("new")))
                _info_lines.append('')
                for _bn, _bc in sorted(_stats.items()):
                    if not _bc.get('bouquet_deleted'):
                        for _cn in _bc.get('removed_names', []):
                            _info_lines.append('%s:  -%s  %s' % (_bn, _cn, T("Deleted")))
                if picons and picons.get('folder'):
                    _info_lines.append('')
                    _info_lines.append(T("Picons saved to") + ': ' + picons['folder'])
                _last_m3u_update_info = _info_lines
                _save_m3u_update_info(_info_lines)
                # ── Brief summary message ───────────────────────────────────
                msg = (T("Playlist updated successfully!\n%d bouquet(s) updated in /etc/enigma2.\n"
                         "Enigma2 channel list has been reloaded.") % result.get('bouquets', 0))
                if _stats:
                    _lines = []
                    for _bn, _bc in sorted(_stats.items()):
                        if _bc['added'] > 0 or _bc['removed'] > 0:
                            _lines.append('  %s:  +%d new  -%d removed'
                                          % (_bn, _bc['added'], _bc['removed']))
                    if _lines:
                        msg += '\n\n' + '\n'.join(_lines)
                msg += '\n\n' + T("Press 1 or Menu for full channel list")
            else:
                msg = (T("Bouquets created successfully!\n%d bouquet(s) written to /etc/enigma2.\n"
                         "Enigma2 channel list has been reloaded.") % result.get('bouquets', 0))
            picons = result.get('picons')
            if picons:
                _skipped = picons.get('skipped', 0)
                _deleted = picons.get('deleted', 0)
                msg += ('\n\n' + T("Picons: %d downloaded, %d failed")
                        % (picons['downloaded'], picons['failed']))
                if _skipped:
                    msg += ('  ' + T("(%d skipped)") % _skipped)
                if _deleted:
                    msg += ('  ' + T("(%d deleted)") % _deleted)
                msg += ('\n' + T("Saved to: %s") % picons['folder'])
            self.session.open(MessageBox, msg, type=MessageBox.TYPE_INFO, timeout=10)
        else:
            self.session.open(MessageBox,
                T("Bouquet creation failed:\n%s") % result.get('error', T('Unknown error')),
                type=MessageBox.TYPE_ERROR, timeout=8)

    def keyCustomEPG(self):
        """Open Custom EPG screen for currently selected provider."""
        cur = self["config"].getCurrent()
        provider = {}
        if cur and self._cfg_entries:
            for i, cfg in self._cfg_entries:
                if cfg is cur[1]:
                    provider = dict(self._providers_raw[i])
                    break
        self.session.open(CustomEPGScreen, provider=provider)

    def keyShowUpdateInfo(self):
        self.session.open(IPTVUpdateInfoScreen)

    def keyCreateArchives(self):
        if self._build_running:
            self._build_cancelled = True
            self["key_green"].setText(T("Create Archives"))
            return
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov = self._providers_raw[idx]
        if not prov.get('create_archives'):
            self.session.open(MessageBox,
                T("'Create Provider Archives' is OFF for this provider.\n"
                  "Enable it in Edit Provider first."),
                type=MessageBox.TYPE_INFO, timeout=5)
            return
        if not (prov.get('xmltv_url') or '').strip():
            self.session.open(MessageBox,
                T("No XMLTV URL set for this provider."),
                type=MessageBox.TYPE_INFO, timeout=5)
            return
        self._build_running   = True
        self._build_cancelled = False
        self["key_green"].setText(T("Stop Build"))
        self["help_label"].setText(T("Building EPG cache...\nParsing XMLTV."))
        import threading as _thr
        t = _thr.Thread(target=self._archiveBuildThread, args=([prov],))
        t.daemon = True
        t.start()

    def _archiveBuildThread(self, providers):
        _error_msg = None
        try:
            def _progress(done, total, prov_name):
                try:
                    from twisted.internet import reactor as _r
                    _r.callFromThread(self._archiveBuildProgress, done, total, prov_name)
                except Exception:
                    pass
            _buildAllChannelCaches(providers, '', '',
                progress_cb=_progress,
                cancel_check=lambda: self._build_cancelled)
        except Exception as _e:
            _error_msg = str(_e)
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(self._archiveBuildDone, _error_msg)
        except Exception:
            self._archiveBuildDone(_error_msg)

    def _archiveBuildProgress(self, done, total, prov_name):
        try:
            pct = int(100 * done / total) if total else 0
            self["help_label"].setText(
                T("Building EPG cache... %d%%") % pct + "\n" +
                T("Provider: %s") % prov_name + "\n" +
                T("Channels cached: %d / %d") % (done, total))
        except Exception:
            pass

    def _archiveBuildDone(self, error_msg=None):
        try:
            self._build_running   = False
            self._build_cancelled = False
            self["key_green"].setText(T("Create Archives"))
            if error_msg:
                self["help_label"].setText(T("Archive build FAILED:\n") + error_msg)
                self.session.open(MessageBox, error_msg,
                                  type=MessageBox.TYPE_ERROR, timeout=10)
            else:
                self["help_label"].setText(T("Archive build complete."))
        except Exception:
            pass

    def keyTest(self):
        if self._testing:
            self.session.open(MessageBox, T("Test already running, please wait."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov = self._providers_raw[idx]
        if not (prov.get('m3u_source') or prov.get('xmltv_url') or '').strip()                 and not prov.get('xtream_enabled'):
            self.session.open(MessageBox,
                T("Selected provider has no M3U or XMLTV URL to test."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return
        self._test_idx = idx
        self._testing  = True
        self["key_blue"].setText(T("Please wait..."))
        # Build the test provider dict (archive-specific if create_archives=True)
        test_prov = ({
            'name':       (prov.get('name') or '').strip(),
            'xmltv_url':  (prov.get('xmltv_url')  or '').strip(),
            'm3u_source': (prov.get('m3u_source') or '').strip(),
            'channel_id': (prov.get('archive_channel_id') or '').strip(),
            'days':       int(prov.get('archive_days', 7) or 7),
            'picon_naming': prov.get('picon_naming', 'off'),
        } if prov.get('create_archives') else prov)
        self._test_prov_cache = test_prov  # store before thread starts
        import threading as _thr
        t = _thr.Thread(target=self._testThread, args=(test_prov,))
        t.daemon = True
        t.start()

    def _testThread(self, prov):
        """Step 1 — fetch M3U only (fast). XMLTV is deferred to Channels ID."""
        try:
            result = _testM3UOnly(prov)
        except Exception as e:
            result = {
                'prov_name': prov.get('name') or T('unnamed'),
                'm3u_ok': False, 'm3u_count': 0, 'm3u_error': str(e)[:120],
                'xmltv_ok': False, 'xmltv_ch': 0, 'xmltv_ev': 0,
                'xmltv_error': str(e)[:120], 'm3u_channels_raw': [],
                'matched_channels': [], 'unmatched_channels': [],
                'm3u_only': True,
            }
        result['picon_naming'] = prov.get('picon_naming', 'off')
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(self._testDone, result)
        except Exception:
            self._testDone(result)

    def _testDone(self, r):
        self._testing = False
        self["key_blue"].setText(T("Select Bouquets"))
        idx  = getattr(self, '_test_idx', None)
        prov = self._providers_raw[idx] if idx is not None else {}
        saved_selection = prov.get('selected_channels') or []
        channels = r.get('m3u_channels_raw') or []
        # Cache for use in _xmltvDone
        self._m3u_channels_cache   = channels
        self._saved_selection_cache = saved_selection
        # Open Channel Browser exactly once with test result already stored
        dlg = self.session.openWithCallback(
            self._onBrowserClosed,
            IPTVChannelBrowserScreen, channels, saved_selection, r)
        # Pass provider so Channel Browser can load XMLTV if needed
        if dlg:
            dlg._test_prov = getattr(self, '_test_prov_cache', None)

    def _onBrowserClosed(self, result_tuple):
        """Handle Channel Browser close — tuple of (action, data)."""
        if not isinstance(result_tuple, tuple):
            return
        action, data = result_tuple

        if action == 'cancel':
            return  # User cancelled — stay on main screen

        idx = getattr(self, '_test_idx', None)
        if idx is None:
            return

        if action == 'save':
            # Blue Save — store selection and return to main screen
            prov = self._providers_raw[idx]
            # Store as dict: 'selected' = checked URLs, 'known' = all URLs seen
            if isinstance(data, dict) and 'selected' in data:
                prov['selected_channels'] = data
            else:
                # data is a set/list of selected URLs; build known from current channels
                _all_urls = set()
                try:
                    _channels = _parseM3UPlaylist(prov.get('m3u_source', ''))
                    _all_urls = {(ch.get('url') or '').strip() for ch in _channels}
                except Exception:
                    pass
                prov['selected_channels'] = {'selected': list(data), 'known': list(_all_urls or data)}
            savePlaylistProviderConfig(self._providers_raw)

        elif action == 'show_channels_id':
            # Yellow Channels ID — open Channels ID, then come back to browser
            prov = self._providers_raw[idx]
            saved_selection = prov.get('selected_channels') or []
            channels = (data.get('m3u_channels_raw') or []) if isinstance(data, dict) else []
            test_result = data if isinstance(data, dict) else None
            self.session.openWithCallback(
                lambda r: self._onChannelsIDClosed(r, channels, saved_selection, test_result),
                IPTVProviderTestResultScreen, data)

    def _onChannelsIDClosed(self, result, channels, saved_selection, test_result):
        """Channels ID closed — reopen Channel Browser.""";
        dlg2 = self.session.openWithCallback(
            self._onBrowserClosed,
            IPTVChannelBrowserScreen, channels, saved_selection, test_result)
        if dlg2:
            dlg2._test_prov = getattr(self, '_test_prov_cache', None)

    def keyClose(self):
        global _auto_build_listener
        if _auto_build_listener is self:
            _auto_build_listener = None
        self.close()

    def keyVodBrowser(self):
        """Open the IPTVVodBrowserScreen for the selected Xtream provider."""
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov = self._providers_raw[idx]
        if not prov.get('xtream_enabled'):
            self.session.open(MessageBox,
                T("Selected provider is not an Xtream provider.\nVOD Browser requires Xtream (Level 3) type."),
                type=MessageBox.TYPE_INFO, timeout=5)
            return
        self.session.open(IPTVVodBrowserScreen, prov)


# ---------------------------------------------------------------------------
# IPTVPlaylistProviderEditDialog — add / edit one playlist provider
# ---------------------------------------------------------------------------

def _resolveXtreamUrls(prov):
    """Return (m3u_url, xmltv_url) built from Xtream credentials, or (None, None)."""
    if not prov.get('xtream_enabled'):
        return None, None
    server = (prov.get('xtream_url') or '').strip().rstrip('/')
    xtype  = (prov.get('xtream_type') or 'user_pass').strip()
    if not server:
        return None, None
    if xtype == 'user_pass':
        user = (prov.get('xtream_username') or '').strip()
        pw   = (prov.get('xtream_password') or '').strip()
        if not user:
            return None, None
        m3u_url   = '%s/get.php?username=%s&password=%s&type=m3u_plus&output=ts' % (server, user, pw)
        xmltv_url = '%s/xmltv.php?username=%s&password=%s' % (server, user, pw)
    else:
        token = (prov.get('xtream_token') or '').strip()
        if not token:
            return None, None
        m3u_url   = '%s/get.php?token=%s&type=m3u_plus&output=ts' % (server, token)
        xmltv_url = '%s/xmltv.php?token=%s' % (server, token)
    return m3u_url, xmltv_url


# ===========================================================================
# IPTVVodInfoScreen — on-demand info overlay for a single Xtream VOD item.
#
# Usage:
#   session.open(IPTVVodInfoScreen, stream_id, stream_name, stream_ext, prov)
#
# stream_id   : int — the Xtream stream_id (e.g. 12345)
# stream_name : str — display name from the bouquet
# stream_ext  : str — container extension from get_vod_streams (e.g. 'mkv')
# prov        : dict — provider config (xtream_url, xtream_type, credentials)
#
# Keys inside the screen:
#   OK / Green  → play the movie via Enigma2 native player
#   UP / DOWN   → scroll plot text
#   EXIT        → back to caller
# ===========================================================================

class IPTVVodInfoScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1376,770" title="Movie Info" backgroundColor="#33000000">
            <widget name="cover"    position="22,22"   size="291,425"
                    alphaTest="blend" />
            <widget name="title"    position="335,22"  size="1019,68"
                    font="Bold;35" valign="center" halign="left" transparent="1" />
            <widget name="meta"     position="335,97"  size="1019,42"
                    font="Regular;29" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="genre"    position="335,161" size="1019,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
            <widget name="director" position="335,205" size="1019,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
            <widget name="cast"     position="335,249" size="1019,75"
                    font="Regular;29" valign="top"    halign="left" transparent="1" />
            <eLabel position="0,457" size="1376,2" backgroundColor="#555555"/>
            <widget name="plot"     position="22,467"  size="1332,216"
                    font="Regular;37" transparent="1" />
            <eLabel position="0,691" size="1376,2" backgroundColor="#555555"/>
            <widget name="status"   position="22,699"  size="969,61"
                    font="Regular;29" valign="center" transparent="1"
                    foregroundColor="#aaaaaa" />
            <ePixmap position="1057,709" size="35,25" pixmap="buttons/green.png"
                     alphaTest="blend" />
            <widget name="key_green" position="1104,703" size="255,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1376,770" title="Movie Info">
            <widget name="cover"    position="22,22"   size="291,425"
                    alphaTest="blend" />
            <widget name="title"    position="335,22"  size="1019,68"
                    font="Bold;35" valign="center" halign="left" transparent="1" />
            <widget name="meta"     position="335,97"  size="1019,42"
                    font="Regular;29" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="genre"    position="335,161" size="1019,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
            <widget name="director" position="335,205" size="1019,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
            <widget name="cast"     position="335,249" size="1019,75"
                    font="Regular;29" valign="top"    halign="left" transparent="1" />
            <eLabel position="0,457" size="1376,2" backgroundColor="#555555"/>
            <widget name="plot"     position="22,467"  size="1332,216"
                    font="Regular;37" />
            <eLabel position="0,691" size="1376,2" backgroundColor="#555555"/>
            <widget name="status"   position="22,699"  size="969,61"
                    font="Regular;29" valign="center" transparent="1"
                    foregroundColor="#aaaaaa" />
            <ePixmap position="1057,709" size="35,25" pixmap="buttons/green.png"
                     alphaTest="blend" />
            <widget name="key_green" position="1104,703" size="255,40"
                    font="Regular;29" valign="center" halign="left" transparent="1" />
        </screen>"""
    skin    = _SKIN_T

    def __init__(self, session, stream_id, stream_name, stream_ext, prov):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._stream_id   = int(stream_id)
        self._stream_name = stream_name or ''
        self._stream_ext  = (stream_ext or 'mp4').strip() or 'mp4'
        self._prov        = prov
        self._play_url    = ''
        self._cover_path  = None
        self._loading     = True
        self._vod_result  = {}

        try:
            from Components.Pixmap import Pixmap as _Pixmap
        except Exception:
            _Pixmap = None
        if _Pixmap is not None:
            self["cover"] = _Pixmap()
        else:
            self["cover"] = Label('')
        self["title"]     = Label(stream_name or '')
        self["meta"]      = Label('')
        self["genre"]     = Label('')
        self["director"]  = Label('')
        self["cast"]      = Label('')
        self["plot"]      = ScrollLabel(T("Loading movie info..."))
        self["status"]    = Label(T("Fetching info, please wait..."))
        self["key_green"] = Label(T("Play"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {"ok":     self._keyPlay,
             "cancel": self._keyExit,
             "green":  self._keyPlay,
             "up":     self._scrollUp,
             "down":   self._scrollDown}, -2)

        self.setTitle((stream_name or T("Movie Info")) + u"  \u2014  " + T("Movie Info"))

        # Initialise ePicLoad for cover display (graceful if unavailable)
        self._picload = None
        try:
            from enigma import ePicLoad
            self._picload = ePicLoad()
            self._picload.PictureData.get().append(self._onPictureDecoded)
        except Exception:
            pass

        # Fetch info + cover in background thread
        import threading
        t = threading.Thread(target=self._fetchThread)
        t.daemon = True
        t.start()

    # ------------------------------------------------------------------
    # Picture loading
    # ------------------------------------------------------------------

    def _onPictureDecoded(self, picInfo=None):
        if self._picload is None:
            return
        try:
            ptr = self._picload.getData()
            if ptr:
                self["cover"].instance.setPixmap(ptr)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Background fetch thread
    # ------------------------------------------------------------------

    def _buildPlayerApi(self):
        """Return (server_base, player_api_base_url) from provider config."""
        server = (self._prov.get('xtream_url') or '').strip().rstrip('/')
        xtype  = (self._prov.get('xtream_type') or 'user_pass').strip()
        if xtype == 'token':
            token = (self._prov.get('xtream_token') or '').strip()
            return server, '%s/player_api.php?token=%s' % (server, token)
        user = (self._prov.get('xtream_username') or '').strip()
        pw   = (self._prov.get('xtream_password') or '').strip()
        return server, '%s/player_api.php?username=%s&password=%s' % (server, user, pw)

    def _fetchThread(self):
        import tempfile, os
        server, player_api = self._buildPlayerApi()

        # Fetch vod_info
        info_url = '%s&action=get_vod_info&vod_id=%d' % (player_api, self._stream_id)
        try:
            data = _fetchXtreamApiJson(info_url, timeout=15)
        except Exception as e:
            self._callFromThread(self._showError, T("API error: %s") % str(e)[:80])
            return

        if not data or not isinstance(data, dict):
            self._callFromThread(self._showError, T("No info returned from server."))
            return

        info        = data.get('info') or {}
        movie_data  = data.get('movie_data') or {}

        title    = (info.get('name') or movie_data.get('name') or self._stream_name or '').strip()
        year     = str(info.get('releasedate') or '')[:4].strip()
        rating   = str(info.get('rating') or movie_data.get('rating') or '').strip()
        duration = (info.get('duration') or '').strip()
        country  = (info.get('country') or '').strip()
        genre    = (info.get('genre') or '').strip()
        director = (info.get('director') or '').strip()
        actors   = (info.get('actors') or info.get('cast') or '').strip()
        plot     = (info.get('plot') or info.get('description') or '').strip()
        cover_url = (info.get('cover_big') or info.get('movie_image') or '').strip()

        # Build compact meta line
        meta_parts = []
        if year:     meta_parts.append(year)
        if rating and rating not in ('0', '0.0', ''):
            meta_parts.append(u'\u2605 ' + rating)
        if duration: meta_parts.append(duration)
        if country:  meta_parts.append(country)
        meta_line = u'   \u2502   '.join(meta_parts)

        # Download cover image to a temp file
        cover_path = None
        if cover_url:
            try:
                import urllib.request as _ur
                req = _ur.Request(cover_url, headers={'User-Agent': 'Mozilla/5.0'})
                with _ur.urlopen(req, timeout=10) as _r:
                    img_data = _r.read()
                suffix = '.png' if cover_url.lower().endswith('.png') else '.jpg'
                cover_path = tempfile.mktemp(suffix=suffix)
                with open(cover_path, 'wb') as _f:
                    _f.write(img_data)
            except Exception:
                cover_path = None

        # Build playback URL (same format as bouquet entries)
        xtype = (self._prov.get('xtream_type') or 'user_pass').strip()
        ext   = (movie_data.get('container_extension') or self._stream_ext or 'mp4').strip()
        if xtype == 'token':
            token    = (self._prov.get('xtream_token') or '').strip()
            play_url = '%s/movie/%s/%d.%s' % (server, token, self._stream_id, ext)
        else:
            user     = (self._prov.get('xtream_username') or '').strip()
            pw       = (self._prov.get('xtream_password') or '').strip()
            play_url = '%s/movie/%s/%s/%d.%s' % (server, user, pw, self._stream_id, ext)

        result = {
            'title': title, 'meta': meta_line, 'genre': genre,
            'director': director, 'actors': actors, 'plot': plot,
            'cover_path': cover_path, 'play_url': play_url,
            'year': year, 'duration_str': duration,
        }
        self._callFromThread(self._showResult, result)

    # ------------------------------------------------------------------
    # UI update (called from main thread via reactor)
    # ------------------------------------------------------------------

    def _callFromThread(self, fn, *args):
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(fn, *args)
        except Exception:
            fn(*args)

    def _showError(self, msg):
        self["status"].setText(msg)
        self["plot"].setText(msg)
        self._loading = False

    def _showResult(self, r):
        self._loading    = False
        self._vod_result = r
        self._play_url   = r.get('play_url') or ''
        self._cover_path = r.get('cover_path')

        title = r.get('title') or self._stream_name or ''
        self.setTitle(title or T("Movie Info"))
        self["title"].setText(title)
        self["meta"].setText(r.get('meta') or '')

        genre = r.get('genre') or ''
        if genre:
            self["genre"].setText(T("Genre") + ': ' + genre)

        director = r.get('director') or ''
        if director:
            self["director"].setText(T("Director") + ': ' + director)

        actors = r.get('actors') or ''
        if actors:
            parts = [a.strip() for a in actors.split(',') if a.strip()]
            shown = ', '.join(parts[:4])
            if len(parts) > 4:
                shown += u', \u2026'
            self["cast"].setText(T("Cast") + ': ' + shown)

        self["plot"].setText(r.get('plot') or T("(No plot available)"))
        self["status"].setText(T("OK / Green = Play     EXIT = Back"))

        # Load cover via ePicLoad
        if self._cover_path and self._picload is not None:
            try:
                sc = self["cover"].instance.size()
                self._picload.setPara([sc.width(), sc.height(), 0, 0, False, 1, '#FF000000'])
                self._picload.startDecode(self._cover_path)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Key handlers
    # ------------------------------------------------------------------

    def _keyPlay(self):
        if self._loading or not self._play_url:
            return
        try:
            from enigma import eServiceReference
            sref_url = self._play_url.replace(':', '%3a')
            sref = eServiceReference('4097:0:0:0:0:0:0:0:0:0:' + sref_url)
            self._nativeInjectEpg(sref)
            self.session.nav.playService(sref)
            self.close()
        except Exception as e:
            self.session.open(MessageBox,
                T("Playback error: %s") % str(e)[:120],
                type=MessageBox.TYPE_ERROR, timeout=6)

    def _nativeInjectEpg(self, sref):
        info = self._vod_result or {}
        if not info:
            return
        try:
            import time, re
            from enigma import eEPGCache
            title    = (info.get('title') or self._stream_name or '').strip()
            short    = (info.get('meta')  or '').strip()
            extended = (info.get('plot')  or '').strip()
            dur_str  = info.get('duration_str') or ''
            dur_secs = 7200
            m = re.match(r'(\d+)\s*h\s*(\d+)', dur_str, re.I)
            if m:
                dur_secs = int(m.group(1)) * 3600 + int(m.group(2)) * 60
            else:
                m = re.match(r'(\d+)\s*min', dur_str, re.I)
                if m:
                    dur_secs = int(m.group(1)) * 60
                else:
                    m = re.match(r'(\d+)', dur_str)
                    if m:
                        val = int(m.group(1))
                        dur_secs = val if val > 300 else val * 60
            begin    = int(time.time())
            sref_str = str(sref)
            cache    = eEPGCache.getInstance()
            try:
                cache.importEvents(sref_str,
                    [(begin, dur_secs, 1, title, short, extended)])
            except Exception:
                try:
                    cache.importEvents(
                        [(sref_str, [(begin, dur_secs, 1, title, short, extended)])])
                except Exception:
                    pass
        except Exception:
            pass

    def _keyExit(self):
        # Clean up temp cover file
        if self._cover_path:
            try:
                import os
                os.remove(self._cover_path)
            except Exception:
                pass
        self.close()

    def _scrollUp(self):
        try:
            self["plot"].pageUp()
        except Exception:
            pass

    def _scrollDown(self):
        try:
            self["plot"].pageDown()
        except Exception:
            pass


# ===========================================================================
# IPTVVodSeekDialog — seek dialog with position display and progress bar.
# ===========================================================================

class IPTVVodSeekDialog(Screen):
    skin = """
        <screen position="center,center" size="620,290" title="Seek">
            <widget name="pos_label"  position="10,15"  size="600,30"
                    font="Regular;22" halign="center" transparent="1" />
            <widget name="bar_label"  position="10,52"  size="600,26"
                    font="Regular;18" halign="center"
                    foregroundColor="#00cc44" transparent="1" />
            <eLabel position="0,86" size="620,2" backgroundColor="#444444"/>
            <widget name="dir_label"  position="10,96"  size="250,36"
                    font="Regular;22" transparent="1" />
            <widget name="min_val"    position="270,92" size="80,44"
                    font="Bold;30"   halign="center"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="min_unit"   position="358,96" size="250,36"
                    font="Regular;22" transparent="1" />
            <eLabel position="0,144" size="620,2" backgroundColor="#444444"/>
            <widget name="tgt_label"  position="10,152" size="600,36"
                    font="Regular;22" halign="center"
                    foregroundColor="#ffaa00" transparent="1" />
            <eLabel position="0,198" size="620,2" backgroundColor="#555555"/>
            <widget name="key_ok"     position="10,206"  size="290,36"
                    font="Regular;20" halign="center" transparent="1" />
            <widget name="key_cancel" position="320,206" size="290,36"
                    font="Regular;20" halign="center" transparent="1" />
        </screen>"""

    def __init__(self, session, direction, cur_pts, length_pts):
        Screen.__init__(self, session)
        self._direction  = direction
        self._cur_pts    = cur_pts
        self._length_pts = length_pts
        self._minutes    = 1
        self._num_buf    = ''

        self["pos_label"]  = Label('')
        self["bar_label"]  = Label('')
        self["dir_label"]  = Label(T("Skip forward:") if direction > 0 else T("Skip back:"))
        self["min_val"]    = Label('1')
        self["min_unit"]   = Label(T("minute(s)"))
        self["tgt_label"]  = Label('')
        self["key_ok"]     = Label(u"OK  \u2192  Seek")
        self["key_cancel"] = Label(u"EXIT  \u2192  Cancel")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "NumberActions"],
            {"ok":     self._doSeek,
             "cancel": lambda: self.close(None),
             "up":     self._incMin,
             "down":   self._decMin,
             "1": lambda: self._numKey('1'), "2": lambda: self._numKey('2'),
             "3": lambda: self._numKey('3'), "4": lambda: self._numKey('4'),
             "5": lambda: self._numKey('5'), "6": lambda: self._numKey('6'),
             "7": lambda: self._numKey('7'), "8": lambda: self._numKey('8'),
             "9": lambda: self._numKey('9'), "0": lambda: self._numKey('0'),
             }, -2)

        self._update()

    @staticmethod
    def _ptsToHMS(pts):
        secs = max(0, int(pts // 90000))
        return '%02d:%02d:%02d' % (secs // 3600, (secs % 3600) // 60, secs % 60)

    @staticmethod
    def _buildBar(pct, width=28):
        filled = int(width * pct / 100.0)
        return u'[\u2588' * 1 + u'\u2588' * max(0, filled - 1) + u'\u2591' * (width - filled) + u']  %d%%' % int(pct)

    def _update(self):
        cur_str = self._ptsToHMS(self._cur_pts)
        if self._length_pts > 0:
            tot_str = self._ptsToHMS(self._length_pts)
            pct     = min(100.0, self._cur_pts * 100.0 / max(1, self._length_pts))
            self["pos_label"].setText(u'%s  \u2502  %s' % (cur_str, tot_str))
            self["bar_label"].setText(self._buildBar(pct))
        else:
            self["pos_label"].setText(cur_str)
            self["bar_label"].setText('')
        skip_pts = self._direction * self._minutes * 60 * 90000
        tgt_pts  = max(0, self._cur_pts + skip_pts)
        if self._length_pts > 0:
            tgt_pts = min(tgt_pts, self._length_pts)
        arrow = u'\u2192' if self._direction > 0 else u'\u2190'
        self["tgt_label"].setText(u'%s  %s' % (arrow, self._ptsToHMS(tgt_pts)))
        self["min_val"].setText(str(self._minutes))

    def _incMin(self):
        self._minutes = min(999, self._minutes + 1)
        self._num_buf = ''
        self._update()

    def _decMin(self):
        self._minutes = max(1, self._minutes - 1)
        self._num_buf = ''
        self._update()

    def _numKey(self, digit):
        self._num_buf += digit
        val = int(self._num_buf)
        if val == 0:
            self._num_buf = ''
            val = 1
        if val > 999:
            self._num_buf = digit
            val = int(digit) or 1
        self._minutes = val
        self._update()

    def _doSeek(self):
        self.close(self._minutes)


# ===========================================================================
# IPTVVodPlayerScreen — transparent player overlay for Xtream VOD streams.
#
# Opened by IPTVVodInfoScreen when the user presses OK/Green to play.
# Handles: pause/play, stop (EXIT), seek forward/back (FF/RW keys).
# The screen is invisible (size 0×0) — the video fills the display.
# ===========================================================================

class IPTVVodPlayerScreen(Screen):
    skin = """<screen position="0,0" size="0,0" flags="wfNoBorder"/>"""

    def __init__(self, session, sref, title='', vod_info=None):
        Screen.__init__(self, session)
        self._sref     = sref
        self._title    = title or ''
        self._vod_info = vod_info or {}

        self["actions"] = ActionMap(
            ["OkCancelActions", "InfobarSeekActions",
             "MediaPlayerActions", "SetupActions"],
            {
                "cancel":         self._keyStop,
                "stop":           self._keyStop,
                "pause":          self._keyPause,
                "play":           self._keyPause,
                "seekFwd":        lambda: self._askSeek(1),
                "seekBack":       lambda: self._askSeek(-1),
                "seekFwdManual":  lambda: self._seekRelative(15),
                "seekBackManual": lambda: self._seekRelative(-15),
            }, -2)

        self.onLayoutFinish.append(self._startPlay)

    def _startPlay(self):
        try:
            self.session.nav.playService(self._sref)
        except Exception:
            pass
        self._injectEpgEvent()

    def _keyStop(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close()

    def _keyPause(self):
        try:
            svc = self.session.nav.getCurrentService()
            if svc:
                pc = svc.pause()
                if pc:
                    if pc.isPaused():
                        pc.unpause()
                    else:
                        pc.pause()
        except Exception:
            pass

    def _askSeek(self, direction):
        try:
            cur_pts    = 0
            length_pts = 0
            svc = self.session.nav.getCurrentService()
            if svc:
                seek = svc.seek()
                if seek:
                    ret, pos = seek.getPlayPosition()
                    if ret == 0:
                        cur_pts = pos
                    ret2, length = seek.getLength()
                    if ret2 == 0:
                        length_pts = length
            self.session.openWithCallback(
                lambda result: self._onSeekInput(result, direction),
                IPTVVodSeekDialog,
                direction, cur_pts, length_pts)
        except Exception:
            self._seekRelative(direction * 60)

    def _onSeekInput(self, result, direction):
        if result is None:
            return
        try:
            minutes = int(result)
            if minutes > 0:
                self._seekRelative(direction * minutes * 60)
        except (ValueError, TypeError):
            pass

    def _seekRelative(self, seconds):
        try:
            svc = self.session.nav.getCurrentService()
            if not svc:
                return
            seek = svc.seek()
            if not seek:
                return
            ret, pos = seek.getPlayPosition()
            if ret == 0:
                newpos = max(0, pos + int(seconds * 90000))
                seek.seekTo(newpos)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # EPG injection — shows movie info in the standard Enigma2 infobar
    # ------------------------------------------------------------------

    def _parseDuration(self, s):
        import re
        s = (s or '').strip()
        m = re.match(r'(\d+)\s*h\s*(\d+)', s, re.I)
        if m:
            return int(m.group(1)) * 3600 + int(m.group(2)) * 60
        m = re.match(r'(\d+)\s*min', s, re.I)
        if m:
            return int(m.group(1)) * 60
        m = re.match(r'(\d+)', s)
        if m:
            val = int(m.group(1))
            return val if val > 300 else val * 60
        return 7200

    def _injectEpgEvent(self):
        if not self._vod_info:
            return
        try:
            import time
            from enigma import eEPGCache
            title    = (self._vod_info.get('title') or self._title or '').strip()
            short    = (self._vod_info.get('meta')  or '').strip()
            extended = (self._vod_info.get('plot')  or '').strip()
            dur_secs = self._parseDuration(self._vod_info.get('duration_str') or '')
            begin    = int(time.time())
            sref_str = str(self._sref)
            cache    = eEPGCache.getInstance()
            try:
                cache.importEvents(sref_str,
                    [(begin, dur_secs, 1, title, short, extended)])
            except Exception:
                try:
                    cache.importEvents(
                        [(sref_str, [(begin, dur_secs, 1, title, short, extended)])])
                except Exception:
                    pass
        except Exception:
            pass


# ===========================================================================
# IPTVVodBrowserScreen — two-panel Xtream VOD browser.
#
# Left panel  : categories fetched from get_vod_categories
# Right panel : movies for the selected category (from get_vod_streams)
#
# Keys:
#   OK (right panel)   → open IPTVVodInfoScreen for highlighted movie
#   INFO               → open IPTVVodInfoScreen for highlighted movie
#   OK (left panel)    → switch focus to right panel
#   Green              → toggle focus between panels
#   Yellow / EXIT      → close
# ===========================================================================

class IPTVVodBrowserScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1376,828" title="VOD Browser" backgroundColor="#33000000">
            <widget name="cat_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="mov_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="cat_list"  position="11,71"  size="662,600"
                    scrollbarMode="showOnDemand" font="Regular;22" itemHeight="30" transparent="1"/>
            <widget name="mov_list"  position="684,71" size="681,600"
                    scrollbarMode="showOnDemand" font="Regular;22" itemHeight="30" transparent="1"/>
            <eLabel position="0,685" size="1376,76" backgroundColor="#000000" zPosition="4"/>
            <widget name="infobar_cat" position="11,685"  size="1354,38"
                    font="Regular;33" valign="center" halign="left"
                    foregroundColor="#ffcc00" zPosition="5" transparent="1" />
            <widget name="infobar_mov" position="11,723"  size="1354,38"
                    font="Regular;33" valign="center" halign="left"
                    foregroundColor="#ffcc00" zPosition="5" transparent="1" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="470,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="813,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1157,776" size="204,35"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
            <widget name="key_hint"   position="11,790"   size="1354,1"
                    font="Regular;1" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1376,828" title="VOD Browser">
            <widget name="cat_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="mov_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="cat_list"  position="11,71"  size="662,600"
                    scrollbarMode="showOnDemand" font="Regular;22" itemHeight="30" />
            <widget name="mov_list"  position="684,71" size="681,600"
                    scrollbarMode="showOnDemand" font="Regular;22" itemHeight="30" />
            <widget name="infobar_cat" position="11,685"  size="1354,38"
                    font="Regular;33" valign="center" halign="left"
                    foregroundColor="#ffcc00" zPosition="5" />
            <widget name="infobar_mov" position="11,723"  size="1354,38"
                    font="Regular;33" valign="center" halign="left"
                    foregroundColor="#ffcc00" zPosition="5" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="470,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="813,776"  size="253,35"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_blue"   position="1157,776" size="204,35"
                    font="Regular;24" valign="center" halign="left" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
            <widget name="key_hint"   position="11,790"   size="1354,1"
                    font="Regular;1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, prov):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._prov       = prov
        self._focus_left = True    # start with category panel focused
        self._cat_list   = []      # [(display_name, cat_id), ...]
        self._vod_by_cat = {}      # {cat_id: [stream_dict, ...]}
        self._vod_all    = []      # all streams (for the "All" category)
        self._loading    = True
        self._vis        = True    # track hide/show state
        self._paused     = False   # local pause state (isPaused() unreliable)
        self._sort_mode  = 0       # 0=Name  1=Rating  2=Year

        self["cat_title"]  = Label('')
        self["mov_title"]  = Label('')
        self["cat_list"]   = MenuList([])
        self["mov_list"]   = MenuList([])
        self["key_red"]    = Label(T("Hide"))
        self["key_green"]  = Label(T("Switch Panel"))
        self["key_yellow"] = Label(T("Back"))
        self["key_blue"]   = Label(T("Sort: Name"))
        self["key_hint"]    = Label("")
        self["infobar_cat"] = Label("")
        self["infobar_mov"] = Label("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions",
             "EPGSelectActions", "MediaPlayerActions", "InfobarEPGActions",
             "InfobarSeekActions"],
            {"cancel":         self.close,
             "ok":             self._keyOk,
             "red":            self._toggleVisible,
             "green":          self._toggleFocus,
             "yellow":         self.close,
             "blue":           self._cycleSort,
             "epg":            self._keyInfo,
             "showEPGList":    self._keyInfo,
             "up":             self._navUp,
             "down":           self._navDown,
             "left":           self._navLeft,
             "right":          self._navRight,
             "pause":          self._mediaPause,
             "play":           self._mediaPause,
             "playpause":      self._mediaPause,
             "stop":           self._mediaStop,
             "seekFwd":        lambda: self._askSeek(+1),
             "seekBack":       lambda: self._askSeek(-1),
             "seekFwdManual":  lambda: self._mediaSeekRel(+15),
             "seekBackManual": lambda: self._mediaSeekRel(-15)}, -2)

        self.setTitle(T("VOD Browser") + u"  \u2014  " + (prov.get('name') or ''))

        import threading
        t = threading.Thread(target=self._loadThread)
        t.daemon = True
        t.start()

    # ------------------------------------------------------------------
    # Hide / Show toggle
    # ------------------------------------------------------------------

    def _toggleVisible(self):
        if self._vis:
            self.hide()
            self._vis = False
        else:
            self.show()
            self._vis = True

    # ------------------------------------------------------------------
    # Media controls — forwarded to the currently playing service so that
    # pause / FF / RW work while the browser is visible on screen.
    # ------------------------------------------------------------------

    def _mediaPause(self):
        try:
            svc = self.session.nav.getCurrentService()
            if svc:
                pc = svc.pause()
                if pc:
                    if self._paused:
                        pc.unpause()
                        self._paused = False
                    else:
                        pc.pause()
                        self._paused = True
        except Exception:
            pass

    def _mediaStop(self):
        try:
            self.session.nav.stopService()
            self._paused = False
        except Exception:
            pass

    def _askSeek(self, direction):
        try:
            cur_pts    = 0
            length_pts = 0
            svc = self.session.nav.getCurrentService()
            if svc:
                seek = svc.seek()
                if seek:
                    ret, pos = seek.getPlayPosition()
                    if ret == 0:
                        cur_pts = pos
                    ret2, length = seek.getLength()
                    if ret2 == 0:
                        length_pts = length
            self.session.openWithCallback(
                lambda result: self._onSeekInput(result, direction),
                IPTVVodSeekDialog,
                direction, cur_pts, length_pts)
        except Exception:
            self._mediaSeekRel(direction * 60)

    def _onSeekInput(self, result, direction):
        if result is None:
            return
        try:
            minutes = int(result)
            if minutes > 0:
                self._mediaSeekRel(direction * minutes * 60)
        except (ValueError, TypeError):
            pass

    def _mediaSeekRel(self, seconds):
        try:
            svc = self.session.nav.getCurrentService()
            if not svc:
                return
            seek = svc.seek()
            if not seek:
                return
            ret, pos = seek.getPlayPosition()
            if ret == 0:
                newpos = max(0, pos + int(seconds * 90000))
                seek.seekTo(newpos)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Background load
    # ------------------------------------------------------------------

    def _buildPlayerApi(self):
        server = (self._prov.get('xtream_url') or '').strip().rstrip('/')
        xtype  = (self._prov.get('xtream_type') or 'user_pass').strip()
        if xtype == 'token':
            token = (self._prov.get('xtream_token') or '').strip()
            return '%s/player_api.php?token=%s' % (server, token)
        user = (self._prov.get('xtream_username') or '').strip()
        pw   = (self._prov.get('xtream_password') or '').strip()
        return '%s/player_api.php?username=%s&password=%s' % (server, user, pw)

    def _loadThread(self):
        try:
            player_api = self._buildPlayerApi()
            cats    = _fetchXtreamApiJson(player_api + '&action=get_vod_categories') or []
            streams = _fetchXtreamApiJson(player_api + '&action=get_vod_streams')    or []
        except Exception as e:
            self._callFromThread(self._showLoadError, str(e)[:120])
            return

        if not isinstance(cats,    list): cats    = []
        if not isinstance(streams, list): streams = []

        # category id → name map
        cat_name_map = {}
        for c in cats:
            cid = str(c.get('category_id') or '')
            cat_name_map[cid] = (c.get('category_name') or cid or T('Unknown')).strip()

        # group streams by category
        vod_by_cat = {}
        vod_all    = []
        for s in streams:
            try:
                sid = int(s.get('stream_id', 0))
            except Exception:
                continue
            if not sid:
                continue
            name = (s.get('name') or '').strip()
            if not name:
                continue
            cid = str(s.get('category_id') or '')
            vod_by_cat.setdefault(cid, []).append(s)
            vod_all.append(s)

        # build sorted category list
        cat_list = []
        for cid, cname in sorted(cat_name_map.items(), key=lambda x: x[1].lower()):
            if cid in vod_by_cat:
                cat_list.append((cname, cid))

        # prepend an "All" entry
        if vod_all:
            cat_list.insert(0, (T('All') + '  (%d)' % len(vod_all), '__all__'))

        self._callFromThread(self._showLoaded, cat_list, vod_by_cat, vod_all)

    def _callFromThread(self, fn, *args):
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(fn, *args)
        except Exception:
            fn(*args)

    def _showLoadError(self, msg):
        self._loading = False
        self["key_hint"].setText(T("Error loading VOD: ") + msg)

    def _showLoaded(self, cat_list, vod_by_cat, vod_all):
        self._loading    = False
        self._cat_list   = cat_list
        self._vod_by_cat = vod_by_cat
        self._vod_all    = vod_all

        cat_entries = []
        for cname, cid in cat_list:
            if cid == '__all__':
                cat_entries.append(cname)
            else:
                cat_entries.append('%s  (%d)' % (cname, len(vod_by_cat.get(cid, []))))
        self["cat_list"].setList(cat_entries)

        self._updateMovieList()
        self._updateTitles()
        self["key_hint"].setText(
            T("OK / EPG") + " \u2014 " + T("Movie Info") +
            "   |   " + T("GREEN") + " \u2014 " + T("Switch Panel") +
            "   |   " + T("BLUE") + " \u2014 " + T("Sort") +
            "   |   " + T("EXIT") + " \u2014 " + T("Back"))

    # ------------------------------------------------------------------
    # Navigation helpers
    # ------------------------------------------------------------------

    def _getCurrentStreams(self):
        try:
            idx = self["cat_list"].getSelectedIndex()
        except Exception:
            idx = 0
        if not (0 <= idx < len(self._cat_list)):
            return []
        _, cid = self._cat_list[idx]
        if cid == '__all__':
            return self._vod_all
        return self._vod_by_cat.get(cid, [])

    def _sortedStreams(self, streams):
        """Return streams sorted according to self._sort_mode."""
        try:
            if self._sort_mode == 1:
                return sorted(streams,
                              key=lambda s: float(s.get('rating') or 0),
                              reverse=True)
            if self._sort_mode == 2:
                return sorted(streams,
                              key=lambda s: int(s.get('year') or 0),
                              reverse=True)
        except Exception:
            pass
        return sorted(streams, key=lambda s: (s.get('name') or '').lower())

    def _updateMovieList(self):
        streams = self._sortedStreams(self._getCurrentStreams())
        entries = []
        for s in streams:
            name   = (s.get('name') or '').strip()
            rating = str(s.get('rating') or '').strip()
            year   = str(s.get('year')   or '').strip()
            suffix = ''
            if rating and rating not in ('0', '0.0'):
                suffix += u'  \u2605%s' % rating
            if year and year != '0':
                suffix += u'  (%s)' % year
            entries.append(name + suffix)
        self["mov_list"].setList(entries)
        try:
            self["mov_list"].instance.moveSelection(self["mov_list"].instance.moveTop)
        except Exception:
            pass

    def _cycleSort(self):
        _labels = [T("Sort: Name"), T("Sort: Rating \u2193"), T("Sort: Year \u2193")]
        self._sort_mode = (self._sort_mode + 1) % 3
        self["key_blue"].setText(_labels[self._sort_mode])
        self._updateMovieList()

    def _updateTitles(self):
        try:
            cidx = self["cat_list"].getSelectedIndex()
        except Exception:
            cidx = 0
        streams  = self._getCurrentStreams()
        cat_name = self._cat_list[cidx][0] if 0 <= cidx < len(self._cat_list) else ''
        cat_lbl = T("Categories") + '  (%d)' % len(self._cat_list)
        mov_lbl = T("Movies") + '  (%d)' % len(streams)
        if self._focus_left:
            self["cat_title"].setText(u'\u25ba ' + cat_lbl)
            self["mov_title"].setText(u'   '     + mov_lbl)
        else:
            self["cat_title"].setText(u'   '     + cat_lbl)
            self["mov_title"].setText(u'\u25ba ' + mov_lbl)
        # infobar: category name (line 1) + selected movie name with rating/year (line 2)
        try:
            midx = self["mov_list"].getSelectedIndex()
        except Exception:
            midx = 0
        sorted_streams = self._sortedStreams(self._getCurrentStreams())
        if 0 <= midx < len(sorted_streams):
            s = sorted_streams[midx]
            mov_name = (s.get('name') or '').strip()
            rating   = str(s.get('rating') or '').strip()
            year     = str(s.get('year')   or '').strip()
            suffix   = ''
            if rating and rating not in ('0', '0.0'):
                suffix += u'  \u2605%s' % rating
            if year and year != '0':
                suffix += u'  (%s)' % year
            mov_display = mov_name + suffix
        else:
            mov_display = ''
        try:
            self["infobar_cat"].setText(cat_name)
            self["infobar_mov"].setText(mov_display)
        except Exception:
            pass

    def _toggleFocus(self):
        self._focus_left = not self._focus_left
        self._updateTitles()

    def _navUp(self):
        if self._focus_left:
            try: self["cat_list"].up()
            except Exception: pass
            self._updateMovieList()
        else:
            try: self["mov_list"].up()
            except Exception: pass
        self._updateTitles()

    def _navDown(self):
        if self._focus_left:
            try: self["cat_list"].down()
            except Exception: pass
            self._updateMovieList()
        else:
            try: self["mov_list"].down()
            except Exception: pass
        self._updateTitles()

    def _navLeft(self):
        if self._focus_left:
            try: self["cat_list"].pageUp()
            except Exception: pass
            self._updateMovieList()
        else:
            try: self["mov_list"].pageUp()
            except Exception: pass
        self._updateTitles()

    def _navRight(self):
        if self._focus_left:
            try: self["cat_list"].pageDown()
            except Exception: pass
            self._updateMovieList()
        else:
            try: self["mov_list"].pageDown()
            except Exception: pass
        self._updateTitles()

    def _getSelectedStream(self):
        streams = self._sortedStreams(self._getCurrentStreams())
        try:
            idx = self["mov_list"].getSelectedIndex()
        except Exception:
            idx = 0
        if 0 <= idx < len(streams):
            return streams[idx]
        return None

    # ------------------------------------------------------------------
    # Key handlers
    # ------------------------------------------------------------------

    def _keyOk(self):
        if self._loading:
            return
        if self._focus_left:
            # Switch focus to the movie panel
            self._focus_left = False
            self._updateTitles()
            return
        s = self._getSelectedStream()
        if not s:
            return
        sid  = s.get('stream_id', 0)
        name = (s.get('name') or '').strip()
        ext  = (s.get('container_extension') or 'mp4').strip() or 'mp4'
        self.session.open(IPTVVodInfoScreen, int(sid), name, ext, self._prov)

    def _keyInfo(self):
        if self._loading or self._focus_left:
            return
        s = self._getSelectedStream()
        if not s:
            return
        sid  = s.get('stream_id', 0)
        name = (s.get('name') or '').strip()
        ext  = (s.get('container_extension') or 'mp4').strip() or 'mp4'
        self.session.open(IPTVVodInfoScreen, int(sid), name, ext, self._prov)


def _fetchXtreamApiJson(url, timeout=20):
    """HTTP GET url and return parsed JSON data, or None on error."""
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with _ur.urlopen(req, timeout=timeout) as _r:
            raw = _r.read()
        import json as _json
        return _json.loads(raw.decode('utf-8', errors='replace'))
    except Exception as e:
        iptvLogWrite('[Playlist][Xtream] API fetch error (%s): %s' % (url.split('?')[0], str(e)))
        return None


def _buildXtreamBouquets(prov, _reactor=None, _progress_cb=None):
    """Level 3 full Xtream Codes API build: Live / VOD / Series via player_api.php.

    Supports Xtream-specific strategies (same_as_provider / group_into_folder).
    Automatically generates EPG import files when epg_parse_type != 'off'.
    Downloads picons when xtream_picon != 'off'; reports progress via _progress_cb.

    Returns (total_bouquets_created, error_string_or_None).
    """
    import re as _re
    _migrateSafeName(prov)

    prov_name       = (prov.get('name') or 'Provider').strip()
    safe_name       = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-') or 'Provider'
    server          = (prov.get('xtream_url') or '').strip().rstrip('/')
    xtype           = (prov.get('xtream_type') or 'user_pass').strip()
    playback        = prov.get('playback_with', 'gstplayer')
    order           = prov.get('channel_order', 'provider')
    xtream_strategy = (prov.get('xtream_strategy') or 'same_as_provider').strip()
    xtream_picon    = (prov.get('xtream_picon') or 'off').strip()
    show_live       = bool(prov.get('xtream_show_live',   True))
    show_vod        = bool(prov.get('xtream_show_vod',    True))
    show_series     = bool(prov.get('xtream_show_series', True))
    epg_mode        = (prov.get('epg_parse_type') or 'off').strip()
    custom_xmltv    = (prov.get('xmltv_url') or '').strip()
    _excl_ids           = set(str(x) for x in (prov.get('excluded_stream_ids') or []))
    _xt_markers_enabled = bool(prov.get('create_archive_markers', False))

    # Resolve output format (ts / m3u8).
    # Legacy values 'gstplayer' / 'exteplayer3' in xtream_output are mapped to ts.
    xt_output_raw = (prov.get('xtream_output') or 'm3u8').strip()
    if xt_output_raw in ('gstplayer', 'exteplayer3'):
        output = 'ts'
    elif xt_output_raw == 'ts':
        output = 'ts'
    else:
        output = 'm3u8'

    # Per-content-type stream types (new settings: xtream_live_type / xtream_vod_type /
    # xtream_series_type).  Legacy fallback: old 'exteplayer3' in xtream_output or
    # playback_with maps to 5001 when the new per-type setting is absent.
    _legacy_5001 = (xt_output_raw == 'exteplayer3' or playback == 'exteplayer3')
    _valid_types = ('4097', '5001', '5002')
    live_stream_type   = (prov.get('xtream_live_type')   or '').strip()
    vod_stream_type    = (prov.get('xtream_vod_type')    or '').strip()
    series_stream_type = (prov.get('xtream_series_type') or '').strip()
    if live_stream_type not in _valid_types:
        live_stream_type   = '5001' if _legacy_5001 else '4097'
    if vod_stream_type not in _valid_types:
        vod_stream_type    = '5001' if _legacy_5001 else '4097'
    if series_stream_type not in _valid_types:
        series_stream_type = '5001' if _legacy_5001 else '4097'
    # Backward-compat alias used by picon download (live only)
    stream_type = live_stream_type

    enigma2_dir = '/etc/enigma2'

    # Purge any legacy EC-format lamedb entries left by older plugin builds.
    # Must clean BOTH lamedb5 and lamedb4 explicitly — _updateLamedb uses
    # if/else and only touches one file, so the other stays dirty and
    # DreamboxEdit keeps showing the phantom sref from whichever file it reads.
    import zlib as _zlib
    _old_tsid_hex = '%X' % (_zlib.crc32(safe_name.encode('utf-8', 'replace')) & 0xFFFF)
    for _lm_path, _lm_ver in [
            (os.path.join(enigma2_dir, 'lamedb5'), 5),
            (os.path.join(enigma2_dir, 'lamedb'),  4)]:
        if os.path.exists(_lm_path):
            try:
                _updateLamedbN(_lm_path, _lm_ver, prov_name, [], {},
                               _old_tsid_hex, None)
            except Exception:
                pass

    if xtype == 'user_pass':
        user = (prov.get('xtream_username') or '').strip()
        pw   = (prov.get('xtream_password') or '').strip()
        if not user or not server:
            return 0, T("Xtream credentials incomplete (URL or username missing).")
        player_api = '%s/player_api.php?username=%s&password=%s' % (server, user, pw)
        xmltv_api  = '%s/xmltv.php?username=%s&password=%s' % (server, user, pw)
    else:
        token = (prov.get('xtream_token') or '').strip()
        if not token or not server:
            return 0, T("Xtream credentials incomplete (URL or token missing).")
        player_api = '%s/player_api.php?token=%s' % (server, token)
        xmltv_api  = '%s/xmltv.php?token=%s' % (server, token)
        user = token
        pw   = ''

    # Use custom XMLTV URL if provided, otherwise fall back to the Xtream XMLTV endpoint
    effective_xmltv = custom_xmltv or xmltv_api

    # Compute unique_ref by summing the ordinals of every character in the
    # full get.php M3U URL — identical to the BMX formula (BMX hashes
    # playlist_info["full_url"] which is always the get.php URL, not the
    # player_api URL) so service references, EPG mappings and picon filenames
    # all match BMX output for the same provider.
    if xtype == 'user_pass':
        _full_url_for_ref = '%s/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % (
            server, user, pw, output)
    else:
        _full_url_for_ref = '%s/get.php?token=%s&type=m3u_plus&output=%s' % (
            server, token, output)
    unique_ref = sum(ord(c) for c in str(_full_url_for_ref))

    try:
        from urllib.parse import quote as _quote
    except ImportError:
        from urllib import quote as _quote
    host_encoded = _quote(server, safe='/')

    # ── Authentication check ────────────────────────────────────────────────
    auth_data = _fetchXtreamApiJson(player_api, timeout=12)
    if auth_data is None:
        return 0, T("Xtream server did not respond. Check URL and credentials.")
    user_info = auth_data.get('user_info') if isinstance(auth_data, dict) else None
    if user_info and user_info.get('auth', 1) == 0:
        return 0, T("Xtream authentication failed — wrong username or password.")

    bouquet_refs     = []
    total_bouquets   = 0
    epg_channels     = []   # live channels for EPGImport auto-generation
    all_sub_refs     = []   # collected sub-bouquet refs for group_into_folder
    _xt_stats_holder = {}   # shared dict for user_defined merge stats

    def _safe_cat(name):
        s = _re.sub(r'[^\w]', '_', (name or 'Unknown').strip()).strip('_')
        return s[:48] or 'Unknown'

    def _clean_name(name):
        return (name or '').replace(':', '').replace('"', '').replace(
            '\u2022', '-').strip('- ').strip()

    def _make_sid(stream_id_int):
        # BMX-compatible service reference format:
        #   sid  = stream_id // 65535
        #   tsid = stream_id %  65535
        #   namespace = unique_ref (sum of all player_api URL characters)
        try:
            _id1 = int(stream_id_int) // 65535
            _id2 = int(stream_id_int) - _id1 * 65535
        except Exception:
            _id1, _id2 = 0, 0
        return ':0:1:%x:%x:%x:0:0:0:0:' % (_id1, _id2, unique_ref)

    def _write_file(fname, bouquet_name, svc_lines, force_standard=False):
        path = os.path.join(enigma2_dir, fname)
        try:
            import io as _io

            # ── User Defined: merge preserving existing order ─────────────
            # force_standard=True for parent/reference bouquets that contain
            # subbouquet refs, not stream URLs — merge logic can't handle them.
            if order == 'user_defined' and os.path.isfile(path) and not force_standard:
                import re as _re_sid

                # ── Diagnostic: why did we enter merge vs standard write? ──
                _reason_standard = None
                if order != 'user_defined':
                    _reason_standard = 'order=%s' % order
                elif not os.path.isfile(path):
                    _reason_standard = 'file_not_found'
                elif force_standard:
                    _reason_standard = 'force_standard=True'
                if _reason_standard:
                    iptvLogWrite('[UD] %s → STANDARD WRITE (reason: %s)' % (fname, _reason_standard))
                else:
                    iptvLogWrite('[UD] %s → MERGE' % fname)

                def _extract_sid(line):
                    """Extract stream_id string from a service line.
                    Tries two methods:
                    1. URL pattern: /live|movie|series/user/pass/STREAM_ID.ext
                       Works when Enigma2 preserves the full URL in the service ref.
                    2. Numeric fields: #SERVICE type:0:1:SID:TSID:NS:...
                       Works when Enigma2 rewrites the ref after remote-control sorting,
                       stripping the URL. Recovers stream_id = SID*65535 + TSID,
                       verified against unique_ref namespace.
                    Returns stream_id as string, or None if not found."""
                    # Method 1: URL
                    m = _re_sid.search(
                        r'/(?:live|movie|series)/[^/]+/[^/]+/(\d+)\.', line)
                    if m:
                        return m.group(1)  # method=url
                    # Method 2: numeric service reference fields
                    # Format: #SERVICE stype:0:1:SID_HEX:TSID_HEX:NS_HEX:0:0:0:0:
                    if line.startswith('#SERVICE'):
                        parts = line.split(':')
                        if len(parts) >= 7:
                            try:
                                _ns = int(parts[6], 16)
                                if _ns == unique_ref:
                                    _s  = int(parts[3], 16)
                                    _t  = int(parts[4], 16)
                                    _sid_int = _s * 65535 + _t
                                    if _sid_int > 0:
                                        return str(_sid_int)  # method=numeric
                                else:
                                    return '__foreign_ns_%x__' % _ns  # wrong namespace
                            except Exception:
                                pass
                    return None  # unrecognised

                # Build stream_id → fresh svc_line map from API data
                new_by_sid  = {}
                new_desc_sid = {}
                _last_svc_sid = None
                for ln in svc_lines:
                    sid_key = _extract_sid(ln)
                    if sid_key:
                        new_by_sid[sid_key] = ln
                        _last_svc_sid = sid_key
                    elif ln.startswith('#DESCRIPTION ') and _last_svc_sid:
                        new_desc_sid[_last_svc_sid] = ln

                iptvLogWrite('[UD] %s: new_by_sid has %d entries (from API)' % (fname, len(new_by_sid)))
                # Read existing bouquet — preserve order AND custom #NAME
                merged        = []
                seen_sid      = set()
                custom_name   = None
                _cnt_kept     = 0
                _cnt_drop     = 0
                _last_was_kept = False
                _cnt_unrec  = 0
                _cnt_foreign = 0
                with _io.open(path, 'r', encoding='utf-8', errors='replace') as _rf:
                    for raw in _rf:
                        raw = raw.rstrip('\r\n')
                        if raw.startswith('#NAME'):
                            custom_name = raw[len('#NAME'):].strip()
                            continue
                        sid = _extract_sid(raw)
                        if sid is not None:
                            if sid.startswith('__foreign_ns_'):
                                # Service line from different provider — skip
                                _cnt_foreign += 1
                                _last_was_kept = False
                            elif sid in new_by_sid:
                                # Still in API — keep position, use fresh line
                                merged.append(new_by_sid[sid])
                                if sid in new_desc_sid:
                                    merged.append(new_desc_sid[sid])
                                seen_sid.add(sid)
                                _cnt_kept += 1
                                _last_was_kept = True
                            else:
                                # sid extracted but not in API anymore — dropped
                                _cnt_drop += 1
                                _last_was_kept = False
                                iptvLogWrite('[UD] %s: dropped sid=%s (not in API)' % (fname, sid))
                                if '_xt_dropped_sids' not in _xt_stats_holder:
                                    _xt_stats_holder['_xt_dropped_sids'] = set()
                                _xt_stats_holder['_xt_dropped_sids'].add(sid)
                        elif raw and not raw.startswith('#SERVICE'):
                            if raw.startswith('#DESCRIPTION ') and _last_was_kept:
                                # Fresh #DESCRIPTION already appended with ▶ if needed
                                _last_was_kept = False
                            else:
                                merged.append(raw + '\n')
                        elif raw.startswith('#SERVICE'):
                            # #SERVICE line but sid extraction failed entirely
                            _cnt_unrec += 1
                            iptvLogWrite('[UD] %s: UNRECOGNISED line (no sid): %s' % (fname, raw[:80]))
                        # else: empty line — skip
                iptvLogWrite('[UD] %s: kept=%d dropped=%d unrecognised=%d foreign=%d' % (
                    fname, _cnt_kept, _cnt_drop, _cnt_unrec, _cnt_foreign))

                # FIX 1: insert new channels respecting update_mode_sub (top/bottom)
                new_lines = []
                for ln in svc_lines:
                    sid = _extract_sid(ln)
                    if sid and sid not in seen_sid:
                        new_lines.append(ln)

                if new_lines:
                    _upd = prov.get('update_playlist_mode', 'bottom')
                    if _upd == 'top':
                        merged = new_lines + merged
                    else:
                        merged = merged + new_lines

                # Write back — use custom name if the user renamed the bouquet
                _bname = custom_name if custom_name else bouquet_name
                with _io.open(path, 'w', encoding='utf-8') as _wf:
                    _wf.write('#NAME %s\n' % _bname)
                    for ln in merged:
                        _wf.write(ln if ln.endswith('\n') else ln + '\n')
                iptvLogWrite('[Playlist][Xtream] Merged (user_defined): %s (%d entries, %d new)'
                             % (fname, len(merged), len(new_lines)))
                # Store new_lines on result for caller to collect stats
                _xt_stats_holder['_last_new_lines'] = new_lines
                return True

            # ── Standard write (provider / alphabetical order) ────────────
            if order == 'user_defined' and not os.path.isfile(path):
                iptvLogWrite('[UD] %s → STANDARD WRITE (reason: new_file, no existing to merge)' % fname)
            elif order == 'user_defined' and force_standard:
                iptvLogWrite('[UD] %s → STANDARD WRITE (reason: force_standard=True)' % fname)
            with _io.open(path, 'w', encoding='utf-8') as _wf:
                _wf.write('#NAME %s\n' % bouquet_name)
                for ln in svc_lines:
                    _wf.write(ln)
            iptvLogWrite('[Playlist][Xtream] Written: %s (%d entries)' % (fname, len(svc_lines)))
            # For new bouquets, all channels are 'new'
            _xt_stats_holder['_last_new_lines'] = svc_lines
            _xt_stats_holder['_last_is_new_bouquet'] = True
            return True
        except Exception as e:
            iptvLogWrite('[Playlist][Xtream] Write error %s: %s' % (fname, str(e)))
            return False

    def _add_ref(fname):
        ref = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % fname
        bouquet_refs.append((fname, ref))

    # ── Strategy dispatcher ───────────────────────────────────────────────────
    def _apply_strategy(type_prefix, cats, cat_map, all_lines, type_label):
        """Write bouquets for one content type according to xtream_strategy.

        type_prefix : 'live' | 'vod' | 'series'
        cats        : list of {category_id, category_name} dicts
        cat_map     : {category_id: [svc_line, ...]}
        all_lines   : flat list of all svc_lines for this type (in order)
        type_label  : display label e.g. 'Live' / 'VOD' / 'Series'

        'same_as_provider'  — one userbouquet per category, all flat in list.
        'group_into_folder' — one subbouquet per category, all refs collected
                              in all_sub_refs; single parent written after all
                              content types are processed.
        """
        nonlocal total_bouquets

        if xtream_strategy == 'group_into_folder':
            # ── Sub-bouquets only; parent written after all types ────────────
            for cat in cats:
                cat_id   = str(cat.get('category_id') or '')
                cat_name = (cat.get('category_name') or cat_id or type_label).strip()
                lines    = cat_map.get(cat_id, [])
                if not lines:
                    # Category is empty (all streams excluded) — delete old file if exists
                    if type_prefix == 'live':
                        _del_sfname = 'subbouquet.%s_%s_%s.tv' % (safe_name, type_prefix, _safe_cat(cat_name))
                        _del_path   = os.path.join(enigma2_dir, _del_sfname)
                        if os.path.isfile(_del_path):
                            try:
                                # Count existing channels before deleting
                                _removed_count = 0
                                try:
                                    import io as _io_del
                                    with _io_del.open(_del_path, 'r', encoding='utf-8', errors='replace') as _df:
                                        _removed_count = sum(1 for _l in _df if _l.startswith('#SERVICE') and '1:7:1:' not in _l)
                                except Exception:
                                    pass
                                os.remove(_del_path)
                                iptvLogWrite('[Playlist][Xtream] Deleted empty sub-bouquet: %s (%d channels)' % (_del_sfname, _removed_count))
                                if '_xt_merge_stats' not in _xt_stats_holder:
                                    _xt_stats_holder['_xt_merge_stats'] = []
                                _xt_stats_holder['_xt_merge_stats'].append({
                                    'bouquet':        cat_name,
                                    'added':          0,
                                    'removed':        _removed_count,
                                    'added_names':    [],
                                    'removed_names':  [],
                                    'is_new_bouquet': False,
                                    'bouquet_deleted': True,
                                })
                            except Exception as _de:
                                iptvLogWrite('[Playlist][Xtream] Delete error %s: %s' % (_del_sfname, str(_de)))
                    continue
                sfname = 'subbouquet.%s_%s_%s.tv' % (safe_name, type_prefix, _safe_cat(cat_name))
                bname  = cat_name if type_prefix == 'live' else ('%s - %s' % (type_label, cat_name))
                _xt_stats_holder.pop('_last_new_lines', None)
                _xt_stats_holder.pop('_last_is_new_bouquet', None)
                if _write_file(sfname, bname, lines):
                    all_sub_refs.append(
                        '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % sfname)
                    # Collect stats for live bouquets only
                    if type_prefix == 'live':
                        _nl = _xt_stats_holder.get('_last_new_lines', [])
                        _is_new = _xt_stats_holder.get('_last_is_new_bouquet', False)
                        if _nl or _is_new:
                            if '_xt_merge_stats' not in _xt_stats_holder:
                                _xt_stats_holder['_xt_merge_stats'] = []
                            _added_names = []
                            for _al in _nl:
                                try:
                                    _nm = _al.rstrip('\n').rsplit(':', 1)[-1].strip()
                                    if _nm: _added_names.append(_nm)
                                except Exception: pass
                            _xt_stats_holder['_xt_merge_stats'].append({
                                'bouquet':       cat_name,
                                'added':         len(_nl),
                                'removed':       0,
                                'added_names':   _added_names,
                                'removed_names': [],
                                'is_new_bouquet': _is_new,
                            })
            unc = cat_map.get('', []) + cat_map.get('0', [])
            if unc:
                sfname = 'subbouquet.%s_%s_Uncategorized.tv' % (safe_name, type_prefix)
                bname  = T("Uncategorized") if type_prefix == 'live' else (
                    '%s - %s' % (type_label, T("Uncategorized")))
                if _write_file(sfname, bname, unc):
                    all_sub_refs.append(
                        '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % sfname)

        else:
            # ── 'same_as_provider' — one userbouquet per category (default) ──
            for cat in cats:
                cat_id   = str(cat.get('category_id') or '')
                cat_name = (cat.get('category_name') or cat_id or type_label).strip()
                lines    = cat_map.get(cat_id, [])
                if not lines:
                    # Category is empty (all streams excluded) — delete old file if exists
                    if type_prefix == 'live':
                        _del_fname = 'userbouquet.%s_%s_%s.tv' % (safe_name, type_prefix, _safe_cat(cat_name))
                        _del_path  = os.path.join(enigma2_dir, _del_fname)
                        if os.path.isfile(_del_path):
                            try:
                                # Count existing channels before deleting
                                _removed_count = 0
                                try:
                                    import io as _io_del
                                    with _io_del.open(_del_path, 'r', encoding='utf-8', errors='replace') as _df:
                                        _removed_count = sum(1 for _l in _df if _l.startswith('#SERVICE') and '1:7:1:' not in _l)
                                except Exception:
                                    pass
                                os.remove(_del_path)
                                iptvLogWrite('[Playlist][Xtream] Deleted empty userbouquet: %s (%d channels)' % (_del_fname, _removed_count))
                                if '_xt_merge_stats' not in _xt_stats_holder:
                                    _xt_stats_holder['_xt_merge_stats'] = []
                                _xt_stats_holder['_xt_merge_stats'].append({
                                    'bouquet':        cat_name,
                                    'added':          0,
                                    'removed':        _removed_count,
                                    'added_names':    [],
                                    'removed_names':  [],
                                    'is_new_bouquet': False,
                                    'bouquet_deleted': True,
                                })
                            except Exception as _de:
                                iptvLogWrite('[Playlist][Xtream] Delete error %s: %s' % (_del_fname, str(_de)))
                    continue
                fname = 'userbouquet.%s_%s_%s.tv' % (safe_name, type_prefix, _safe_cat(cat_name))
                bname = cat_name if type_prefix == 'live' else ('%s - %s' % (type_label, cat_name))
                _xt_stats_holder.pop('_last_new_lines', None)
                _xt_stats_holder.pop('_last_is_new_bouquet', None)
                if _write_file(fname, bname, lines):
                    _add_ref(fname)
                    total_bouquets += 1
                    if type_prefix == 'live':
                        _nl = _xt_stats_holder.get('_last_new_lines', [])
                        _is_new = _xt_stats_holder.get('_last_is_new_bouquet', False)
                        if _nl or _is_new:
                            if '_xt_merge_stats' not in _xt_stats_holder:
                                _xt_stats_holder['_xt_merge_stats'] = []
                            _added_names = []
                            for _al in _nl:
                                try:
                                    _nm = _al.rstrip('\n').rsplit(':', 1)[-1].strip()
                                    if _nm: _added_names.append(_nm)
                                except Exception: pass
                            _xt_stats_holder['_xt_merge_stats'].append({
                                'bouquet':       cat_name,
                                'added':         len(_nl),
                                'removed':       0,
                                'added_names':   _added_names,
                                'removed_names': [],
                                'is_new_bouquet': _is_new,
                            })
            unc = cat_map.get('', []) + cat_map.get('0', [])
            if unc:
                fname = 'userbouquet.%s_%s_Uncategorized.tv' % (safe_name, type_prefix)
                bname = T("Uncategorized") if type_prefix == 'live' else (
                    '%s - %s' % (type_label, T("Uncategorized")))
                if _write_file(fname, bname, unc):
                    _add_ref(fname)
                    total_bouquets += 1

    # ── LIVE TV ─────────────────────────────────────────────────────────────
    if show_live:
        live_cats    = _fetchXtreamApiJson(player_api + '&action=get_live_categories') or []
        live_streams = _fetchXtreamApiJson(player_api + '&action=get_live_streams') or []

        if not isinstance(live_cats, list):    live_cats    = []
        if not isinstance(live_streams, list): live_streams = []

        if order == 'alphabetical':
            live_streams.sort(key=lambda x: (x.get('name') or '').lower())

        live_cat_map = {}
        live_all     = []
        for ch in live_streams:
            try:
                sid = int(ch.get('stream_id', 0))
            except Exception:
                continue
            cat_id = str(ch.get('category_id') or '')
            name      = _clean_name(ch.get('name') or '')
            _xt_arc   = _xt_markers_enabled and bool(ch.get('tv_archive', 0))
            if not name or not sid:
                continue
            if _excl_ids and str(sid) in _excl_ids:
                continue
            # Honour custom_sid from the Xtream API when present.
            # Validate exactly as BMX does: reject null/"None"/"0"/all-zeros
            # and entries too short to contain real sref fields (len <= 16).
            # Providers vary: some send "4097:0:1:..." (stream type included),
            # others send ":0:1:..." (colon-first, no type prefix).
            # Detect the format explicitly so both cases produce a valid sref.
            _api_csid = (ch.get('custom_sid') or '').strip()
            _csid_valid = (_api_csid
                           and str(_api_csid) not in ('null', 'None', '0', ':0:0:0:0:0:0:0:0:0:')
                           and len(_api_csid) > 16)
            if _csid_valid:
                if _api_csid[0].isdigit():
                    # Stream type already included — use verbatim as prefix.
                    _svc_prefix = _api_csid.rstrip(':') + ':'
                    # For EPG sref, strip the leading stream-type field → ':0:1:…'.
                    _colon_idx = _api_csid.find(':')
                    _sid_tail  = _api_csid[_colon_idx:].rstrip(':') + ':' if _colon_idx >= 0 else _make_sid(sid)
                else:
                    # Colon-first format — prepend stream_type.
                    _svc_prefix = stream_type + _api_csid.rstrip(':') + ':'
                    _sid_tail   = _api_csid.rstrip(':') + ':'
            else:
                _sid_tail   = _make_sid(sid)
                _svc_prefix = stream_type + _sid_tail
            # BMX-compatible service line: name is appended INLINE with ':'
            # after the URL (not on a separate #DESCRIPTION line).  This is
            # the format Enigma2 expects for named IPTV services and matches
            # what bouquet parsers on all E2 distributions handle correctly.
            svc_line   = '#SERVICE %s%s/live/%s/%s/%d.%s:%s\n' % (
                _svc_prefix, host_encoded, user, pw, sid, output, name)
            if _xt_arc:
                desc_line = '#DESCRIPTION ▶ %s\n' % name
                live_cat_map.setdefault(cat_id, []).extend([svc_line, desc_line])
                live_all.extend([svc_line, desc_line])
            else:
                live_cat_map.setdefault(cat_id, []).append(svc_line)
                live_all.append(svc_line)
            # Collect EPG channel entry for EPGImport file generation
            epg_ch_id = (ch.get('epg_channel_id') or '').strip()
            if epg_ch_id:
                epg_channels.append({
                    'name':   name,
                    'url':    '%s/live/%s/%s/%d.%s' % (server, user, pw, sid, output),
                    'tvg_id': epg_ch_id,
                    'logo':   (ch.get('stream_icon') or '').strip(),
                    # BMX fix 2+3: EPG channels XML uses type "1" and the
                    # http%3a//example.m3u8 placeholder — no real credentials
                    # are written to disk, and the colon encoding is lowercase
                    # (%3a) to match BMX output exactly.
                    'sref':   '1%s%s' % (_sid_tail, 'http%3a//example.m3u8'),
                })

        live_before = total_bouquets
        _apply_strategy('live', live_cats, live_cat_map, live_all, 'Live')
        iptvLogWrite('[Playlist][Xtream] Live: %d bouquets, %d streams' % (
            total_bouquets - live_before, len(live_streams)))

    # ── VOD ─────────────────────────────────────────────────────────────────
    if show_vod:
        vod_cats    = _fetchXtreamApiJson(player_api + '&action=get_vod_categories') or []
        vod_streams = _fetchXtreamApiJson(player_api + '&action=get_vod_streams') or []

        if not isinstance(vod_cats, list):    vod_cats    = []
        if not isinstance(vod_streams, list): vod_streams = []

        if order == 'alphabetical':
            vod_streams.sort(key=lambda x: (x.get('name') or '').lower())

        vod_cat_map = {}
        vod_all     = []
        for ch in vod_streams:
            try:
                sid = int(ch.get('stream_id', 0))
            except Exception:
                continue
            cat_id = str(ch.get('category_id') or '')
            name   = _clean_name(ch.get('name') or '')
            ext    = (ch.get('container_extension') or 'mp4').strip() or 'mp4'
            if not name or not sid:
                continue
            if _excl_ids and str(sid) in _excl_ids:
                continue
            # Honour custom_sid from the Xtream API when present.
            # Detect format: digit-first = stream type included; colon-first = prepend type.
            _api_csid_vod = (ch.get('custom_sid') or '').strip()
            _csid_vod_valid = (_api_csid_vod
                               and str(_api_csid_vod) not in ('null', 'None', '0', ':0:0:0:0:0:0:0:0:0:')
                               and len(_api_csid_vod) > 16)
            if _csid_vod_valid:
                if _api_csid_vod[0].isdigit():
                    _vod_svc_prefix = _api_csid_vod.rstrip(':') + ':'
                else:
                    _vod_svc_prefix = vod_stream_type + _api_csid_vod.rstrip(':') + ':'
            else:
                _vod_svc_prefix = vod_stream_type + _make_sid(sid)
            # BMX-compatible: name inline after URL with ':' separator
            svc_line   = '#SERVICE %s%s/movie/%s/%s/%d.%s:%s\n' % (
                _vod_svc_prefix, host_encoded, user, pw, sid, ext, name)
            vod_cat_map.setdefault(cat_id, []).append(svc_line)
            vod_all.append(svc_line)

        vod_before = total_bouquets
        _apply_strategy('vod', vod_cats, vod_cat_map, vod_all, 'VOD')
        iptvLogWrite('[Playlist][Xtream] VOD: %d bouquets, %d streams' % (
            total_bouquets - vod_before, len(vod_streams)))

    # ── SERIES ───────────────────────────────────────────────────────────────
    if show_series:
        try:
            # Compiled patterns for S##E## / Episode ## fallback detection
            _SER_PAT = _re.compile(r'\bS\d{1,4}\b',        _re.IGNORECASE)
            _EPI_PAT = _re.compile(r'\bE\d{1,4}\b',         _re.IGNORECASE)
            _EPI_WRD = _re.compile(r'\bEpisode\s\d+\b',     _re.IGNORECASE)

            def _is_series_stream(name, lower_url):
                """Accept if /series/ in URL, OR name has both season+episode markers."""
                if '/series/' in lower_url:
                    return True
                return bool(_SER_PAT.search(name) and
                            (_EPI_PAT.search(name) or _EPI_WRD.search(name)))

            def _simplify_series_name(s):
                """Remove duplicated words/segments that some providers repeat in names."""
                if not s:
                    return s
                try:
                    s = s.replace(':', '').replace('"', '').strip('- ')
                    s = ' '.join(s.split())
                    parts = s.split(' - ')
                    if len(parts) > 1 and parts[0] in parts[1]:
                        return ' - '.join([parts[0]] + parts[2:])
                    if len(parts) > 2 and parts[0] in parts[2]:
                        return ' - '.join([parts[0], parts[1]] + parts[3:])
                    words, seen = [], set()
                    for w in s.split():
                        if w not in seen:
                            seen.add(w)
                            words.append(w)
                    return ' '.join(words)
                except Exception:
                    return s

            ser_cats = _fetchXtreamApiJson(player_api + '&action=get_series_categories') or []
            if not isinstance(ser_cats, list):
                ser_cats = []

            if xtype == 'user_pass':
                m3u_url = '%s/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % (
                    server, user, pw, output)
            else:
                m3u_url = '%s/get.php?token=%s&type=m3u_plus&output=%s' % (server, user, output)

            # ── Streaming line-by-line parser (memory-safe, no full-load) ──
            ser_cat_map = {}
            used_cats   = set()
            _ser_resp   = None

            try:
                import urllib.request as _ur_ser
                _ser_req  = _ur_ser.Request(_normalizeHttpUrl(m3u_url), headers=HEADERS)
                _ser_resp = _ur_ser.urlopen(_ser_req, timeout=30)
            except Exception as _dl_err:
                iptvLogWrite('[Playlist][Xtream] Series M3U error: %s' % str(_dl_err))

            if _ser_resp is not None:
                try:
                    _cur_name  = None
                    _cur_group = None

                    for _raw_line in _ser_resp:
                        try:
                            _ln = _raw_line.decode('utf-8', errors='replace').strip()
                        except Exception:
                            continue
                        if not _ln:
                            continue

                        # ── URL line ──────────────────────────────────────
                        if _ln.startswith(('http://', 'https://')):
                            _src   = _ln.split()[0]
                            _lower = _src.lower()
                            if '/live/' in _lower or '/movie' in _lower:
                                _cur_name = _cur_group = None
                                continue
                            if _cur_name and _cur_group and _is_series_stream(_cur_name, _lower):
                                try:
                                    # BMX uses abs(hash(source)) with NO bitmask.
                                    # The & 0xFFFFFF mask produced different id1/id2
                                    # values and therefore mismatched service refs.
                                    _sid_h = abs(hash(_src))
                                    _b1    = _sid_h // 65535
                                    _b2    = _sid_h - _b1 * 65535
                                    _csid  = ':0:1:%x:%x:%x:0:0:0:0:' % (_b1, _b2, unique_ref)
                                    # BMX uses quote(source) with default safe='/'
                                    # which encodes ':' as %3A. Keeping colons raw
                                    # breaks Enigma2's colon-delimited svc_line
                                    # parsing when the URL contains a port number.
                                    _enc   = _quote(_src, safe='/')
                                    # BMX-compatible: name inline after URL
                                    _svc   = '#SERVICE %s%s%s:%s\n' % (
                                        series_stream_type, _csid, _enc,
                                        _simplify_series_name(_cur_name))
                                    ser_cat_map.setdefault(_cur_group, []).append(_svc)
                                    used_cats.add(_cur_group)
                                except Exception:
                                    pass
                            _cur_name = _cur_group = None
                            continue

                        # ── Non-EXTINF comment/junk ───────────────────────
                        if not _ln.startswith('#EXTINF'):
                            if not _ln.startswith('#'):
                                _cur_name = _cur_group = None
                            continue

                        # ── Parse #EXTINF ─────────────────────────────────
                        _nm  = ''
                        _grp = ''
                        _p   = _ln.find('tvg-name="')
                        if _p > -1:
                            _e = _ln.find('"', _p + 10)
                            if _e > -1:
                                _nm = _ln[_p + 10:_e].strip()
                        if not _nm:
                            _c = _ln.rfind(',')
                            if _c > -1:
                                _nm = _ln[_c + 1:].strip()
                        _p = _ln.find('group-title="')
                        if _p > -1:
                            _e = _ln.find('"', _p + 13)
                            if _e > -1:
                                _grp = _ln[_p + 13:_e].strip()

                        if _nm and _grp:
                            _cur_name  = _nm
                            _cur_group = _grp
                        else:
                            _cur_name = _cur_group = None

                finally:
                    try:
                        _ser_resp.close()
                    except Exception:
                        pass

            # Build pseudo-cats: API order first, orphan groups from M3U appended
            known_cats      = {(c.get('category_name') or '').strip() for c in ser_cats}
            ser_pseudo_cats = [
                {'category_id': (c.get('category_name') or '').strip(),
                 'category_name': (c.get('category_name') or '').strip()}
                for c in ser_cats
                if (c.get('category_name') or '').strip() in used_cats
            ]
            for grp in ser_cat_map:
                if grp not in known_cats and grp in used_cats:
                    ser_pseudo_cats.append({'category_id': grp, 'category_name': grp})

            ser_before = total_bouquets
            _apply_strategy('series', ser_pseudo_cats, ser_cat_map, [], 'Series')
            iptvLogWrite('[Playlist][Xtream] Series: %d bouquets, %d categories' % (
                total_bouquets - ser_before, len(used_cats)))

        except Exception as e:
            iptvLogWrite('[Playlist][Xtream] Series section error: %s' % str(e))

    # ── Group into folder: write one parent bouquet covering all types ───────
    if xtream_strategy == 'group_into_folder' and all_sub_refs:
        pfname = 'userbouquet.%s.tv' % safe_name
        ppath  = os.path.join(enigma2_dir, pfname)
        if order == 'user_defined' and os.path.isfile(ppath):
            # Preserve user's subbouquet order from the existing parent file.
            # Read existing refs, keep those still valid, append new ones.
            import io as _io_p, re as _re_p
            existing_refs = []
            try:
                with _io_p.open(ppath, 'r', encoding='utf-8', errors='replace') as _pf:
                    for _ln in _pf:
                        _ln = _ln.rstrip('\r\n')
                        if 'FROM BOUQUET' in _ln:
                            existing_refs.append(_ln)
            except Exception:
                existing_refs = []
            # new_refs_set: all refs from this build
            new_refs_set = set(all_sub_refs)
            # Keep existing in user order (only those still valid)
            merged_refs = [r for r in existing_refs if r in new_refs_set]
            seen_refs   = set(merged_refs)
            # Append brand-new categories
            new_cats = [r for r in all_sub_refs if r not in seen_refs]
            _upd = prov.get('update_playlist_mode', 'bottom')
            if _upd == 'top':
                merged_refs = new_cats + merged_refs
            else:
                merged_refs = merged_refs + new_cats
            final_refs = merged_refs
        else:
            final_refs = all_sub_refs
        # Preserve custom parent bouquet name set by user in DreamboxEdit
        _parent_name = prov_name
        if order == 'user_defined' and os.path.isfile(ppath):
            try:
                import io as _io_pn
                with _io_pn.open(ppath, 'r', encoding='utf-8', errors='replace') as _pnf:
                    for _pnl in _pnf:
                        if _pnl.startswith('#NAME'):
                            _custom = _pnl[5:].strip()
                            if _custom:
                                _parent_name = _custom
                            break
            except Exception:
                pass
        if _write_file(pfname, _parent_name, [r + '\n' for r in final_refs], force_standard=True):
            _add_ref(pfname)
            total_bouquets += 1

    # ── Update bouquets.tv and reload Enigma2 ────────────────────────────────
    _updateBouquetsTv(bouquet_refs)

    # Must run on the Enigma2 main thread — calling eDVBDB from a background
    # thread races with Enigma2's own service-list operations and can crash it.
    # _reactor is already available in this function's scope (passed by caller).
    def _do_reload_xtream():
        try:
            from enigma import eDVBDB
            eDVBDB.getInstance().reloadServicelist()
            eDVBDB.getInstance().reloadBouquets()
            iptvLogWrite('[Playlist][Xtream] Enigma2 service list and bouquets reloaded — %d total' % total_bouquets)
        except Exception as e:
            iptvLogWrite('[Playlist][Xtream] Bouquet reload error: %s' % str(e))
    if _reactor:
        _reactor.callFromThread(_do_reload_xtream)
    else:
        _do_reload_xtream()

    # ── Auto-generate EPG import file for EPGImporter ────────────────────────
    # Always generate EPG files — no epg_parse_type opt-in required.
    # All live channels with a non-empty epg_channel_id are written directly
    # without XMLTV pre-verification (mirrors BouquetMakerXtream behaviour).
    if epg_channels:
        try:
            _generateXtreamEpgFiles(safe_name, prov_name, epg_channels, effective_xmltv)
            iptvLogWrite('[Playlist][Xtream] EPG import file generated (%d live channels)' % len(epg_channels))
        except Exception as e:
            iptvLogWrite('[Playlist][Xtream] EPG generation error: %s' % str(e))

    # ── Custom EPG merge for Xtream — runs independently of epg_channels ────────
    try:
        import re as _re_cepg
        _safe_cepg = _re_cepg.sub(r'[^\w]', '_', prov_name).strip('_') or 'Provider'
        _json_cepg = os.path.join(getDataDir(), 'Custom EPG Sources',
                                  _safe_cepg + '_customepg.json')
        _ch_path   = '/etc/epgimport/CustomIPTV/%s.xml' % safe_name
        if prov.get('custom_epg_enabled', True):
            if os.path.isfile(_json_cepg):
                # Create empty channels XML if not already written by epg_channels block
                if not os.path.isfile(_ch_path):
                    try:
                        os.makedirs('/etc/epgimport/CustomIPTV')
                    except OSError:
                        pass
                    with open(_ch_path, 'w') as _cf:
                        _cf.write('<?xml version="1.0" encoding="utf-8"?>\n<channels>\n</channels>\n')
                _mergeCustomEpgIntoChannelsFile(safe_name, _ch_path, prov_name)
                if effective_xmltv:
                    _updateCombinedSourcesFile(safe_name, prov_name, _ch_path, effective_xmltv)
        else:
            _removeCustomEpgFromSources(safe_name)
    except Exception as e:
        iptvLogWrite('[Playlist][Xtream] Custom EPG merge error: %s' % str(e))

    # ── Download Xtream picons ────────────────────────────────────────────────
    _picon_result = None
    if xtream_picon != 'off' and show_live:
        try:
            _xt_picon_location    = (prov.get('xtream_picon_location') or '/usr/share/enigma2/picon').strip()
            _xt_picon_symlink     = bool(prov.get('xtream_picon_symlink', False))
            _xt_picon_with_folder = bool(prov.get('xtream_picon_with_folder', True))
            # migrate old keyword values
            if _xt_picon_location in ('enigma2_picon',):
                _xt_picon_location = '/usr/share/enigma2/picon'
            elif _xt_picon_location in ('plugin_dir', ''):
                _xt_picon_location = getDataDir()
            _picons_deleted = 0
            # Include user-excluded stream IDs alongside API-dropped ones
            # so picons for unchecked bouquet channels are also deleted.
            _dropped_sids = set(_xt_stats_holder.get('_xt_dropped_sids', set()))
            _dropped_sids.update(_excl_ids)
            if _dropped_sids:
                # Build sid → channel data map from full live_streams API list
                _sid_to_ch = {}
                for _ch in live_streams:
                    try:
                        _sid_to_ch[str(int(_ch.get('stream_id', 0)))] = _ch
                    except Exception:
                        pass
                # Delete picons using the same folder and filename formula
                # as _downloadXtreamPicons (Extream_picon subfolder, not Picons)
                import re as _re_pdel
                if _xt_picon_with_folder:
                    _xt_picon_folder = os.path.join(_xt_picon_location, '%s_Extream_picon' % safe_name)
                else:
                    _xt_picon_folder = _xt_picon_location
                for _dsid in _dropped_sids:
                    _ch = _sid_to_ch.get(_dsid)
                    if not _ch:
                        continue
                    try:
                        _ch_name = (_ch.get('name') or '').strip()
                        _ch_sid  = int(_ch.get('stream_id', 0))
                        # Build filename list matching _downloadXtreamPicons exactly
                        _del_fnames = []
                        if xtream_picon == 'display_name':
                            _sfn = _re_pdel.sub(r'[^\w\s\-]', '', _ch_name).strip()
                            _sfn = _re_pdel.sub(r'\s+', ' ', _sfn)
                            if _sfn:
                                _del_fnames.append(_sfn + '.png')
                        elif xtream_picon == 'tvg_id':
                            _tvg = (_ch.get('epg_channel_id') or '').strip()
                            if _tvg:
                                _stv = _re_pdel.sub(r'[^\w\-\.]', '_', _tvg).strip('_. ')
                                if _stv:
                                    _del_fnames.append(_stv + '.png')
                        else:
                            _id1 = _ch_sid // 65535
                            _id2 = _ch_sid - _id1 * 65535
                            _del_fnames.append('%s_0_1_%X_%X_%X_0_0_0_0.png' % (
                                str(stream_type), _id1, _id2, unique_ref))
                        for _dfn in _del_fnames:
                            _dfp = os.path.join(_xt_picon_folder, _dfn)
                            if os.path.isfile(_dfp):
                                try:
                                    os.remove(_dfp)
                                    _picons_deleted += 1
                                    iptvLogWrite('[Picon Delete] Xtream removed: %s' % _dfn)
                                except Exception as _pe:
                                    iptvLogWrite('[Picon Delete] Error: %s' % str(_pe))
                            if _xt_picon_symlink:
                                _lp = os.path.join('/usr/share/enigma2/picon', _dfn)
                                if os.path.lexists(_lp):
                                    try:
                                        os.remove(_lp)
                                    except Exception:
                                        pass
                    except Exception:
                        pass
            # Exclude excluded streams so their picons are not re-downloaded
            # after being deleted in the step above.
            _picon_streams = [_ch for _ch in live_streams
                              if str(int(_ch.get('stream_id', 0) or 0)) not in _excl_ids]
            _picon_result = _downloadXtreamPicons(safe_name, xtream_picon, _picon_streams,
                                  stream_type, server,
                                  unique_ref=unique_ref,
                                  picon_location=_xt_picon_location,
                                  picon_symlink=_xt_picon_symlink,
                                  picon_with_folder=_xt_picon_with_folder,
                                  _reactor=_reactor, _progress_cb=_progress_cb)
            if _picon_result:
                _picon_result['deleted'] = _picons_deleted
        except Exception as e:
            iptvLogWrite('[Playlist][Xtream] Picon download error: %s' % str(e))

    _xt_merge_stats = _xt_stats_holder.get('_xt_merge_stats', [])
    if _picon_result:
        for _s in _xt_merge_stats:
            if isinstance(_s, dict):
                _s['_picon_result'] = _picon_result
                break
        else:
            _xt_merge_stats.append({'_picon_result': _picon_result})
    return total_bouquets, None, _xt_merge_stats


def _makeXtreamPiconImage(raw_bytes):
    """Process raw image bytes into a 220x132 px RGBA PNG (XPicon standard).

    Mirrors the BMX makePicon logic:
      1. Decode image with PIL.
      2. Auto-crop PNG transparency border.
      3. Thumbnail-resize to fit within 220x132 (preserves aspect ratio, LANCZOS).
      4. Centre the result on a blank 220x132 transparent canvas.
      5. Return optimised PNG bytes.

    Returns processed PNG bytes, or the original raw_bytes when PIL is absent
    or the image cannot be decoded (graceful fallback — raw download still saved).
    """
    try:
        import io as _io
        try:
            from PIL import Image, ImageChops
        except ImportError:
            return raw_bytes

        PICON_W, PICON_H = 220, 132

        image_file = _io.BytesIO(raw_bytes)
        try:
            im = Image.open(image_file)
            im.load()
        except Exception:
            return raw_bytes

        im_fmt = im.format or ''
        try:
            im = im.convert('RGBA')
        except Exception:
            return raw_bytes

        # Auto-crop transparent border (PNG only — matches BMX behaviour)
        if im_fmt == 'PNG':
            try:
                _r, _g, _b, _a = im.split()
                bbox = _a.getbbox()
                if bbox:
                    im = im.crop(bbox)
                    cw, ch = im.size
                    cropped = Image.new('RGBA', (cw, ch), (0, 0, 0, 0))
                    cropped.paste(im, (0, 0))
                    im = cropped
            except Exception:
                pass

        # Thumbnail-resize to fit inside 220x132 (aspect-ratio preserving)
        try:
            try:
                im.thumbnail((PICON_W, PICON_H), Image.Resampling.LANCZOS)
            except AttributeError:
                im.thumbnail((PICON_W, PICON_H), Image.ANTIALIAS)
        except Exception:
            return raw_bytes

        # Centre on blank 220x132 transparent canvas (matches BMX canvas merge)
        blank = Image.new('RGBA', (PICON_W, PICON_H), (255, 255, 255, 0))
        iw, ih = im.size
        bw, bh = blank.size
        try:
            im_alpha    = im.convert('RGBA').split()[-1]
            blank_alpha = blank.convert('RGBA').split()[-1]

            temp = Image.new('L', (bw, bh), 0)
            temp.paste(im_alpha, ((bw - iw) // 2, (bh - ih) // 2), im_alpha)

            blank_alpha = ImageChops.screen(blank_alpha, temp)
            blank.paste(im, ((bw - iw) // 2, (bh - ih) // 2), im)
            blank.putalpha(blank_alpha)
        except Exception:
            blank.paste(im, ((bw - iw) // 2, (bh - ih) // 2))

        out = _io.BytesIO()
        blank.save(out, format='PNG', optimize=True)
        return out.getvalue()

    except Exception:
        return raw_bytes


def _downloadXtreamPicons(safe_name, picon_mode, live_streams, stream_type, server,
                          unique_ref=0, picon_location='/usr/share/enigma2/picon',
                          picon_symlink=False, picon_with_folder=True,
                          _reactor=None, _progress_cb=None):
    """Download channel logos from Xtream API stream_icon URLs.

    Images are processed with PIL (when available) into 220x132 px XPicon-standard
    PNGs matching BMX behaviour: auto-crop transparent border, LANCZOS resize,
    centred on a transparent 220x132 canvas.  Falls back to raw download when
    PIL/Pillow is not installed on the receiver.

    HTTP Content-Type is validated — only image/png and image/jpeg are accepted.

    picon_mode : 'display_name' ("With Display Name" / "By Display Name")
                   — one file per channel named after the sanitised display name
                 'tvg_id'       ("By tvg-id")
                   — one file per channel named after epg_channel_id
                   — <epg_channel_id>.png
                   — for EPGImporter and skins that do tvg-id picon lookup
                 'reference'    ("With Reference Number" / "By Reference Number")
                   — one file per channel named after the Enigma2 service reference
                   — LOWERCASE hex (CRITICAL: Enigma2 derives the picon filename
                     directly from the sref string which uses lowercase %x hex;
                     any .upper() causes a case-mismatch on ext4/case-sensitive
                     internal flash and picons are never found)
                   — format: <stype>_0_1_<id1>_<id2>_<namespace>_0_0_0_0.png
                     where id1 = stream_id // 65535, id2 = stream_id % 65535,
                     namespace = unique_ref (sum of all player_api URL characters)
                   — matches the sref written by _make_sid into the bouquet
                   — for Enigma2 native skin picon lookup

    picon_location : 'enigma2_picon' — base is /usr/share/enigma2/picon/
                     'plugin_dir'    — base is getDataDir()
    picon_symlink  : when True, symlinks are created in /usr/share/enigma2/picon/
                     for every downloaded picon pointing to the subfolder file.

    Picons are always stored inside a subfolder named <safe_name>_Extream_picon
    under the chosen base location.

    Progress reported to _progress_cb(done, total) via _reactor.callFromThread
    every 25 channels.
    """
    if picon_mode == 'off' or not live_streams:
        return
    import re as _re
    import zlib as _zlib_pic
    _VALID_CTYPES = ('image/png', 'image/jpeg', 'image/jpg', 'image/webp')
    try:
        # Determine base location — picon_location is now an actual path.
        # Legacy keyword migration for any saved configs.
        if picon_location in ('enigma2_picon',):
            _base = '/usr/share/enigma2/picon'
        elif picon_location in ('plugin_dir', ''):
            _base = getDataDir()
        else:
            _base = picon_location
        if picon_with_folder:
            folder = os.path.join(_base, '%s_Extream_picon' % safe_name)
        else:
            folder = _base
        try:
            os.makedirs(folder)
        except OSError:
            pass
        try:
            from urllib2 import urlopen, Request
        except ImportError:
            from urllib.request import urlopen, Request
        total      = len([ch for ch in live_streams if (ch.get('stream_icon') or '').strip()])
        downloaded = 0
        failed     = 0
        skipped    = 0
        done       = 0
        for ch in live_streams:
            icon_url = (ch.get('stream_icon') or '').strip()
            if not icon_url:
                continue
            name = (ch.get('name') or '').strip()
            try:
                sid = int(ch.get('stream_id', 0))
            except Exception:
                sid = 0

            # Build the list of filenames to save this picon under.
            fnames = []
            if picon_mode == 'display_name':
                # "With Display Name" / "By Display Name"
                # One file named after the sanitised channel display name.
                safe_fn = _re.sub(r'[^\w\s\-]', '', name).strip()
                safe_fn = _re.sub(r'\s+', ' ', safe_fn)
                if safe_fn:
                    fnames.append(safe_fn + '.png')

            elif picon_mode == 'tvg_id':
                # "By tvg-id" — one file named after the EPG channel ID (tvg-id).
                # Used by EPGImporter and skins that do tvg-id picon lookup.
                # File  →  <epg_channel_id>.png
                tvg_id = (ch.get('epg_channel_id') or '').strip()
                if tvg_id:
                    safe_tvg = _re.sub(r'[^\w\-\.]', '_', tvg_id).strip('_. ')
                    if safe_tvg:
                        fnames.append(safe_tvg + '.png')

            else:
                # "With Reference Number" / "By Reference Number"
                # BMX-compatible formula — but MUST use lowercase hex so the
                # filename matches what Enigma2 generates from the sref string.
                #
                # Enigma2 derives the picon filename by taking the first 10
                # colon-separated fields of the sref (stripping the URL), then
                # replacing each ':' with '_':
                #   sref fields[0..9]: {type}:0:1:{id1}:{id2}:{uref}:0:0:0:0
                #   → {type}_0_1_{id1}_{id2}_{uref}_0_0_0_0.png
                #
                # The sref is built with '%x' (lowercase hex), so the picon
                # filename must also be lowercase.  Using .upper() (as BMX does
                # for VFAT USB storage) breaks picon lookup on ext4 / the
                # internal flash filesystem which is case-sensitive.
                #
                # If the Xtream API provides a custom_sid for this channel, parse
                # its fields to derive id1/id2/namespace and stream_type so the
                # picon filename matches the bouquet sref exactly.
                # Format A (digit-first): "4097:0:1:id1:id2:ns:0:0:0:0"  → fields[0..9]
                # Format B (colon-first): ":0:1:id1:id2:ns:0:0:0:0"       → fields[0]=''
                # Validate the same way BMX does before trusting the field.
                _api_csid_pic = (ch.get('custom_sid') or '').strip()
                _csid_pic_valid = (_api_csid_pic
                                   and str(_api_csid_pic) not in ('null', 'None', '0', ':0:0:0:0:0:0:0:0:0:')
                                   and len(_api_csid_pic) > 16)
                if _csid_pic_valid:
                    try:
                        _cp = _api_csid_pic.rstrip(':').split(':')
                        if _cp[0] and _cp[0][0].isdigit():
                            # Format A: field 0 = stream type, fields 3/4/5 = id1/id2/ns
                            _pstype = _cp[0]
                            _id1    = int(_cp[3], 16) if len(_cp) > 3 else 0
                            _id2    = int(_cp[4], 16) if len(_cp) > 4 else 0
                            _pns    = int(_cp[5], 16) if len(_cp) > 5 else unique_ref
                        else:
                            # Format B: field 0 is empty, use stream_type; id1/id2/ns at 2/3/4
                            _pstype = str(stream_type)
                            _id1    = int(_cp[2], 16) if len(_cp) > 2 else 0
                            _id2    = int(_cp[3], 16) if len(_cp) > 3 else 0
                            _pns    = int(_cp[4], 16) if len(_cp) > 4 else unique_ref
                    except Exception:
                        if not sid:
                            continue
                        _pstype = str(stream_type)
                        _id1    = int(sid) // 65535
                        _id2    = int(sid) - _id1 * 65535
                        _pns    = unique_ref
                else:
                    if not sid:
                        continue
                    try:
                        _id1 = int(sid) // 65535
                        _id2 = int(sid) - _id1 * 65535
                    except Exception:
                        continue
                    _pstype = str(stream_type)
                    _pns    = unique_ref
                # UPPERCASE hex — matches BMX (.upper()) and Enigma2 picon
                # filename derivation on case-sensitive ext4 / internal flash.
                sref_fn = '%s_0_1_%X_%X_%X_0_0_0_0.png' % (_pstype, _id1, _id2, _pns)
                fnames.append(sref_fn)

            if not fnames:
                continue

            # Skip download if all picon files for this channel already exist on disk.
            # Mirrors the User Defined smart-skip logic — new channels have no file
            # yet so they are downloaded; existing channels are left untouched.
            if all(os.path.isfile(os.path.join(folder, fn)) for fn in fnames):
                skipped += 1
                done += 1
                if _reactor and _progress_cb and (done % 25 == 0 or done == total):
                    _reactor.callFromThread(_progress_cb, done, total)
                continue

            try:
                req  = Request(icon_url, headers={'User-Agent': 'Mozilla/5.0'})
                resp = urlopen(req, timeout=8)

                # ── Content-Type validation (mirrors BMX) ─────────────────────
                ctype = ''
                try:
                    ctype = (resp.headers.get('content-type')
                             or resp.headers.get('Content-Type') or '').lower().split(';')[0].strip()
                except Exception:
                    pass
                if ctype and not any(ctype.startswith(ct) for ct in _VALID_CTYPES):
                    resp.close()
                    skipped += 1
                    done += 1
                    if _reactor and _progress_cb and (done % 25 == 0 or done == total):
                        _reactor.callFromThread(_progress_cb, done, total)
                    continue

                raw = resp.read()
                resp.close()

                if not raw:
                    failed += 1
                    done += 1
                    if _reactor and _progress_cb and (done % 25 == 0 or done == total):
                        _reactor.callFromThread(_progress_cb, done, total)
                    continue

                # ── PIL processing: resize to 220×132, crop, centre ───────────
                img_data = _makeXtreamPiconImage(raw)

                for fn in fnames:
                    with open(os.path.join(folder, fn), 'wb') as _f:
                        _f.write(img_data)
                downloaded += 1

            except Exception:
                failed += 1

            done += 1
            if _reactor and _progress_cb and (done % 25 == 0 or done == total):
                _reactor.callFromThread(_progress_cb, done, total)

        iptvLogWrite('[Playlist][Xtream] Picons: %d downloaded, %d failed, %d skipped (bad type) → %s'
                     % (downloaded, failed, skipped, folder))

        # ── Symlinks: /usr/share/enigma2/picon/ → subfolder files ────────────
        if picon_symlink:
            _symlink_dir = '/usr/share/enigma2/picon'
            try:
                os.makedirs(_symlink_dir)
            except OSError:
                pass
            _sym_ok = 0
            _sym_fail = 0
            for _fn in os.listdir(folder):
                if not _fn.endswith('.png'):
                    continue
                _src  = os.path.join(folder, _fn)
                _link = os.path.join(_symlink_dir, _fn)
                try:
                    if os.path.islink(_link) or os.path.exists(_link):
                        os.remove(_link)
                    os.symlink(_src, _link)
                    _sym_ok += 1
                except Exception:
                    _sym_fail += 1
            iptvLogWrite('[Playlist][Xtream] Picon symlinks: %d created, %d failed → %s'
                         % (_sym_ok, _sym_fail, _symlink_dir))
        return {'downloaded': downloaded, 'failed': failed, 'skipped': skipped}
    except Exception as e:
        iptvLogWrite('[Playlist][Xtream] Picon error: %s' % str(e))
    return {'downloaded': 0, 'failed': 0, 'skipped': 0}


class IPTVPlaylistProviderEditDialog(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,800" title="Playlist Provider" backgroundColor="#33000000">
            <widget name="config" position="10,10" size="1230,680"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" transparent="1" />
            <widget name="web_url" position="10,690" size="1230,30"
                    font="Regular;28" halign="center" foregroundColor="#f0c040" transparent="1" />
            <ePixmap position="72,753"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,753"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,753"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,753" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,732" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,799" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="427,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="739,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1051,748" size="194,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,800" title="Playlist Provider">
            <widget name="config" position="10,10" size="1230,680"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" />
            <widget name="web_url" position="10,690" size="1230,30"
                    font="Regular;28" halign="center" foregroundColor="#f0c040" transparent="1" />
            <ePixmap position="72,753"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,753"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,753"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,753" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,732" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,799" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="427,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="739,748"  size="264,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_blue"   position="1051,748" size="194,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
        </screen>"""
    skin    = _SKIN_T


    _STRATEGIES = [
        ('same_playlist',     "Same in Playlist"),
        ('all_channels',      "Bouquet for All Channels"),
        ('all_and_groups',    "Bouquets for All Channels and Groups"),
        ('parent_sub',        "Bouquet with Provider Name and Sub-Bouquets"),
    ]
    _EPG_PARSE_TYPE = [
        ('off',          "Off"),
        ('display_name', "By Display Name"),
        ('tvg_id',       "By tvg-id"),
    ]
    _PLAYBACK = [
        ('gstplayer',   "GStreamer Player"),
        ('gst_player',  "GstPlayer"),
        ('exteplayer3', "ExtEplayer3"),
        ('dvb',         "DVB"),
    ]
    _ORDER = [
        ('provider',      "Use Provider Order"),
        ('alphabetical',  "Alphabetically"),
        ('user_defined',  "User Defined (Use for Sorted Channels/Bouquets)"),
    ]
    _XTREAM_TYPE = [
        ('user_pass', "Xtream Codes (Username/Password)"),
        ('token',     "Xtream (Codes/Token)"),
    ]
    _XTREAM_OUTPUT = [
        ('ts',          "TS"),
        ('m3u8',        "HLS / m3u8 (Recommended)"),
        ('gstplayer',   "GStreamer Player"),
        ('gst_player',  "GstPlayer"),
        ('exteplayer3', "ExtEplayer3"),
        ('dvb',         "DVB"),
    ]
    _XTREAM_STRATEGY = [
        ('same_as_provider',  "Same As Provider"),
        ('group_into_folder', "Group all Into One Folder"),
    ]
    _XTREAM_PICON = [
        ('off',          "Off"),
        ('display_name', "With Display Name"),
        ('reference',    "With Reference Number"),
    ]
    _PICON_NAMING = [
        ('display_name', "With Display Name"),
        ('reference',    "With Reference Number"),
    ]
    _UPDATE_MODE = [
        ('off',    "Off"),
        ('top',    "New Channel on Top"),
        ('bottom', "New Channel on Bottom"),
    ]

    def __init__(self, session, provider_data, is_edit=False):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._is_edit = is_edit
        self.setTitle(T("Edit IPTV Playlist/Archives Provider") if is_edit else T("Add IPTV Playlist/Archives Provider"))
        self._cfg = {
            'enabled':          ConfigYesNo(default=bool(provider_data.get('enabled', True))),
            'name':             ConfigText(default=provider_data.get('name', '')       or '', fixed_size=False),
            'xmltv_url':        ConfigText(default=provider_data.get('xmltv_url', '')  or '', fixed_size=False),
            'm3u_source':       ConfigText(default=provider_data.get('m3u_source', '') or '', fixed_size=False),
            'epg_parse_type':   ConfigSelection(
                choices=[(v, T(l)) for v, l in self._EPG_PARSE_TYPE],
                default=provider_data.get('epg_parse_type', 'off')),
            'bouquet_strategy': ConfigSelection(
                choices=[(v, T(l)) for v, l in self._STRATEGIES],
                default=provider_data.get('bouquet_strategy', 'same_playlist')),
            'playback_with':    ConfigSelection(
                choices=[(v, T(l)) for v, l in self._PLAYBACK],
                default=provider_data.get('playback_with', 'gstplayer')),
            'channel_order':    ConfigSelection(
                choices=[(v, T(l)) for v, l in self._ORDER],
                default=provider_data.get('channel_order', 'provider')),
            'clean_bouquets':     ConfigYesNo(default=False),
        }
        # ── Archive settings (merged from IPTVProviderEditDialog) ─────────────
        self._cfg['create_archives']        = ConfigYesNo(
            default=bool(provider_data.get('create_archives', False)))
        self._cfg['create_archive_markers'] = ConfigYesNo(
            default=bool(provider_data.get('create_archive_markers', False)))

        self._cfg['archive_days']       = ConfigInteger(
            default=max(1, min(7, int(provider_data.get('archive_days', 7) or 7))), limits=(1, 7))
        _raw_off = int(provider_data.get('time_offset_sec', 0) or 0)
        self._cfg['time_offset_sign']   = ConfigSelection(
            choices=['+', '-'], default='+' if _raw_off >= 0 else '-')
        self._cfg['time_offset_abs']    = ConfigInteger(
            default=abs(_raw_off), limits=(0, 99999))
        self._cfg['stream_hostname']    = ConfigText(
            default=(provider_data.get('stream_hostname') or '').strip(), fixed_size=False)
        self._cfg['player_override']    = ConfigYesNo(
            default=bool(provider_data.get('player_override', False)))
        self._cfg['player_int_on']      = ConfigYesNo(
            default=bool(provider_data.get('player_int_on', True)))
        self._cfg['player_sl_on']       = ConfigYesNo(
            default=bool(provider_data.get('player_sl_on', False)))
        self._cfg['player_rec_on']      = ConfigYesNo(
            default=bool(provider_data.get('player_rec_on', False)))
        self._cfg['clear_cache_on_save'] = ConfigYesNo(default=False)
        self._ttl_custom_val  = bool(provider_data.get('cache_ttl_custom', False))
        self._ttl_days_val    = int(provider_data.get('cache_ttl_days', 7) or 7)
        self._ttl_sentinel_ref    = None
        self._offset_sentinel_ref = None
        self._cfg['create_archives'].addNotifier(self._onArchivesToggled, initial_call=False)
        self._cfg['player_override'].addNotifier(self._onArchivesToggled, initial_call=False)
        # ── Picon settings — migrate old 'off' value to picon_enabled=False ──
        _old_picon_naming = provider_data.get('picon_naming', 'off')
        _picon_enabled    = _old_picon_naming != 'off'
        _picon_naming_val = _old_picon_naming if _old_picon_naming != 'off' else 'reference'
        # Build dynamic mount-point list from detected media paths
        _mount_choices = [('/usr/share/enigma2/picon', '/usr/share/enigma2/picon')]
        try:
            for _mp in _detectMediaPaths():
                if _mp != '/etc':
                    _mount_choices.append(('%s/picon' % _mp, '%s/picon' % _mp))
        except Exception:
            pass
        _saved_location = provider_data.get('picon_location', '/usr/share/enigma2/picon')
        # migrate old keyword values
        if _saved_location in ('enigma2_picon', 'plugin_dir', ''):
            _saved_location = '/usr/share/enigma2/picon'
        if _saved_location not in [v for v, _ in _mount_choices]:
            _mount_choices.append((_saved_location, _saved_location))
        self._cfg['picon_enabled']    = ConfigYesNo(default=_picon_enabled)
        self._cfg['custom_epg_enabled'] = ConfigYesNo(
            default=bool(provider_data.get('custom_epg_enabled', True)))
        self._cfg['picon_naming']     = ConfigSelection(
            choices=[(v, T(l)) for v, l in self._PICON_NAMING],
            default=_picon_naming_val)
        self._cfg['picon_location']   = ConfigSelection(
            choices=_mount_choices,
            default=_saved_location)
        self._cfg['picon_with_folder'] = ConfigYesNo(
            default=bool(provider_data.get('picon_with_folder', True)))
        self._cfg['picon_symlink']    = ConfigYesNo(
            default=bool(provider_data.get('picon_symlink', False)))
        _saved_update = provider_data.get('update_playlist_mode', 'off')
        if _saved_update not in ('top', 'bottom'):
            _saved_update = 'top'
        self._cfg['update_mode_sub'] = ConfigSelection(
            choices=[('top', T("New Channels on Top")), ('bottom', T("New Channels on Bottom"))],
            default=_saved_update)
        lst = self._buildList()
        ConfigListScreen.__init__(self, lst, session=session)
        self._cfg['channel_order'].addNotifier(self._onOrderChanged, initial_call=False)
        self._cfg['picon_enabled'].addNotifier(self._onPiconChanged, initial_call=False)
        self["key_red"]    = Button(T("Delete Provider") if is_edit else T("Cancel"))
        self["key_green"]  = Button(T("Save"))
        self["key_yellow"] = Button(T("Browse File"))
        self["key_blue"]   = Button(T("Exit"))
        self["web_url"]    = Label("")
        self["plEditActions"] = ActionMap(
            ["ColorActions", "OkCancelActions", "SetupActions"],
            {"ok": self.keyOK, "cancel": self.keyExit, "red": self.keyDelete,
             "green": self.keySave, "yellow": self.keyBrowse,
             "blue": self.keyExit, "save": self.keySave}, -2)
        self._webserver = None
        self._pollTimer = eTimer()
        try:
            self._poll_conn = self._pollTimer.timeout.connect(self._pollWebInput)
        except Exception:
            self._pollTimer.callback.append(self._pollWebInput)
        self.onClose.append(self._stopWebServer)
        self._startWebServer()

    def _buildList(self):
        entries = [
            getConfigListEntry(T("Enabled"),                   self._cfg['enabled']),
            getConfigListEntry(T("Provider Name"),              self._cfg['name']),
            getConfigListEntry(T("XMLTV URL / Local File"),     self._cfg['xmltv_url']),
            getConfigListEntry(T("M3U URL / M3U Playlist"),     self._cfg['m3u_source']),
            getConfigListEntry(T("Create EPG File"),            self._cfg['epg_parse_type']),
            getConfigListEntry(T("Bouquet Creation Strategy"),  self._cfg['bouquet_strategy']),
            getConfigListEntry(T("Playback With"),              self._cfg['playback_with']),
            getConfigListEntry(T("Channels Ordering By"),       self._cfg['channel_order']),
        ]
        if self._cfg['channel_order'].value == 'user_defined':
            entries.append(getConfigListEntry(
                T("Update M3U Playlist Only"), self._cfg['update_mode_sub']))
        entries.append(getConfigListEntry(T("Download Picons"),   self._cfg['picon_enabled']))
        if self._cfg['picon_enabled'].value:
            entries.append(getConfigListEntry(T("  Naming"),         self._cfg['picon_naming']))
            entries.append(getConfigListEntry(T("  Mounted Points"), self._cfg['picon_location']))
            entries.append(getConfigListEntry(T("  With Folder"),    self._cfg['picon_with_folder']))
            entries.append(getConfigListEntry(T("  Create Symlink"), self._cfg['picon_symlink']))
        entries.append(getConfigListEntry(T("Custom EPG File"),   self._cfg['custom_epg_enabled']))
        entries.append(getConfigListEntry(T("Clean Bouquets"),   self._cfg['clean_bouquets']))
        entries.append(getConfigListEntry(T("Create Provider Archives"), self._cfg['create_archives']))
        if self._cfg['create_archives'].value:

            entries.append(getConfigListEntry(T("  Create Archive Markers ( ▶ )"),       self._cfg['create_archive_markers']))
            entries.append(getConfigListEntry(T("  Archive Days (1-7)"),          self._cfg['archive_days']))
            self._ttl_sentinel_ref = ConfigSelection(
                choices=[self._ttlSentinelLabel()], default=self._ttlSentinelLabel())
            entries.append(getConfigListEntry(T("  TTL Days For Cached Files"),   self._ttl_sentinel_ref))
            self._offset_sentinel_ref = ConfigSelection(
                choices=[self._offsetSentinelLabel()],
                default=self._offsetSentinelLabel())
            entries.append(getConfigListEntry(
                T("  Archive Start Offset (+/- sec)"), self._offset_sentinel_ref))
            entries.append(getConfigListEntry(T("  Player Override (Provider-Specific)"), self._cfg['player_override']))
            if self._cfg['player_override'].value:
                entries.append(getConfigListEntry(T("    Player: Integrated"),    self._cfg['player_int_on']))
                entries.append(getConfigListEntry(T("    Player: StreamLink"),    self._cfg['player_sl_on']))
                entries.append(getConfigListEntry(T("    Player: Receiver"),      self._cfg['player_rec_on']))
            entries.append(getConfigListEntry(T("  Clear Cache on Save"),         self._cfg['clear_cache_on_save']))
        return entries

    def _onOrderChanged(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _onPiconChanged(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _onArchivesToggled(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _ttlSentinelLabel(self):
        if self._ttl_custom_val:
            return T("Custom: %d days") % self._ttl_days_val + '  [OK]'
        return T("Default (7 days)") + '  [OK]'

    def _offsetSentinelLabel(self):
        sign = self._cfg['time_offset_sign'].value
        sec  = self._cfg['time_offset_abs'].value
        host = (self._cfg['stream_hostname'].value or '').strip()
        if sec == 0 and not host:
            val = T("off")
        else:
            parts = []
            if sec != 0:
                parts.append('%s%d sec' % (sign, sec))
            if host:
                parts.append('[%s]' % host)
            val = '  '.join(parts)
        return val + '  [OK]'

    def _onOffsetClosed(self, result=None):
        if result is not None:
            sign, sec, host = result
            self._cfg['time_offset_sign'].value  = sign
            self._cfg['time_offset_abs'].value   = sec
            self._cfg['stream_hostname'].value   = host
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _startWebServer(self):
        if not _WEB_INPUT_OK:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))
            return
        prefill = {
            '_is_edit':           self._is_edit,
            'name':               self._cfg['name'].value,
            'xmltv_url':          self._cfg['xmltv_url'].value,
            'm3u_source':         self._cfg['m3u_source'].value,
            'enabled':            '1' if self._cfg['enabled'].value else '0',
            'epg_parse_type':     self._cfg['epg_parse_type'].value,
            'bouquet_strategy':   self._cfg['bouquet_strategy'].value,
            'playback_with':      self._cfg['playback_with'].value,
            'channel_order':      self._cfg['channel_order'].value,
            'update_mode_sub':    self._cfg['update_mode_sub'].value,
            'picon_enabled':      '1' if self._cfg['picon_enabled'].value else '0',
            'picon_naming':       self._cfg['picon_naming'].value,
            'picon_with_folder':  '1' if self._cfg['picon_with_folder'].value else '0',
            'picon_symlink':      '1' if self._cfg['picon_symlink'].value else '0',
            'clean_bouquets':     '0',
            'create_archives':        '1' if self._cfg['create_archives'].value else '0',
            'create_archive_markers': '1' if self._cfg['create_archive_markers'].value else '0',
            'custom_epg_enabled':     '1' if self._cfg['custom_epg_enabled'].value else '0',

            'archive_days':       str(self._cfg['archive_days'].value),
            'cache_ttl_custom':   '1' if self._ttl_custom_val else '0',
            'cache_ttl_days':     str(self._ttl_days_val),
            'time_offset_sign':   self._cfg['time_offset_sign'].value,
            'time_offset_abs':    str(self._cfg['time_offset_abs'].value),
            'stream_hostname':    self._cfg['stream_hostname'].value,
            'player_override':    '1' if self._cfg['player_override'].value else '0',
            'player_int_on':      '1' if self._cfg['player_int_on'].value else '0',
            'player_sl_on':       '1' if self._cfg['player_sl_on'].value else '0',
            'player_rec_on':      '1' if self._cfg['player_rec_on'].value else '0',
            'clear_cache_on_save':'0',
            'ui_language': _get_enigma2_lang(),
        }
        _pl_upload_dir = os.path.join(getDataDir(), 'IPTVPlaylistCreator')
        try:
            os.makedirs(_pl_upload_dir)
        except OSError:
            pass
        self._webserver = IPTVWebInputServer(WEB_PORT, upload_dir=_pl_upload_dir)
        ok, ip, port = self._webserver.start(prefill=prefill, form_type='playlist')
        if ok:
            url = "http://%s:%d" % (ip, port)
            self["web_url"].setText("PC Input: %s" % url)
            self._pollTimer.start(500, True)
        else:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))

    def _pollWebInput(self):
        if self._webserver is None:
            return
        data = self._webserver.poll()
        if data:
            self._applyWebData(data)
        else:
            self._pollTimer.start(500, True)

    def _applyWebData(self, data):
        self._pollTimer.stop()
        if self._webserver:
            self._webserver.stop()
            self._webserver = None
        def _s(k): return (data.get(k) or '').strip()
        if _s('name'):       self._cfg['name'].value       = _s('name')
        if _s('xmltv_url'):  self._cfg['xmltv_url'].value  = _s('xmltv_url')
        if _s('m3u_source'): self._cfg['m3u_source'].value = _s('m3u_source')
        if 'enabled' in data:
            self._cfg['enabled'].value = data['enabled'] not in ('0', 'false', 'False', 'no')
        if _s('epg_parse_type'):
            valid = [v for v, _ in self._EPG_PARSE_TYPE]
            if _s('epg_parse_type') in valid:
                self._cfg['epg_parse_type'].value = _s('epg_parse_type')
        if _s('bouquet_strategy'):
            valid = [v for v, _ in self._STRATEGIES]
            if _s('bouquet_strategy') in valid:
                self._cfg['bouquet_strategy'].value = _s('bouquet_strategy')
        if _s('playback_with'):
            valid = [v for v, _ in self._PLAYBACK]
            if _s('playback_with') in valid:
                self._cfg['playback_with'].value = _s('playback_with')
        if _s('channel_order'):
            valid = [v for v, _ in self._ORDER]
            if _s('channel_order') in valid:
                self._cfg['channel_order'].value = _s('channel_order')
        if _s('picon_naming'):
            valid = [v for v, _ in self._PICON_NAMING]
            if _s('picon_naming') in valid:
                self._cfg['picon_naming'].value = _s('picon_naming')
        if _s('update_mode_sub') in ('top', 'bottom'):
            self._cfg['update_mode_sub'].value = _s('update_mode_sub')
        if 'picon_enabled' in data:
            self._cfg['picon_enabled'].value = data['picon_enabled'] not in ('0','false','False','no','')
        if 'picon_with_folder' in data:
            self._cfg['picon_with_folder'].value = data['picon_with_folder'] not in ('0','false','False','no','')
        if 'picon_symlink' in data:
            self._cfg['picon_symlink'].value = data['picon_symlink'] not in ('0','false','False','no','')
        if 'create_archives' in data:
            self._cfg['create_archives'].value = data['create_archives'] not in ('0','false','False','no','')
        if 'create_archive_markers' in data:
            self._cfg['create_archive_markers'].value = data['create_archive_markers'] not in ('0','false','False','no','')
        if 'custom_epg_enabled' in data:
            self._cfg['custom_epg_enabled'].value = data['custom_epg_enabled'] not in ('0','false','False','no','')

        try:
            _days = int(_s('archive_days'))
            if 1 <= _days <= 7:
                self._cfg['archive_days'].value = _days
        except Exception:
            pass
        if 'cache_ttl_custom' in data:
            self._ttl_custom_val = data['cache_ttl_custom'] not in ('0','false','False','no','')
        try:
            _tdays = int(_s('cache_ttl_days'))
            if 1 <= _tdays <= 30:
                self._ttl_days_val = _tdays
        except Exception:
            pass
        if _s('time_offset_sign') in ('+', '-'):
            self._cfg['time_offset_sign'].value = _s('time_offset_sign')
        try:
            _abs = int(_s('time_offset_abs'))
            if 0 <= _abs <= 3600:
                self._cfg['time_offset_abs'].value = _abs
        except Exception:
            pass
        if 'stream_hostname' in data:
            self._cfg['stream_hostname'].value = _s('stream_hostname')
        for _pk in ('player_override','player_int_on','player_sl_on','player_rec_on'):
            if _pk in data:
                self._cfg[_pk].value = data[_pk] not in ('0','false','False','no','')
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass
        self["web_url"].setText(T("PC Input: data received"))
        self.session.open(MessageBox,
            T("Provider data received from your PC browser!\nCheck the fields and press Save."),
            type=MessageBox.TYPE_INFO, timeout=4)

    def _stopWebServer(self):
        try:
            self._pollTimer.stop()
        except Exception:
            pass
        try:
            if self._webserver:
                self._webserver.stop()
                self._webserver = None
        except Exception:
            pass

    def keyOK(self):
        cur = self["config"].getCurrent()
        if (cur and self._ttl_sentinel_ref is not None
                and cur[1] is self._ttl_sentinel_ref):
            self.session.openWithCallback(
                self._onTTLClosed, IPTVProviderTTLScreen,
                self._ttl_custom_val, self._ttl_days_val)
            return
        if (cur and self._offset_sentinel_ref is not None
                and cur[1] is self._offset_sentinel_ref):
            self.session.openWithCallback(
                self._onOffsetClosed, IPTVArchiveOffsetDialog,
                self._cfg['time_offset_sign'].value,
                self._cfg['time_offset_abs'].value,
                self._cfg['stream_hostname'].value)
            return
        ConfigListScreen.keyOK(self)

    def _onTTLClosed(self, result=None):
        if result is not None:
            self._ttl_custom_val, self._ttl_days_val = result
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def keySave(self):
        _new_name = self._cfg['name'].value.strip()
        if _new_name:
            # Check name doesn't collide with any other provider (playlist or Xtream)
            # using the same safe-name formula used for bouquet filenames.
            # Skip self when editing — identified by the original name in provider_data.
            _orig_name = (self._cfg['name'].default or '').strip() if self._is_edit else None
            _conflict = _checkProviderNameConflict(_new_name,
                                                   skip_playlist_name=_orig_name)
            if _conflict:
                self.session.open(MessageBox,
                    T("Provider name '%s' conflicts with existing provider '%s'.\n"
                      "Each provider must have a unique name to avoid bouquet file collisions."
                      ) % (_new_name, _conflict),
                    type=MessageBox.TYPE_ERROR, timeout=8)
                return
        if self._cfg['clean_bouquets'].value:
            prov_name = self._cfg['name'].value.strip()
            if prov_name:
                _deletePlaylistProviderFiles(prov_name)
        if self._cfg['create_archives'].value and self._cfg['clear_cache_on_save'].value:
            _pn = self._cfg['name'].value.strip()
            if _pn:
                try:
                    _cd = _xmltvCacheDir(_pn)
                    import os as _os2
                    for _f in _os2.listdir(_cd):
                        if _f.startswith('epg_') and _f.endswith('.json'):
                            try: _os2.remove(_os2.path.join(_cd, _f))
                            except Exception: pass
                    iptvLogWrite('[ArchiveCache] Cleared cache for: %s' % _pn)
                except Exception:
                    pass
                try:
                    from ._epg import _epgSourceFilePath, _xmltvLocalFilePath
                    import os as _os3
                    _xu = self._cfg['xmltv_url'].value.strip()
                    if _xu:
                        for _xp in (_epgSourceFilePath(_xu, _pn), _xmltvLocalFilePath(_xu, _pn)):
                            if _os3.path.isfile(_xp):
                                try: _os3.remove(_xp)
                                except Exception: pass
                        iptvLogWrite('[ArchiveCache] Cleared XMLTV source for: %s' % _pn)
                except Exception:
                    pass
        self.close({
            'enabled':            self._cfg['enabled'].value,
            'name':               self._cfg['name'].value,
            'xmltv_url':          self._cfg['xmltv_url'].value,
            'm3u_source':         self._cfg['m3u_source'].value,
            'epg_parse_type':     self._cfg['epg_parse_type'].value,
            'bouquet_strategy':   self._cfg['bouquet_strategy'].value,
            'playback_with':      self._cfg['playback_with'].value,
            'channel_order':      self._cfg['channel_order'].value,
            'update_playlist_mode': (self._cfg['update_mode_sub'].value
                                     if self._cfg['channel_order'].value == 'user_defined'
                                     else 'off'),
            'picon_naming':       self._cfg['picon_naming'].value if self._cfg['picon_enabled'].value else 'off',
            'picon_enabled':      self._cfg['picon_enabled'].value,
            'custom_epg_enabled': self._cfg['custom_epg_enabled'].value,
            'picon_location':     self._cfg['picon_location'].value,
            'picon_with_folder':  self._cfg['picon_with_folder'].value,
            'picon_symlink':      self._cfg['picon_symlink'].value,
            'xtream_enabled':     False,
            'clean_bouquets':     False,
            'create_archives':        self._cfg['create_archives'].value,
            'create_archive_markers': self._cfg['create_archive_markers'].value,

            'archive_days':       self._cfg['archive_days'].value,
            'time_offset_sec':    (self._cfg['time_offset_abs'].value
                                   if self._cfg['time_offset_sign'].value == '+'
                                   else -self._cfg['time_offset_abs'].value),
            'stream_hostname':    self._cfg['stream_hostname'].value.strip(),
            'player_override':    self._cfg['player_override'].value,
            'player_int_on':      self._cfg['player_int_on'].value,
            'player_sl_on':       self._cfg['player_sl_on'].value,
            'player_rec_on':      self._cfg['player_rec_on'].value,
            'cache_ttl_custom':   self._ttl_custom_val,
            'cache_ttl_days':     self._ttl_days_val if self._ttl_custom_val else 7,
        })

    def keyDelete(self):
        if not self._is_edit:
            self.close(None)
            return
        name = self._cfg['name'].value.strip() or T('(unnamed)')
        self.session.openWithCallback(self._confirmDelete, MessageBox,
            T("Delete provider '%s'?\nThis will also remove all bouquet and EPG files\n"
              "created by this provider from /etc/enigma2 and /etc/epgimport.") % name,
            type=MessageBox.TYPE_YESNO)

    def _confirmDelete(self, confirmed):
        if confirmed:
            self.close({'_delete': True})

    def keyExit(self):
        self.close(None)

    def keyBrowse(self):
        cur = self["config"].getCurrent()
        if cur is not None and cur[1] is self._cfg['m3u_source']:
            val       = self._cfg['m3u_source'].value
            start_dir = '/media/hdd/'
            if val and val.startswith('/'):
                d = os.path.dirname(val)
                if os.path.isdir(d): start_dir = d
            self.session.openWithCallback(self._fileBrowserM3UCB, IPTVFileBrowser, start_dir)
        elif cur is not None and cur[1] is self._cfg['xmltv_url']:
            val       = self._cfg['xmltv_url'].value
            start_dir = '/media/hdd/'
            if val and val.startswith('/'):
                d = os.path.dirname(val)
                if os.path.isdir(d): start_dir = d
            self.session.openWithCallback(self._fileBrowserXmltvCB, IPTVFileBrowser, start_dir)
        else:
            self.session.open(MessageBox,
                T("Please select the 'M3U URL' or 'XMLTV URL' field first."),
                type=MessageBox.TYPE_INFO, timeout=3)

    def _fileBrowserM3UCB(self, path):
        if path:
            self._cfg['m3u_source'].value = path
            try:
                lst = self._buildList()
                self["config"].list = lst
                self["config"].l.setList(lst)
            except Exception:
                pass

    def _fileBrowserXmltvCB(self, path):
        if path:
            self._cfg['xmltv_url'].value = path
            try:
                lst = self._buildList()
                self["config"].list = lst
                self["config"].l.setList(lst)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# IPTVArchiveJumpInput — minute-input jump dialog
# ---------------------------------------------------------------------------

_JUMP_SKIN_COMMON = """
        position="center,center" size="560,340"
        title=" " flags="wfNoBorder" backgroundColor="#AA111122">
        <eLabel position="0,0"   size="560,2"   backgroundColor="#CC33FF"/>
        <eLabel position="0,338" size="560,2"   backgroundColor="#CC33FF"/>
        <eLabel position="0,0"   size="2,340"   backgroundColor="#CC33FF"/>
        <eLabel position="558,0" size="2,340"   backgroundColor="#CC33FF"/>
        <widget name="hint" position="14,302" size="532,26"
                font="Regular;21" halign="center" transparent="1"/>"""

_JUMP_SKIN_FWD = """<screen name="IPTVArchiveJumpInput" """ + _JUMP_SKIN_COMMON + """
        <widget name="icon"   position="10,30"  size="256,256"
                alphaTest="blend" transparent="1"/>
        <widget name="number" position="282,118" size="256,80"
                font="Bold;57" halign="center" valign="center"
                foregroundColor="#44FF44" transparent="1"/>
    </screen>"""

_JUMP_SKIN_BACK = """<screen name="IPTVArchiveJumpInput" """ + _JUMP_SKIN_COMMON + """
        <widget name="number" position="12,118" size="256,80"
                font="Bold;57" halign="center" valign="center"
                foregroundColor="#44FF44" transparent="1"/>
        <widget name="icon"   position="294,30" size="256,256"
                alphaTest="blend" transparent="1"/>
    </screen>"""


class IPTVArchiveJumpInput(Screen):

    def __init__(self, session, forward):
        self._forward = forward
        self.skin = _JUMP_SKIN_FWD if forward else _JUMP_SKIN_BACK
        Screen.__init__(self, session)
        self._digits = ''
        try:
            from Components.Pixmap import Pixmap as _Pixmap
            self['icon'] = _Pixmap()
        except Exception:
            pass
        self['number'] = Label('_ min')
        self['hint']   = Label('0-9999: minutes    OK: jump    EXIT: cancel')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'NumberActions'],
            {'ok': self._confirm, 'cancel': self._cancel,
             '0': lambda: self._digit('0'), '1': lambda: self._digit('1'),
             '2': lambda: self._digit('2'), '3': lambda: self._digit('3'),
             '4': lambda: self._digit('4'), '5': lambda: self._digit('5'),
             '6': lambda: self._digit('6'), '7': lambda: self._digit('7'),
             '8': lambda: self._digit('8'), '9': lambda: self._digit('9')}, -1)
        self.onLayoutFinish.append(self._loadIcon)

    def _loadIcon(self):
        try:
            from enigma import loadPNG
            _dir = os.path.dirname(os.path.abspath(__file__))
            _name = 'fastforward.png' if self._forward else 'rewind.png'
            self['icon'].instance.setPixmap(loadPNG(os.path.join(_dir, 'icons', _name)))
        except Exception:
            pass

    def _digit(self, d):
        self._digits = (self._digits + d).lstrip('0') or ''
        if len(self._digits) > 4:
            self._digits = self._digits[-4:]
        self['number'].setText((self._digits if self._digits else '_') + ' min')

    def _confirm(self):
        try:    mins = int(self._digits) if self._digits else 0
        except ValueError: mins = 0
        self.close(mins * 60 if self._forward else -mins * 60)

    def _cancel(self):
        self.close(None)

# ---------------------------------------------------------------------------
# IPTVArchivePausePopup — pause icon overlay
# ---------------------------------------------------------------------------

class IPTVArchivePausePopup(Screen):
    skin = """
        <screen position="center,center" size="256,256"
                title=" " flags="wfNoBorder" backgroundColor="#00000000">
            <widget name="icon" position="0,0" size="256,256"
                    alphaTest="blend" transparent="1"/>
        </screen>"""

    def __init__(self, session, icon_path):
        Screen.__init__(self, session)
        try:
            from Components.Pixmap import Pixmap as _Pixmap
            self["icon"] = _Pixmap()
        except Exception:
            pass
        self._icon_path = icon_path
        self["actions"] = ActionMap(
            ["OkCancelActions", "InfobarSeekActions", "MediaPlayerActions",
             "InfobarMediaPlayerInfoActions"],
            {
                "ok":               self.close,
                "cancel":           self.close,
                "playpauseService": self.close,
                "play":             self.close,
                "pause":            self.close,
                "stop":             self.close,
            }, -1)
        self.onLayoutFinish.append(self._loadIcon)

    def _loadIcon(self):
        try:
            from enigma import loadPNG
            self["icon"].instance.setPixmap(loadPNG(self._icon_path))
        except Exception:
            pass

# ---------------------------------------------------------------------------
# iptvArchiveSecondInfoBar — now/next overlay
# ---------------------------------------------------------------------------

class iptvArchiveSecondInfoBar(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = ['iptvArchiveProSecondInfoBar', 'iptvArchiveSecondInfoBar', 'SecondInfoBar']
        self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
            {"ok": self.close, "cancel": self.close}, -2)

# ---------------------------------------------------------------------------
# iptvArchiveInfoBar — archive playback InfoBar
# ---------------------------------------------------------------------------

class iptvArchiveInfoBar(Screen, InfoBarAudioSelection, InfoBarNotifications,
                          InfoBarSubtitleSupport, InfoBarMenu):
    STATE_HIDDEN = 0
    STATE_SHOWN  = 1

    def __init__(self, session, ev, base_ref_str='', all_events=None, streamlink_port=0):
        Screen.__init__(self, session)
        self._streamlink_port = int(streamlink_port)
        for x in (InfoBarAudioSelection, InfoBarNotifications,
                   InfoBarSubtitleSupport, InfoBarMenu):
            try:
                x.__init__(self)
            except Exception:
                pass
        self.skinName      = ['iptvArchiveProInfoBar', 'iptvArchiveInfoBar', 'InfoBar']
        self.skinAttributes = None
        self._all_events   = sorted(all_events, key=lambda e: e[2]) if all_events else []

        try:
            self._saved_event_now  = self.session.screen.get('Event_Now',  None)
            self._saved_event_next = self.session.screen.get('Event_Next', None)
        except Exception as e:
            iptvLogWrite('[INFOBAR] screen.get failed: %s' % str(e))
            self._saved_event_now  = None
            self._saved_event_next = None
        try:
            self.session.screen['Event_Now']  = Event()
            self.session.screen['Event_Next'] = Event()
            iptvLogWrite('[INFOBAR] Event_Now/Event_Next set OK')
        except Exception as e:
            iptvLogWrite('[INFOBAR] Event_Now/Event_Next set FAILED: %s' % str(e))

        if base_ref_str:
            self.strRef = base_ref_str
        else:
            self.strRef = str(ServiceReference(
                self.session.nav.getCurrentlyPlayingServiceReference()))
        self.ev        = ev
        self.hideTimer = eTimer()
        try:
            self.timer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except Exception:
            self.hideTimer.callback.append(self.doTimerHide)

        self["setupActions"] = ActionMap(
            ["MediaPlayerActions", "HotkeyActions", "InfobarSeekActions", "SetupActions"],
            {
                "ok":       self.ok,
                "cancel":   self.cancel,
                "info":     self.close,
                "epg":      self.close,
                iptvHotKey: self.close,
                "pause":    self.pause,
                "play":     self.pause,
                "stop":     self.stop,
                "1": lambda: self.myjump(1),
                "3": lambda: self.myjump(3),
                "4": lambda: self.myjump(4),
                "6": lambda: self.myjump(6),
                "7": lambda: self.myjump(7),
                "9": lambda: self.myjump(9),
                "seekBack": self.jumpInputBack,
                "seekFwd":  self.jumpInputFwd,
            }, -2)

        self["HbbtvApplication"]  = Boolean(fixed=0); self["HbbtvApplication"].name  = ""
        self["KeyRedText"]        = Boolean(fixed=0); self["KeyRedText"].name         = ""
        self["KeyGreenText"]      = Boolean(fixed=0); self["KeyGreenText"].name       = ""
        self["KeyYellowText"]     = Boolean(fixed=0); self["KeyYellowText"].name      = ""
        self["KeyBlueText"]       = Boolean(fixed=0); self["KeyBlueText"].name        = ""

        self.onClose.append(self.__onClose)
        self.updateEvent()
        self.doShow()

    def __onClose(self):
        _prov.myStartTime = _prov.myStartTime + currTime() - _prov.myTimeStamp
        _prov.myTimeStamp = currTime()
        if self._saved_event_now is not None:
            self.session.screen['Event_Now']  = self._saved_event_now
        elif 'Event_Now' in self.session.screen:
            del self.session.screen['Event_Now']
        if self._saved_event_next is not None:
            self.session.screen['Event_Next'] = self._saved_event_next
        elif 'Event_Next' in self.session.screen:
            del self.session.screen['Event_Next']

    def ok(self):
        if _prov.myTimeStamp > 0:
            if self.__state == self.STATE_SHOWN:
                self.__state = self.STATE_HIDDEN
                self.hide()
                self.session.open(iptvArchiveSecondInfoBar)
            else:
                self.doShow()
        else:
            self.myjump(0)

    def doShow(self):
        self.__state = self.STATE_SHOWN
        self.show()
        self.startHideTimer()

    def doTimerHide(self):
        self.hideTimer.stop()
        self.__state = self.STATE_HIDDEN
        self.hide()

    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN:
            try:
                idx = config.usage.infobar_timeout.index
            except AttributeError:
                try:
                    idx = config.usage.infobar_timeout.value
                except Exception:
                    idx = 3
            if idx:
                self.hideTimer.start(idx * 1000, True)

    def _close_pause_popup(self):
        try:
            if getattr(self, '_pause_popup', None) is not None:
                self._skip_resume_callback = True
                self._pause_popup.close()
        except Exception:
            pass
        self._pause_popup = None

    def _resume_from_popup(self, *args):
        self._pause_popup = None
        if getattr(self, '_skip_resume_callback', False):
            self._skip_resume_callback = False
            return
        if _prov.myTimeStamp == 0:
            self.myjump(0)

    def pause(self):
        if _prov.myTimeStamp > 0:
            self.session.nav.stopService()
            _prov.myStartTime = _prov.myStartTime + currTime() - _prov.myTimeStamp
            _prov.myTimeStamp = 0
            self.doShow()
            try:
                _icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons', 'pause.png')
                self._pause_popup = self.session.openWithCallback(
                    self._resume_from_popup, IPTVArchivePausePopup, _icon)
            except Exception:
                self._pause_popup = None
        else:
            self._close_pause_popup()
            self.myjump(0)

    def stop(self, value=True):
        if value:
            self.close(True)

    def cancel(self):
        if paramExist(MessageBox.__init__, 'title'):
            self.session.openWithCallback(
                self.stop, MessageBox,
                T("%s\n\nStop playback and return to channel list?") % self.ev.getEventName(),
                timeout=10, default=True, title=self.strRef.split(':')[-1])
        else:
            self.session.openWithCallback(
                self.stop, MessageBox,
                T("%s\n\nStop playback and return to channel list?") % self.ev.getEventName(),
                timeout=10, default=True)

    def _findEventAt(self, ts):
        evs = self._all_events
        if not evs:
            return None
        lo, hi, idx = 0, len(evs) - 1, -1
        while lo <= hi:
            mid = (lo + hi) // 2
            if evs[mid][2] <= ts:
                idx = mid; lo = mid + 1
            else:
                hi = mid - 1
        if idx < 0:
            return None
        e = evs[idx]
        if e[3] and ts >= e[2] + e[3]:
            return None
        return epgEvent(e[0], e[1], e[2], e[3], e[4])

    def updateEvent(self):
        # _prov.myStartTime is in _str_btime reference (server string parsed as
        # receiver local time).  _all_events are keyed by _ts_btime (UTC epoch).
        # myXtreamEpgOffset bridges the two: add it to get the UTC-based lookup
        # time that matches event btimes, and subtract it from the time projection
        # so "now" is correctly placed on the event timeline.
        _epg_offset = getattr(_prov, 'myXtreamEpgOffset', 0)
        _epg_ts     = _prov.myStartTime + _epg_offset
        ev    = self._findEventAt(_epg_ts) or self.ev
        btime = ev.getBeginTime()
        self.session.screen['Event_Now'].newEvent(epgEvent(
            ev.getShortDescription(), random.randint(0, 1000),
            currTime() + btime - _epg_ts, ev.getDuration(), ev.getEventName()))
        ev_next = self._findEventAt(btime + ev.getDuration()) if ev.getDuration() else None
        if ev_next:
            self.session.screen['Event_Next'].newEvent(epgEvent(
                '', random.randint(0, 1000),
                ev_next.getBeginTime(), ev_next.getDuration(), ev_next.getEventName()))
        else:
            self.session.screen['Event_Next'].newEvent(epgEvent(
                '', random.randint(0, 1000),
                btime, ev.getDuration(), ev.getArchiveBeginTimeString()))

    def myjump(self, secondsJump=0):
        secondsJump = {
            0:  0,
            1: -10,   3:  10,
            4: -60,   6:  60,
            7: -300,  9:  300,
        }.get(secondsJump, secondsJump)

        if _prov.myTimeStamp > 0:
            startTime = _prov.myStartTime + currTime() - _prov.myTimeStamp + secondsJump
        else:
            startTime = _prov.myStartTime + secondsJump

        if currTime() > startTime:
            self._close_pause_popup()
            _prov.myStartTime = startTime
            _prov.myTimeStamp = currTime()
            _prov.myStartStr  = ''
            newRef = eServiceReference(self.strRef)
            newRef.setPath(getArchiveUrl(newRef.getPath()))
            if self._streamlink_port:
                # For Streamlink, wrap the new archive URL through the proxy.
                # Copy newRef (preserves channel SID/TSID) so the skin shows
                # the channel name instead of the raw proxy URL.
                archive_url = newRef.getPath()
                sep = '&' if '?' in archive_url else '?'
                proxied_url = 'http://127.0.0.1:%d/%s%sdefault-stream=best' % (
                    self._streamlink_port, archive_url, sep)
                iptvLogWrite('[SEEK] StreamlinkProxy playService: %r' % proxied_url)
                sl_seek_ref = eServiceReference(str(newRef))
                sl_seek_ref.setPath(proxied_url)
                self.session.nav.playService(sl_seek_ref)
            else:
                iptvLogWrite('[SEEK] playService: %r' % newRef.getPath())
                self.session.nav.playService(newRef)

        self.updateEvent()
        self.doShow()

    def jumpInputFwd(self):
        self.hideTimer.stop()
        self.session.openWithCallback(self._onJumpInput, IPTVArchiveJumpInput, True)

    def jumpInputBack(self):
        self.hideTimer.stop()
        self.session.openWithCallback(self._onJumpInput, IPTVArchiveJumpInput, False)

    def _onJumpInput(self, seconds):
        if seconds is not None and seconds != 0:
            self.myjump(seconds)
        else:
            self.updateEvent()
            self.doShow()


# ===========================================================================
# IPTVIntegratedProvidersScreen — view/toggle/edit all integrated providers
# ===========================================================================

class IPTVIntegratedProvidersScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,690"
                title="Create IPTV Archive Programs From Providers" backgroundColor="#33000000">
            <widget name="stop_label" position="20,14" size="1210,40"
                    font="Regular;27" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1"/>
            <eLabel position="0,58" size="1250,2" backgroundColor="#555555"/>
            <widget source="list" render="Listbox" enableWrapAround="1"
                    position="20,66" size="1210,524"
                    secondForegroundColor="#aaaaaa" secondBackgroundColor="#00000000"
                    backgroundColor="#00000000" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(10,0),   size=(170,48), font=0, color=0x00e8e8e8, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                        MultiContentEntryText(pos=(286,0),  size=(534,48), font=0, color=0x00aaaaaa, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                        MultiContentEntryText(pos=(840,0),  size=(80,48),  font=0, color=0x00ffcc00, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=2),
                        MultiContentEntryText(pos=(930,0),  size=(170,48), font=0, color=0x00888888, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=3),
                        MultiContentEntryText(pos=(1090,0), size=(100,48), font=0, color=0x0000e000, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=4),
                        MultiContentEntryText(pos=(1090,0), size=(100,48), font=0, color=0x00e00000, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=5)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 48, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
                <ePixmap position="20,647"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend"/>
            <eLabel position="0,629" size="1250,1" backgroundColor="#00aa00"/>
        <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
        <ePixmap position="340,647" size="35,25" pixmap="buttons/red.png"    alphaTest="blend"/>
            <ePixmap position="660,647" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="980,647" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend"/>
            <widget name="key_green"  position="63,641"   size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
            <widget name="key_red"    position="383,641"  size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
            <widget name="key_yellow" position="703,641"  size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
            <widget name="key_blue"   position="1023,641" size="220,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,690"
                title="Create IPTV Archive Programs From Providers">
            <widget name="stop_label" position="20,14" size="1210,40"
                    font="Regular;27" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1"/>
            <eLabel position="0,58" size="1250,2" backgroundColor="#555555"/>
            <widget source="list" render="Listbox" enableWrapAround="1"
                    position="20,66" size="1210,524"
                    secondForegroundColor="#aaaaaa">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos=(10,0),   size=(170,48), font=0, color=0x00e8e8e8, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                        MultiContentEntryText(pos=(286,0),  size=(534,48), font=0, color=0x00aaaaaa, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                        MultiContentEntryText(pos=(840,0),  size=(80,48),  font=0, color=0x00ffcc00, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=2),
                        MultiContentEntryText(pos=(930,0),  size=(170,48), font=0, color=0x00888888, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=3),
                        MultiContentEntryText(pos=(1090,0), size=(100,48), font=0, color=0x0000e000, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=4),
                        MultiContentEntryText(pos=(1090,0), size=(100,48), font=0, color=0x00e00000, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=5)],
                     "fonts": [gFont("Regular",26)],
                     "itemHeight": 48, "scrollbarMode": "showOnDemand"}
                </convert>
            </widget>
                <ePixmap position="20,647"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend"/>
            <eLabel position="0,629" size="1250,1" backgroundColor="#00aa00"/>
        <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
        <ePixmap position="340,647" size="35,25" pixmap="buttons/red.png"    alphaTest="blend"/>
            <ePixmap position="660,647" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="980,647" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend"/>
            <widget name="key_green"  position="63,641"   size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
            <widget name="key_red"    position="383,641"  size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
            <widget name="key_yellow" position="703,641"  size="260,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
            <widget name="key_blue"   position="1023,641" size="220,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("Create IPTV Archive Programs From Providers"))
        from Components.Sources.List import List as _CList
        self["list"] = _CList([])
        self["stop_label"] = Label("")
        self["key_green"]  = Button(T("Add New"))
        self["key_red"]    = Button(T("Delete"))
        self["key_yellow"] = Button(T("Toggle ON/OFF"))
        self["key_blue"]   = Button(T("ALL On/Off"))
        self["ipActions"]  = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {"ok":     self._keyEdit,
             "cancel": self.close,
             "green":  self._keyAdd,
             "red":    self._keyDelete,
             "yellow": self._keyToggle,
             "blue":   self._keyMasterStop,
             "up":     lambda: self["list"].selectPrevious(),
             "down":   lambda: self["list"].selectNext()}, -1)
        self._rebuild()

    # ── data helpers ──────────────────────────────────────────────────────────

    def _buildProviderList(self):
        ps      = loadPluginSettings()
        stopped = set(ps.get('stopped_provider_tags', []))
        day_ovr = ps.get('integrated_provider_days_overrides', {})
        # Built-in providers — group IPTV_PROVIDERS by tag
        builtin_map = {}
        for frag, (tag, days) in IPTV_PROVIDERS.items():
            if tag is None:
                continue
            if tag not in builtin_map:
                builtin_map[tag] = {
                    'type': 'builtin', 'tag': tag,
                    'days': int(day_ovr.get(tag, days)),
                    'days_default': days,
                    'fragments': [],
                    'enabled': tag not in stopped,
                }
            builtin_map[tag]['fragments'].append(frag)
        builtin_list = sorted(builtin_map.values(), key=lambda x: x['tag'])
        # User-added custom integrated providers
        custom_list = []
        for i, p in enumerate(ps.get('integrated_providers_custom', [])):
            d            = dict(p)
            d['type']    = 'custom'
            d['idx']     = i
            _ctag        = (p.get('tag') or '').strip() or \
                            p.get('name', '').lower().replace(' ', '-')
            d['effective_tag'] = _ctag
            d['enabled'] = p.get('enabled', True) and (_ctag not in stopped)
            custom_list.append(d)
        return builtin_list + custom_list

    def _rowEntry(self, p):
        H = 48  # item height
        if p['type'] == 'builtin':
            frags = ', '.join(sorted(p['fragments']))
            if len(frags) > 50:
                frags = frags[:48] + u'\u2026'
            tag   = p['tag']
            days  = u'%dd' % p['days']
            typ   = T('[Built-in]')
            state = T('ON') if p['enabled'] else T('OFF')
            col   = 0x00e8e8e8
        else:
            tag   = (p.get('name') or p.get('tag') or '?')
            frags = (p.get('url_fragment') or '')
            days  = u'%dd' % int(p.get('days', 7) or 7)
            typ   = T('[Custom]')
            state = T('ON') if p.get('enabled', True) else T('OFF')
            col   = 0x00c8d8ff
        # text=0:tag  1:frags  2:days  3:type  4:ON(green)  5:OFF(red)  6:p
        on_text  = state if state == T('ON')  else ''
        off_text = state if state == T('OFF') else ''
        return (tag, frags, days, typ, on_text, off_text, p)

    def _rebuild(self):
        ps     = loadPluginSettings()
        master = ps.get('stop_integrated_providers', False)
        self["stop_label"].setText(
            T("All Integrated Providers: %s") % (
                T("OFF \u2014 providers stopped") if master
                else T("ON \u2014 providers active")))
        self._provs = self._buildProviderList()
        self["list"].setList([self._rowEntry(p) for p in self._provs])

    def _current(self):
        sel = self["list"].getCurrent()
        if sel is None:
            return None
        if isinstance(sel, (list, tuple)) and len(sel) > 0:
            return sel[-1]
        return None

    # ── key handlers ──────────────────────────────────────────────────────────

    def _keyEdit(self):
        p = self._current()
        if p is None:
            return
        self.session.openWithCallback(
            self._onEditClosed, IPTVIntegratedProviderEditScreen, p)

    def _onEditClosed(self, saved=False):
        self._rebuild()

    def _keyAdd(self):
        new_p = {
            'type': 'custom', 'name': '', 'tag': '', 'url_fragment': '',
            'days': 7, 'enabled': True, 'archive_pattern': 'standard',
            'epg_pattern': 'ottp', 'epg_url_template': '', 'idx': -1,
        }
        self.session.openWithCallback(
            self._onEditClosed, IPTVIntegratedProviderEditScreen, new_p)

    def _keyDelete(self):
        p = self._current()
        if p is None or p['type'] != 'custom':
            return
        ps      = loadPluginSettings()
        customs = list(ps.get('integrated_providers_custom', []))
        idx     = p.get('idx', -1)
        if 0 <= idx < len(customs):
            customs.pop(idx)
            ps['integrated_providers_custom'] = customs
            savePluginSettings(ps)
        self._rebuild()

    def _keyToggle(self):
        p = self._current()
        if p is None:
            return
        ps      = loadPluginSettings()
        stopped = list(ps.get('stopped_provider_tags', []))
        tag     = p['tag'] if p['type'] == 'builtin' else \
                  (p.get('tag') or '').strip() or \
                   p.get('name', '').lower().replace(' ', '-')
        if tag in stopped:
            stopped.remove(tag)
        else:
            stopped.append(tag)
        ps['stopped_provider_tags'] = stopped
        savePluginSettings(ps)
        self._rebuild()

    def _keyMasterStop(self):
        ps = loadPluginSettings()
        ps['stop_integrated_providers'] = not ps.get('stop_integrated_providers', False)
        savePluginSettings(ps)
        self._rebuild()


# ===========================================================================
# IPTVIntegratedProviderEditScreen — edit one built-in or custom integrated provider
# ===========================================================================

class IPTVIntegratedProviderEditScreen(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="800,640"
                title="Edit Archives From Provider" backgroundColor="#33000000">
            <widget name="config" position="20,20" size="760,460"
                    scrollbarMode="showOnDemand" font="Regular;27"
                    itemHeight="48" transparent="1"/>
                <widget name="web_url" position="20,536" size="760,34"
                    font="Regular;32" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
                <ePixmap position="116,593"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend"/>
            <eLabel position="0,572" size="800,1" backgroundColor="#00aa00"/>
        <eLabel position="0,639" size="800,1" backgroundColor="#00aa00"/>
        <ePixmap position="383,593" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="649,593" size="35,25" pixmap="buttons/red.png"    alphaTest="blend"/>
            <widget name="key_green"  position="151,588"  size="215,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
            <widget name="key_yellow" position="418,588" size="215,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
            <widget name="key_red"    position="684,588" size="100,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="800,640"
                title="Edit Archives From Provider">
            <widget name="config" position="20,20" size="760,460"
                    scrollbarMode="showOnDemand" font="Regular;27"
                    itemHeight="48"/>
                <widget name="web_url" position="20,536" size="760,34"
                    font="Regular;32" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1"/>
                <ePixmap position="116,593"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend"/>
            <eLabel position="0,572" size="800,1" backgroundColor="#00aa00"/>
        <eLabel position="0,639" size="800,1" backgroundColor="#00aa00"/>
        <ePixmap position="383,593" size="35,25" pixmap="buttons/yellow.png" alphaTest="blend"/>
            <ePixmap position="649,593" size="35,25" pixmap="buttons/red.png"    alphaTest="blend"/>
            <widget name="key_green"  position="151,588"  size="215,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
            <widget name="key_yellow" position="418,588" size="215,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
            <widget name="key_red"    position="684,588" size="100,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left"/>
        </screen>"""
    skin    = _SKIN_T


    _ARCHIVE_PATTERNS = [
        ('standard',       'Standard (utc/lutc params)'),
        ('path_archive',   'Path Archive  (archive-start-dur.m3u8)'),
        ('path_timeshift', 'Path Timeshift  (video-timeshift_abs-start.m3u8)'),
        ('simple_offset',  'Simple Offset  (archive=start)'),
    ]
    _EPG_PATTERNS = [
        ('ottp',         'ottp.eu.org database (recommended)'),
        ('ott-play',     'OTT-play / DRM-play (gabbarit API)'),
        ('provider_api', 'Provider own API URL'),
    ]

    def __init__(self, session, provider):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._prov       = dict(provider)
        self._is_builtin = (provider.get('type') == 'builtin')
        self.setTitle(T("Edit Provider") if self._is_builtin
                      else T("Edit Archives From Provider"))
        self["key_green"]  = Button(T("Save"))
        self["key_yellow"] = Button(T("PC Web Input") if not self._is_builtin else "")
        self["key_red"]    = Button(T("Cancel"))
        self["web_url"]    = Label("")
        self["editActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions"],
            {"ok":     self.keyOK,
             "save":   self.keySave,
             "green":  self.keySave,
             "cancel": self.close,
             "red":    self.close,
             "yellow": self._keyWebInput}, -2)
        self._buildCfgList()
        ConfigListScreen.__init__(self, self._entries, session=session)

        self._webserver = None
        self._pollTimer = eTimer()
        try:
            self._poll_conn = self._pollTimer.timeout.connect(self._pollWebInput)
        except Exception:
            self._pollTimer.callback.append(self._pollWebInput)
        self.onClose.append(self._stopWebServer)
        if not self._is_builtin:
            self._startWebServer()

    # ── config list ───────────────────────────────────────────────────────────

    def _buildCfgList(self):
        p   = self._prov
        ent = []
        if self._is_builtin:
            frags = ', '.join(sorted(p.get('fragments', [])))
            ent.append(getConfigListEntry(
                T("Provider Tag"),
                ConfigSelection(choices=[(p['tag'], p['tag'])], default=p['tag'])))
            ent.append(getConfigListEntry(
                T("URL Fragments"),
                ConfigSelection(choices=[(frags, frags)], default=frags)))
            self._cfg_days    = ConfigInteger(
                default=int(p.get('days', p.get('days_default', 7))), limits=(1, 7))
            self._cfg_enabled = ConfigYesNo(default=bool(p.get('enabled', True)))
            ent.append(getConfigListEntry(T("Archive Days Override"), self._cfg_days))
            ent.append(getConfigListEntry(T("Enabled"),              self._cfg_enabled))
        else:
            self._cfg_name    = ConfigText(
                default=(p.get('name') or ''), fixed_size=False)
            self._cfg_frag    = ConfigText(
                default=(p.get('url_fragment') or ''), fixed_size=False)
            self._cfg_days    = ConfigInteger(
                default=int(p.get('days', 7) or 7), limits=(1, 7))
            _arch_def         = p.get('archive_pattern', 'standard')
            self._cfg_arch    = ConfigSelection(
                choices=[(v, T(l)) for v, l in self._ARCHIVE_PATTERNS],
                default=_arch_def if any(v == _arch_def
                                         for v, _ in self._ARCHIVE_PATTERNS)
                        else 'standard')
            _epg_def          = p.get('epg_pattern', 'ottp')
            self._cfg_epg     = ConfigSelection(
                choices=[(v, T(l)) for v, l in self._EPG_PATTERNS],
                default=_epg_def if any(v == _epg_def
                                        for v, _ in self._EPG_PATTERNS)
                        else 'ottp')
            self._cfg_epg_url = ConfigText(
                default=(p.get('epg_url_template') or ''), fixed_size=False)
            self._cfg_enabled = ConfigYesNo(default=bool(p.get('enabled', True)))
            ent.append(getConfigListEntry(T("Provider Name"),        self._cfg_name))
            ent.append(getConfigListEntry(T("URL Fragment"),         self._cfg_frag))
            ent.append(getConfigListEntry(T("Archive Days (1-7)"),   self._cfg_days))
            ent.append(getConfigListEntry(T("Archive URL Pattern"),  self._cfg_arch))
            ent.append(getConfigListEntry(T("EPG Source"),           self._cfg_epg))
            ent.append(getConfigListEntry(T("EPG API URL Template"), self._cfg_epg_url))
            ent.append(getConfigListEntry(T("Enabled"),              self._cfg_enabled))
        self._entries = ent

    # ── web input ─────────────────────────────────────────────────────────────

    def _keyWebInput(self):
        if self._is_builtin:
            return
        if self._webserver is None:
            self._startWebServer()
        else:
            self._stopWebServer()
            self["web_url"].setText("")

    def _startWebServer(self):
        if not _WEB_INPUT_OK:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))
            return
        p = self._prov
        prefill = {
            '_is_edit':         True,
            'name':             (p.get('name') or ''),
            'url_fragment':     (p.get('url_fragment') or ''),
            'days':             str(int(p.get('days', 7) or 7)),
            'archive_pattern':  p.get('archive_pattern', 'standard'),
            'epg_pattern':      p.get('epg_pattern', 'ottp'),
            'epg_url_template': (p.get('epg_url_template') or ''),
            'enabled':          '1' if p.get('enabled', True) else '0',
            'ui_language': _get_enigma2_lang(),
        }
        self._webserver = IPTVWebInputServer(WEB_PORT, upload_dir=getDataDir())
        ok, ip, port = self._webserver.start(prefill=prefill, form_type='integrated')
        if ok:
            url = "http://%s:%d" % (ip, port)
            self["web_url"].setText("PC Input: %s" % url)
            self._pollTimer.start(500, True)
        else:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))

    def _stopWebServer(self):
        self._pollTimer.stop()
        if self._webserver is not None:
            self._webserver.stop()
            self._webserver = None

    def _pollWebInput(self):
        if self._webserver is None:
            return
        data = self._webserver.poll()
        if data:
            self._applyWebData(data)
        else:
            self._pollTimer.start(500, True)

    def _applyWebData(self, data):
        self._pollTimer.stop()
        if self._webserver:
            self._webserver.stop()
            self._webserver = None
        self["web_url"].setText(T("PC Input: data received — fields updated"))

        def _str(k):
            return (data.get(k) or '').strip()

        if _str('name'):
            self._cfg_name.value = _str('name')
        if _str('url_fragment'):
            self._cfg_frag.value = _str('url_fragment')
        if _str('days'):
            try:
                self._cfg_days.value = max(1, min(7, int(_str('days'))))
            except (ValueError, TypeError):
                pass
        if _str('archive_pattern') and any(
                v == _str('archive_pattern') for v, _ in self._ARCHIVE_PATTERNS):
            self._cfg_arch.value = _str('archive_pattern')
        if _str('epg_pattern') and any(
                v == _str('epg_pattern') for v, _ in self._EPG_PATTERNS):
            self._cfg_epg.value = _str('epg_pattern')
        if _str('epg_url_template'):
            self._cfg_epg_url.value = _str('epg_url_template')
        if _str('enabled') in ('0', '1'):
            self._cfg_enabled.value = (_str('enabled') == '1')
        self._buildCfgList()
        self["config"].setList(self._entries)

    # ── ok / save ─────────────────────────────────────────────────────────────

    def keyOK(self):
        ConfigListScreen.keyOK(self)

    def keySave(self):
        p  = self._prov
        ps = loadPluginSettings()
        if self._is_builtin:
            tag     = p['tag']
            day_ovr = dict(ps.get('integrated_provider_days_overrides', {}))
            new_days = int(self._cfg_days.value)
            if new_days != p.get('days_default', new_days):
                day_ovr[tag] = new_days
            else:
                day_ovr.pop(tag, None)
            ps['integrated_provider_days_overrides'] = day_ovr
            stopped = list(ps.get('stopped_provider_tags', []))
            if self._cfg_enabled.value:
                if tag in stopped:
                    stopped.remove(tag)
            else:
                if tag not in stopped:
                    stopped.append(tag)
            ps['stopped_provider_tags'] = stopped
            savePluginSettings(ps)
        else:
            customs = list(ps.get('integrated_providers_custom', []))
            _name   = (self._cfg_name.value or '').strip()
            _frag   = (self._cfg_frag.value or '').strip()
            _tag    = _name.lower().replace(' ', '-') if _name else \
                      (_frag.split('.')[0] if _frag else 'custom')
            new_entry = {
                'name':             _name,
                'tag':              _tag,
                'url_fragment':     _frag,
                'days':             int(self._cfg_days.value),
                'archive_pattern':  self._cfg_arch.value,
                'epg_pattern':      self._cfg_epg.value,
                'epg_url_template': (self._cfg_epg_url.value or '').strip(),
                'enabled':          bool(self._cfg_enabled.value),
            }
            idx = p.get('idx', -1)
            if 0 <= idx < len(customs):
                customs[idx] = new_entry
            else:
                customs.append(new_entry)
            ps['integrated_providers_custom'] = customs
            savePluginSettings(ps)
        self.close(True)


# ===========================================================================
# IPTVXtreamMediaChoiceScreen — two-panel live-channel selector for Xtream.
# Fetches live categories + streams via player_api.php in a background thread.
# Same key layout as IPTVChannelBrowserScreen.
# Returns set of selected stream_id strings on Blue (Apply), None on EXIT.
# ===========================================================================

class IPTVXtreamMediaChoiceScreen(Screen):
    _SKIN_T = """
        <screen position="center,center" size="1376,828" title="Xtream Media Choice" backgroundColor="#33000000">
            <widget name="bouquet_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="channel_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="bouquet_list"  position="11,71"  size="662,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" transparent="1"/>
            <widget name="channel_list"  position="684,71" size="681,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" transparent="1"/>
            <widget name="key_web"    position="11,725"   size="1020,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="excl_label" position="1040,725" size="325,36"
                    font="Regular;26" valign="center" halign="right"
                    foregroundColor="#2ecc71" transparent="1" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="470,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="813,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1157,776" size="204,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
            <widget name="key_hint"   position="11,790"   size="1354,1"
                    font="Regular;1" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1376,828" title="Xtream Media Choice">
            <widget name="bouquet_title" position="11,12"  size="662,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="channel_title" position="684,12" size="681,57"
                    font="Regular;32" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="bouquet_list"  position="11,71"  size="662,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" />
            <widget name="channel_list"  position="684,71" size="681,652"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="42" />
            <widget name="key_web"    position="11,725"   size="1020,36"
                    font="Regular;30" valign="center" halign="center"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="excl_label" position="1040,725" size="325,36"
                    font="Regular;26" valign="center" halign="right"
                    foregroundColor="#2ecc71" />
            <eLabel position="0,761" size="1376,1" backgroundColor="#00aa00"/>
            <ePixmap position="79,781"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="422,781"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="766,781"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1109,781" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <widget name="key_red"    position="127,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="470,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="813,776"  size="253,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_blue"   position="1157,776" size="204,35" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <eLabel position="0,827" size="1376,1" backgroundColor="#00aa00"/>
            <widget name="key_hint"   position="11,790"   size="1354,1"
                    font="Regular;1" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session, provider_data):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._provider_data  = provider_data
        self._focus_left     = True
        self._groups_order   = []
        self._groups_map     = {}
        self._bouquet_checked = {}
        self._channel_checked = {}
        self._loaded         = False
        self._pending_groups_order = []
        self._pending_groups_map   = {}
        self._done_timer     = None
        self._xt_web_server  = None
        self._xt_web_timer   = None
        self._visible_groups = []

        excluded = provider_data.get('excluded_stream_ids') or []
        self._excluded_ids = set(str(x) for x in excluded)

        self["bouquet_title"] = Label('')
        self["channel_title"] = Label('')
        self["bouquet_list"]  = MenuList([], enableWrapAround=True)
        self["channel_list"]  = MenuList([], enableWrapAround=True)
        self["key_red"]       = Label(T("Select All"))
        self["key_green"]     = Label(T("Switch Panel"))
        self["key_yellow"]    = Label(T("Deselect All"))
        self["key_blue"]      = Label(T("Apply Selection"))
        self["excl_label"]    = Label("")
        self["key_hint"]      = Label(
            T("OK") + u" \u2014 " + T("Toggle") +
            u"   |   " + T("GREEN") + u" \u2014 " + T("Switch Panel") +
            u"   |   " + T("RED") + u" \u2014 " + T("Select All") +
            u"   |   " + T("YELLOW") + u" \u2014 " + T("Deselect All") +
            u"   |   " + T("BLUE") + u" \u2014 " + T("Apply Selection") +
            u"   |   " + T("EXIT") + u" \u2014 " + T("Cancel"))
        self["key_web"]       = Label(T("Loading Xtream channels, please wait..."))

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {"cancel": self.keyCancel, "ok": self.keyOk,
             "red":    self.keySelectAll,  "green": self.toggleWindow,
             "yellow": self.keyDeselectAll, "blue": self.keyApply,
             "up": self.navUp, "down": self.navDown,
             "left": self.navLeft, "right": self.navRight}, -2)

        self._load_timer = eTimer()
        try:
            self._load_timer.timeout.connect(self._startLoading)
        except Exception:
            self._load_timer.callback.append(self._startLoading)
        self._load_timer.start(200, True)

    # ---- loading ----

    def _startLoading(self):
        server = (self._provider_data.get('xtream_url') or '').strip().rstrip('/')
        xtype  = (self._provider_data.get('xtream_type') or 'user_pass')
        if xtype == 'user_pass':
            user = (self._provider_data.get('xtream_username') or '').strip()
            pw   = (self._provider_data.get('xtream_password') or '').strip()
            api_url = '%s/player_api.php?username=%s&password=%s' % (server, user, pw)
        else:
            token = (self._provider_data.get('xtream_token') or '').strip()
            api_url = '%s/player_api.php?token=%s' % (server, token)
        import threading as _thr
        t = _thr.Thread(target=self._loadThread, args=(api_url,))
        t.daemon = True
        t.start()

    @staticmethod
    def _isSep(grp):
        return grp.startswith('__SEP__')

    @staticmethod
    def _sepLabel(grp):
        title = grp[7:]
        return u'\u2015\u2015\u2015  %s  \u2015\u2015\u2015' % title

    def _loadThread(self, api_url):
        groups_order = []
        groups_map   = {}

        def _addSection(label):
            key = '__SEP__' + label
            groups_order.append(key)
            groups_map[key] = []

        def _addStreams(cat_list, stream_list):
            cat_map = {}
            for c in (cat_list or []):
                cid  = str(c.get('category_id', ''))
                name = (c.get('category_name') or '').strip() or T('(no group)')
                cat_map[cid] = name
            for s in (stream_list or []):
                cid = str(s.get('category_id', ''))
                grp = cat_map.get(cid) or T('(no group)')
                if grp not in groups_map:
                    groups_map[grp] = []
                    groups_order.append(grp)
                sid  = str(s.get('stream_id', ''))
                name = (s.get('name') or '').strip() or sid
                if sid:
                    groups_map[grp].append({'stream_id': sid, 'name': name})

        try:
            live_cats    = _fetchXtreamApiJson(api_url + '&action=get_live_categories') or []
            live_streams = _fetchXtreamApiJson(api_url + '&action=get_live_streams')    or []
        except Exception:
            live_cats = live_streams = []
        _addSection(T("Live TV"))
        _addStreams(live_cats, live_streams)

        try:
            vod_cats    = _fetchXtreamApiJson(api_url + '&action=get_vod_categories') or []
            vod_streams = _fetchXtreamApiJson(api_url + '&action=get_vod_streams')    or []
        except Exception:
            vod_cats = vod_streams = []
        _addSection(T("VOD"))
        _addStreams(vod_cats, vod_streams)

        try:
            ser_cats    = _fetchXtreamApiJson(api_url + '&action=get_series_categories') or []
            ser_streams = _fetchXtreamApiJson(api_url + '&action=get_series')            or []
        except Exception:
            ser_cats = ser_streams = []
        _addSection(T("Series"))
        _addStreams(ser_cats, ser_streams)

        self._pending_groups_order = groups_order
        self._pending_groups_map   = groups_map
        self._done_timer = eTimer()
        try:
            self._done_timer.timeout.connect(self._onLoadDone)
        except Exception:
            self._done_timer.callback.append(self._onLoadDone)
        self._done_timer.start(50, True)

    def _onLoadDone(self):
        self._groups_order = self._pending_groups_order
        self._groups_map   = self._pending_groups_map
        # Build a map of sid -> list of groups it appears in
        _sid_groups = {}
        for grp, streams in self._groups_map.items():
            if self._isSep(grp):
                continue
            for s in streams:
                sid = s['stream_id']
                _sid_groups.setdefault(sid, []).append(grp)
        for grp, streams in self._groups_map.items():
            if self._isSep(grp):
                continue
            for s in streams:
                sid = s['stream_id']
                if sid in self._excluded_ids:
                    # Only mark excluded in this group if ALL sids in this group
                    # are excluded — meaning the group was intentionally excluded.
                    # If only some sids match, it may be a cross-category collision.
                    _grp_sids = set(str(x['stream_id']) for x in streams)
                    _all_excl  = _grp_sids.issubset(self._excluded_ids)
                    self._channel_checked[(grp, sid)] = not _all_excl
                else:
                    self._channel_checked[(grp, sid)] = True
            self._bouquet_checked[grp] = any(
                self._channel_checked.get((grp, s['stream_id']), True) for s in streams)
        self._loaded = True
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()
        self._initWebServer()

    # ---- web server ----

    def _initWebServer(self):
        if not _WEB_INPUT_OK:
            self["key_web"].setText(T("PC Xtream Browser: not available"))
            return
        try:
            from ._epg import loadPluginSettings as _lps
            _is_ru = _lps().get('ui_language', 'ENG') == 'RUS'
        except Exception:
            _is_ru = False
        channels_for_web = []
        prov_name = (self._provider_data.get('name') or '').strip()
        for grp in self._groups_order:
            for s in self._groups_map[grp]:
                channels_for_web.append({
                    'group_title': grp,
                    'tvg_name':    s['name'],
                    'url':         s['stream_id'],
                    'provider_name': prov_name,
                })
        checked_ids = set(
            sid for (grp, sid), v in self._channel_checked.items() if v)
        self._xt_web_server = IPTVChannelBrowserWebServer(WEB_XTREAM_BROWSER_PORT)
        ok, ip, port = self._xt_web_server.start(
            channels_for_web, is_ru=_is_ru, selected_urls=checked_ids)
        if ok:
            _url = u'http://%s:%d' % (ip, port)
            self["key_web"].setText(
                T("PC Xtream Browser: open  %s  in your browser") % _url)
            self._xt_web_timer = eTimer()
            try:
                self._xt_web_timer.timeout.connect(self._pollWebInput)
            except Exception:
                self._xt_web_timer.callback.append(self._pollWebInput)
            self._xt_web_timer.start(500, False)
        else:
            self["key_web"].setText(T("PC Xtream Browser: not available"))

    def _stopWebServer(self):
        if self._xt_web_timer is not None:
            try:
                self._xt_web_timer.stop()
            except Exception:
                pass
            self._xt_web_timer = None
        if self._xt_web_server is not None:
            self._xt_web_server.stop()
            self._xt_web_server = None

    def _pollWebInput(self):
        if self._xt_web_server is None:
            return
        result = self._xt_web_server.poll()
        if result is not None:
            self._applyWebSelection(result)

    def _applyWebSelection(self, selected_ids):
        id_set = set(str(x) for x in selected_ids)
        for grp in self._groups_order:
            if self._isSep(grp):
                continue
            grp_has = False
            for s in self._groups_map[grp]:
                sid = s['stream_id']
                checked = sid in id_set
                self._channel_checked[(grp, sid)] = checked
                if checked:
                    grp_has = True
            self._bouquet_checked[grp] = grp_has
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()
        self["key_web"].setText(T("Selection received from PC browser"))

    # ---- rendering helpers ----

    def _bouquetLabel(self, grp):
        if self._isSep(grp):
            return self._sepLabel(grp)
        chk   = u'\u2713' if self._bouquet_checked.get(grp, True) else u' '
        total   = len(self._groups_map[grp])
        checked = sum(
            1 for s in self._groups_map[grp]
            if self._channel_checked.get((grp, s['stream_id']), True)
        )
        count_str = u'(%d/%d)' % (checked, total) if checked < total else u'(%d)' % total
        return u'[%s] %s  %s' % (chk, grp, count_str)

    def _channelLabel(self, grp, s):
        sid  = s['stream_id']
        name = s['name']
        chk  = u'\u2713' if self._channel_checked.get((grp, sid), True) else u' '
        return u'[%s] %s' % (chk, name)

    def _visibleGroups(self):
        """Return groups_order filtered: empty non-separator groups are dropped,
        and section separators with no visible groups beneath them are also dropped."""
        result = []
        i = 0
        while i < len(self._groups_order):
            grp = self._groups_order[i]
            if self._isSep(grp):
                has_content = False
                j = i + 1
                while j < len(self._groups_order):
                    ng = self._groups_order[j]
                    if self._isSep(ng):
                        break
                    if len(self._groups_map.get(ng, [])) > 0:
                        has_content = True
                        break
                    j += 1
                if has_content:
                    result.append(grp)
            else:
                if len(self._groups_map.get(grp, [])) > 0:
                    result.append(grp)
            i += 1
        return result

    def _refreshBouquetList(self):
        self._visible_groups = self._visibleGroups()
        self["bouquet_list"].setList(
            [self._bouquetLabel(grp) for grp in self._visible_groups])

    def _currentGroup(self):
        try:
            idx = self["bouquet_list"].getSelectedIndex()
        except Exception:
            idx = 0
        if 0 <= idx < len(self._visible_groups):
            return idx, self._visible_groups[idx]
        return 0, None

    def _updateChannelList(self, restore_idx=None):
        _, grp = self._currentGroup()
        if grp is None:
            self["channel_list"].setList([])
            return
        entries = [self._channelLabel(grp, s) for s in self._groups_map[grp]]
        self["channel_list"].setList(entries)
        if restore_idx is not None and restore_idx > 0:
            try:
                self["channel_list"].instance.moveSelectionTo(restore_idx)
            except Exception:
                try:
                    for _ in range(restore_idx):
                        self["channel_list"].down()
                except Exception:
                    pass
        else:
            try:
                self["channel_list"].instance.moveSelection(
                    self["channel_list"].instance.moveTop)
            except Exception:
                pass

    def _updateTitles(self):
        _, grp   = self._currentGroup()
        ch_count = len(self._groups_map.get(grp, []))
        _vis_real = [g for g in self._visible_groups if not self._isSep(g)]
        sel_b    = sum(1 for g in _vis_real if self._bouquet_checked.get(g, True))
        sel_ch   = sum(1 for v in self._channel_checked.values() if v)
        if not self._loaded:
            self["bouquet_title"].setText(T("Loading Xtream channels, please wait..."))
            self["channel_title"].setText('')
            return
        _total_b   = len(_vis_real)
        prov = (self._provider_data.get('name') or '').strip()
        title_base = (T("Xtream Media Choice") + (u'  \u2014  ' + prov if prov else ''))
        _grp_display = (grp[7:] if grp and self._isSep(grp) else grp) if grp else None
        # Count excluded (unchecked) channels across all groups
        _excl_count = sum(
            1 for (grp_k, sid_k), v in self._channel_checked.items()
            if not v and grp_k in self._groups_map
        )
        try:
            self["excl_label"].setText(
                (T("Excluded") + u': %d' % _excl_count) if _excl_count else u'')
        except Exception:
            pass
        if self._focus_left:
            self["bouquet_title"].setText(
                u'\u25ba ' + T("Bouquets") + u'  (%d/%d)' % (sel_b, _total_b))
            self["channel_title"].setText(
                u'   ' + T("Xtream Media") +
                (u': ' + _grp_display if _grp_display else u''))
        else:
            self["bouquet_title"].setText(
                u'   ' + T("Bouquets") + u'  (%d/%d)' % (sel_b, _total_b))
            self["channel_title"].setText(
                u'\u25ba ' + T("Xtream Media") +
                (u': ' + _grp_display if _grp_display else u''))

    # ---- key handlers ----

    def toggleWindow(self):
        self._focus_left = not self._focus_left
        self._updateTitles()

    def keyOk(self):
        if not self._loaded:
            return
        if self._focus_left:
            _, grp = self._currentGroup()
            if grp is not None and not self._isSep(grp):
                new_state = not self._bouquet_checked.get(grp, True)
                self._bouquet_checked[grp] = new_state
                for s in self._groups_map.get(grp, []):
                    self._channel_checked[(grp, s['stream_id'])] = new_state
                self._refreshBouquetList()
                self._updateChannelList()
                self._updateTitles()
        else:
            _, grp = self._currentGroup()
            if grp is None:
                return
            try:
                ch_idx = self["channel_list"].getSelectedIndex()
            except Exception:
                ch_idx = 0
            streams = self._groups_map.get(grp, [])
            if 0 <= ch_idx < len(streams):
                sid = streams[ch_idx]['stream_id']
                key = (grp, sid)
                self._channel_checked[key] = not self._channel_checked.get(key, True)
                self._updateChannelList(restore_idx=ch_idx)
                self._refreshBouquetList()
                self._updateTitles()

    def keySelectAll(self):
        for grp in self._groups_order:
            if self._isSep(grp):
                continue
            self._bouquet_checked[grp] = True
            for s in self._groups_map[grp]:
                self._channel_checked[(grp, s['stream_id'])] = True
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()

    def keyDeselectAll(self):
        for grp in self._groups_order:
            if self._isSep(grp):
                continue
            self._bouquet_checked[grp] = False
            for s in self._groups_map[grp]:
                self._channel_checked[(grp, s['stream_id'])] = False
        self._refreshBouquetList()
        self._updateChannelList()
        self._updateTitles()

    def keyApply(self):
        self._stopWebServer()
        excluded = set()
        for grp in self._groups_order:
            if self._isSep(grp):
                continue
            for s in self._groups_map[grp]:
                sid = s['stream_id']
                if not self._channel_checked.get((grp, sid), True):
                    excluded.add(sid)
        self.close(excluded)

    def keyCancel(self):
        self._stopWebServer()
        self.close(None)

    # ---- navigation ----

    def _moveList(self, lst, direction):
        try:
            if   direction == 'up':       lst.up()
            elif direction == 'down':     lst.down()
            elif direction == 'pageup':   lst.pageUp()
            elif direction == 'pagedown': lst.pageDown()
        except Exception:
            pass

    def navUp(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'up')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'up')
        self._updateTitles()

    def navDown(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'down')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'down')
        self._updateTitles()

    def navLeft(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'pageup')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'pageup')
        self._updateTitles()

    def navRight(self):
        if self._focus_left:
            self._moveList(self["bouquet_list"], 'pagedown')
            self._updateChannelList()
        else:
            self._moveList(self["channel_list"], 'pagedown')
        self._updateTitles()


# ===========================================================================
# IPTVXtreamProviderEditDialog — add / edit one Xtream-only provider.
# Shows ONLY Xtream fields; M3U / XMLTV / channel-ordering fields are omitted.
# ===========================================================================

class IPTVXtreamProviderEditDialog(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,800"
                title="Xtream Media Provider" backgroundColor="#33000000">
            <widget name="config" position="10,10" size="1230,680"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" transparent="1" />
            <widget name="web_url" position="10,690" size="1230,30"
                    font="Regular;28" halign="center" foregroundColor="#f0c040" transparent="1" />
            <ePixmap position="72,752"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,752"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,752"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="950,752"  size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,732" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,799" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,745" size="264,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="427,745" size="264,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="739,745" size="206,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="993,745" size="252,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,800"
                title="Xtream Media Provider">
            <widget name="config" position="10,10" size="1230,680"
                    scrollbarMode="showOnDemand" font="Regular;26"
                    itemHeight="40" />
            <widget name="web_url" position="10,690" size="1230,30"
                    font="Regular;28" halign="center" foregroundColor="#f0c040" transparent="1" />
            <ePixmap position="72,752"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,752"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,752"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="950,752"  size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,732" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,799" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,745" size="264,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_green"  position="427,745" size="264,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_yellow" position="739,745" size="206,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
            <widget name="key_blue"   position="993,745" size="252,40" zPosition="1"
                    font="Regular;24" valign="center" halign="left" />
        </screen>"""
    skin    = _SKIN_T


    _XTREAM_TYPE = [
        ('user_pass', "Xtream Codes (Username / Password)"),
        ('token',     "Xtream (Token)"),
    ]
    _XTREAM_OUTPUT = [
        ('m3u8', "HLS / m3u8 (Recommended)"),
        ('ts',   "TS"),
    ]
    _XTREAM_STRATEGY = [
        ('same_as_provider',  "Same As Provider"),
        ('group_into_folder', "Group All Into One Folder"),
    ]
    _XTREAM_PICON = [
        ('off',          "Off"),
        ('display_name', "With Display Name"),
        ('reference',    "With Reference Number"),
    ]
    _STREAM_TYPE = [
        ('4097', "GStreamer (4097)"),
        ('5001', "GstPlayer (5001)"),
        ('5002', "ExtePlayer3 (5002)"),
    ]
    _XTREAM_ORDER = [
        ('provider',     "Use Provider Order"),
        ('alphabetical', "Alphabetically"),
        ('user_defined', "User Defined (Use for Sorted Channels/Bouquets)"),
    ]

    def __init__(self, session, provider_data, is_edit=False, prov_idx=None):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._is_edit = is_edit
        self._prov_idx = prov_idx
        self.setTitle(T("Edit Xtream Provider") if is_edit else T("Add Xtream Provider"))
        self._cfg = {
            'enabled':            ConfigYesNo(default=bool(provider_data.get('enabled', True))),
            'name':               ConfigText(default=provider_data.get('name', '') or '', fixed_size=False),
            'xtream_type':        ConfigSelection(
                choices=[(v, T(l)) for v, l in self._XTREAM_TYPE],
                default=provider_data.get('xtream_type', 'user_pass')),
            'xtream_url':         ConfigText(default=provider_data.get('xtream_url', '') or '', fixed_size=False),
            'xtream_username':    ConfigText(default=provider_data.get('xtream_username', '') or '', fixed_size=False),
            'xtream_password':    ConfigText(default=provider_data.get('xtream_password', '') or '', fixed_size=False),
            'xtream_token':       ConfigText(default=provider_data.get('xtream_token', '') or '', fixed_size=False),
            'xtream_output':      ConfigSelection(
                choices=[(v, T(l)) for v, l in self._XTREAM_OUTPUT],
                default=provider_data.get('xtream_output', 'm3u8')),
            'xtream_strategy':    ConfigSelection(
                choices=[(v, T(l)) for v, l in self._XTREAM_STRATEGY],
                default=provider_data.get('xtream_strategy', 'same_as_provider')),
            'channel_order':      ConfigSelection(
                choices=[(v, T(l)) for v, l in self._XTREAM_ORDER],
                default=provider_data.get('channel_order', 'provider')),
            'xtream_picon':       ConfigSelection(
                choices=[(v, T(l)) for v, l in self._XTREAM_PICON],
                default=provider_data.get('xtream_picon', 'off')),
            'xtream_picon_symlink': ConfigYesNo(
                default=bool(provider_data.get('xtream_picon_symlink', False))),
            'xtream_picon_with_folder': ConfigYesNo(
                default=bool(provider_data.get('xtream_picon_with_folder', True))),
            'xtream_show_live':   ConfigYesNo(default=bool(provider_data.get('xtream_show_live', True))),
            'xtream_live_type':   ConfigSelection(
                choices=[(v, T(l)) for v, l in self._STREAM_TYPE],
                default=provider_data.get('xtream_live_type', '4097')),
            'xtream_show_vod':    ConfigYesNo(default=bool(provider_data.get('xtream_show_vod', True))),
            'xtream_vod_type':    ConfigSelection(
                choices=[(v, T(l)) for v, l in self._STREAM_TYPE],
                default=provider_data.get('xtream_vod_type', '4097')),
            'xtream_show_series': ConfigYesNo(default=bool(provider_data.get('xtream_show_series', True))),
            'xtream_series_type': ConfigSelection(
                choices=[(v, T(l)) for v, l in self._STREAM_TYPE],
                default=provider_data.get('xtream_series_type', '4097')),
            'clean_bouquets':     ConfigYesNo(default=False),
            'custom_epg_enabled': ConfigYesNo(
                default=bool(provider_data.get('custom_epg_enabled', True))),
            'create_archive_markers': ConfigYesNo(
                default=bool(provider_data.get('create_archive_markers', False))),
        }
        # update_mode_sub for User Defined order
        _xt_saved_update = provider_data.get('update_playlist_mode', 'off')
        if _xt_saved_update not in ('top', 'bottom'):
            _xt_saved_update = 'top'
        self._cfg['update_mode_sub'] = ConfigSelection(
            choices=[('top', T("New Channels on Top")), ('bottom', T("New Channels on Bottom"))],
            default=_xt_saved_update)
        self._cfg['channel_order'].addNotifier(self._onOrderChanged, initial_call=False)
        # Dynamic mount-point list for Xtream picon location
        _xt_mount_choices = [('/usr/share/enigma2/picon', '/usr/share/enigma2/picon')]
        try:
            for _mp in _detectMediaPaths():
                if _mp != '/etc':
                    _xt_mount_choices.append(('%s/picon' % _mp, '%s/picon' % _mp))
        except Exception:
            pass
        _xt_saved_loc = provider_data.get('xtream_picon_location', '/usr/share/enigma2/picon')
        if _xt_saved_loc in ('enigma2_picon', 'plugin_dir', ''):
            _xt_saved_loc = '/usr/share/enigma2/picon'
        if _xt_saved_loc not in [v for v, _ in _xt_mount_choices]:
            _xt_mount_choices.append((_xt_saved_loc, _xt_saved_loc))
        self._cfg['xtream_picon_location'] = ConfigSelection(
            choices=_xt_mount_choices, default=_xt_saved_loc)
        lst = self._buildList()
        ConfigListScreen.__init__(self, lst, session=session)
        self._cfg['xtream_type'].addNotifier(self._onTypeChanged, initial_call=False)
        self._cfg['xtream_show_live'].addNotifier(self._onBuildChanged, initial_call=False)
        self._cfg['xtream_show_vod'].addNotifier(self._onBuildChanged, initial_call=False)
        self._cfg['xtream_show_series'].addNotifier(self._onBuildChanged, initial_call=False)
        self._cfg['xtream_picon'].addNotifier(self._onBuildChanged, initial_call=False)
        self._testing  = False
        self._webserver = None
        self._excluded_stream_ids = set(
            str(x) for x in (provider_data.get('excluded_stream_ids') or []))
        _n = len(self._excluded_stream_ids)
        _blue_lbl = T("Media Choice")
        self["key_red"]    = Button(T("Delete Provider"))
        self["key_green"]  = Button(T("Save"))
        self["key_yellow"] = Button(T("Check Status"))
        self["key_blue"]   = Button(_blue_lbl)
        self["web_url"]    = Label("")
        self["xtEditActions"] = ActionMap(
            ["ColorActions", "OkCancelActions", "SetupActions"],
            {"cancel": self.keyExit,
             "red":    self.keyDelete,
             "green":  self.keySave,
             "yellow": self.keyTest,
             "blue":   self.keyMediaChoice,
             "save":   self.keySave}, -2)
        self._pollTimer = eTimer()
        try:
            self._poll_conn = self._pollTimer.timeout.connect(self._pollWebInput)
        except Exception:
            self._pollTimer.callback.append(self._pollWebInput)
        self.onClose.append(self._stopWebServer)
        self._startWebServer()

    def _buildList(self):
        entries = [
            getConfigListEntry(T("Enabled"),               self._cfg['enabled']),
            getConfigListEntry(T("Provider Name"),          self._cfg['name']),
            getConfigListEntry(T("Xtream Type"),            self._cfg['xtream_type']),
            getConfigListEntry(T("Xtream URL"),             self._cfg['xtream_url']),
        ]
        if self._cfg['xtream_type'].value == 'user_pass':
            entries.append(getConfigListEntry(T("Xtream Username"),   self._cfg['xtream_username']))
            entries.append(getConfigListEntry(T("Xtream Password"),   self._cfg['xtream_password']))
        else:
            entries.append(getConfigListEntry(T("Xtream Token"),      self._cfg['xtream_token']))
        entries += [
            getConfigListEntry(T("Stream Output"),          self._cfg['xtream_output']),
            getConfigListEntry(T("Bouquet Strategy"),        self._cfg['xtream_strategy']),
            getConfigListEntry(T("Channels Ordering By"),    self._cfg['channel_order']),
        ]
        if self._cfg['channel_order'].value == 'user_defined':
            entries.append(getConfigListEntry(
                T("Update M3U Playlist Only"), self._cfg['update_mode_sub']))
        entries += [
            getConfigListEntry(T("Build Live TV Bouquets"), self._cfg['xtream_show_live']),
        ]
        if self._cfg['xtream_show_live'].value:
            entries.append(getConfigListEntry(T("  Stream Type"), self._cfg['xtream_live_type']))
        entries.append(getConfigListEntry(T("Build VOD Bouquets"), self._cfg['xtream_show_vod']))
        if self._cfg['xtream_show_vod'].value:
            entries.append(getConfigListEntry(T("  Stream Type"), self._cfg['xtream_vod_type']))
        entries.append(getConfigListEntry(T("Build Series Bouquets"), self._cfg['xtream_show_series']))
        if self._cfg['xtream_show_series'].value:
            entries.append(getConfigListEntry(T("  Stream Type"), self._cfg['xtream_series_type']))
        entries += [
            getConfigListEntry(T("Download Picons"),         self._cfg['xtream_picon']),
        ]
        if self._cfg['xtream_picon'].value != 'off':
            entries.append(getConfigListEntry(T("  Mounted Points"), self._cfg['xtream_picon_location']))
            entries.append(getConfigListEntry(T("  With Folder"),    self._cfg['xtream_picon_with_folder']))
            entries.append(getConfigListEntry(T("  Create Symlink"), self._cfg['xtream_picon_symlink']))
        entries += [
            getConfigListEntry(T("Create Archive Markers ( ▶ )"),   self._cfg['create_archive_markers']),
            getConfigListEntry(T("Custom EPG File"),          self._cfg['custom_epg_enabled']),
            getConfigListEntry(T("Clean Bouquets"),          self._cfg['clean_bouquets']),
        ]
        return entries

    def _onTypeChanged(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _onOrderChanged(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _onBuildChanged(self, cfg=None):
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass

    def _startWebServer(self):
        if not _WEB_INPUT_OK:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))
            return
        prefill = {
            '_is_edit':             self._is_edit,
            'name':                 self._cfg['name'].value,
            'enabled':              '1' if self._cfg['enabled'].value else '0',
            'xtream_enabled':       '1',
            'xtream_type':          self._cfg['xtream_type'].value,
            'xtream_url':           self._cfg['xtream_url'].value,
            'xtream_username':      self._cfg['xtream_username'].value,
            'xtream_password':      self._cfg['xtream_password'].value,
            'xtream_token':         self._cfg['xtream_token'].value,
            'xtream_output':        self._cfg['xtream_output'].value,
            'xtream_strategy':      self._cfg['xtream_strategy'].value,
            'channel_order':        self._cfg['channel_order'].value,
            'xtream_picon':              self._cfg['xtream_picon'].value,
            'xtream_picon_location':      self._cfg['xtream_picon_location'].value,
            'xtream_picon_with_folder':   '1' if self._cfg['xtream_picon_with_folder'].value else '0',
            'xtream_picon_symlink':        '1' if self._cfg['xtream_picon_symlink'].value else '0',
            'xtream_clean_bouquets':       '0',
            'create_archive_markers':      '1' if self._cfg['create_archive_markers'].value else '0',
            'custom_epg_enabled':          '1' if self._cfg['custom_epg_enabled'].value else '0',
            'xtream_show_live':     '1' if self._cfg['xtream_show_live'].value else '0',
            'xtream_live_type':     self._cfg['xtream_live_type'].value,
            'xtream_show_vod':      '1' if self._cfg['xtream_show_vod'].value else '0',
            'xtream_vod_type':      self._cfg['xtream_vod_type'].value,
            'xtream_show_series':   '1' if self._cfg['xtream_show_series'].value else '0',
            'xtream_series_type':   self._cfg['xtream_series_type'].value,
            'ui_language': _get_enigma2_lang(),
        }
        _upload_dir = os.path.join(getDataDir(), 'IPTVXtreamCreator')
        try:
            os.makedirs(_upload_dir)
        except OSError:
            pass
        self._webserver = IPTVWebInputServer(WEB_PORT, upload_dir=_upload_dir)
        ok, ip, port = self._webserver.start(prefill=prefill, form_type='xtream')
        if ok:
            url = "http://%s:%d" % (ip, port)
            self["web_url"].setText("PC Input: %s" % url)
            self._pollTimer.start(500, True)
        else:
            self["web_url"].setText(T("PC Input: http://ipaddress:port"))

    def _pollWebInput(self):
        if self._webserver is None:
            return
        data = self._webserver.poll()
        if data:
            self._applyWebData(data)
        else:
            self._pollTimer.start(500, True)

    def _applyWebData(self, data):
        self._pollTimer.stop()
        if self._webserver:
            self._webserver.stop()
            self._webserver = None
        def _s(k): return (data.get(k) or '').strip()
        if _s('name'):            self._cfg['name'].value            = _s('name')
        if _s('xtream_url'):      self._cfg['xtream_url'].value      = _s('xtream_url')
        if _s('xtream_username'): self._cfg['xtream_username'].value = _s('xtream_username')
        if _s('xtream_password'): self._cfg['xtream_password'].value = _s('xtream_password')
        if _s('xtream_token'):    self._cfg['xtream_token'].value    = _s('xtream_token')
        if 'enabled' in data:
            self._cfg['enabled'].value = data['enabled'] not in ('0', 'false', 'False', 'no')
        if _s('xtream_type') in [v for v, _ in self._XTREAM_TYPE]:
            self._cfg['xtream_type'].value = _s('xtream_type')
        if _s('xtream_output') in [v for v, _ in self._XTREAM_OUTPUT]:
            self._cfg['xtream_output'].value = _s('xtream_output')
        if _s('xtream_strategy') in [v for v, _ in self._XTREAM_STRATEGY]:
            self._cfg['xtream_strategy'].value = _s('xtream_strategy')
        if _s('channel_order') in [v for v, _ in self._XTREAM_ORDER]:
            self._cfg['channel_order'].value = _s('channel_order')
        if _s('update_mode_sub') in ('top', 'bottom'):
            self._cfg['update_mode_sub'].value = _s('update_mode_sub')
        if _s('xtream_picon') in [v for v, _ in self._XTREAM_PICON]:
            self._cfg['xtream_picon'].value = _s('xtream_picon')
        if _s('xtream_picon_location'):
            _xt_loc = _s('xtream_picon_location')
            if _xt_loc in ('enigma2_picon', 'plugin_dir'):
                _xt_loc = '/usr/share/enigma2/picon'
            if _xt_loc in [v for v, _ in self._cfg['xtream_picon_location'].choices]:
                self._cfg['xtream_picon_location'].value = _xt_loc
        if 'xtream_picon_with_folder' in data:
            self._cfg['xtream_picon_with_folder'].value = data['xtream_picon_with_folder'] not in ('0', 'false', 'False', 'no')
        if 'xtream_picon_symlink' in data:
            self._cfg['xtream_picon_symlink'].value = data['xtream_picon_symlink'] not in ('0', 'false', 'False', 'no')
        if 'xtream_show_live' in data:
            self._cfg['xtream_show_live'].value = data['xtream_show_live'] not in ('0', 'false', 'False', 'no')
        if _s('xtream_live_type') in [v for v, _ in self._STREAM_TYPE]:
            self._cfg['xtream_live_type'].value = _s('xtream_live_type')
        if 'xtream_show_vod' in data:
            self._cfg['xtream_show_vod'].value = data['xtream_show_vod'] not in ('0', 'false', 'False', 'no')
        if _s('xtream_vod_type') in [v for v, _ in self._STREAM_TYPE]:
            self._cfg['xtream_vod_type'].value = _s('xtream_vod_type')
        if 'xtream_show_series' in data:
            self._cfg['xtream_show_series'].value = data['xtream_show_series'] not in ('0', 'false', 'False', 'no')
        if _s('xtream_series_type') in [v for v, _ in self._STREAM_TYPE]:
            self._cfg['xtream_series_type'].value = _s('xtream_series_type')
        if 'create_archive_markers' in data:
            self._cfg['create_archive_markers'].value = data['create_archive_markers'] not in ('0','false','False','no','')
        if 'custom_epg_enabled' in data:
            self._cfg['custom_epg_enabled'].value = data['custom_epg_enabled'] not in ('0','false','False','no','')
        if 'xtream_clean_bouquets' in data:
            self._cfg['clean_bouquets'].value = data['xtream_clean_bouquets'] not in ('0', 'false', 'False', 'no')
        try:
            lst = self._buildList()
            self["config"].list = lst
            self["config"].l.setList(lst)
        except Exception:
            pass
        self["web_url"].setText(T("PC Input: data received"))
        self.session.open(MessageBox,
            T("Provider data received from your PC browser!\nCheck the fields and press Save."),
            type=MessageBox.TYPE_INFO, timeout=4)

    def _stopWebServer(self):
        try:
            self._pollTimer.stop()
        except Exception:
            pass
        try:
            if self._webserver:
                self._webserver.stop()
                self._webserver = None
        except Exception:
            pass

    def keySave(self):
        _new_name = self._cfg['name'].value.strip()
        if _new_name:
            _skip_xt  = self._prov_idx if self._is_edit else None
            _conflict = _checkProviderNameConflict(_new_name,
                                                   skip_xtream_idx=_skip_xt)
            if _conflict:
                self.session.open(MessageBox,
                    T("Provider name '%s' conflicts with existing provider '%s'.\n"
                      "Each provider must have a unique name to avoid bouquet file collisions."
                      ) % (_new_name, _conflict),
                    type=MessageBox.TYPE_ERROR, timeout=8)
                return
        if self._cfg['clean_bouquets'].value:
            prov_name = self._cfg['name'].value.strip()
            if prov_name:
                _deletePlaylistProviderFiles(prov_name)
        self.close({
            'enabled':             self._cfg['enabled'].value,
            'name':                self._cfg['name'].value,
            'xtream_enabled':      True,
            'xtream_type':         self._cfg['xtream_type'].value,
            'xtream_url':          self._cfg['xtream_url'].value,
            'xtream_username':     self._cfg['xtream_username'].value,
            'xtream_password':     self._cfg['xtream_password'].value,
            'xtream_token':        self._cfg['xtream_token'].value,
            'xtream_output':       self._cfg['xtream_output'].value,
            'xtream_strategy':     self._cfg['xtream_strategy'].value,
            'channel_order':       self._cfg['channel_order'].value,
            'update_playlist_mode': (self._cfg['update_mode_sub'].value
                                     if self._cfg['channel_order'].value == 'user_defined'
                                     else 'off'),
            'xtream_picon':              self._cfg['xtream_picon'].value,
            'xtream_picon_location':     self._cfg['xtream_picon_location'].value,
            'xtream_picon_with_folder':  self._cfg['xtream_picon_with_folder'].value,
            'xtream_picon_symlink':      self._cfg['xtream_picon_symlink'].value,
            'xtream_show_live':    self._cfg['xtream_show_live'].value,
            'xtream_live_type':    self._cfg['xtream_live_type'].value,
            'xtream_show_vod':     self._cfg['xtream_show_vod'].value,
            'xtream_vod_type':     self._cfg['xtream_vod_type'].value,
            'xtream_show_series':  self._cfg['xtream_show_series'].value,
            'xtream_series_type':  self._cfg['xtream_series_type'].value,
            'clean_bouquets':      False,
            'custom_epg_enabled':      self._cfg['custom_epg_enabled'].value,
            'create_archive_markers':  self._cfg['create_archive_markers'].value,
            'excluded_stream_ids': list(self._excluded_stream_ids),
        })

    def keyDelete(self):
        if not self._is_edit:
            self.close(None)
            return
        name = self._cfg['name'].value.strip() or T('(unnamed)')
        self.session.openWithCallback(self._confirmDelete, MessageBox,
            T("Delete Xtream provider '%s'?\nThis will also remove all bouquet files\n"
              "created by this provider from /etc/enigma2.") % name,
            type=MessageBox.TYPE_YESNO)

    def _confirmDelete(self, confirmed):
        if confirmed:
            self.close({'_delete': True})

    def keyTest(self):
        if self._testing:
            self.session.open(MessageBox, T("Test already running, please wait."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        server = self._cfg['xtream_url'].value.strip().rstrip('/')
        if not server:
            self.session.open(MessageBox, T("Please enter an Xtream URL first."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        xtype = self._cfg['xtream_type'].value
        if xtype == 'user_pass':
            user = self._cfg['xtream_username'].value.strip()
            pw   = self._cfg['xtream_password'].value.strip()
            if not user or not pw:
                self.session.open(MessageBox,
                    T("Please enter both Username and Password before testing."),
                    type=MessageBox.TYPE_INFO, timeout=3)
                return
            api_url = '%s/player_api.php?username=%s&password=%s' % (server, user, pw)
        else:
            token = self._cfg['xtream_token'].value.strip()
            if not token:
                self.session.open(MessageBox,
                    T("Please enter the Xtream Token before testing."),
                    type=MessageBox.TYPE_INFO, timeout=3)
                return
            api_url = '%s/player_api.php?token=%s' % (server, token)
        self._testing = True
        self["key_yellow"].setText(T("Select Bouquets"))
        import threading as _thr
        t = _thr.Thread(target=self._testThread, args=(api_url,))
        t.daemon = True
        t.start()

    def _testThread(self, api_url):
        result = {'ok': False, 'error': '', 'user_info': {}, 'server_info': {}}
        try:
            data = _fetchXtreamApiJson(api_url, timeout=12)
            if data is None:
                result['error'] = T("No response from server.\nCheck the URL and credentials.")
            elif not isinstance(data, dict):
                result['error'] = T("Unexpected response format from server.")
            else:
                ui = data.get('user_info') or {}
                si = data.get('server_info') or {}
                if not ui:
                    result['error'] = T("Server responded but returned no account info.\n"
                                        "The credentials may be wrong or the server\n"
                                        "does not support the Xtream API.")
                else:
                    auth = ui.get('auth', 0)
                    if str(auth) in ('0', 'false', 'False') or auth is False:
                        result['error'] = T("Authentication failed — wrong credentials.")
                    else:
                        result['ok']          = True
                        result['user_info']   = ui
                        result['server_info'] = si
        except Exception as e:
            result['error'] = str(e)
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(self._testDone, result)
        except Exception:
            self._testDone(result)

    def _testDone(self, result):
        self._testing = False
        self["key_yellow"].setText(T("Check Status"))
        if not result.get('ok'):
            self.session.open(MessageBox,
                T("Connection test failed:\n%s") % result.get('error', T('Unknown error')),
                type=MessageBox.TYPE_ERROR, timeout=10)
            return
        ui = result['user_info']
        si = result['server_info']

        status   = (ui.get('status') or 'Unknown').strip()
        is_trial = str(ui.get('is_trial', '0')) not in ('0', 'false', 'False', '')
        active   = str(ui.get('active_cons', '?'))
        max_conn = str(ui.get('max_connections', '?'))

        exp_raw  = ui.get('exp_date') or ui.get('exp_date_txt') or ''
        try:
            import datetime as _dt
            exp_ts  = int(exp_raw)
            exp_str = _dt.datetime.utcfromtimestamp(exp_ts).strftime('%Y-%m-%d  %H:%M UTC')
        except Exception:
            exp_str = str(exp_raw) if exp_raw else T('Unknown')

        srv_url  = (si.get('url') or '').strip()
        srv_port = str(si.get('port') or si.get('https_port') or '')
        srv_tz   = (si.get('timezone') or '').strip()

        lines = [
            T("Connection test successful!"),
            '',
            T("Account Status : ") + status + ((' (' + T("Trial") + ')') if is_trial else ''),
            T("Expiry Date    : ") + exp_str,
            T("Connections    : ") + active + ' / ' + max_conn + T(" (active / max)"),
        ]
        if srv_url:
            lines.append(T("Server         : ") + srv_url
                         + ((':' + srv_port) if srv_port else ''))
        if srv_tz:
            lines.append(T("Timezone       : ") + srv_tz)
        out_fmts = ui.get('allowed_output_formats')
        if isinstance(out_fmts, list) and out_fmts:
            lines.append(T("Output formats : ") + ', '.join(out_fmts))

        self.session.open(MessageBox, '\n'.join(lines),
                          type=MessageBox.TYPE_INFO, timeout=15)

    def keyMediaChoice(self):
        server = self._cfg['xtream_url'].value.strip().rstrip('/')
        xtype  = self._cfg['xtream_type'].value
        if not server:
            self.session.open(MessageBox,
                T("Xtream URL or credentials are missing.\n"
                  "Please fill in the URL and credentials first."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return
        if xtype == 'user_pass':
            user = self._cfg['xtream_username'].value.strip()
            pw   = self._cfg['xtream_password'].value.strip()
            if not user or not pw:
                self.session.open(MessageBox,
                    T("Xtream URL or credentials are missing.\n"
                      "Please fill in the URL and credentials first."),
                    type=MessageBox.TYPE_INFO, timeout=4)
                return
        else:
            token = self._cfg['xtream_token'].value.strip()
            if not token:
                self.session.open(MessageBox,
                    T("Xtream URL or credentials are missing.\n"
                      "Please fill in the URL and credentials first."),
                    type=MessageBox.TYPE_INFO, timeout=4)
                return
        prov = {
            'name':               self._cfg['name'].value,
            'xtream_type':        xtype,
            'xtream_url':         server,
            'xtream_username':    self._cfg['xtream_username'].value.strip(),
            'xtream_password':    self._cfg['xtream_password'].value.strip(),
            'xtream_token':       self._cfg['xtream_token'].value.strip(),
            'excluded_stream_ids': list(self._excluded_stream_ids),
        }
        self.session.openWithCallback(
            self._onMediaChoiceDone, IPTVXtreamMediaChoiceScreen, prov)

    def _onMediaChoiceDone(self, excluded_ids):
        if excluded_ids is None:
            return
        self._excluded_stream_ids = set(str(x) for x in excluded_ids)
        n = len(self._excluded_stream_ids)
        self["key_blue"].setText(T("Media Choice"))
        if self._prov_idx is not None:
            try:
                _cfg = loadXtreamProviderConfig()
                _cfg[self._prov_idx]['excluded_stream_ids'] = list(self._excluded_stream_ids)
                saveXtreamProviderConfig(_cfg)
            except Exception:
                pass

    def keyExit(self):
        self.close(None)


# ===========================================================================
# IPTVXtreamProviderSettings — list / build screen for Xtream-only providers.
# ===========================================================================

class IPTVXtreamProviderSettings(ConfigListScreen, Screen):
    _SKIN_T = """
        <screen position="center,center" size="1250,690"
                title="Xtream Media Creator" backgroundColor="#33000000">
            <widget name="help_label" position="20,60"  size="360,545"
                    font="Regular;22" valign="top" halign="left"
                    transparent="1" />
            <eLabel position="383,0" size="1,623" backgroundColor="#ffffff"/>
            <widget name="list_header" position="525,60" size="706,44"
                    font="Regular;30" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="config" position="525,109" size="706,475"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="46" transparent="1"/>
            <ePixmap position="72,643"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,643"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,643"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,643" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,623" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,638" size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_green"  position="427,638" size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_yellow" position="739,638" size="230,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
            <widget name="key_blue"   position="1051,638" size="185,35"
                    zPosition="1" font="Regular;24" valign="center" halign="left" transparent="1" />
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="1250,690"
                title="Xtream Media Creator">
            <widget name="help_label" position="20,60"  size="360,545"
                    font="Regular;22" valign="top" halign="left"
                    transparent="1" />
            <eLabel position="383,0" size="1,623" backgroundColor="#ffffff"/>
            <widget name="list_header" position="525,60" size="706,44"
                    font="Regular;30" valign="center" halign="left"
                    foregroundColor="#ffcc00" transparent="1" />
            <widget name="config" position="525,109" size="706,475"
                    scrollbarMode="showOnDemand" font="Regular;30" itemHeight="46" />
            <ePixmap position="72,643"   size="35,25" pixmap="buttons/red.png"    alphaTest="blend" />
            <ePixmap position="384,643"  size="35,25" pixmap="buttons/green.png"  alphaTest="blend" />
            <ePixmap position="696,643"  size="35,25" pixmap="buttons/yellow.png" alphaTest="blend" />
            <ePixmap position="1008,643" size="35,25" pixmap="buttons/blue.png"   alphaTest="blend" />
            <eLabel position="0,623" size="1250,1" backgroundColor="#00aa00"/>
            <eLabel position="0,689" size="1250,1" backgroundColor="#00aa00"/>
            <widget name="key_red"    position="115,638" size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_green"  position="427,638" size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_yellow" position="739,638" size="230,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
            <widget name="key_blue"   position="1051,638" size="185,35"
                    zPosition="1" font="Regular;20" valign="center" halign="left" />
        </screen>"""
    skin    = _SKIN_T


    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self._providers_raw = loadXtreamProviderConfig()
        self._creating      = False
        self._edit_idx      = None
        self._cfg_entries   = []
        ConfigListScreen.__init__(self, [], session=session)
        self.setTitle(T("Xtream Media Creator"))
        self["list_header"] = Label(T("Configured Xtream Providers"))
        self["help_label"]  = Label(
            u"\u2191\u2193  \u2014  " + T("Navigate")                   + "\n" +
            u"\u25c4\u25ba / OK  \u2014  " + T("Toggle ON/OFF")         + "\n" +
            T("Red")    + "  \u2014  " + T("Start Create")              + "\n" +
            T("Green")  + "  \u2014  " + T("Add Provider")              + "\n" +
            T("Yellow") + "  \u2014  " + T("Edit Provider")             + "\n" +
            T("Blue")   + "  \u2014  " + T("VOD Browser")              + "\n" +
            T("Exit")   + "  \u2014  " + T("Close") + "\n" +
            T("EPG")    + "  \u2014  " + T("Make Custom EPG")             + "\n" +
            "1  \u2014  " + T("Xtream Playlist Update Info"))
        self["key_red"]    = Button(T("Start Create"))
        self["key_green"]  = Button(T("Add Provider"))
        self["key_yellow"] = Button(T("Edit Provider"))
        self["key_blue"]   = Button(T("VOD Browser"))
        self._testing      = False
        self["xtActions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "SetupActions",
             "EPGSelectActions", "MediaPlayerActions", "InfobarEPGActions",
             "NumberActions"],
            {"cancel": self.keyClose, "ok": self.keyToggleEnabled,
             "save":   self.keyToggleEnabled,
             "red":    self.keyStartCreate, "green": self.keyAdd,
             "yellow": self.keyEdit,
             "blue":   self.keyVodBrowser,
             "epg":          self.keyCustomEPG,
             "showEventInfo": self.keyCustomEPG,
             "1":      self.keyShowUpdateInfo}, -2)
        self._refreshList()

    # ── list helpers ────────────────────────────────────────────────────────

    def _buildEntries(self):
        entries           = []
        self._cfg_entries = []
        for i, p in enumerate(self._providers_raw):
            name = (p.get('name') or '').strip()
            xurl = (p.get('xtream_url') or '').strip()
            if not name and not xurl:
                continue
            xtype = p.get('xtream_type', 'user_pass')
            label = '%s  [%s]' % (name or T('(unnamed)'), xtype.replace('_', '/'))
            cfg_en = ConfigYesNo(default=bool(p.get('enabled')))
            def _make_save(raw_idx):
                def _save(el):
                    self._providers_raw[raw_idx]['enabled'] = el.value
                    saveXtreamProviderConfig(self._providers_raw)
                return _save
            cfg_en.addNotifier(_make_save(i), initial_call=False)
            entries.append(getConfigListEntry(label, cfg_en))
            self._cfg_entries.append((i, cfg_en))
        return entries

    def _refreshList(self):
        entries = self._buildEntries()
        if not entries:
            entries = [getConfigListEntry(
                T('No Xtream providers configured — press Green to add.'),
                ConfigYesNo(default=False))]
            self._cfg_entries = []
        self["config"].setList(entries)

    def _selectedIndex(self):
        try:
            list_idx = self["config"].getCurrentIndex()
            if 0 <= list_idx < len(self._cfg_entries):
                return self._cfg_entries[list_idx][0]
        except Exception:
            pass
        return None

    # ── key handlers ────────────────────────────────────────────────────────

    def keyToggleEnabled(self):
        idx = self._selectedIndex()
        if idx is None:
            return
        p = self._providers_raw[idx]
        if not (p.get('name') or p.get('xtream_url')):
            return
        p['enabled'] = not bool(p.get('enabled'))
        saveXtreamProviderConfig(self._providers_raw)
        self._refreshList()

    def keyAdd(self):
        for i, p in enumerate(self._providers_raw):
            if not (p.get('name') or p.get('xtream_url')):
                self._edit_idx = i
                self.session.openWithCallback(
                    self._onEditDone, IPTVXtreamProviderEditDialog, {}, False, i)
                return
        self.session.open(MessageBox,
            T("Maximum of %d providers reached.\nDelete one before adding another.")
            % MAX_XTREAM_PROVIDERS,
            type=MessageBox.TYPE_INFO, timeout=5)

    def keyEdit(self):
        idx = self._selectedIndex()
        if idx is None:
            return
        self._edit_idx = idx
        try:
            self._providers_raw = loadXtreamProviderConfig()
        except Exception:
            pass
        self.session.openWithCallback(
            self._onEditDone, IPTVXtreamProviderEditDialog,
            dict(self._providers_raw[idx]), True, idx)

    def _onEditDone(self, data):
        if data is not None and self._edit_idx is not None:
            _empty = {
                'enabled': False, 'name': '',
                'xtream_enabled': True, 'xtream_type': 'user_pass',
                'xtream_url': '', 'xtream_username': '', 'xtream_password': '',
                'xtream_token': '', 'xtream_output': 'm3u8',
                'xtream_strategy': 'same_as_provider', 'xtream_picon': 'off',
                'xtream_picon_location': 'enigma2_picon', 'xtream_picon_symlink': False,
                'xtream_show_live': True, 'xtream_live_type': '4097',
                'xtream_show_vod': True, 'xtream_vod_type': '4097',
                'xtream_show_series': True, 'xtream_series_type': '4097',
                'clean_bouquets': False, 'channel_order': 'provider',
                'update_playlist_mode': 'off', 'xtream_picon_with_folder': True,
            }
            if data.get('_delete'):
                prov_name = (self._providers_raw[self._edit_idx].get('name') or '').strip()
                self._providers_raw[self._edit_idx] = dict(_empty)
                saveXtreamProviderConfig(self._providers_raw)
                if prov_name:
                    _deletePlaylistProviderFiles(prov_name)
            else:
                old  = self._providers_raw[self._edit_idx]
                prev = (old.get('_name_at_last_create') or old.get('name') or '').strip()
                if prev:
                    data.setdefault('_name_at_last_create', prev)
                data['xtream_enabled'] = True
                self._providers_raw[self._edit_idx] = data
                saveXtreamProviderConfig(self._providers_raw)
        self._refreshList()

    def keyStartCreate(self):
        if self._creating:
            self.session.open(MessageBox, T("Build already running, please wait."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        try:
            self._providers_raw = loadXtreamProviderConfig()
        except Exception:
            pass
        prov = self._providers_raw[idx]
        if not prov.get('enabled', False):
            self.session.open(MessageBox, T("Provider is disabled. Enable it first."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        if not (prov.get('xtream_url') or '').strip():
            self.session.open(MessageBox, T("No Xtream URL set for this provider."),
                              type=MessageBox.TYPE_INFO, timeout=4)
            return
        prov['xtream_enabled'] = True
        self._creating = True
        self["key_red"].setText(T("Creating..."))
        import threading as _thr
        t = _thr.Thread(target=self._createThread, args=(dict(prov), idx))
        t.daemon = True
        t.start()

    def _createThread(self, prov, idx=None):
        result = {'ok': False, 'bouquets': 0, 'error': '',
                  '_idx': idx, '_prov_name': ''}
        try:
            from twisted.internet import reactor as _r
        except Exception:
            _r = None
        try:
            prov_name = (prov.get('name') or '').strip()
            result['_prov_name'] = prov_name
            prev_name = (prov.get('_name_at_last_create') or '').strip()
            update_mode = (prov.get('update_playlist_mode') or 'off').strip()
            # Safety: if channel_order is user_defined but update_mode is 'off'
            # (stale save), force 'top' so existing bouquets are never deleted.
            if prov.get('channel_order', 'provider') == 'user_defined' and update_mode == 'off':
                update_mode = 'top'
            # Write corrected update_mode back to prov so _write_file reads it
            prov['update_playlist_mode'] = update_mode
            iptvLogWrite('[Xtream] channel_order=%s update_mode=%s' % (prov.get('channel_order'), update_mode))
            if prev_name and prev_name != prov_name:
                iptvLogWrite('[Xtream] Provider renamed %r → %r — migration will rename files' % (prev_name, prov_name))
            if prov_name and update_mode == 'off':
                iptvLogWrite('[Xtream] Deleting provider files (update_mode=off): %s' % prov_name)
                _deletePlaylistProviderFiles(prov_name)
            prov['xtream_enabled'] = True
            n, err, _xt_merge_stats = _buildXtreamBouquets(prov, _reactor=_r,
                                                            _progress_cb=self._piconProgress)
            result['_xt_merge_stats']  = _xt_merge_stats
            result['_channel_order']   = prov.get('channel_order', 'provider')
            if _xt_merge_stats:
                result['_is_update'] = True
            if err:
                result['error'] = err
            else:
                result['bouquets'] = n
                result['ok'] = True
        except Exception as e:
            result['error'] = str(e)
        if _r:
            _r.callFromThread(self._createDone, result)
        else:
            self._createDone(result)

    def _piconProgress(self, done, total):
        try:
            pct = int(done * 100 / total) if total else 0
            self["key_red"].setText(u"\u2193 %d / %d  (%d%%)" % (done, total, pct))
        except Exception:
            pass

    def keyCustomEPG(self):
        """Open Custom EPG screen for currently selected Xtream provider."""
        idx = self._selectedIndex()
        provider = {}
        if idx is not None:
            provider = dict(self._providers_raw[idx])
            if not provider.get('xmltv_url'):
                server = (provider.get('xtream_url') or '').strip()
                xtype  = provider.get('xtream_type', 'user_pass')
                if xtype == 'user_pass':
                    user = (provider.get('xtream_username') or '').strip()
                    pw   = (provider.get('xtream_password') or '').strip()
                    if server and user:
                        provider['xmltv_url'] = '%s/xmltv.php?username=%s&password=%s' % (server, user, pw)
                else:
                    token = (provider.get('xtream_token') or '').strip()
                    if server and token:
                        provider['xmltv_url'] = '%s/xmltv.php?token=%s' % (server, token)
        self.session.open(CustomEPGScreen, provider=provider)

    def keyShowUpdateInfo(self):
        self.session.open(IPTVXtreamUpdateInfoScreen)

    def _createDone(self, result):
        self._creating = False
        self["key_red"].setText(T("Create Playlist"))
        if result.get('ok'):
            idx       = result.get('_idx')
            prov_name = result.get('_prov_name', '')
            if idx is not None and prov_name:
                try:
                    self._providers_raw[idx]['_name_at_last_create'] = prov_name
                    import re as _re_slcx
                    self._providers_raw[idx]['_safe_name_at_last_create'] = _re_slcx.sub(r'_+', '_', _re_slcx.sub(r'[^\w\-]', '', _re_slcx.sub(r'\s+', '_', prov_name))).strip('_-')
                    saveXtreamProviderConfig(self._providers_raw)
                except Exception:
                    pass
            if result.get('_is_update'):
                # Build detailed Xtream update info — same format as M3U Update Info
                _stats = result.get('_xt_merge_stats') or []
                _info_lines = []
                # Separate new bouquets from existing bouquets with new channels
                _new_bouquets   = [s for s in _stats if isinstance(s, dict) and s.get('is_new_bouquet')]
                _exist_bouquets = [s for s in _stats if isinstance(s, dict) and not s.get('is_new_bouquet')]
                _total_added   = sum(s.get('added', 0) for s in _stats if isinstance(s, dict))
                _total_removed = sum(s.get('removed', 0) for s in _stats if isinstance(s, dict))
                _total_bq_del  = sum(1 for s in _stats if isinstance(s, dict) and s.get('bouquet_deleted'))
                _picon_res_early = None
                for _s in _stats:
                    if isinstance(_s, dict) and '_picon_result' in _s:
                        _picon_res_early = _s['_picon_result']
                        break
                _picons_removed = (_picon_res_early.get('deleted', 0) if _picon_res_early else 0)
                # ── Line 1: channel + bouquet summary ──────────────────────
                _line1 = (T("Channels Added") + ' (%d)   ' % _total_added +
                          T("Channels Removed") + ' (%d)' % _total_removed)
                if _total_bq_del:
                    _line1 += '   ' + T("Bouquets Removed") + ' (%d)' % _total_bq_del
                _info_lines.append(_line1)
                # ── Line 2: picon summary ───────────────────────────────────
                _info_lines.append(
                    T("Picons Downloaded") + ' (%d)   ' % (_picon_res_early.get('downloaded', 0) if _picon_res_early else 0) +
                    T("Picons Removed") + ' (%d)' % _picons_removed)
                _info_lines.append('')
                # ── Deleted bouquet names ───────────────────────────────────
                for _s in sorted(_stats, key=lambda x: x.get('bouquet', '') if isinstance(x, dict) else ''):
                    if isinstance(_s, dict) and _s.get('bouquet_deleted'):
                        _info_lines.append(T("Bouquet Removed") + ':  ' + _s.get('bouquet', ''))
                _info_lines.append('')
                # ── New bouquets section ────────────────────────────────────
                if _new_bouquets:
                    _info_lines.append('── ' + T("New Bouquets") + ' ──')
                    for _s in sorted(_new_bouquets, key=lambda x: x.get('bouquet', '')):
                        _bn = _s.get('bouquet', '')
                        _info_lines.append('%s  (%d %s)' % (_bn, _s.get('added', 0), T("channels")))
                        for _cn in _s.get('added_names', []):
                            _info_lines.append('    +%s' % _cn)
                # ── New channels in existing bouquets ──────────────────────
                if _exist_bouquets:
                    _info_lines.append('')
                    for _s in sorted(_exist_bouquets, key=lambda x: x.get('bouquet', '')):
                        _bn = _s.get('bouquet', '')
                        for _cn in _s.get('added_names', []):
                            _info_lines.append('%s:  +%s  %s' % (_bn, _cn, T("new")))
                _info_lines.append('')
                # ── Removed channels (non-deleted bouquets only) ────────────
                for _s in sorted(_stats, key=lambda x: x.get('bouquet', '') if isinstance(x, dict) else ''):
                    if not isinstance(_s, dict) or _s.get('bouquet_deleted'): continue
                    _bn = _s.get('bouquet', '')
                    for _cn in _s.get('removed_names', []):
                        _info_lines.append('%s:  -%s  %s' % (_bn, _cn, T("Deleted")))
                global _last_xtream_update_info
                _last_xtream_update_info = _info_lines
                _save_xtream_update_info(_info_lines)
                msg = (T("Xtream bouquets updated successfully!\n%d bouquet(s) updated.\n"
                         "Press 1 for full update info.") % result.get('bouquets', 0))
                if _stats:
                    _lines = []
                    for _s in sorted(_stats, key=lambda x: x.get('bouquet', '') if isinstance(x, dict) else x[0]):
                        _bn  = _s.get('bouquet', '') if isinstance(_s, dict) else _s[0]
                        _add = _s.get('added', 0)   if isinstance(_s, dict) else _s[1]
                        _rem = _s.get('removed', 0) if isinstance(_s, dict) else 0
                        _lines.append('  %s:  +%d new  -%d removed' % (_bn, _add, _rem))
                    msg += '\n\n' + '\n'.join(_lines)
                msg += '\n\n' + T("Press 1 or Menu for full channel list")
            else:
                msg = (T("Xtream bouquets created successfully!\n%d bouquet(s) written to /etc/enigma2.\n"
                         "Enigma2 channel list has been reloaded.") % result.get('bouquets', 0))
                if result.get('_channel_order') == 'user_defined':
                    msg += '\n' + T("Press 1 for Xtream Playlist Update Info")
            self.session.open(MessageBox, msg, type=MessageBox.TYPE_INFO, timeout=10)
        else:
            self.session.open(MessageBox,
                T("Xtream bouquet creation failed:\n%s") % result.get('error', T('Unknown error')),
                type=MessageBox.TYPE_ERROR, timeout=8)

    def keyVodBrowser(self):
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov   = self._providers_raw[idx]
        server = (prov.get('xtream_url') or '').strip()
        if not server:
            self.session.open(MessageBox,
                T("Selected provider has no Xtream URL configured."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.open(IPTVVodBrowserScreen, prov)

    def keyTest(self):
        if self._testing:
            self.session.open(MessageBox, T("Test already running, please wait."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov   = self._providers_raw[idx]
        server = (prov.get('xtream_url') or '').strip().rstrip('/')
        if not server:
            self.session.open(MessageBox,
                T("Selected provider has no Xtream URL configured."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return
        xtype = prov.get('xtream_type', 'user_pass')
        if xtype == 'user_pass':
            user = (prov.get('xtream_username') or '').strip()
            pw   = (prov.get('xtream_password') or '').strip()
            if not user or not pw:
                self.session.open(MessageBox,
                    T("Please enter both Username and Password before testing."),
                    type=MessageBox.TYPE_INFO, timeout=3)
                return
            api_url = '%s/player_api.php?username=%s&password=%s' % (server, user, pw)
        else:
            token = (prov.get('xtream_token') or '').strip()
            if not token:
                self.session.open(MessageBox,
                    T("Please enter the Xtream Token before testing."),
                    type=MessageBox.TYPE_INFO, timeout=3)
                return
            api_url = '%s/player_api.php?token=%s' % (server, token)
        self._testing = True
        self["key_blue"].setText(T("Select Bouquets"))
        import threading as _thr
        t = _thr.Thread(target=self._testThread, args=(api_url,))
        t.daemon = True
        t.start()

    def _testThread(self, api_url):
        result = {'ok': False, 'error': '', 'user_info': {}, 'server_info': {}}
        try:
            data = _fetchXtreamApiJson(api_url, timeout=12)
            if data is None:
                result['error'] = T("No response from server.\nCheck the URL and credentials.")
            elif not isinstance(data, dict):
                result['error'] = T("Unexpected response format from server.")
            else:
                ui = data.get('user_info') or {}
                if not ui:
                    result['error'] = T("Server responded but returned no account info.\n"
                                        "The credentials may be wrong or the server\n"
                                        "does not support the Xtream API.")
                else:
                    auth = ui.get('auth', 0)
                    if str(auth) in ('0', 'false', 'False') or auth is False:
                        result['error'] = T("Authentication failed — wrong credentials.")
                    else:
                        result['ok']          = True
                        result['user_info']   = ui
                        result['server_info'] = data.get('server_info') or {}
        except Exception as e:
            result['error'] = str(e)
        try:
            from twisted.internet import reactor as _r
            _r.callFromThread(self._testDone, result)
        except Exception:
            self._testDone(result)

    def _testDone(self, result):
        self._testing = False
        self["key_blue"].setText(T("VOD Browser"))
        if not result.get('ok'):
            self.session.open(MessageBox,
                T("Connection test failed:\n%s") % result.get('error', T('Unknown error')),
                type=MessageBox.TYPE_ERROR, timeout=10)
            return
        ui = result['user_info']
        si = result['server_info']
        status   = (ui.get('status') or 'Unknown').strip()
        is_trial = str(ui.get('is_trial', '0')) not in ('0', 'false', 'False', '')
        active   = str(ui.get('active_cons', '?'))
        max_conn = str(ui.get('max_connections', '?'))
        exp_raw  = ui.get('exp_date') or ui.get('exp_date_txt') or ''
        try:
            import datetime as _dt
            exp_ts  = int(exp_raw)
            exp_str = _dt.datetime.utcfromtimestamp(exp_ts).strftime('%Y-%m-%d  %H:%M UTC')
        except Exception:
            exp_str = str(exp_raw) if exp_raw else T('Unknown')
        srv_url  = (si.get('url') or '').strip()
        srv_port = str(si.get('port') or si.get('https_port') or '')
        lines = [
            T("Connection test successful!"),
            '',
            T("Account Status : ") + status + ((' (' + T("Trial") + ')') if is_trial else ''),
            T("Expiry Date    : ") + exp_str,
            T("Connections    : ") + active + ' / ' + max_conn + T(" (active / max)"),
        ]
        if srv_url:
            lines.append(T("Server         : ") + srv_url
                         + ((':' + srv_port) if srv_port else ''))
        self.session.open(MessageBox, '\n'.join(lines),
                          type=MessageBox.TYPE_INFO, timeout=15)

    def keyVodBrowser(self):
        idx = self._selectedIndex()
        if idx is None:
            self.session.open(MessageBox, T("No provider selected."),
                              type=MessageBox.TYPE_INFO, timeout=3)
            return
        prov = dict(self._providers_raw[idx])
        prov['xtream_enabled'] = True
        if not (prov.get('xtream_url') or '').strip():
            self.session.open(MessageBox,
                T("Selected provider has no Xtream URL configured."),
                type=MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.open(IPTVVodBrowserScreen, prov)

    def keyClose(self):
        self.close()


# IPTVAddWorkflow — small popup menu: "Add Workflow"
#   Item 1: Create IPTV Archive Programs Locally       → IPTVProviderSettings
#   Item 2: Create IPTV Archive Programs From Providers→ IPTVIntegratedProvidersScreen
#   Item 3: Create IPTV Bouquets/Channels              → IPTVPlaylistProviderSettings
#   Item 4: Create Xtream Media                        → IPTVXtreamProviderSettings
# Plain Screen, no video widget (avoids full-screen TV takeover).
# ===========================================================================

class IPTVAddWorkflow(Screen):
    _SKIN_T = """
        <screen position="center,center" size="860,470"
                title="Add Workflow" backgroundColor="#33000000">

            <!-- Section list — large font for TV readability -->
            <widget name="menu" position="30,30" size="800,320"
                    scrollbarMode="showNever"
                    font="Regular;30" itemHeight="80" transparent="1"/>

            <!-- Thin separator above hint line -->
            <eLabel position="0,362" size="860,2" backgroundColor="#aaaaaa"/>

            <!-- Bottom hint -->
            <widget name="hint" position="30,372" size="800,46"
                    font="Regular;18" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
        </screen>"""
    _SKIN_R = """
        <screen position="center,center" size="860,470"
                title="Add Workflow">

            <!-- Section list — large font for TV readability -->
            <widget name="menu" position="30,30" size="800,320"
                    scrollbarMode="showNever"
                    font="Regular;30" itemHeight="80"/>

            <!-- Thin separator above hint line -->
            <eLabel position="0,362" size="860,2" backgroundColor="#aaaaaa"/>

            <!-- Bottom hint -->
            <widget name="hint" position="30,372" size="800,46"
                    font="Regular;18" valign="center" halign="left"
                    foregroundColor="#aaaaaa" transparent="1"/>
        </screen>"""
    skin    = _SKIN_T


    _ITEMS = [
        ("Create IPTV Archive Programs From Providers", "integrated"),
        ("Create IPTV Archives Bouquets/Channels",      "bouquets"),
        ("Create Xtream Media",                         "xtream_media"),
    ]

    def __init__(self, session):
        self.skin = self._SKIN_T if loadPluginSettings().get('skin_type', 'transparent') == 'transparent' else self._SKIN_R
        Screen.__init__(self, session)
        self.setTitle(T("Add Workflow"))
        _stop = loadPluginSettings().get('stop_integrated_providers', False)
        _visible = [(T(lbl), key) for lbl, key in self._ITEMS
                    if not (_stop and key == 'integrated')]
        self["menu"] = MenuList(_visible)
        self["hint"] = Label(T(u"OK  \u2014  Open     EXIT  \u2014  Close"))
        self["wfActions"] = ActionMap(
            ["OkCancelActions", "DirectionActions"],
            {"ok":     self._keyOk,
             "cancel": self.close,
             "up":     self._keyUp,
             "down":   self._keyDown}, -1)

    def _keyOk(self):
        sel = self["menu"].getCurrent()
        if not sel:
            return
        key = sel[1]
        if key == "integrated":
            self.session.openWithCallback(self._back, IPTVIntegratedProvidersScreen)
        elif key == "bouquets":
            self.session.openWithCallback(self._back, IPTVPlaylistProviderSettings)
        elif key == "xtream_media":
            self.session.openWithCallback(self._back, IPTVXtreamProviderSettings)

    def _keyUp(self):
        self["menu"].up()

    def _keyDown(self):
        self["menu"].down()

    def _back(self, *args):
        pass
