# -*- coding: utf-8 -*-
"""
_epg.py — CustomIPTVArchiveMakerPro
========================
EPG / XMLTV / M3U engine.  Inlines the xxh32 hash implementation (previously
_xxh32.py) so the package ships as fewer files.

Public surface used by _screens.py and _providers.py
-----------------------------------------------------
  xxh32                   — reusable xxh32 hash instance (call __init__ to reset)
  iptvLogWrite(str)       — append a timestamped line to the plugin log
  currTime()              — int(time.time())
  paramExist(fn, param)   — True if param is in fn's signature
  xml_unescape(text)      — HTML/XML entity decode
  query_get(q, key)       — get a value from a parsed query-string dict
  _wrapPath(path, w)      — wrap long file path at a slash boundary
  _normalizeHttpUrl(url)  — lowercase the URL scheme
  _gunzip(raw)            — decompress gzip/zlib layers
  _normName(s)            — normalise channel name for fuzzy comparison
  loadPluginSettings()    — load plugin-wide settings dict
  savePluginSettings(d)   — persist plugin-wide settings dict
  loadProviderConfig()    — load custom provider list (7 slots)
  saveProviderConfig(d)   — persist custom provider list
  fetchM3UChannels(src)   — parse M3U or Enigma2 playlist → channel list
  fetchXMLTVEvents(...)   — parse XMLTV for one channel → event list
  _buildAllChannelCaches  — bulk-parse XMLTV and cache all M3U channels
  _fetchCustomProvider    — per-channel XMLTV lookup (on-demand, fast path)
  _testProviderConnection — full M3U+XMLTV test with channel cross-match
  _clearProviderCache     — delete all epg_*.json files for a provider
  _providerHasAnyCache    — True if Start Build has ever run for a provider
  PLUGIN_DIR, log_file    — filesystem constants
  HEADERS, XMLTV_HEADERS  — HTTP request headers
  DEBUG                   — int (1 = verbose log)
  SIGN                    — ® character
  STATIC_INFO_DIC         — {model, distro, imagever}
  PY3                     — True on Python 3
"""

import os, sys, time, re
try:
    import simplejson as json
except ImportError:
    import json
import tempfile, zlib, traceback, random, struct

PY3 = (sys.version_info[0] == 3)
if PY3:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
    from urllib.parse import urlparse, parse_qs, parse_qsl, urlencode, unquote, quote
else:
    from urllib import urlencode, unquote, quote
    from urllib2 import urlopen, Request, URLError
    from urlparse import urlparse, parse_qs, parse_qsl

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
from xml.sax.saxutils import unescape
from hashlib import md5

from . import _

# ---------------------------------------------------------------------------
# xxh32 — Pure-Python XXH32 hash (inlined from _xxh32.py)
# Based on ppxxh 1.0.0 by Vgbundo, small fixes by prog4dood
# ---------------------------------------------------------------------------

try:
    from struct import iter_unpack as _iter_unpack
except ImportError:
    def _iter_unpack(format, buffer):
        fsize = struct.calcsize(format)
        for i in range(0, len(buffer) - fsize + 1, fsize):
            yield struct.unpack_from(format, buffer, i)


class _xxh32:
    """Pure-Python XXH32 non-cryptographic hash."""

    block_size  = 16
    digest_size = 4
    name        = "xxh32"

    _P1 = 0x9E3779B1
    _P2 = 0x85EBCA77
    _P3 = 0xC2B2AE3D
    _P4 = 0x27D4EB2F
    _P5 = 0x165667B1
    _M32 = 0xFFFFFFFF

    @staticmethod
    def _r(x, bits):
        return ((x << bits) | (x >> (32 - bits))) & _xxh32._M32

    def __init__(self, data=None, seed=0):
        if seed < 0 or seed > 0xFFFFFFFF:
            raise ValueError("Seed must be a 32-bit unsigned integer.")
        self._s0 = (seed + self._P1 + self._P2) & self._M32
        self._s1 = (seed + self._P2) & self._M32
        self._s2 = seed & self._M32
        self._s3 = (seed - self._P1) & self._M32
        self._total_length = 0
        self._buffer = b""
        if data is not None:
            self.update(data)

    def update(self, data):
        self._total_length += len(data)
        self._buffer += data
        n_extra = len(self._buffer) % self.block_size
        for (b0, b1, b2, b3) in _iter_unpack("<IIII", self._buffer[: -n_extra or None]):
            self._s0 = (self._r((self._s0 + b0 * self._P2) & self._M32, 13) * self._P1) & self._M32
            self._s1 = (self._r((self._s1 + b1 * self._P2) & self._M32, 13) * self._P1) & self._M32
            self._s2 = (self._r((self._s2 + b2 * self._P2) & self._M32, 13) * self._P1) & self._M32
            self._s3 = (self._r((self._s3 + b3 * self._P2) & self._M32, 13) * self._P1) & self._M32
        self._buffer = self._buffer[-n_extra:] if n_extra else b""

    def intdigest(self):
        if self._total_length >= self.block_size:
            output = (self._r(self._s0, 1) + self._r(self._s1, 7) +
                      self._r(self._s2, 12) + self._r(self._s3, 18))
        else:
            output = self._s2 + self._P5
        output = (output + self._total_length) & self._M32
        n_extra = len(self._buffer) % 4
        for (b,) in _iter_unpack("<I", self._buffer[: -n_extra or None]):
            output = (self._r((output + b * self._P3) & self._M32, 17) * self._P4) & self._M32
        tmpbuffer = self._buffer[-n_extra:] if n_extra else b""
        for b in tmpbuffer:
            bval = b if isinstance(b, int) else ord(b)
            output = (self._r((output + bval * self._P5) & self._M32, 11) * self._P1) & self._M32
        output = ((output ^ (output >> 15)) * self._P2) & self._M32
        output = ((output ^ (output >> 13)) * self._P3) & self._M32
        output ^= output >> 16
        return output

    def digest(self):
        return struct.pack(">I", self.intdigest())

    def hexdigest(self):
        if PY3:
            return "".join("{0:0>2x}".format(b) for b in self.digest())
        return "".join("{0:0>2x}".format(ord(b)) for b in self.digest())

    def copy(self):
        cp = _xxh32()
        cp._s0 = self._s0; cp._s1 = self._s1
        cp._s2 = self._s2; cp._s3 = self._s3
        cp._total_length = self._total_length
        cp._buffer = self._buffer
        return cp


# Module-level reusable instance — callers reset it via xxh32.__init__(data=...)
xxh32 = _xxh32()

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

SIGN  = chr(174) if PY3 else unichr(174).encode('utf-8')  # ®
DEBUG = 0

HEADERS = {
    'User-Agent':       'Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) '
                        'AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7',
    'Accept-encoding':  'gzip, deflate',
    'Connection':       'close',
}
XMLTV_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) '
                  'AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7',
    'Connection': 'close',
}

# ---------------------------------------------------------------------------
# Filesystem paths
# ---------------------------------------------------------------------------

PLUGIN_DIR = '/etc/CustomIPTVArchiveMakerPro'
try:
    if not os.path.isdir(PLUGIN_DIR):
        os.makedirs(PLUGIN_DIR)
except Exception:
    PLUGIN_DIR = tempfile.gettempdir()

log_file            = os.path.join(PLUGIN_DIR, 'iptv_archive_pro_plugin.log')
PLUGIN_SETTINGS_FILE = os.path.join(PLUGIN_DIR, 'iptv_archive_settings.json')
PROVIDERS_CFG_FILE  = os.path.join(PLUGIN_DIR, 'iptv_archive_custom_providers.json')
MAX_CUSTOM_PROVIDERS = 50


def _detectMediaPaths():
    """Return available base paths for working data storage.

    Always starts with '/etc'.  Adds '/media/hdd' if mounted.
    Then adds any /media/<x> entry from /proc/mounts that is not
    a known internal HDD name — those are treated as USB drives.
    """
    paths  = ['/etc']
    _hdd   = {'hdd', 'hdd2', 'hdd3'}
    mounted = set()
    try:
        with open('/proc/mounts', 'r') as _mf:
            for _line in _mf:
                _parts = _line.split()
                if len(_parts) >= 2:
                    mounted.add(_parts[1])
    except Exception:
        pass
    if '/media/hdd' in mounted or os.path.isdir('/media/hdd'):
        paths.append('/media/hdd')
    usb = []
    for mp in sorted(mounted):
        if mp.startswith('/media/'):
            name = mp[len('/media/'):]
            if name and name.lower() not in _hdd and mp not in paths:
                usb.append(mp)
    paths.extend(usb)
    return paths


_data_dir_cache = None   # invalidated by savePluginSettings()

def getDataDir():
    """Return (and create) the working data directory based on work_dir setting.

    Settings / providers config / log stay in PLUGIN_DIR (/etc/…) always.
    EPG cache, XMLTV cache and uploaded M3U files go here.
    Result is cached; the cache is cleared whenever savePluginSettings() is
    called in case the user changed work_dir.
    """
    global _data_dir_cache
    if _data_dir_cache is not None:
        return _data_dir_cache
    try:
        base = loadPluginSettings().get('work_dir', '/etc')
    except Exception:
        base = '/etc'
    d = os.path.join(base, 'CustomIPTVArchiveMakerPro')
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
    except Exception:
        d = PLUGIN_DIR
    _data_dir_cache = d
    return d

# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

currTime = lambda: int(round(time.time()))


def paramExist(fn, param):
    """Return True if *param* is in the signature of *fn* (Py2 + Py3 safe)."""
    try:
        code = getattr(fn, '__code__', None) or getattr(fn, 'func_code', None)
        if code:
            return param in code.co_varnames[:code.co_argcount]
    except Exception:
        pass
    return False


LOG_MAX_LINES      = 500
# Approximate byte size at which to bother reading the log for line-count trim.
# Average log line ≈ 60 chars; 500 lines ≈ 30 000 bytes → trim threshold ~35 KB.
_LOG_TRIM_BYTES    = 35000

def iptvLogWrite(msg):
    """Append a timestamped message to the plugin log file.

    Skipped entirely when 'log_enabled' is False in settings.
    Once the file exceeds LOG_MAX_LINES lines the oldest half is discarded,
    keeping the most recent LOG_MAX_LINES // 2 lines.

    Optimisations vs. the original:
    - 'log_enabled' is read from the in-memory settings cache (no extra disk I/O).
    - The log file is only opened for trimming when its on-disk size exceeds
      _LOG_TRIM_BYTES, avoiding a full file read on every write.
    """
    try:
        if not loadPluginSettings().get('log_enabled', True):
            return
        _ld = os.path.dirname(log_file)
        if not os.path.isdir(_ld):
            os.makedirs(_ld)
        ts   = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        line = '[%s] %s\n' % (ts, msg)
        with open(log_file, 'a') as f:
            f.write(line)
        # Only trim when the file is large enough that it might exceed the line cap.
        try:
            if os.path.getsize(log_file) > _LOG_TRIM_BYTES:
                with open(log_file, 'r') as f:
                    lines = f.readlines()
                if len(lines) > LOG_MAX_LINES:
                    keep = lines[len(lines) - LOG_MAX_LINES // 2:]
                    with open(log_file, 'w') as f:
                        f.writelines(keep)
        except Exception:
            pass
    except Exception:
        pass


def getBoxInfo():
    """Return {model, distro, imagever} for the current STB."""
    res = {}.fromkeys(['model', 'distro', 'imagever'], 'unknown')
    for fname in ['hwmodel', 'gbmodel', 'boxtype', 'vumodel', 'azmodel', 'model']:
        try:
            with open('/proc/stb/info/' + fname, 'r') as f:
                res['model'] = ''.join(f.readlines()).strip()
                break
        except Exception:
            continue

    _DISTRO_FILES = [
        ('/etc/openpli-release',   'openpli'),
        ('/etc/openbh-release',    'openbh'),
        ('/etc/blackhole-release', 'openbh'),
        ('/etc/openvix-release',   'openvix'),
        ('/etc/openatv-release',   'openatv'),
        ('/etc/vti-release',       'vti'),
        ('/etc/opendroid-release', 'opendroid'),
        ('/etc/openhdf-release',   'openhdf'),
        ('/etc/egami-release',     'egami'),
        ('/etc/openspa-release',   'openspa'),
        ('/etc/sifteam-release',   'sif'),
        ('/etc/teamblue-release',  'teamblue'),
        ('/etc/dreambox-release',  'dreambox'),
        ('/etc/imageversion',      None),
        ('/etc/issue',             None),
    ]
    _KEYWORD_MAP = [
        ('openpli',   'openpli'),   ('openbh',    'openbh'),
        ('blackhole', 'openbh'),    ('openvix',   'openvix'),
        ('openatv',   'openatv'),   ('vti',       'vti'),
        ('vusolo',    'vti'),       ('vuplus',    'vti'),
        ('opendroid', 'opendroid'), ('openhdf',   'openhdf'),
        ('egami',     'egami'),     ('openspa',   'openspa'),
        ('sifteam',   'sif'),       ('teamblue',  'teamblue'),
        ('dreambox',  'dreambox'),
    ]
    for fpath, forced_distro in _DISTRO_FILES:
        try:
            with open(fpath) as f:
                lines = f.readlines()
            content = ''.join(lines).lower()
            if forced_distro:
                res['distro'] = forced_distro
            else:
                for kw, name in _KEYWORD_MAP:
                    if kw in content:
                        res['distro'] = name
                        break
            stripped = [l.strip() for l in lines if l.strip() and '%h' not in l]
            if stripped:
                parts = stripped[-1].lower().split()
                if len(parts) >= 2:
                    res['imagever'] = parts[-1].replace('-release', '').replace('-snapshot', '')
            break
        except Exception:
            continue
    return res


STATIC_INFO_DIC = getBoxInfo()


def xml_unescape(text):
    """Unescape XML/HTML entities to human-readable text."""
    text = unescape(text, entities={
        r"&apos;": r"'", r"&quot;": r'"',
        r"&#124;": r"|", r"&#91;":  r"[", r"&#93;": r"]",
    })
    return text if PY3 else text.encode('utf-8')


def query_get(query, key, default=''):
    """Get a single value from a pre-parsed query string."""
    return parse_qs(query).get(key, [default])[0]


def _wrapPath(path, width=38):
    """Split a file path at a slash boundary so it fits within *width* chars per line."""
    if not path or len(path) <= width:
        return path
    idx = path.rfind('/', 1, width + 1)
    if idx < 1:
        idx = path.find('/', 1)
    if idx < 1:
        return path
    return path[:idx] + '\n  ' + path[idx:]


def _normalizeHttpUrl(url):
    """Lowercase the URL scheme so urlopen does not raise ValueError."""
    if not url:
        return url
    colon = url.find('://')
    if colon > 0:
        scheme = url[:colon].lower()
        if scheme in ('http', 'https'):
            return scheme + url[colon:]
    return url


def _gunzip(raw):
    """Decompress up to 3 nested gzip/zlib layers; return raw bytes if not compressed."""
    import io as _io
    try:
        import gzip as _gzip
        _have_gzip = True
    except ImportError:
        _have_gzip = False
    for _idx in range(3):
        if len(raw) < 2:
            break
        if raw[:2] == b'\x1f\x8b':
            decompressed = None
            if _have_gzip:
                try:
                    decompressed = _gzip.GzipFile(fileobj=_io.BytesIO(raw)).read()
                except Exception:
                    pass
            if decompressed is None:
                try:
                    decompressed = zlib.decompress(raw, zlib.MAX_WBITS | 16)
                except Exception:
                    pass
            if decompressed is not None:
                raw = decompressed
                continue
            break
        if raw[:2] in (b'\x78\x9c', b'\x78\x01', b'\x78\xda', b'\x78\x5e'):
            try:
                raw = zlib.decompress(raw)
                continue
            except Exception:
                break
        break
    return raw


def _normName(s):
    """Normalise a channel name for fuzzy comparison (strip HD/SD/4K/etc. suffixes)."""
    s = (s or '').lower().strip()
    suffixes = (' hd', ' sd', ' fhd', ' uhd', ' 4k', ' orig', ' original',
                ' backup', ' tv', '+1', ' plus')
    changed = True
    while changed:
        changed = False
        for suf in suffixes:
            if s.endswith(suf):
                s = s[:-len(suf)].strip()
                changed = True
    return s

_ID_PREFIX_RE = re.compile(r'^(?:tvg[-_]?|ch(?=\d)|id[-_])', re.IGNORECASE)

def _stripIdPrefix(s):
    """Strip common provider ID prefixes (tvg_, tvg-, ch, id_) leaving the core.
    e.g. 'tvg_1089' -> '1089',  'ch1089' -> '1089'.
    Returns '' when nothing was stripped (avoids false matches on short values).
    """
    s = (s or '').strip()
    stripped = _ID_PREFIX_RE.sub('', s)
    return stripped if stripped != s else ''

# ---------------------------------------------------------------------------
# Plugin-wide settings
# ---------------------------------------------------------------------------

_SETTINGS_DEFAULTS = {
    'use_builtin_player':         True,
    'streamlink_enabled':         False,
    'streamlink_port':            8088,
    'player_config':              {},
    'stop_integrated_providers':          False,
    'stopped_provider_tags':             [],
    'integrated_provider_days_overrides': {},
    'integrated_providers_custom':        [],
    'work_dir':                   '/etc',
    'auto_build_enabled':         False,
    'auto_build_days':            [0, 1, 2, 3, 4, 5, 6],
    'auto_build_time_h':          3,
    'auto_build_time_m':          0,
    'auto_build_standby':         False,
    'auto_build_clear_cache':     False,
    'auto_build_clear_providers': [],
    'log_enabled':                True,
    'ui_language':                'ENG',
    'skin_type':                  'transparent',
    'global_archive_offset':      0,
    'fallback_providers_epg':     True,
}

# Module-level settings cache — invalidated whenever savePluginSettings() is
# called so all callers see the updated values without re-reading the file.
_settings_cache = None

def loadPluginSettings():
    """Load plugin-wide settings from disk. Missing keys get safe defaults.

    The result is cached in memory after the first load and is only re-read
    from disk after savePluginSettings() invalidates the cache.
    """
    global _settings_cache
    if _settings_cache is not None:
        return _settings_cache
    result = dict(_SETTINGS_DEFAULTS)
    try:
        if os.path.exists(PLUGIN_SETTINGS_FILE):
            with open(PLUGIN_SETTINGS_FILE, 'r') as f:
                data = json.load(f)
            result.update(data)
    except Exception:
        pass
    _settings_cache = result
    return result


def savePluginSettings(data):
    """Persist plugin-wide settings dict to disk. Returns True on success."""
    global _settings_cache, _data_dir_cache
    try:
        with open(PLUGIN_SETTINGS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        _settings_cache = None   # force re-read on next loadPluginSettings()
        _data_dir_cache = None   # work_dir may have changed
        return True
    except Exception:
        return False


def getEnabledPlayers(settings, prov_type, prov_id, prov_data=None):
    """Return list of enabled player keys for a provider at play time.

    prov_type : 'custom' or 'integrated'
    prov_id   : provider name (custom) or service tag string (integrated)
    prov_data : optional dict — if supplied and has player_override=True,
                uses its player_*_on flags directly (avoids loadProviderConfig)
    Returns   : ordered list from {'int', 'sl', 'rec'}

    Custom providers: if the matched provider has player_override=True the
    per-provider flags (player_int_on / player_sl_on / player_rec_on) are
    used instead of the global master switches, giving each custom provider
    its own independent player set (including a choice dialog when >1 active).
    When player_override is False the global master-switch logic applies.

    Integrated providers use a per-tag dict (%s_integrated) keyed by the
    Enigma2 service tag, which is unique and reliable.
    """
    cfg = settings.get('player_config', {})
    result = []

    # For custom providers check for a per-provider player override
    _cprov = None
    if prov_type == 'custom' and prov_id:
        # Use prov_data if supplied (from loadPlaylistProviderConfig in _screens.py).
        # No fallback to loadProviderConfig — that file is orphaned after the merge.
        if prov_data is not None and prov_data.get('player_override', False):
            _cprov = prov_data

    for key in ('int', 'sl', 'rec'):
        if _cprov is not None:
            # ── Per-provider override active ────────────────────────────────
            if _cprov.get('player_' + key + '_on', key == 'int'):
                result.append(key)
        elif str(prov_id) == 'xtream':
            # ── Xtream: dedicated per-player toggle only (no global gate) ───
            # int_xtream_on / sl_xtream_on / rec_xtream_on are the sole
            # switches; the global int_on/sl_on/rec_on are ignored so the
            # choice dialog shows even when StreamLink is globally OFF.
            # Defaults: int=True, sl=True, rec=False — matches the UI defaults
            # so the choice dialog appears even before the user visits Settings.
            _xtream_def = {'int': True, 'sl': True, 'rec': False}
            if cfg.get('%s_xtream_on' % key, _xtream_def[key]):
                result.append(key)
        else:
            # ── 1. Global master switch must be ON ──────────────────────────
            if not cfg.get(key + '_on', key == 'int'):
                continue

            if prov_type == 'custom':
                # ── 2a. Custom: global switch is sufficient (no override) ───
                result.append(key)
            else:
                # ── 2b. Integrated: strict per-tag lookup ───────────────────
                per = cfg.get('%s_integrated' % key, {})
                if per:
                    if bool(per.get(str(prov_id), key == 'int')):
                        result.append(key)
                else:
                    result.append(key)

    return result

# ---------------------------------------------------------------------------
# Custom provider config (7 slots)
# ---------------------------------------------------------------------------

def loadProviderConfig():
    """Load the custom provider list.  Always returns exactly MAX_CUSTOM_PROVIDERS entries."""
    _empty = {'enabled': False, 'name': '', 'xmltv_url': '',
              'm3u_source': '', 'days': 7, 'channel_id': ''}
    default = [dict(_empty) for _idx in range(MAX_CUSTOM_PROVIDERS)]
    try:
        if os.path.exists(PROVIDERS_CFG_FILE):
            with open(PROVIDERS_CFG_FILE, 'r') as f:
                data = json.load(f)
            for entry in data:
                if 'enabled'         not in entry: entry['enabled']         = bool(
                    (entry.get('xmltv_url') or '').strip() and
                    ((entry.get('m3u_source') or '').strip() or (entry.get('channel_id') or '').strip()))
                if 'days'            not in entry: entry['days']            = 7
                if 'channel_id'      not in entry: entry['channel_id']      = ''
                if 'player_override' not in entry: entry['player_override'] = False
                if 'player_int_on'   not in entry: entry['player_int_on']   = True
                if 'player_sl_on'    not in entry: entry['player_sl_on']    = False
                if 'player_rec_on'   not in entry: entry['player_rec_on']   = False
            while len(data) < MAX_CUSTOM_PROVIDERS:
                data.append(dict(_empty))
            return data[:MAX_CUSTOM_PROVIDERS]
    except Exception:
        pass
    return default


def saveProviderConfig(data):
    """Persist the custom provider list. Returns True on success."""
    try:
        dir_path = os.path.dirname(PROVIDERS_CFG_FILE)
        if dir_path and not os.path.isdir(dir_path):
            os.makedirs(dir_path)
        with open(PROVIDERS_CFG_FILE, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


def loadIntegratedProviders():
    """Return list of user-added custom integrated providers from plugin settings."""
    return list(loadPluginSettings().get('integrated_providers_custom', []))


def saveIntegratedProviders(providers):
    """Persist user-added custom integrated providers. Returns True on success."""
    s = loadPluginSettings()
    s['integrated_providers_custom'] = list(providers)
    return savePluginSettings(s)

# ---------------------------------------------------------------------------
# In-memory M3U result cache (1 hour TTL)
# ---------------------------------------------------------------------------

_provider_cache = {}
_CACHE_TTL      = 3600


def _getCachedOrFetch(source, fetch_fn):
    now   = currTime()
    entry = _provider_cache.get(source)
    if entry and entry[0] > now:
        return entry[1]
    data = fetch_fn(source)
    _provider_cache[source] = (now + _CACHE_TTL, data)
    return data

# ---------------------------------------------------------------------------
# Per-channel XMLTV disk cache (12 hour TTL)
# ---------------------------------------------------------------------------

_XMLTV_CACHE_TTL = 7 * 24 * 3600  # 7 days — survives long standby periods

# Per-session set of (prov_name, tvg_id) pairs that have already been retried
# via on-demand fetchXMLTVEvents after a negative (empty) build cache hit.
# Prevents re-parsing a large XMLTV file on every play for channels with no EPG.
_xmltv_negative_retried = set()


def _xmltvCacheDir(prov_name):
    """Return (and create) a per-provider subdirectory inside getDataDir()."""
    safe = re.sub(r'[^\w\-]', '_', (prov_name or 'default').strip()) or 'default'
    d = os.path.join(getDataDir(), safe)
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
    except Exception:
        d = getDataDir()
    return d


def _xmltvCachePath(prov_name, tvg_id):
    key = (tvg_id or '').encode('utf-8') if isinstance((tvg_id or ''), str) else (tvg_id or b'')
    return os.path.join(_xmltvCacheDir(prov_name), 'epg_%s.json' % md5(key).hexdigest())


def _loadXMLTVCache(prov_name, tvg_id, ttl=None):
    """Return cached events list if fresh and valid, else None."""
    effective_ttl = ttl if ttl is not None else _XMLTV_CACHE_TTL
    path = _xmltvCachePath(prov_name, tvg_id)
    try:
        if currTime() - os.path.getmtime(path) < effective_ttl:
            with open(path, 'r') as f:
                data = json.load(f)
            if not isinstance(data, list):
                return None
            return [tuple(e) for e in data]
    except Exception:
        pass
    return None


def _saveXMLTVCache(prov_name, tvg_id, events):
    """Persist events list to disk cache. Only written when events is non-empty."""
    if not events:
        return
    path = _xmltvCachePath(prov_name, tvg_id)
    try:
        with open(path, 'w') as f:
            json.dump([list(e) for e in events], f)
    except Exception:
        pass


def _clearProviderCache(prov_name):
    """Delete all epg_*.json files from *prov_name*'s cache directory."""
    try:
        cache_dir = _xmltvCacheDir(prov_name)
        for fname in os.listdir(cache_dir):
            if fname.startswith('epg_') and fname.endswith('.json'):
                try:
                    os.remove(os.path.join(cache_dir, fname))
                except Exception:
                    pass
    except Exception:
        pass


def _providerHasAnyCache(prov_name):
    """True if Start Build has already been run for *prov_name*."""
    try:
        cache_dir = _xmltvCacheDir(prov_name)
        for fname in os.listdir(cache_dir):
            if fname.startswith('epg_') and fname.endswith('.json'):
                return True
    except Exception:
        pass
    return False

# ---------------------------------------------------------------------------
# XMLTV file-level disk cache (download once, reuse for 12 hours)
# ---------------------------------------------------------------------------

_XMLTV_FILE_TTL = 12 * 3600


def _xmltvLocalFilePath(source, prov_name=None):
    """Return the local disk path used to cache a downloaded XMLTV file."""
    key = source.encode('utf-8') if isinstance(source, str) else source
    h   = md5(key).hexdigest()
    ext = '.xml.gz' if source.lower().rstrip('/').endswith('.gz') else '.xml'
    safe   = re.sub(r'[^\w\-]', '_', (prov_name or '').strip()) if prov_name else ''
    prefix = ('%s_' % safe) if safe else ''
    return os.path.join(getDataDir(), '%sxmltv_%s%s' % (prefix, h, ext))


def _epgSourceFilePath(source, prov_name):
    """Return the single canonical path used to store an EPG XMLTV file.

    Files go to  <data>/IPTVPlaylistCreator/EPG_SourceFiles/<prov>_EPG_Source.<ext>
    so there is exactly one copy — no separate cache in the root folder.
    """
    ext      = '.xml.gz' if source.lower().rstrip('/').endswith('.gz') else '.xml'
    safe     = re.sub(r'[^\w\-]', '_', prov_name.strip())[:60] or 'Provider'
    dest_dir = os.path.join(getDataDir(), 'IPTVPlaylistCreator', 'EPG_SourceFiles')
    try:
        if not os.path.isdir(dest_dir):
            os.makedirs(dest_dir)
    except Exception:
        pass
    return os.path.join(dest_dir, '%s_EPG_Source%s' % (safe, ext))


def _downloadXMLTVToCache(source, prov_name=None, copy_to_epg_dir=True):
    """Download *source* to a local cache file, reusing a fresh copy if available.

    Returns the local file path on success, or None on failure.

    When *copy_to_epg_dir* is True (the default) AND *prov_name* is given the
    file is stored directly as
      <data>/IPTVPlaylistCreator/EPG_SourceFiles/<prov>_EPG_Source.<ext>
    so there is exactly one copy and nothing lands in the root data folder.

    Pass copy_to_epg_dir=False when downloading solely to look up picon logo
    URLs — those use the legacy hash-named root cache and never appear in
    EPG_SourceFiles.
    """
    if copy_to_epg_dir and prov_name:
        local_path = _epgSourceFilePath(source, prov_name)
    else:
        local_path = _xmltvLocalFilePath(source, prov_name)
    # If URL has no .gz extension, the file may have been saved as .xml.gz
    # after magic-byte detection — check for that variant first
    if local_path.endswith('.xml') and not os.path.isfile(local_path):
        _gz_path = local_path + '.gz'
        if os.path.isfile(_gz_path):
            local_path = _gz_path
    tmp_path = local_path + '.tmp'
    try:
        age = currTime() - os.path.getmtime(local_path)
        if age < _XMLTV_FILE_TTL and os.path.getsize(local_path) > 100:
            try:
                iptvLogWrite('[XMLTV] Cache hit: %s (age %dh %dm)' % (
                    local_path, age // 3600, (age % 3600) // 60))
            except Exception:
                pass
            return local_path
    except Exception:
        pass
    resp = None
    try:
        try:
            iptvLogWrite('[XMLTV] Downloading %s ...' % source)
        except Exception:
            pass
        req  = Request(_normalizeHttpUrl(source), headers=XMLTV_HEADERS)
        resp = urlopen(req, timeout=120)
        written = 0
        with open(tmp_path, 'wb') as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                written += len(chunk)
        if written > 0:
            try:
                os.remove(local_path)
            except Exception:
                pass
            os.rename(tmp_path, local_path)
            # If content is gzip but saved without .gz extension, rename it
            if not local_path.lower().endswith('.gz'):
                try:
                    with open(local_path, 'rb') as _mf:
                        _magic = _mf.read(2)
                    if _magic == b'\x1f\x8b':
                        gz_path = local_path + '.gz'
                        try:
                            os.remove(gz_path)
                        except Exception:
                            pass
                        os.rename(local_path, gz_path)
                        local_path = gz_path
                except Exception:
                    pass
            try:
                iptvLogWrite('[XMLTV] Saved %d bytes to %s' % (written, local_path))
            except Exception:
                pass
            return local_path
        try:
            iptvLogWrite('[XMLTV] Download returned 0 bytes from %s' % source)
        except Exception:
            pass
    except Exception as exc:
        try:
            iptvLogWrite('[XMLTV] Download error for %s: %s' % (source, str(exc)[:200]))
        except Exception:
            pass
    finally:
        try:
            if resp:
                resp.close()
        except Exception:
            pass
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
    return None

# ---------------------------------------------------------------------------
# M3U / Enigma2 playlist parsing
# ---------------------------------------------------------------------------

def _parseEnigma2Playlist(content, source=''):
    """Parse Enigma2 bouquet/userbouquet (.tv) format into a channel list."""
    channels = []
    lines    = content.splitlines()
    i        = 0
    while i < len(lines):
        line  = lines[i].strip()
        upper = line.upper()
        if upper.startswith('#SERVICE'):
            svc_str = line[8:].strip()
            if 'FROM BOUQUET' in svc_str.upper():
                i += 1
                continue
            parts    = svc_str.split(':')
            if len(parts) >= 11:
                svc_type = parts[0].strip()
                if svc_type in ('4097', '4096', '1'):
                    raw_url    = ':'.join(parts[10:]).strip()
                    stream_url = raw_url.replace('%3a', ':').replace('%3A', ':')
                    stream_url = stream_url.replace('%2f', '/').replace('%2F', '/')
                    sl = stream_url.lower()
                    if (sl.startswith('http://') or sl.startswith('https://') or
                            sl.startswith('rtsp://') or sl.startswith('rtmp://')):
                        name = ''
                        if i + 1 < len(lines):
                            next_line = lines[i + 1].strip()
                            if next_line.upper().startswith('#DESCRIPTION'):
                                desc_text = next_line[12:].strip()
                                if desc_text:
                                    name = desc_text
                                i += 1
                        if not name:
                            try:
                                name = stream_url.rstrip('/').split('/')[-1].split('.')[0] or stream_url
                            except Exception:
                                name = stream_url
                        channels.append({'tvg_id': '', 'tvg_name': name,
                                         'name': name, 'url': stream_url})
        i += 1
    try:
        iptvLogWrite('[E2Playlist] "%s": %d channels parsed' % (source, len(channels)))
    except Exception:
        pass
    return channels


def fetchM3UChannels(source):
    """Parse a local or HTTP M3U/EXTM3U/Enigma2 playlist → list of channel dicts."""
    channels = []
    try:
        src_lower = (source or '').lower()
        if src_lower.startswith('http://') or src_lower.startswith('https://'):
            req  = Request(_normalizeHttpUrl(source), headers=HEADERS)
            resp = urlopen(req, timeout=15)
            raw  = resp.read()
            resp.close()
        else:
            with open(source, 'rb') as f:
                raw = f.read()
        raw     = _gunzip(raw)
        content = None
        for enc in ('utf-8-sig', 'utf-8', 'cp1251', 'latin-1'):
            try:
                content = raw.decode(enc)
                break
            except (UnicodeDecodeError, LookupError):
                content = None
        if not content:
            content = raw.decode('utf-8', errors='replace')

        content_upper = content.upper()
        is_enigma2 = (
            src_lower.endswith('.tv') or
            (('#SERVICE 4097:' in content_upper or '#SERVICE 4096:' in content_upper) and
             '#EXTINF:' not in content_upper)
        )
        if is_enigma2:
            try:
                iptvLogWrite('[M3U] "%s": detected Enigma2 playlist format' % source)
            except Exception:
                pass
            return _parseEnigma2Playlist(content, source)

        lines       = content.splitlines()
        extinf_count = sum(1 for l in lines if l.strip().startswith('#EXTINF:'))
        try:
            iptvLogWrite('[M3U] "%s": %d lines, %d #EXTINF entries' % (
                source, len(lines), extinf_count))
        except Exception:
            pass
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('#EXTINF:'):
                tvg_id_m        = re.search(r'tvg-id="([^"]*)"',         line)
                tvg_name_m      = re.search(r'tvg-name="([^"]*)"',       line)
                tvg_logo_m      = re.search(r'tvg-logo="([^"]*)"',       line)
                group_m         = re.search(r'group-title="([^"]*)"',    line)
                catchup_src_m   = re.search(r'catchup-source="([^"]*)"', line)
                tvg_id      = tvg_id_m.group(1).strip()       if tvg_id_m      else ''
                tvg_name    = tvg_name_m.group(1).strip()     if tvg_name_m    else ''
                tvg_logo    = tvg_logo_m.group(1).strip()     if tvg_logo_m    else ''
                group_title = group_m.group(1).strip()        if group_m       else ''
                catchup_src = catchup_src_m.group(1).strip()  if catchup_src_m else ''
                display_name = line.split(',', 1)[1].strip() if ',' in line else tvg_name
                i += 1
                while i < len(lines) and (not lines[i].strip() or lines[i].strip().startswith('#')):
                    mid = lines[i].strip()
                    if mid.startswith('#EXTGRP:') and not group_title:
                        group_title = mid[8:].strip()
                    i += 1
                if i < len(lines):
                    stream_url = lines[i].strip()
                    if stream_url:
                        ch = {
                            'tvg_id':      tvg_id,
                            'tvg_name':    tvg_name or display_name,
                            'name':        display_name,
                            'url':         stream_url,
                            'group_title': group_title,
                            'tvg_logo':    tvg_logo,
                        }
                        if catchup_src:
                            ch['catchup_source'] = catchup_src
                        channels.append(ch)
            i += 1
        if not channels:
            try:
                iptvLogWrite('[M3U] 0 channels from "%s"; first 120 bytes: %r' % (source, raw[:120]))
            except Exception:
                pass
    except Exception as exc:
        try:
            iptvLogWrite('[M3U] Exception reading "%s": %s' % (source, str(exc)[:200]))
        except Exception:
            pass
    return channels

# ---------------------------------------------------------------------------
# XMLTV parsing helpers
# ---------------------------------------------------------------------------

def _parseXMLTVTime(ts):
    """Parse an XMLTV timestamp string (20230515143000 +0300) → UTC epoch int."""
    import calendar as _cal
    ts      = ts.strip()
    parts   = ts.split()
    dt_str  = parts[0]
    tz_str  = parts[1] if len(parts) > 1 else '+0000'
    struct  = time.strptime(dt_str, '%Y%m%d%H%M%S')
    utc_ts  = _cal.timegm(struct)
    sign    = 1 if tz_str[0] == '+' else -1
    tz_h    = int(tz_str[1:3]) if len(tz_str) >= 3 else 0
    tz_m    = int(tz_str[3:5]) if len(tz_str) >= 5 else 0
    return utc_ts - sign * (tz_h * 3600 + tz_m * 60)


def fetchXMLTVEvents(source, channel_id, days=7, channel_name=None, prov_name=None):
    """Parse XMLTV events for *channel_id* from *source* (URL or local path).

    Downloads the XMLTV file to a local cache first (reused for 12 h) so that
    large feeds are only fetched once regardless of how many channels are looked up.
    """
    events   = []
    now      = currTime()
    week_ago = now - days * 86400
    _f       = None
    try:
        import gzip as _gzip
        src_lower = (source or '').lower()
        if src_lower.startswith('http://') or src_lower.startswith('https://'):
            local = _downloadXMLTVToCache(source, prov_name)
            if local is None:
                return events
            parse_path = local
        else:
            parse_path = source

        def _open_src(path):
            f = open(path, 'rb')
            _m = f.read(2); f.seek(0)
            s = _gzip.GzipFile(fileobj=f) if _m == b'\x1f\x8b' else f
            return f, s

        _id_low   = (channel_id   or '').lower()
        _id_norm  = _normName(channel_id or '')
        _name_low = (channel_name or '').lower()

        match_ids = set()
        if channel_id:
            match_ids.add(channel_id)

        _f, src  = _open_src(parse_path)
        _xml_root = None
        for _ev, elem in ET.iterparse(src, events=('start', 'end')):
            if _ev == 'start':
                if _xml_root is None:
                    _xml_root = elem
                continue
            tag = elem.tag
            if tag == 'channel':
                ch_xmltv_id = elem.get('id', '')
                if ch_xmltv_id and ch_xmltv_id not in match_ids:
                    ch_low     = ch_xmltv_id.lower()
                    ch_norm    = _normName(ch_xmltv_id)
                    ch_stripped = _stripIdPrefix(ch_low)
                    _id_stripped = _stripIdPrefix(_id_low)
                    if _id_low and (ch_low == _id_low
                                    or (_id_norm and ch_norm == _id_norm)
                                    or (_id_stripped and ch_stripped
                                        and _id_stripped == ch_stripped)):
                        match_ids.add(ch_xmltv_id)
                    else:
                        for dn in elem.findall('display-name'):
                            dn_low = (dn.text or '').strip().lower()
                            if dn_low and ((_id_low   and dn_low == _id_low) or
                                           (_name_low and dn_low == _name_low)):
                                match_ids.add(ch_xmltv_id)
                                break
                elem.clear()
                if _xml_root is not None:
                    try: _xml_root.remove(elem)
                    except Exception: pass
            elif tag == 'programme':
                if elem.get('channel') in match_ids:
                    try:
                        btime = _parseXMLTVTime(elem.get('start', ''))
                        etime = _parseXMLTVTime(elem.get('stop',  ''))
                        if week_ago <= btime < now + days * 86400 and etime > btime:
                            title_el = elem.find('title')
                            desc_el  = elem.find('desc')
                            title = xml_unescape(title_el.text or '') if title_el is not None and title_el.text else ''
                            descr = xml_unescape(desc_el.text  or '') if desc_el  is not None and desc_el.text  else ''
                            events.append((descr, random.randint(0, 1000), btime, etime - btime, title))
                    except Exception:
                        pass
                elem.clear()
                if _xml_root is not None:
                    try: _xml_root.remove(elem)
                    except Exception: pass
    except Exception:
        pass
    finally:
        try:
            if _f:
                _f.close()
        except Exception:
            pass
    return events


def _fetchXMLTVAllChannels(parse_path, targets, days):
    """Single iterparse pass for MULTIPLE channels simultaneously.

    targets  – list of (tvg_id, channel_name) tuples
    Returns  – dict {tvg_id: [event_tuples]}
    """
    import gzip as _gzip
    now      = currTime()
    week_ago = now - days * 86400
    _f       = None
    results  = {}
    try:
        exact_to_tvgids = {}
        norm_to_tvgids  = {}

        def _add(key, tvg_id, table):
            if key:
                table.setdefault(key, set()).add(tvg_id)

        stripped_to_tvgids = {}

        for (tvg_id, ch_name) in targets:
            if not tvg_id:
                continue
            _add(tvg_id.lower(),              tvg_id, exact_to_tvgids)
            _add(_normName(tvg_id),           tvg_id, norm_to_tvgids)
            _add(_stripIdPrefix(tvg_id.lower()), tvg_id, stripped_to_tvgids)
            if ch_name:
                _add(ch_name.lower(), tvg_id, exact_to_tvgids)

        # Pre-seed with exact tvg_id values so that <programme channel="X">
        # elements are captured even when the XMLTV has no <channel id="X">
        # definition block.  This mirrors what fetchXMLTVEvents does by adding
        # the channel_id to match_ids before the parse starts.
        # Also seed the lowercase variant — XMLTV programme channel attributes
        # sometimes differ in case from the M3U tvg-id (e.g. "тнт" vs "ТНТ").
        xmltv_id_to_tvgids = {}
        for (_tid, _) in targets:
            if _tid:
                xmltv_id_to_tvgids.setdefault(_tid, set()).add(_tid)
                _tid_lc = _tid.lower()
                if _tid_lc != _tid:
                    xmltv_id_to_tvgids.setdefault(_tid_lc, set()).add(_tid)

        _f  = open(parse_path, 'rb')
        _m  = _f.read(2); _f.seek(0)
        src = _gzip.GzipFile(fileobj=_f) if _m == b'\x1f\x8b' else _f

        # Two-phase display-name matching.
        #
        # Phase 1 (inside the parse loop): match channels via their id directly
        # (exact / norm / stripped-prefix).  Every tvg_id claimed this way is
        # recorded in `directly_claimed` — those are the "authoritative" owners.
        #
        # Display-name matches are deferred into `dn_pending`:
        #   dn_pending[xmltv_id] = set of tvg_ids the display-names suggested.
        #
        # Phase 2 (after the loop): apply a display-name match only when the
        # suggested tvg_id has NO authoritative owner yet.  This prevents
        # "ntv-hd-tr" (display-name "NTV") from stealing the "ntv" slot that
        # already belongs to <channel id="ntv">, while still allowing a numeric
        # id like "3344" (display-name "NTV") to claim "ntv" when no direct
        # channel-id match for "ntv" exists in this XMLTV file.
        directly_claimed = set()   # tvg_ids owned via steps 1-3
        dn_pending = {}            # xmltv_id → set(tvg_id) from display-name scan

        _xml_root = None
        for _ev, elem in ET.iterparse(src, events=('start', 'end')):
            if _ev == 'start':
                if _xml_root is None:
                    _xml_root = elem
                continue
            tag = elem.tag
            if tag == 'channel':
                xmltv_id = elem.get('id', '')
                if xmltv_id:
                    matched = set()
                    for tid in exact_to_tvgids.get(xmltv_id.lower(), ()):
                        matched.add(tid)
                    for tid in norm_to_tvgids.get(_normName(xmltv_id), ()):
                        matched.add(tid)
                    if not matched:
                        xs = _stripIdPrefix(xmltv_id.lower())
                        if xs:
                            for tid in stripped_to_tvgids.get(xs, ()):
                                matched.add(tid)
                    if matched:
                        # Direct match — record authoritative ownership.
                        directly_claimed.update(matched)
                        # Use update/merge so that duplicate <channel id="X">
                        # blocks accumulate all mapped tvg_ids.
                        xmltv_id_to_tvgids.setdefault(xmltv_id, set()).update(matched)
                    else:
                        # No direct match — scan display-names and defer.
                        dn_matched = set()
                        for dn in elem.findall('display-name'):
                            dn_low = (dn.text or '').strip().lower()
                            if not dn_low:
                                continue
                            for tid in exact_to_tvgids.get(dn_low, ()):
                                dn_matched.add(tid)
                            # No break — scan ALL display-names so that a single
                            # <channel> block listing "Мир 24" then "Мир 24 HD"
                            # maps BOTH tvg_ids to this channel id.
                        if dn_matched:
                            dn_pending.setdefault(xmltv_id, set()).update(dn_matched)
                        elif xmltv_id in xmltv_id_to_tvgids:
                            # Already pre-seeded (tvg_id == xmltv_id); count as direct.
                            directly_claimed.update(xmltv_id_to_tvgids[xmltv_id])
                elem.clear()
                if _xml_root is not None:
                    try: _xml_root.remove(elem)
                    except Exception: pass
            elif tag == 'programme':
                if dn_pending:
                    # Phase 2: apply deferred display-name matches, but only
                    # for tvg_ids that have no authoritative (direct) owner.
                    # Example: <channel id="ntv"> already owns "ntv" directly,
                    # so <channel id="ntv-hd-tr"> with display-name "NTV" cannot
                    # claim it.  But <channel id="3344"> with display-name "NTV"
                    # CAN claim it when no direct owner exists.
                    for _xid, _tids in dn_pending.items():
                        safe = _tids - directly_claimed
                        if safe:
                            xmltv_id_to_tvgids.setdefault(_xid, set()).update(safe)
                    dn_pending.clear()
                tvgids = xmltv_id_to_tvgids.get(elem.get('channel', ''))
                if tvgids:
                    try:
                        btime = _parseXMLTVTime(elem.get('start', ''))
                        etime = _parseXMLTVTime(elem.get('stop',  ''))
                        if week_ago <= btime < now + days * 86400 and etime > btime:
                            title_el = elem.find('title')
                            desc_el  = elem.find('desc')
                            title = xml_unescape(title_el.text or '') if title_el is not None and title_el.text else ''
                            descr = xml_unescape(desc_el.text  or '') if desc_el  is not None and desc_el.text  else ''
                            ev = (descr, random.randint(0, 1000), btime, etime - btime, title)
                            for tid in tvgids:
                                results.setdefault(tid, []).append(ev)
                    except Exception:
                        pass
                elem.clear()
                if _xml_root is not None:
                    try: _xml_root.remove(elem)
                    except Exception: pass
    except Exception:
        pass
    finally:
        try:
            if _f:
                _f.close()
        except Exception:
            pass
    return results

# ---------------------------------------------------------------------------
# Bulk cache build (Start Build / auto-build)
# ---------------------------------------------------------------------------

_BUILD_BATCH_SIZE = 300


def _buildAllChannelCaches(providers, current_url, current_channel_name,
                           progress_cb=None, cancel_check=None):
    """Parse XMLTV once and cache ALL M3U channels for every enabled provider.

    Returns the events list for *current_url* (ready for display), False if
    the build was cancelled, or None if nothing was found.
    """
    def _log(msg):
        try:
            iptvLogWrite('[BulkCache] ' + msg)
        except Exception:
            pass

    current_events = None
    try:
        parsed_cur    = urlparse(current_url)
        cur_url_path  = parsed_cur.path
        cur_no_query  = parsed_cur._replace(query='', fragment='').geturl()
        cur_name_low  = (current_channel_name or '').lower().strip()
        cur_name_norm = _normName(current_channel_name)

        for prov in providers:
            prov_name  = prov.get('name', 'unnamed')
            m3u_source = (prov.get('m3u_source') or '').strip()
            xmltv_url  = (prov.get('xmltv_url')  or '').strip()
            pinned_id  = (prov.get('channel_id') or '').strip()
            if not xmltv_url:
                continue

            prov_days = int(prov.get('days', 7) or 7)

            _ttl_custom = bool(prov.get('cache_ttl_custom', False))
            _ttl_days   = int(prov.get('cache_ttl_days', 0) or 0)
            _prov_ttl   = (_ttl_days * 24 * 3600) if (_ttl_custom and _ttl_days > 0) else _XMLTV_CACHE_TTL

            current_tvg_id = None
            channels       = []
            if pinned_id:
                current_tvg_id = pinned_id
                _log('Provider "%s": using pinned channel_id="%s"' % (prov_name, pinned_id))
                if m3u_source:
                    channels = _getCachedOrFetch(m3u_source, fetchM3UChannels) or []
                    _log('Provider "%s": M3U loaded, %d channels' % (prov_name, len(channels)))
            elif m3u_source:
                _log('Provider "%s": loading M3U...' % prov_name)
                channels = _getCachedOrFetch(m3u_source, fetchM3UChannels) or []
                if not channels:
                    _log('Provider "%s": M3U empty or failed' % prov_name)
                    continue
                _log('Provider "%s": %d channels in M3U' % (prov_name, len(channels)))
            else:
                _log('Provider "%s": no m3u_source and no channel_id — skipping' % prov_name)
                continue

            if not current_tvg_id:
                for ch in channels:
                    ch_url = ch.get('url', '')
                    m_id   = (ch.get('tvg_id') or ch.get('tvg_name') or ch.get('name') or '').strip()
                    if not m_id:
                        continue
                    if ch_url == current_url:
                        current_tvg_id = m_id; break
                    if urlparse(ch_url).path == cur_url_path and cur_url_path:
                        current_tvg_id = m_id; break
                    ch_no_q = urlparse(ch_url)._replace(query='', fragment='').geturl()
                    if ch_no_q == cur_no_query and cur_no_query:
                        current_tvg_id = m_id; break
            if not current_tvg_id and cur_name_low:
                for ch in channels:
                    m_name = (ch.get('tvg_name') or ch.get('name') or '').strip()
                    m_norm = _normName(m_name)
                    if m_name.lower() == cur_name_low:
                        current_tvg_id = (ch.get('tvg_id') or m_name); break
                    if m_norm == cur_name_norm and cur_name_norm:
                        current_tvg_id = (ch.get('tvg_id') or m_name); break
                    if cur_name_norm and m_norm and len(cur_name_norm) >= 3 and len(m_norm) >= 3:
                        if cur_name_norm.startswith(m_norm) or m_norm.startswith(cur_name_norm):
                            current_tvg_id = (ch.get('tvg_id') or m_name); break

            # One-shot directory scan — find already-fresh cache files
            targets      = []
            seen_tvgids  = set()
            _fresh_stems = set()
            try:
                _cache_dir = _xmltvCacheDir(prov_name)
                _now_ts    = currTime()
                for _fname in os.listdir(_cache_dir):
                    if not (_fname.startswith('epg_') and _fname.endswith('.json')):
                        continue
                    try:
                        _fage = _now_ts - os.path.getmtime(os.path.join(_cache_dir, _fname))
                        if _fage < _prov_ttl:
                            _fresh_stems.add(_fname[4:-5])
                    except Exception:
                        pass
            except Exception:
                pass
            _log('Provider "%s": %d fresh cache files found via directory scan' % (
                prov_name, len(_fresh_stems)))

            def _is_fresh(tvg_id):
                if _fresh_stems:
                    _k = tvg_id.encode('utf-8') if isinstance(tvg_id, str) else tvg_id
                    return md5(_k).hexdigest() in _fresh_stems
                return _loadXMLTVCache(prov_name, tvg_id, ttl=_prov_ttl) is not None

            if channels:
                for ch in channels:
                    tvg_id  = (ch.get('tvg_id') or ch.get('tvg_name') or ch.get('name') or '').strip()
                    ch_name = (ch.get('tvg_name') or ch.get('name') or '').strip()
                    if not tvg_id or tvg_id in seen_tvgids:
                        continue
                    seen_tvgids.add(tvg_id)
                    if _is_fresh(tvg_id):
                        continue
                    targets.append((tvg_id, ch_name))
            elif current_tvg_id:
                if not _is_fresh(current_tvg_id):
                    targets.append((current_tvg_id, current_channel_name or current_tvg_id))

            _log('Provider "%s": %d/%d channels need caching' % (
                prov_name, len(targets), len(seen_tvgids) or 1))

            if not targets:
                _log('Provider "%s": all channels already cached' % prov_name)
                if current_tvg_id:
                    current_events = _loadXMLTVCache(prov_name, current_tvg_id) or current_events
                continue

            src_lower = xmltv_url.lower()
            if src_lower.startswith('http://') or src_lower.startswith('https://'):
                parse_path = _downloadXMLTVToCache(xmltv_url, prov_name)
                if not parse_path:
                    _log('Provider "%s": XMLTV download failed' % prov_name)
                    raise Exception('XMLTV download failed for provider "%s". Check XMLTV URL and network connection.' % prov_name)
            else:
                parse_path = xmltv_url

            cached_count = 0
            total_bulk   = len(targets)

            for _batch_start in range(0, len(targets), _BUILD_BATCH_SIZE):
                if cancel_check and cancel_check():
                    _log('Provider "%s": build cancelled after %d channels' % (prov_name, cached_count))
                    return current_events if current_events is not None else False

                batch = targets[_batch_start: _batch_start + _BUILD_BATCH_SIZE]
                _log('Provider "%s": parsing batch %d-%d / %d' % (
                    prov_name, _batch_start + 1, _batch_start + len(batch), total_bulk))

                bulk = _fetchXMLTVAllChannels(parse_path, batch, prov_days)
                _log('Provider "%s": batch matched %d channels' % (prov_name, len(bulk)))

                _matched_ids = set()
                for tvg_id, evs in bulk.items():
                    if cancel_check and cancel_check():
                        _log('Provider "%s": build cancelled after %d channels' % (prov_name, cached_count))
                        return current_events if current_events is not None else False
                    if evs:
                        _saveXMLTVCache(prov_name, tvg_id, evs)
                        _matched_ids.add(tvg_id)
                        cached_count += 1
                        if progress_cb and cached_count % 10 == 0:
                            try:
                                progress_cb(cached_count, total_bulk, prov_name)
                            except Exception:
                                pass

                # Negative cache — write empty marker for channels with no EPG data
                _no_epg_count = 0
                _no_match_ids = []
                for tvg_id, _ch_name in batch:
                    if tvg_id not in _matched_ids:
                        try:
                            with open(_xmltvCachePath(prov_name, tvg_id), 'w') as _mf:
                                _mf.write('[]')
                            _no_epg_count += 1
                            _no_match_ids.append(tvg_id)
                        except Exception:
                            pass
                if _no_epg_count:
                    _log('Provider "%s": wrote %d negative-cache markers' % (prov_name, _no_epg_count))
                    _sample = _no_match_ids[:10]
                    _extra  = len(_no_match_ids) - len(_sample)
                    _log('Provider "%s": no XMLTV match for: %s%s' % (
                        prov_name,
                        ', '.join('"%s"' % x for x in _sample),
                        ('  …+%d more' % _extra) if _extra > 0 else ''))

                if current_tvg_id and current_events is None:
                    _cur_evs = bulk.get(current_tvg_id)
                    if _cur_evs:
                        current_events = sorted(_cur_evs, key=lambda x: x[2], reverse=True)

                del bulk

                try:
                    import time as _time
                    _time.sleep(0.15)
                except Exception:
                    pass

            if progress_cb:
                try:
                    progress_cb(cached_count, total_bulk, prov_name)
                except Exception:
                    pass
            _log('Provider "%s": saved caches for %d channels' % (prov_name, cached_count))

            if current_tvg_id and current_events is None:
                cached = _loadXMLTVCache(prov_name, current_tvg_id)
                if cached:
                    current_events = sorted(cached, key=lambda x: x[2], reverse=True)

    except Exception as exc:
        try:
            iptvLogWrite('[BulkCache] Exception: ' + str(exc))
        except Exception:
            pass

    return current_events

# ---------------------------------------------------------------------------
# Per-channel on-demand fetch (fast path — reads from disk cache when available)
# ---------------------------------------------------------------------------

_matched_catchup_source = ''  # catchup-source from matched M3U channel

def _fetchCustomProvider(url, channel_name, providers):
    """Fetch EPG for one channel from custom providers.  Safe to call in a thread.

    Returns sorted events list, [] (built but no data), or None (no match).
    """
    def _log(msg):
        try:
            iptvLogWrite('[CustomProvider] ' + msg)
        except Exception:
            pass

    try:
        parsed        = urlparse(url)
        url_path      = parsed.path
        url_no_query  = parsed._replace(query='', fragment='').geturl()
        ch_name_norm  = _normName(channel_name)
        ch_name_low   = (channel_name or '').lower().strip()

        # Name of the provider that owns the stream via a URL-based match.
        # Set when a URL match is found but its XMLTV has 0 events and the
        # fallback-EPG option is ON.  Other providers then supply EPG data
        # while this name is used for player-selection so the correct player
        # config is always applied.
        url_matched_prov = None

        _log('--- Starting match for URL=%s  name="%s" ---' % (url, channel_name))

        # Pre-scan: determine which providers URL-match this stream.
        # When at least one provider owns the URL, name-based matching is
        # suppressed for ALL providers — the stream URL is the authoritative
        # ownership signal.  Without this guard a provider whose M3U happens
        # to contain a similarly-named channel (e.g. "Первый канал" ≈
        # "Первый HD") would steal the EPG and apply the wrong player config.
        _url_owners = set()
        for _sp in providers:
            _sp_pinned = (_sp.get('channel_id') or '').strip()
            if _sp_pinned:
                _url_owners.add(_sp.get('name', 'unnamed'))
                continue
            _sp_m3u = (_sp.get('m3u_source') or '').strip()
            if not _sp_m3u:
                continue
            _sp_chs = _getCachedOrFetch(_sp_m3u, fetchM3UChannels)
            if not _sp_chs:
                continue
            for _sc in _sp_chs:
                _sc_url = _sc.get('url', '')
                if not _sc_url:
                    continue
                if _sc_url == url:
                    _url_owners.add(_sp.get('name', 'unnamed')); break
                if urlparse(_sc_url).path == url_path and url_path:
                    _url_owners.add(_sp.get('name', 'unnamed')); break
                _sc_nq = urlparse(_sc_url)._replace(query='', fragment='').geturl()
                if _sc_nq == url_no_query and url_no_query:
                    _url_owners.add(_sp.get('name', 'unnamed')); break
        _name_match_allowed = not _url_owners
        if _url_owners:
            _log('URL-owner pre-scan: [%s] — name matching suppressed'
                 % ', '.join(sorted(_url_owners)))
        else:
            _log('URL-owner pre-scan: no URL match found — name matching allowed')

        for prov in providers:
            prov_name  = prov.get('name', 'unnamed')
            m3u_source = (prov.get('m3u_source') or '').strip()
            xmltv_url  = (prov.get('xmltv_url')  or '').strip()
            if not m3u_source or not xmltv_url:
                continue

            _log('Provider "%s": fetching M3U from %s' % (prov_name, m3u_source))
            channels = _getCachedOrFetch(m3u_source, fetchM3UChannels)
            _log('Provider "%s": M3U parsed, %d channels found' % (prov_name, len(channels)))
            if not channels:
                continue

            tvg_id       = None
            match_method = None

            pinned_id = (prov.get('channel_id') or '').strip()
            if pinned_id:
                tvg_id       = pinned_id
                match_method = 'pinned_channel_id'
                _log('Provider "%s": using pinned channel_id="%s"' % (prov_name, tvg_id))

            _matched_ch = None
            if not tvg_id:
                for ch in channels:
                    ch_url = ch.get('url', '')
                    if not ch_url:
                        continue
                    if ch_url == url:
                        tvg_id       = ch.get('tvg_id') or ch.get('tvg_name') or ch.get('name') or ''
                        _matched_ch  = ch
                        match_method = 'exact_url'; break
                    if urlparse(ch_url).path == url_path and url_path:
                        tvg_id       = ch.get('tvg_id') or ch.get('tvg_name') or ch.get('name') or ''
                        _matched_ch  = ch
                        match_method = 'path_match'; break
                    ch_no_q = urlparse(ch_url)._replace(query='', fragment='').geturl()
                    if ch_no_q == url_no_query and url_no_query:
                        tvg_id       = ch.get('tvg_id') or ch.get('tvg_name') or ch.get('name') or ''
                        _matched_ch  = ch
                        match_method = 'url_no_query'; break
                # Store catchup_source from matched channel in module-level var
                if _matched_ch is not None:
                    global _matched_catchup_source
                    _matched_catchup_source = _matched_ch.get('catchup_source', '')

            if not tvg_id and ch_name_low and _name_match_allowed:
                fuzzy_candidates = []
                for ch in channels:
                    m_name = (ch.get('tvg_name') or ch.get('name') or '').strip()
                    m_low  = m_name.lower()
                    m_norm = _normName(m_name)
                    if m_low == ch_name_low:
                        tvg_id = ch.get('tvg_id') or m_name or ''
                        match_method = 'name_exact'; break
                    if m_norm == ch_name_norm and ch_name_norm:
                        tvg_id = ch.get('tvg_id') or m_name or ''
                        match_method = 'name_fuzzy'; break
                    if ch_name_norm and m_norm and len(ch_name_norm) >= 3 and len(m_norm) >= 3:
                        if ch_name_norm.startswith(m_norm) or m_norm.startswith(ch_name_norm):
                            fuzzy_candidates.append((0, ch.get('tvg_id') or m_name or '', 'name_contains'))
                        elif ch_name_norm in m_norm or m_norm in ch_name_norm:
                            fuzzy_candidates.append((1, ch.get('tvg_id') or m_name or '', 'name_contains'))
                if not tvg_id and fuzzy_candidates:
                    fuzzy_candidates.sort(key=lambda x: x[0])
                    _, tvg_id, match_method = fuzzy_candidates[0]

            if not tvg_id:
                _log('Provider "%s": no channel match found' % prov_name)
                continue

            _log('Provider "%s": matched by %s -> tvg_id="%s"' % (prov_name, match_method, tvg_id))

            prov_days  = int(prov.get('days', 7) or 7)
            retry_key  = (prov_name, tvg_id)
            events     = _loadXMLTVCache(prov_name, tvg_id)
            if events is not None:
                _log('Provider "%s": XMLTV loaded from disk cache (%d events)' % (prov_name, len(events)))
                # Negative cache written by Start Build — the bulk pass may have
                # missed this channel due to a tvg_id/display-name mismatch.
                # Attempt one on-demand fetch per session (XMLTV file is already
                # cached locally, so no extra download cost).
                if not events and retry_key not in _xmltv_negative_retried:
                    _xmltv_negative_retried.add(retry_key)
                    _log('Provider "%s": negative cache — trying on-demand fetch '
                         'for tvg_id="%s"' % (prov_name, tvg_id))
                    fresh = fetchXMLTVEvents(xmltv_url, tvg_id, prov_days,
                                             channel_name=channel_name,
                                             prov_name=prov_name)
                    _log('Provider "%s": on-demand retry returned %d events' % (
                        prov_name, len(fresh)))
                    if fresh:
                        _saveXMLTVCache(prov_name, tvg_id, fresh)
                        events = fresh
            elif _providerHasAnyCache(prov_name):
                # Build has run but left no cache entry for this tvg_id.
                # Try on-demand fetch once per session before giving up.
                if retry_key not in _xmltv_negative_retried:
                    _xmltv_negative_retried.add(retry_key)
                    _log('Provider "%s": no cache entry for tvg_id="%s" — '
                         'trying on-demand fetch' % (prov_name, tvg_id))
                    events = fetchXMLTVEvents(xmltv_url, tvg_id, prov_days,
                                              channel_name=channel_name,
                                              prov_name=prov_name)
                    _log('Provider "%s": on-demand fetch returned %d events' % (
                        prov_name, len(events)))
                    if events:
                        _saveXMLTVCache(prov_name, tvg_id, events)
                    else:
                        # Write negative marker so future plays skip the parse.
                        try:
                            with open(_xmltvCachePath(prov_name, tvg_id), 'w') as _mf:
                                _mf.write('[]')
                        except Exception:
                            pass
                        return [], prov_name
                else:
                    _log('Provider "%s": provider cache exists but no entry for '
                         'tvg_id="%s" — skipping (already retried)' %
                         (prov_name, tvg_id))
                    return [], prov_name
            else:
                _log('Provider "%s": fetching XMLTV from %s' % (prov_name, xmltv_url))
                events = fetchXMLTVEvents(xmltv_url, tvg_id, prov_days,
                                          channel_name=channel_name, prov_name=prov_name)
                _log('Provider "%s": XMLTV returned %d events' % (prov_name, len(events)))
                if events:
                    _saveXMLTVCache(prov_name, tvg_id, events)

            if events:
                # url_matched_prov is set when an earlier URL-owner had no EPG
                # data and EPG fallback is ON.  Prefer url_matched_prov only
                # when the *current* provider matched by channel NAME (i.e. it
                # is a pure EPG-fallback supplier that does not own the stream).
                # When the current provider also matched by URL it is an equally
                # valid owner — use its own name so its player config and
                # time-offset settings are applied instead of the first provider's.
                _url_methods = ('exact_url', 'path_match', 'url_no_query',
                                'pinned_channel_id')
                _owner = (prov_name if match_method in _url_methods
                          else (url_matched_prov or prov_name))
                return sorted(events, key=lambda x: x[2], reverse=True), _owner

            # URL-based match → this provider definitively owns the stream.
            if match_method in ('exact_url', 'path_match', 'url_no_query',
                                 'pinned_channel_id'):
                _fb = loadPluginSettings().get('fallback_providers_epg', True)
                if _fb:
                    # EPG fallback is ON: let the loop continue so other
                    # providers can supply archive data.  Remember who owns
                    # the stream so the right player config is used.
                    if url_matched_prov is None:
                        url_matched_prov = prov_name
                        _log('Provider "%s": URL match — EPG fallback ON, '
                             'searching remaining providers for archive data'
                             % prov_name)
                    # (implicit continue — for-loop moves to next provider)
                else:
                    _log('Provider "%s": URL match — returning as owner '
                         'despite 0 events (EPG fallback OFF)' % prov_name)
                    return [], prov_name

    except Exception as exc:
        try:
            iptvLogWrite('[CustomProvider] Exception: ' + str(exc))
        except Exception:
            pass

    # Loop ended — URL-match owner found but no provider had EPG data.
    if url_matched_prov:
        return [], url_matched_prov
    return None, None

# ---------------------------------------------------------------------------
# Provider connection test (Blue button in provider settings)
# ---------------------------------------------------------------------------

def _testM3UOnly(prov):
    """Fetch only the M3U — fast path for Select Bouquets (XMLTV deferred)."""
    result = {
        'prov_name':          prov.get('name') or 'unnamed',
        'm3u_ok':             False,  'm3u_count':  0, 'm3u_error':   None,
        'xmltv_ok':           False,  'xmltv_ch':   0, 'xmltv_ev':    0,
        'xmltv_error':        None,
        'matched_channels':   [],
        'unmatched_channels': [],
        'm3u_channels_raw':   [],
        'm3u_only':           True,
    }
    m3u_src = (prov.get('m3u_source') or '').strip()
    if m3u_src:
        try:
            m3u_channels               = fetchM3UChannels(m3u_src)
            result['m3u_count']        = len(m3u_channels)
            result['m3u_ok']           = len(m3u_channels) > 0
            result['m3u_channels_raw'] = m3u_channels
            if not result['m3u_ok']:
                result['m3u_error'] = 'parsed 0 channels'
        except Exception as e:
            result['m3u_error'] = str(e)[:120]
    else:
        result['m3u_error'] = 'no M3U source configured'
    return result

def _testProviderConnection(prov):
    """Fetch the M3U and XMLTV for *prov*, cross-match channels, return a report dict."""
    result = {
        'prov_name':          prov.get('name') or 'unnamed',
        'm3u_ok':             False,  'm3u_count':  0, 'm3u_error':   None,
        'xmltv_ok':           False,  'xmltv_ch':   0, 'xmltv_ev':    0,
        'xmltv_error':        None,
        'matched_channels':   [],
        'unmatched_channels': [],
        'm3u_channels_raw':   [],
    }

    m3u_channels = []
    m3u_src = (prov.get('m3u_source') or '').strip()
    if m3u_src:
        try:
            m3u_channels               = fetchM3UChannels(m3u_src)
            result['m3u_count']        = len(m3u_channels)
            result['m3u_ok']           = len(m3u_channels) > 0
            result['m3u_channels_raw'] = m3u_channels
            if not result['m3u_ok']:
                result['m3u_error'] = 'parsed 0 channels'
        except Exception as e:
            result['m3u_error'] = str(e)[:120]
    else:
        result['m3u_error'] = 'no M3U source configured'

    xmltv_url = (prov.get('xmltv_url') or '').strip()
    if xmltv_url:
        _xfile = None
        ch_id_to_names = {}
        ev_count       = 0
        try:
            import gzip as _gzip
            xu_lower = xmltv_url.lower()
            if xu_lower.startswith('http://') or xu_lower.startswith('https://'):
                parse_path = _downloadXMLTVToCache(xmltv_url, result.get('prov_name'))
                if not parse_path:
                    raise Exception('XMLTV download failed or returned empty file')
            else:
                parse_path = xmltv_url
            _xfile = open(parse_path, 'rb')
            _xm    = _xfile.read(2); _xfile.seek(0)
            xsrc   = _gzip.GzipFile(fileobj=_xfile) if _xm == b'\x1f\x8b' else _xfile
            try:
                for _xev, elem in ET.iterparse(xsrc, events=('end',)):
                    if elem.tag == 'programme':
                        ev_count += 1
                        elem.clear()
                    elif elem.tag == 'channel':
                        cid = elem.get('id', '')
                        if cid:
                            disp = [(dn.text or '').strip()
                                    for dn in elem.findall('display-name')
                                    if (dn.text or '').strip()]
                            ch_id_to_names[cid] = disp
                        elem.clear()
            except ET.ParseError as pe:
                result['xmltv_error'] = 'XML parse error: ' + str(pe)[:80]
        except Exception as e:
            result['xmltv_error'] = str(e)[:120]
        finally:
            try:
                if _xfile: _xfile.close()
            except Exception:
                pass
        result['xmltv_ch'] = len(ch_id_to_names)
        result['xmltv_ev'] = ev_count
        result['xmltv_ok'] = ev_count > 0 or len(ch_id_to_names) > 0
        if not result['xmltv_ok'] and not result['xmltv_error']:
            result['xmltv_error'] = 'no channels or programmes found'

        if m3u_channels and ch_id_to_names:
            ch_id_low    = {}
            ch_id_norm   = {}
            ch_disp_low  = {}
            ch_disp_norm = {}
            for xmltv_id, disp_names in ch_id_to_names.items():
                lo   = xmltv_id.lower()
                norm = _normName(xmltv_id)
                if lo not in ch_id_low:
                    ch_id_low[lo] = xmltv_id
                if norm and norm not in ch_id_norm:
                    ch_id_norm[norm] = xmltv_id
                for nm in disp_names:
                    nm_lo   = nm.lower()
                    nm_norm = _normName(nm)
                    if nm_lo not in ch_disp_low:
                        ch_disp_low[nm_lo] = xmltv_id
                    if nm_norm and nm_norm not in ch_disp_norm:
                        ch_disp_norm[nm_norm] = xmltv_id

            matched   = []
            unmatched = []
            for ch in m3u_channels:
                tvg_id   = (ch.get('tvg_id')    or '').strip()
                tvg_name = (ch.get('tvg_name')  or '').strip()
                name     = (ch.get('name')      or '').strip()
                group    = (ch.get('group_title') or '').strip()
                display  = tvg_name or name or tvg_id
                if not display:
                    continue
                matched_tag      = None
                matched_xmltv_id = None
                for (val, lbl) in [(tvg_id, 'tvg-id'), (tvg_name, 'tvg-name'), (name, 'name')]:
                    if not val:
                        continue
                    vlo   = val.lower()
                    vnorm = _normName(val)
                    vstrp = _stripIdPrefix(vlo)
                    if vlo in ch_id_low:
                        matched_xmltv_id = ch_id_low[vlo]
                        matched_tag = '[%s: %s]' % (lbl, matched_xmltv_id); break
                    if vnorm and vnorm in ch_id_norm:
                        matched_xmltv_id = ch_id_norm[vnorm]
                        matched_tag = '[%s~: %s]' % (lbl, matched_xmltv_id); break
                    if vstrp:
                        for xid_lo, xid in ch_id_low.items():
                            if _stripIdPrefix(xid_lo) == vstrp:
                                matched_xmltv_id = xid
                                matched_tag = '[%s-pfx: %s]' % (lbl, matched_xmltv_id); break
                        if matched_tag:
                            break
                    if vlo in ch_disp_low:
                        matched_xmltv_id = ch_disp_low[vlo]
                        matched_tag = '[disp/%s: %s]' % (lbl, matched_xmltv_id); break
                    if vnorm and vnorm in ch_disp_norm:
                        matched_xmltv_id = ch_disp_norm[vnorm]
                        matched_tag = '[disp~/%s: %s]' % (lbl, matched_xmltv_id); break
                if matched_tag:
                    matched.append({
                        'display':          '%s  %s' % (matched_tag, display),
                        'm3u_tvg_id':       tvg_id,
                        'm3u_tvg_name':     tvg_name,
                        'm3u_name':         name,
                        'm3u_group':        group,
                        'match_tag':        matched_tag,
                        'xmltv_id':         matched_xmltv_id,
                        'xmltv_disp_names': ch_id_to_names.get(matched_xmltv_id, []),
                    })
                else:
                    tried = tvg_id or tvg_name or name
                    unmatched.append({
                        'display':          '[no-match: %s]  %s' % (tried, display),
                        'm3u_tvg_id':       tvg_id,
                        'm3u_tvg_name':     tvg_name,
                        'm3u_name':         name,
                        'm3u_group':        group,
                        'match_tag':        None,
                        'xmltv_id':         None,
                        'xmltv_disp_names': [],
                    })
            result['matched_channels']   = matched
            result['unmatched_channels'] = unmatched
    else:
        result['xmltv_error'] = 'no XMLTV URL configured'

    try:
        iptvLogWrite('[TestProvider] %s: M3U=%s(%d) XMLTV=%s(ch=%d ev=%d) matched=%d unmatched=%d' % (
            result['prov_name'],
            result['m3u_ok'], result['m3u_count'],
            result['xmltv_ok'], result['xmltv_ch'], result['xmltv_ev'],
            len(result['matched_channels']), len(result['unmatched_channels'])))
    except Exception:
        pass
    return result
