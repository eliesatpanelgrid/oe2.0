# -*- coding: utf-8 -*-
"""
_codemap.py — CustomIPTVArchiveMakerPro Developer Reference  v7.6
=================================================
This file is documentation only — it is never imported at runtime.

Version history
---------------
v7.6  (current)
  Localisation — multi-language support via _lang.py:
  • _lang.py now contains compiled translation dicts for DE, IT, PL, RU, UK
    (generated from .mo files — 589-606 translations per language).
  • T() integrates with Enigma2 system language via language.getLanguage()[:2].
    Priority: system language dict → plugin ui_language=RUS → English fallback.
  • No file I/O at runtime — all lookups are instant Python dict.get() calls.
  • No freeze risk — T() never calls gettext() system catalog search.
  • Russian: works via both system language (ru) and plugin ui_language=RUS setting.
  • Language takes effect after Enigma2 restart (standard Enigma2 behaviour).

  EPG cache — TTL fix:
  • _loadXMLTVCache now accepts ttl= parameter so per-provider TTL
    settings (_prov_ttl) are respected in the build path.
  • _is_fresh() fallback passes ttl=_prov_ttl instead of using hardcoded 7-day global.

  Archive list — past events filter:
  • past_events filtered by archive_days lower bound — entries older than
    the configured archive depth are no longer shown (they were unplayable).

  Clear Cache on Save — XMLTV source file deletion:
  • _clearProviderCache now also deletes the downloaded XMLTV source file
    so the next build always fetches fresh data from the provider.

  Return-to-standby fix:
  • AutoBuild only returns receiver to standby if it was in standby when
    the build triggered — no longer interrupts active use.

  AutoBuild progress in settings screen:
  • IPTVPlaylistProviderSettings shows live build progress in help_label
    when opened during a headless AutoBuild run.

  Xtream picon improvements:
  • Smart skip — existing picon files are not re-downloaded (mirrors User Defined logic).
  • Deletion — picons for channels removed from provider are deleted (User Defined mode).
  • Popup counts — "Xtream Playlist Update Info" shows downloaded/skipped/deleted/failed.

v7.5
  Provider updates:
  • TorrentTV: updated domain to .enchart., added utc/lutc archive URL parameters.
  • TVTeam: EPG URL changed from tv.team to epg.team.
  • CAS provider: added 162.19.205.146 IP mapping.
  • Service types 5002/5001 (ExtePlayer/GstPlayer) now recognised in bouquet
    file parsing and detection.
  • getTvgIdForUrl() helper added to _epg.py for URL→tvg_id lookup.
  • ttv (TorrentTV) archive support added to _screens.py.

v7.3  (previous)
  User Defined order — token-rotation fix:
  • _updatePlaylistBouquets now uses URL path identity (scheme+host+path,
    no query string) for channel diff and SID computation.  Providers that
    rotate ?token=... on every M3U fetch (e.g. tv.team) no longer cause all
    channels to appear as deleted+new on each "Start Create".
  • token_refreshed counter: bouquet #SERVICE lines are rewritten in-place
    with the fresh token while preserving the user's custom channel order.
  • _channel_sid_map updated to CRC the path-only identity so service
    references remain stable across token rotations (EPG, timers, picons
    are no longer broken after a token change).
  • provider name in #NAME line now uses prov_name directly instead of
    prov_name.capitalize() — preserves original casing (e.g. TeamTV-2).
  • Logging improvements for User Defined mode:
    - diff summary: M3U/Bouquet counts, New/Deleted/Token-refreshed totals
    - per-bouquet patch reason: removed/added/token-refreshed counts
    - sample URLs logged for deleted, new, and token-refreshed channels

v7.0
  Xtream Media — service reference and picon fixes:
  • unique_ref now hashes the get.php M3U URL (identical to BMX) instead of
    player_api URL — all service references, EPG mappings and picon filenames
    now match BouquetMakerXtream output for the same provider.
  • Picon filename changed to uppercase hex (%X) to match BMX .upper() and
    Enigma2 picon lookup on case-sensitive ext4 / internal flash.
  • custom_sid validation now rejects "null"/"None"/"0"/":0:0:0:0:0:0:0:0:0:"/
    len<=16 (identical to BMX blacklist) for live, VOD, and picon sections.
  • custom_sid format detection handles both digit-first ("4097:0:1:...") and
    colon-first (":0:1:...") provider formats in live, VOD, and picon sections.
  • Series episode hash: removed & 0xFFFFFF bitmask — now abs(hash(source))
    with no mask, matching BMX exactly.
  • Series URL encoding: changed safe=':@...' to safe='/' so colons in the URL
    (http://, port) are encoded as %3A — prevents Enigma2 svc_line misparse.
  Xtream web form (_webserver.py _HTML_XTREAM) — full sync with Enigma2 dialog:
  • ADDED: Live Stream Type, VOD Stream Type, Series Stream Type selects.
  • ADDED: Picon Download Location select (enigma2_picon / plugin_dir).
  • ADDED: Make Symlink to Picon Folder toggle.
  • ADDED: tvg-id option to Download Picons select.
  • REMOVED: old "Playback With" select (replaced by per-type stream types).
  • REMOVED: legacy gstplayer / exteplayer3 options from Stream Output.
  • Form now divided into named sections: General, Credentials, Bouquet Options,
    Live TV, VOD, Series, Picons.
  • Russian translations updated for all new fields and section headers.
  • _startWebServer prefill dict extended with xtream_picon_location and
    xtream_picon_symlink so edit mode pre-fills all fields correctly.
  Plugin version: 7.0 (PLUGIN_VERSION in __init__.py).

Package layout
--------------
  CustomIPTVArchiveMakerPro/
  ├── __init__.py          Translation bootstrap + stale .pyc cleanup
  ├── plugin.py            Thin Enigma2 entry point  (Plugins / autostart)
  ├── _epg.py              EPG engine  (xxh32 inlined, XMLTV, M3U, cache, utils)
  ├── _providers.py        Integrated provider table + getArchiveUrl
  ├── _screens.py          All UI Screen classes + auto-build scheduler
  ├── _webserver.py        Tiny threaded HTTP server for PC-based provider entry
  ├── _codemap.py          This file — developer reference
  ├── plugin.png           Plugin icon
  └── locale/              Translation .mo files (DE, IT, PL, RU, UK)
      ├── de/LC_MESSAGES/CustomIPTVArchiveMakerPro.mo
      ├── it/LC_MESSAGES/CustomIPTVArchiveMakerPro.mo
      ├── pl/LC_MESSAGES/CustomIPTVArchiveMakerPro.mo
      ├── ru/LC_MESSAGES/CustomIPTVArchiveMakerPro.mo
      └── uk/LC_MESSAGES/CustomIPTVArchiveMakerPro.mo
  └── icons/               Custom playback overlay icons (256×256 PNG)
      ├── pause.png        Shown when archive playback is paused
      ├── rewind.png       Shown in the rewind (left-key) jump-input dialog
      └── fastforward.png  Shown in the fast-forward (right-key) jump-input dialog

Import chain (no circular imports)
-----------------------------------
  __init__.py   ← defines _() translation
        ↓
  _epg.py       ← no inter-module plugin imports
        ↓
  _providers.py ← imports from _epg
        ↓
  _webserver.py ← stdlib only (http.server, threading, socket, os, re, json)
        ↓
  _screens.py   ← imports from _epg, _providers, _webserver
        ↓
  plugin.py     ← imports from _screens

Module: _epg.py
---------------
PURPOSE
  Pure-Python EPG / XMLTV / M3U engine.  No Enigma2 Screen objects here.
  Inlines the xxh32 hash (previously a separate _xxh32.py file) so the
  package ships as fewer files.

KEY OBJECTS
  xxh32                   Module-level _xxh32 instance.  Callers reset it:
                            xxh32.__init__(data=b"...")
                            result = xxh32.intdigest()
  iptvLogWrite(str)       Append timestamped line to /etc/CustomIPTVArchiveMakerPro/
                            iptv_archive_pro_plugin.log
  currTime()              int(round(time.time()))
  paramExist(fn, name)    True if *name* is in fn's arglist (Py2/3 safe)
  xml_unescape(text)      HTML entity decode (apos, quot, #124, #91, #93)
  query_get(q, key)       Single-value from a parse_qs() result dict
  _wrapPath(path, w)      Break a long filesystem path at a slash boundary
  _normalizeHttpUrl(url)  Lowercase scheme to prevent urlopen ValueError
  _gunzip(raw)            Unwrap up to 3 nested gzip / zlib layers
  _normName(s)            Strip HD/SD/4K suffixes for fuzzy channel matching
  _stripIdPrefix(s)       Strip common provider ID prefixes (tvg_, tvg-, ch,
                            id_) from a channel ID string, returning the bare
                            core (e.g. 'tvg_1089' → '1089', 'ch1089' → '1089').
                            Returns '' when nothing was stripped so short values
                            don't produce false positives.
  _detectMediaPaths()     Return list of available base paths for working data:
                            always '/etc', then '/media/hdd' if mounted, then
                            any /media/<x> from /proc/mounts that is not a
                            known HDD name (treated as USB drives).
  getDataDir()            Return (and create) the data directory based on the
                            'work_dir' setting: os.path.join(work_dir,
                            'CustomIPTVArchiveMakerPro').  Falls back to
                            PLUGIN_DIR on error.  Settings / providers config /
                            log always stay in PLUGIN_DIR regardless.

SETTINGS FILES
  /etc/CustomIPTVArchiveMakerPro/iptv_archive_settings.json
    loadPluginSettings() / savePluginSettings(dict)
    Keys: use_builtin_player, stop_integrated_providers, work_dir,
          parse_type, auto_build_enabled, auto_build_days,
          auto_build_time_h, auto_build_time_m, auto_build_standby,
          auto_build_clear_cache, auto_build_clear_providers,
          streamlink_enabled, streamlink_port
    work_dir default: '/etc'  — choices built from _detectMediaPaths()
    streamlink_enabled default: False
    streamlink_port    default: 8088

  /etc/CustomIPTVArchiveMakerPro/iptv_archive_custom_providers.json
    loadProviderConfig() / saveProviderConfig(list)
    Always exactly MAX_CUSTOM_PROVIDERS (7) entries.
    Keys per entry: enabled, name, xmltv_url, m3u_source, days, channel_id

  /etc/CustomIPTVArchiveMakerPro/CustomIPTVPlaylist_providers.json
    loadPlaylistProviderConfig() / savePlaylistProviderConfig(list)
    Always exactly MAX_PLAYLIST_PROVIDERS (7) entries.
    Migration: auto-copies from /etc/CustomIPTVPlaylist_providers.json on first load.
    Keys per entry: enabled, name, xmltv_url, m3u_source, epg_parse_type,
      bouquet_strategy, playback_with, channel_order, picon_naming,
      picon_location, picon_symlink,
      update_playlist_mode, xtream_enabled (always False), clean_bouquets
    channel_order choices: provider | alphabetical | user_defined
    update_playlist_mode: saved as 'off' unless channel_order=='user_defined',
      in which case 'top' or 'bottom' (sub-row only visible when user_defined)
    picon_location: 'plugin_dir' (default, saves to getDataDir()/<name>_Picons/)
                    'enigma2_picon' (saves to /usr/share/enigma2/picon/<name>_Picons/)
      Only visible when picon_naming != 'off'.
    picon_symlink: bool — when True, creates symlinks for each picon file directly
      inside /usr/share/enigma2/picon/ (one level above the provider subfolder)
      so Enigma2 can find them without subfolder lookup.
      Works for both picon_location values. Only visible when picon_naming != 'off'.

  /etc/CustomIPTVArchiveMakerPro/CustomIPTVXtream_providers.json
    loadXtreamProviderConfig() / saveXtreamProviderConfig(list)
    Always exactly MAX_XTREAM_PROVIDERS (7) entries.
    Migration: auto-copies from /etc/CustomIPTVXtream_providers.json on first load.
    Keys per entry: enabled, name, xtream_type, xtream_url, xtream_username,
      xtream_password, xtream_token, xtream_output, xtream_strategy,
      channel_order, xtream_picon,
      xtream_show_live, xtream_live_type,
      xtream_show_vod, xtream_vod_type,
      xtream_show_series, xtream_series_type,
      clean_bouquets, selected_stream_ids
    channel_order choices: provider | alphabetical (no user_defined for Xtream)
    xtream_output choices: m3u8 (default) | ts
      Legacy values 'gstplayer' / 'exteplayer3' are silently mapped to 'ts'.
    xtream_live_type / xtream_vod_type / xtream_series_type:
      Per-content stream-type: '4097' (GStreamer, default) | '5001' (GstPlayer)
      | '5002' (ExtePlayer3).  Each resolved independently in _buildXtreamBouquets.
      Legacy: absent key or invalid value → '4097'; old exteplayer3 fallback
      via playback_with still honoured when new keys are absent.
    playback_with: retained in JSON for backward compatibility but no longer
      exposed in the Edit Xtream Provider UI. Only used as legacy fallback in
      _buildXtreamBouquets when xtream_live/vod/series_type are absent.

EPG DISK CACHE
  Directory per provider: /etc/CustomIPTVArchiveMakerPro/<safe_provider_name>/
  File per channel:       epg_<md5(tvg_id)>.json
  TTL: _XMLTV_CACHE_TTL = 12 * 3600 seconds

  _xmltvCacheDir(prov_name)              → str
  _xmltvCachePath(prov_name, tvg_id)     → str
  _loadXMLTVCache(prov_name, tvg_id, ttl=None)  → list | None
  _saveXMLTVCache(prov_name, tvg_id, evs)
  _clearProviderCache(prov_name)
  _providerHasAnyCache(prov_name)        → bool

XMLTV FILE CACHE
  Large XMLTV feeds are downloaded once to disk and reused for 12 hours.
  _xmltvLocalFilePath(source, prov_name) → str
  _downloadXMLTVToCache(source, prov_name) → local_path | None

HTTP RESULT CACHE (in-memory, 1 h)
  _provider_cache   {source: (expiry_epoch, data)}
  _getCachedOrFetch(source, fetch_fn)

M3U PARSING
  fetchM3UChannels(source) → [{'tvg_id', 'tvg_name', 'name', 'url', ...}]
  Handles: EXTM3U, Enigma2 .tv bouquets, gzip, cp1251 encoding.

XMLTV PARSING
  fetchXMLTVEvents(source, channel_id, days, channel_name, prov_name)
    → [(descr, eventid, btime, duration, title)]
  _fetchXMLTVAllChannels(parse_path, targets, days)
    → {tvg_id: [event_tuples]}   (single iterparse pass, many channels)

BULK BUILD
  _buildAllChannelCaches(providers, current_url, current_channel_name,
                          progress_cb, cancel_check)
    → sorted events for current channel | False (cancelled) | None
  _BUILD_BATCH_SIZE = 300 channels per iterparse pass

ON-DEMAND FAST PATH
  _fetchCustomProvider(url, channel_name, providers) → events | [] | None

PROVIDER TEST
  _testProviderConnection(prov) → result dict
    Keys: prov_name, m3u_ok, m3u_count, m3u_error, xmltv_ok, xmltv_ch,
          xmltv_ev, xmltv_error, matched_channels, unmatched_channels,
          m3u_channels_raw

Module: _providers.py
---------------------
PURPOSE
  Integrated provider detection + archive URL construction.

PROVIDER TABLE
  IPTV_PROVIDERS   dict   {url_substring: (provider_tag, archive_days)}
  Provider tags    : shura, 1ott, only4, iptvx.one, shara.club, ipstream,
                     ilook, edem, fox-tv, online, magic, shara-tv, uz-tv,
                     bcu, antifriz, app-greatiptv, zala, zabava, sharavoz,
                     tvoetv, ttv, ottclub, itv, cbilling, tvteam, viplime,
                     propg.net, zmedia, flussonic, None (= no match)
  Sentinel key     : 'undefined' → (None, 0)

PLAYBACK GLOBALS  (mutated by _screens.py)
  myStartTime = 0   epoch of currently-playing archive programme
  myDuration  = 0   duration of that programme in seconds
  myTimeStamp = 0   wall-clock epoch of last seek / play

  Screens access these as:
    import _providers as _prov
    _prov.myStartTime = ...

ARCHIVE URL
  getArchiveUrl(url, title='') → str
  Converts a live stream URL to a provider-specific time-shifted URL
  using myStartTime / myDuration / myTimeStamp from this module.
  Provider-specific path transformations (cbilling, antifriz, zala,
  zabava, 1ott, tvoetv, bcumedia, itv/glanz, tv.team/troya/1usd,
  satbilling/only4, shara.club/ipstream, and generic utc= approach).

Module: _webserver.py
---------------------
PURPOSE
  Standalone HTTP server (Python stdlib only) used by IPTVProviderEditDialog
  to allow PC-based provider entry and M3U file upload.
  Never imported by any other module except _screens.py.

CONSTANTS
  WEB_PORT = 1010               Default listen port (tries 1010–1019 on conflict)
  WEB_CHANNEL_BROWSER_PORT=1012 Used by IPTVChannelBrowserWebServer
  _UPLOAD_DIR                   /etc/CustomIPTVArchiveMakerPro/LocalPlayListFromWeb
                                Created automatically on first file upload.

HELPERS
  _get_local_ip() → str         Detects receiver's LAN IP via UDP connect trick.

HTML TEMPLATES
  _HTML             Archive provider form (name, xmltv_url, m3u_source, channel_id,
                    days, enabled, player overrides, cache TTL).
  _HTML_PLAYLIST    Playlist provider form (M3U URL, XMLTV URL, EPG parse type,
                    bouquet strategy, channel order [provider/alphabetical/user_defined],
                    update_mode_sub [top/bottom, visible only when user_defined],
                    Download Picons, Enabled). No Xtream fields. form_type='playlist'.
  _HTML_INTEGRATED  Integrated provider form (name, url_fragment, days, archive
                    pattern, EPG source, enabled). form_type='integrated'.
  _HTML_XTREAM      Xtream-only provider form — dedicated clean form with NO M3U /
                    XMLTV / channel-order / EPG fields. Contains: Provider Name,
                    Enabled, Xtream Type, Xtream URL, Username/Password or Token,
                    Stream Output, Bouquet Strategy, Download Picons, Build Live/
                    VOD/Series bouquets, Playback With. Russian translations via
                    _RU_XT JS object; toggleXtreamType() shows user_pass or token
                    fields on change. form_type='xtream'.

CLASS  IPTVWebInputServer
  __init__(port=WEB_PORT, upload_dir=None)
  start(prefill=None, form_type='archive') → (ok: bool, ip: str, port: int)
    Starts a daemon thread running an HTTPServer.
    prefill    — dict of existing provider values (used in Edit mode);
                 injected as a JSON literal into the HTML so the browser
                 form is pre-filled with current data.
    form_type  — 'archive'    → _HTML  (default)
                 'playlist'   → _HTML_PLAYLIST
                 'integrated' → _HTML_INTEGRATED
                 'xtream'     → _HTML_XTREAM
  stop()              Shuts down the HTTP server.
  poll() → dict|None  Thread-safe: returns the next submitted form dict
                      or None.  Called every 500 ms by an eTimer.

HTTP ENDPOINTS
  GET  /        Serves the HTML form (pre-filled if prefill was given).
  POST /        Receives URL-encoded form fields; pushes dict to queue.
  POST /upload  Receives a raw M3U/XMLTV file (bytes) with X-Filename header;
                saves it to upload_dir keeping the original filename;
                returns {"ok": true, "path": "..."}.

HTML FORM FIELDS  (match IPTVProviderEditDialog._cfg keys)
  Archive:  name, xmltv_url, m3u_source, channel_id, days, enabled
  Playlist: name, m3u_source, xmltv_url, epg_parse_type, bouquet_strategy,
            playback_with, channel_order, update_mode_sub (only when
            channel_order=user_defined), picon_naming, enabled.
  Xtream:   name, enabled, xtream_type, xtream_url, xtream_username,
            xtream_password, xtream_token, xtream_output, xtream_strategy,
            xtream_picon, xtream_show_live, xtream_show_vod,
            xtream_show_series, playback_with.

Module: _screens.py
-------------------
PURPOSE
  All Enigma2 Screen classes + auto-build scheduler.

MODULE GLOBALS
  iptvHotKey           str   key name for the plugin hot-key
  _iptv_open_requested bool  True when opened via Extensions/Plugin menu
  _auto_build_session       Enigma2 session saved at WHERE_AUTOSTART
  _auto_build_timer    eTimer fires _checkAutoBuild every 60 s
  _auto_build_pending  bool  True while headless build thread runs
  _auto_build_progress tuple (done, total, prov_name)
  _auto_build_listener open iptvArchiveSelection that wants progress
  _WEB_INPUT_OK        bool  True if _webserver imported successfully

SCREEN CLASSES
  epgEvent
    Wraps a raw (descr, eventid, btime, duration, title) tuple so it
    satisfies the Enigma2 EPG interface.  Returned by onCreate / InfoBar.
    Key methods: getEventName, getShortDescription, getBeginTime,
                 getDuration, getEventId, getArchiveBeginTimeString.

  IPTVArchiveEventViewEPGSelect
    Event detail overlay (EventViewEPGSelect subclass).

  iptvArchiveSelection   ← MAIN SCREEN
    EPGSelection subclass.  Entry point for all archive operations.
    Keys:
      RED    → searchTMDB  (requires TMBD plugin)
      GREEN  → _toggleBuild  (start/stop bulk EPG cache build)
      YELLOW → openAddWorkflow → IPTVAddWorkflow (v5.2)
      BLUE   → blueButtonPressedNoPLi (channel browser)
      OK     → eventSelected → plays archive + opens iptvArchiveInfoBar
      INFO   → infoKeyPressed → IPTVArchiveEventViewEPGSelect
      MENU   → openPluginSettings → IPTVArchivePluginSettings
      EXIT   → cancel (with confirm if archive is playing)
    Data flow:
      onCreate()
        1. Resolve currentService URL
        2. Guard: stop_integrated_providers → _tryCustomProviders or stop
        3. Match url against IPTV_PROVIDERS table → self.provider / self.days
        4. Try _loadFromEPGCache() (Enigma2 live EPG cache)
        5. Build per-provider API request → archiveListLoaded()
        6. On API failure → retry _loadFromEPGCache / _tryCustomProviders
      _tryCustomProviders()
        Spawns _customProviderThread (daemon thread).
        On finish → _customProviderDone (reactor.callFromThread).
      _toggleBuild()
        If already fetching → cancel (_build_cancelled flag).
        Else → _tryCustomProviders(..., build_all=True).
      eventSelected()
        Sets _prov.myStartTime / myDuration / myTimeStamp.
        If streamlink_enabled → opens ChoiceBox "Play Normal / Play via
          StreamlinkProxy".  Callback _onPlayerChoice dispatches to
          _playNormal or _playStreamlink.
        If streamlink_enabled is off → calls _playNormal directly.
      _playNormal(ref)
        Calls playService(ref), then showInfoBar().
      _playStreamlink(ref)
        1. TCP connect-check on 127.0.0.1:port (2 s timeout).
        2. Builds proxy URL: http://127.0.0.1:PORT/ARCHIVE_URL&default-stream=best
        3. playService(eServiceReference(4097, 0, proxied_url))
        4. Calls _showStreamlinkInfoBar(port).
      _showStreamlinkInfoBar(port)
        Mirrors showInfoBar() but opens iptvArchiveInfoBar with
        streamlink_port=port and callback _onStreamlinkInfoBarClosed.
        If use_builtin_player is False: sets _streamlink_exit flag and
        calls self.close() skipping oldService restore in __onClose.
      _onStreamlinkInfoBarClosed(*args)
        Restores self.oldService and calls self.show() — identical to
        _onInfoBarClosed so EPG/hotkey presses return to archive list.

  IPTVFileBrowser
    Portable file-browser dialog using Enigma2 FileList.
    Handles divergent APIs across image versions.

  IPTVChannelMatchDetailScreen
    Scrollable detail view for one matched/unmatched M3U↔XMLTV entry.
    Sections: M3U File Data / Match Result / XMLTV File Data.
    Match priority (first wins, applied for tvg-id then tvg-name then name):
      1. exact match against xmltv channel id       tag: [field: id]
      2. _normName match against xmltv channel id   tag: [field~: id]
      3. _stripIdPrefix match against xmltv id      tag: [field-pfx: id]
           e.g. tvg-id="tvg_1089" matches <channel id="ch1089">
           because both strip to "1089"
      4. exact match against display-name           tag: [disp/field: id]
      5. _normName match against display-name       tag: [disp~/field: id]
    _ID_PREFIX_RE strips: tvg_, tvg-, ch (before digit), id_

  IPTVProviderTestResultScreen
    Shows M3U fetch stats, XMLTV stats, and matched/unmatched lists.
    RED = cycle sort order (original / by name / by XMLTV id).
    GREEN = toggle matched ↔ unmatched list.
    YELLOW = open IPTVChannelBrowserScreen.
    OK = IPTVChannelMatchDetailScreen for focused row.

  IPTVChannelBrowserScreen
    Two-panel bouquet/channel browser for M3U raw channel lists.
    All bouquets and channels are checked by default.
    RED    = Select All (bouquets + channels).
    GREEN  = Switch Panel (toggle focus left ↔ right).
    YELLOW = Deselect All.
    BLUE   = Add Selected → close(set_of_selected_urls).
    OK     = Toggle checkbox for focused bouquet or channel.
    EXIT   = Cancel → close(None).
    skin widget "key_web" (blue label, y=594) shows the PC web browser URL
    while the screen is open: IPTVChannelBrowserWebServer serves a full
    two-panel HTML page on port WEB_CHANNEL_BROWSER_PORT (1012).
    An eTimer polls every 500 ms; when the user clicks "Save Selection" in
    the PC browser, _applyWebSelection() syncs all checkbox state and updates
    the label to "Selection received from PC browser".

  IPTVAutoBuildDayPicker
    7-row ConfigListScreen of ConfigYesNo for day-of-week selection.

  IPTVStopProvidersScreen
    Sub-screen opened by OK on "Stop All Integrated Providers" row.
    Row 1: "Stop All Integrated Providers" master ConfigYesNo.
    Rows 2+: one ConfigYesNo per unique integrated provider tag
             (sorted list built from IPTV_PROVIDERS at class-load time).
    Green=Save → closes with (master_bool, [stopped_tags]).
    Red/Cancel → closes with None (no change).

  IPTVClearProvidersScreen
    Sub-screen opened by OK on "Clear Providers Cached Files Before Build".
    Shows one ConfigYesNo per named custom provider.
    Green=Save → closes with list of provider indices to clear.
    Red/Cancel → closes with None (no change).

  IPTVArchivePluginSettings
    Title: "Custom IPTV MakerPro Settings"
    Plugin-wide settings (rows in order):
      Use Built-in Archive Player   — ConfigYesNo
      Working Directory Location    — ConfigSelection (left/right on remote)
        Choices built from _detectMediaPaths() each time the screen opens.
        Saved as 'work_dir' in settings.
      Stop All Integrated Providers (summary) — ConfigSelection trigger
        Summary shows "All Stopped" / "N stopped" / "All Active".
        OK → IPTVStopProvidersScreen.
        Saved as 'stop_integrated_providers' (master bool) and
        'stopped_provider_tags' (list of individually stopped tags).
      Cached Files Parse Type       — ConfigSelection (bulk/single/m3u)
      Auto Start Build              — ConfigYesNo + sub-rows when enabled:
        Choose Days                 — OK → IPTVAutoBuildDayPicker
        Start Hour / Start Minute   — ConfigInteger
        Start Build in StandBy      — ConfigYesNo
        Clear Providers Cached Files Before Build (summary) — trigger
          Summary shows "N providers" / "None selected".
          OK → IPTVClearProvidersScreen.
          Saved as 'auto_build_clear_cache' (bool) and
          'auto_build_clear_providers' (list of indices).
    BLUE → IPTVParseTypeHelpScreen (includes working directory explanation)

  IPTVAddWorkflow  (v5.2 — new; extended in v5.3 with Xtream item)
    Small centered popup titled "Add Workflow".  No video widget.
    Four menu items (font 30pt, itemHeight 80, popup height 470px):
      "Create IPTV Archive Programs Locally"        → IPTVProviderSettings
      "Create IPTV Archive Programs From Providers" → IPTVIntegratedProvidersScreen
      "Create IPTV Bouquets/Channels"               → IPTVPlaylistProviderSettings
      "Create Xtream Media"                          → IPTVXtreamProviderSettings
    OK = open selected screen.  EXIT = close popup.
    Russian translations added to _lang.py under sections "add workflow menu"
    and "IPTVXtreamProviderEditDialog + IPTVXtreamProviderSettings".

  IPTVProviderSettings  (titled "IPTV Programs Archives Creator Settings" since v5.2)
    Manages the 7 custom provider slots.
    RED    = clear EPG cache for selected provider.
    GREEN  = Start Build / Stop Build — builds all channel archives for all enabled providers;
             live progress shown in the left help_label panel within the same window.
    YELLOW = Edit selected provider → IPTVProviderEditDialog.
    BLUE   = Test selected provider → IPTVProviderTestResultScreen.
    OK on "[ + Add New Provider ]" entry at bottom of list = Add provider → IPTVProviderEditDialog.
    NOTE (v5.2): "Programs Archives Mode" and "IPTV Playlist Mode" rows
    removed from config list display; underlying _mode_cfg_ref logic intact.

  IPTVProviderEditDialog
    Add / edit one provider: Enabled, Provider Name, XMLTV URL,
    M3U URL / M3U Playlist, Channel ID, Archive Days (1-7).
    YELLOW = file browser (IPTVFileBrowser) for local M3U on receiver HDD.
    Bottom label (yellow, large font) shows the PC web-input URL while
    the dialog is open.

    PC Web Input (automatic, both Add and Edit mode):
      On open → IPTVWebInputServer starts on port 1010 (auto-fallback).
      Label shows "PC Input: open http://<ip>:<port> in your browser".
      In Edit mode the browser form is pre-filled with current values.
      eTimer polls IPTVWebInputServer.poll() every 500 ms.
      On data received → _applyWebData() fills all cfg fields,
        shows MessageBox "Data received from PC browser!", stops server.
      M3U Browse button in browser → uploads file to receiver via
        POST /upload → saved to /etc/CustomIPTVArchiveMakerPro/
        LocalPlayListFromWeb/<original_filename> (folder created
        automatically) → path auto-filled into m3u_source field.
      On dialog close (any path) → _stopWebServer() called via onClose.

    _startWebServer()   starts IPTVWebInputServer with current cfg as prefill
    _pollWebInput()     eTimer callback — checks queue, calls _applyWebData
    _applyWebData(data) fills _cfg from received dict, refreshes list
    _stopWebServer()    stops timer + server; registered in self.onClose

  IPTVArchiveJumpInput
    Minute-input overlay opened by seekFwd (right key) or seekBack (left key).
    Displays a custom icon from icons/ (fastforward.png or rewind.png) loaded
    via loadPNG / setPixmap on layout finish.  Layout is direction-aware:
      Forward  → icon on LEFT,  green minute counter on RIGHT
      Backward → green minute counter on LEFT,  icon on RIGHT
    Border: thin purple (#CC33FF) rectangle on a semi-transparent dark background.
    Digit keys accumulate 1-4 digits (minutes).  Green Bold;57 font.
    OK → closes with ±seconds (positive=fwd, negative=back).  EXIT → None.

  IPTVArchivePausePopup
    Borderless transparent overlay opened when archive playback is paused.
    Displays icons/pause.png (256×256) centred on screen via loadPNG / setPixmap.
    Stays on screen until playback resumes — no auto-close timer.
    Opened via session.openWithCallback(self._resume_from_popup, ...) so that
    closing the popup for ANY reason (play key, OK, EXIT) automatically resumes
    playback through the _resume_from_popup callback.
    Key bindings: ok, cancel, playpauseService, play, pause, stop — all close
    the popup and trigger _resume_from_popup → myjump(0).
    _close_pause_popup() sets _skip_resume_callback = True before calling
    close() so programmatic closes (seek, stop) do NOT trigger a double-resume.

  iptvArchiveSecondInfoBar
    Minimal overlay (now/next).  Opened by double-OK in iptvArchiveInfoBar.

  iptvArchiveInfoBar
    Archive playback InfoBar.  Used for both integrated and Streamlink play.
    __init__ signature: (session, ev, base_ref_str='', all_events=None,
                         streamlink_port=0)
      streamlink_port=0  → normal HLS archive seek
      streamlink_port=N  → Streamlink-aware seek (wraps archive URL through proxy)
    Keys: 1/3=±10 s, 4/6=±1 min, 7/9=±5 min,
          seekBack/seekFwd = IPTVArchiveJumpInput,
          EPG / iptvHotKey → close info bar (returns to archive list).
    Seek mechanism: myjump() recalculates myStartTime, calls
      eServiceReference(self.strRef).setPath(getArchiveUrl(...)).
      If streamlink_port > 0: wraps result as
        http://127.0.0.1:PORT/ARCHIVE_URL&default-stream=best
        and plays eServiceReference(4097, 0, proxied_url).
      Else: plays newRef directly (normal HLS archive).
    NOTE: Service reference buffer flags (1, 3) must NOT be used for
      HLS archive streams — they switch GStreamer into timeshift mode
      and break all key handling.  Only flag 0 (default) is valid here.
    On close: advances myStartTime by elapsed real time.
    Event_Now / Event_Next are pushed to session.screen[] and restored
    on close so normal InfoBar behaviour is unaffected.
    Pause / resume flow:
      pause() — if playing (myTimeStamp > 0): stops service, records position,
        opens IPTVArchivePausePopup via openWithCallback(_resume_from_popup).
        Stores popup reference in self._pause_popup.
      pause() — if paused (myTimeStamp == 0): calls _close_pause_popup() then
        myjump(0) to resume from the saved position.
      _resume_from_popup(*args) — callback fired when popup closes normally
        (user presses play/OK/EXIT on popup).  Calls myjump(0) unless
        _skip_resume_callback is True (set by programmatic close).
      _close_pause_popup() — safely closes popup and sets _skip_resume_callback
        so _resume_from_popup does NOT trigger a double-resume.  Called from
        myjump() (seek while paused) and wherever playback restarts.

  _last_m3u_update_info  (module-level list)
    Stores the detailed per-channel add/remove info from the most recent
    "Start Create" run that used update mode (User Defined order, top/bottom).
    Format: list of str lines — header, blank, added lines, blank, removed lines.
    Reset (replaced) on each successful update run.
    Displayed by IPTVUpdateInfoScreen.

  IPTVUpdateInfoScreen
    Scrollable full-screen detail view for the last M3U update.
    Title: "M3U Update Info".
    Shows:
      "Channels Added (N)   Channels Removed (N)"
      BouquetName:  +ChannelName  new
      ...
      BouquetName:  -ChannelName  Deleted
      ...
    UP/DOWN/LEFT/RIGHT = page scroll.
    OK / EXIT = close.
    Opened from IPTVPlaylistProviderSettings via key "1" or Menu.

  IPTVPlaylistProviderSettings  (titled "IPTV Bouquets/Playlist Creator Settings")
    Manages the 7 Playlist Creator provider slots.
    RED    = Start Create — builds bouquets for selected provider in a daemon thread.
    GREEN  = Add Provider → IPTVPlaylistProviderEditDialog (new slot).
    YELLOW = Edit selected provider → IPTVPlaylistProviderEditDialog.
    BLUE   = Test Provider — runs _testProviderConnection() for selected provider
             in a daemon thread; shows result in IPTVProviderTestResultScreen.
             key_blue shows "Testing..." during run; resets to "Test Provider" on done.
    1 / MENU = keyShowUpdateInfo → opens IPTVUpdateInfoScreen with last update detail.
    OK / LEFT/RIGHT = Toggle enabled flag for selected provider (saved immediately).
    EXIT   = close.
    Infobar hint: "1 / Menu — Show M3U Update Info".
    After a successful update run (User Defined order): brief summary MessageBox
    (10 s) shows per-bouquet +N/-N counts plus hint to press 1/Menu for full list.
    _last_m3u_update_info is populated with per-channel detail at that point.

  IPTVPlaylistProviderEditDialog
    Add / edit one IPTV Playlist Creator provider.
    Title: "Edit IPTV Playlist Provider" / "Add IPTV Playlist Provider".
    Rows (in order):
      Enabled                    — ConfigYesNo
      Provider Name              — ConfigText
      XMLTV URL / Local File     — ConfigText  (blank = no separate EPG)
      M3U URL / M3U Playlist     — ConfigText  (skipped when xtream_enabled)
      Create EPG File            — ConfigSelection (off / display_name / tvg_id)
      Bouquet Creation Strategy  — ConfigSelection (same_playlist / all_channels /
                                     all_and_groups / parent_sub)
      Playback With              — ConfigSelection (gstplayer / exteplayer3)
      Channels Ordering By       — ConfigSelection (provider / alphabetical)
      Enable Xtream Media        — ConfigYesNo
        [shown when Enable Xtream Media = Yes]
        Xtream Media Type        — ConfigSelection:
          user_pass → "Xtream Codes (Username/Password)"
          token     → "Xtream (Codes/Token)"
        Xtream Media URL         — ConfigText  (base server, e.g. http://host:8080)
        [shown when type = user_pass]
          Xtream Media Username  — ConfigText
          Xtream Media Password  — ConfigText
        [shown when type = token]
          Xtream Media (Codes/Token) — ConfigText
        Xtream Stream Output              — ConfigSelection (ts / m3u8 / gstplayer / exteplayer3)
          ts          — TS stream, player from "Playback With" setting
          m3u8        — HLS stream, GStreamer player
          gstplayer   — TS stream, forces GStreamer player (stream_type 4097)
          exteplayer3 — TS stream, forces ExtEplayer3 player (stream_type 5001)
        Xtream Bauquets Creation Strategy — ConfigSelection:
          same_as_provider  — one userbouquet per category, all flat in list
          group_into_folder — all subbouquets under one parent folder bouquet
        Xtream download Picons            — ConfigSelection (off / display_name / reference)
          off          — no picon download
          display_name — saved as "<channel name>.png"
          reference    — saved as Enigma2 service-ref filename
          Files saved to: {getDataDir()}/{safe_name}_Picons/
          Progress shown on RED key label during background download.
        Xtream Build Live TV Bouquets     — ConfigYesNo
        Xtream Build VOD Bouquets         — ConfigYesNo
        Xtream Build Series Bouquets      — ConfigYesNo
      Download Picons            — ConfigSelection (off / display_name / reference)
        [shown when Download Picons != Off]
        Download Location        — ConfigSelection:
          plugin_dir    → saves to {getDataDir()}/{safe_name}_Picons/
          enigma2_picon → saves to /usr/share/enigma2/picon/{safe_name}_Picons/
        Make Symlink             — ConfigYesNo
          When Yes: after download, creates symlinks for each .png file directly
          in /usr/share/enigma2/picon/ (one level above the provider subfolder).
          Applies regardless of Download Location choice.
      Clean Bouquets             — ConfigYesNo
        When Yes and Save pressed: all Channels/Bouquets of this provider are
        removed from the receiver; provider config is kept and clean_bouquets
        resets to No in the saved data. This is a one-time action on save,
        not a permanent toggle.

    _buildXtreamBouquets(prov, _reactor=None, _progress_cb=None):
      Level 3 Xtream Codes API build using player_api.php.
      Fetches Live/VOD/Series categories and streams; builds userbouquet/
      subbouquet files according to xtream_strategy:
        same_as_provider  — one userbouquet per category per content type (flat)
        group_into_folder — subbouquet per category across all types, single
                            parent userbouquet named after the provider
      EPG: always generates EPG import files for EPGImporter regardless of
        epg_parse_type setting.  Calls _generateXtreamEpgFiles(safe_name,
        prov_name, epg_channels, effective_xmltv) after bouquet build.
        _generateXtreamEpgFiles writes all live channels with a non-empty
        tvg_id directly to /etc/epgimport/CustomIPTV/<safe_name>.xml without
        XMLTV pre-verification (mirrors BouquetMakerXtream behaviour).
        XMLTV URL: auto-built from credentials as
        {server}/xmltv.php?username=…&password=… then passed to
        _updateCombinedSourcesFile. Custom xmltv_url overrides.
      Stream types: resolved per content type from xtream_live_type,
        xtream_vod_type, xtream_series_type (new per-provider keys, each
        '4097'|'5001'|'5002').  Legacy playback_with / gstplayer/exteplayer3
        in xtream_output still honoured as fallback when new keys absent.
      Picons: when xtream_picon != 'off', calls _downloadXtreamPicons after
        bouquet build; passes _reactor + _progress_cb so RED key shows progress.
      M3U URL validation bypassed in keyStartCreate / keyTest when xtream_enabled.

    _downloadXtreamPicons(safe_name, picon_mode, live_streams, stream_type,
                          unique_ref, _reactor=None, _progress_cb=None):
      Downloads stream_icon URLs for all live channels from the Xtream API.
      Saves to {getDataDir()}/{safe_name}_Picons/.
      Reports progress every 25 channels via _reactor.callFromThread(_progress_cb,
      done, total) — same RED key label as M3U picon download (_piconProgressCreate).

    Dynamic list: _onXtreamChanged() notifier registered on xtream_enabled and
      xtream_type; rebuilds the config list whenever either changes.

    YELLOW = file browser (IPTVFileBrowser) for local M3U or XMLTV on receiver.
    PC Web Input: same pattern as IPTVProviderEditDialog — IPTVWebInputServer
      starts on WEB_PORT with form_type='playlist'; web form includes all Xtream
      fields (type, URL, credentials, output, strategy, picon, show_live/vod/series)
      with JS show/hide (toggleXtream / toggleXtreamType); PREFILL pre-fills all fields.

    keySave() returns dict with keys:
      enabled, name, xmltv_url, m3u_source, epg_parse_type, bouquet_strategy,
      playback_with, channel_order, picon_naming,
      xtream_enabled, xtream_type, xtream_url, xtream_username,
      xtream_password, xtream_token, xtream_output, xtream_strategy, xtream_picon,
      xtream_show_live, xtream_show_vod, xtream_show_series,
      clean_bouquets (always False — reset after clean action)

  IPTVXtreamProviderEditDialog  (v5.3 — new)
    Add / edit one Xtream-only provider (no M3U / XMLTV / channel-order fields).
    Title: "Edit Xtream Provider" / "Add Xtream Provider".
    Config file: /etc/CustomIPTVArchiveMakerPro/CustomIPTVXtream_providers.json
                 (MAX_XTREAM_PROVIDERS = 7 slots)
    Helpers: loadXtreamProviderConfig() / saveXtreamProviderConfig(list)
    Rows (in order):
      Enabled                   — ConfigYesNo
      Provider Name             — ConfigText
      Xtream Type               — ConfigSelection (user_pass / token)
      Xtream URL                — ConfigText  (base server, e.g. http://host:8080)
      [shown when type = user_pass]
        Xtream Username         — ConfigText
        Xtream Password         — ConfigText
      [shown when type = token]
        Xtream Token            — ConfigText
      Stream Output             — ConfigSelection (ts / m3u8 / gstplayer / exteplayer3)
      Playback With             — ConfigSelection (gstplayer / exteplayer3)  ← under Stream Output
      Bouquet Strategy          — ConfigSelection (same_as_provider / group_into_folder)
      Channels Ordering By      — ConfigSelection (provider / alphabetical)
      Download Picons           — ConfigSelection (off / display_name / reference)
      Build Live TV Bouquets    — ConfigYesNo
      Build VOD Bouquets        — ConfigYesNo
      Build Series Bouquets     — ConfigYesNo
      Clean Bouquets            — ConfigYesNo
    RED    = Delete provider (with confirm; close({'_delete': True})).
    GREEN  = Save → close(dict of all Xtream fields, always xtream_enabled=True).
    YELLOW = Test Connection — hits /player_api.php, shows account status /
             expiry / active connections / server info in a MessageBox (timeout 15 s).
             Uses a daemon thread; _testDone() called via reactor.callFromThread.
    BLUE   = Exit / cancel.
    PC Web Input: IPTVWebInputServer starts on WEB_PORT with form_type='xtream'
      (→ _HTML_XTREAM).  Pre-fills all Xtream fields from current cfg.
      eTimer polls every 500 ms; _applyWebData() receives: name, enabled,
      xtream_type, xtream_url, xtream_username, xtream_password, xtream_token,
      xtream_output, xtream_strategy, channel_order, xtream_picon, xtream_show_live,
      xtream_show_vod, xtream_show_series, playback_with.
    Dynamic list: _onTypeChanged() notifier on xtream_type rebuilds the row list.

  IPTVXtreamProviderSettings  (v5.3 — new)
    Title: "Xtream Media Creator".
    List shows all configured Xtream providers (name + type tag, ConfigYesNo toggle).
    Left panel: help_label with key-map legend.
    Header: list_header "Configured Xtream Providers".
    RED    = Start Create — builds bouquets for selected provider via
             _buildXtreamBouquets() in a daemon thread; progress shown in
             key_red label during picon download (↓ done/total %).
             _createDone() opens success / error MessageBox.
    GREEN  = Add Provider → IPTVXtreamProviderEditDialog (new slot).
    YELLOW = Edit selected provider → IPTVXtreamProviderEditDialog (existing slot).
    BLUE   = Test Provider — tests Xtream API connection for selected provider
             (same logic as IPTVXtreamProviderEditDialog.keyTest but reads from
             _providers_raw[idx]; shows account status / expiry / connections).
             _testing flag prevents concurrent tests; key_blue shows "Testing..."
             while the daemon thread runs; _testDone() resets to "Test Provider".
    OK / LEFT/RIGHT = Toggle enabled flag for selected provider (saved immediately).
    EXIT   = close.
    NOTE: MENU key and EPG / showEPGList bindings removed; keyVodBrowser method
          kept but no longer bound to any hotkey.

  IPTVXtreamMediaChoiceScreen
    VOD pre-selection: on _onLoadDone(), groups in the VOD section (between
      __SEP__VOD and the next separator) are ALWAYS marked checked=True
      regardless of whether saved_ids exist, so VOD bouquets are pre-selected
      by default every time the screen opens.
    Empty-group hiding: _visibleGroups() method builds a filtered view of
      _groups_order that drops:
        • non-separator groups whose stream count == 0
        • section separators that have no non-empty groups following them
      _refreshBouquetList() populates self._visible_groups from _visibleGroups()
      and uses it for the bouquet_list display.
      _currentGroup() looks up in _visible_groups (not _groups_order) so
      navigation, toggle, and apply all respect the filtered view.
      Effect: Series section with 0-content bouquets is hidden automatically.

AUTO-BUILD SCHEDULER
  _startAutoBuildTimer(session)
    Called by autostart(reason=0).  Creates an eTimer that fires every
    60 s → _checkAutoBuild().

  _checkAutoBuild()
    Reads schedule from loadPluginSettings().  Fires _triggerAutoBuild()
    when current time matches the configured day/hour/minute.

  _triggerAutoBuild(settings)
    Spawns _autoBuildThread (daemon thread).

  _autoBuildThread(providers, settings)
    Optionally clears caches, calls _buildAllChannelCaches(), reports
    progress to _auto_build_listener via reactor.callFromThread.
    Sets _auto_build_pending = False when done.

  _onAutoBuildComplete(go_standby)
    Updates open iptvArchiveSelection; optionally returns box to standby.

Module: plugin.py
-----------------
PURPOSE
  Enigma2 entry point.  As thin as possible.

  where_extensionsmenu(session, **kwargs)
    Sets _sc._iptv_open_requested = True, then opens iptvArchiveSelection.

  autostart(reason, session, **kwargs)
    Delegates to _screens.autostart.

  Plugins(**kwargs)
    Returns two PluginDescriptors:
      WHERE_EXTENSIONSMENU | WHERE_PLUGINMENU → where_extensionsmenu
      WHERE_AUTOSTART                         → autostart

Filesystem layout at runtime
-----------------------------
  /etc/
  ├── CustomIPTVXtream_providers.json     Xtream-only provider list (7 slots)
  │                                       loadXtreamProviderConfig() / saveXtreamProviderConfig()
  └── CustomIPTVArchiveMakerPro/
      ├── iptv_archive_pro_plugin.log     append-only log
      ├── iptv_archive_settings.json      plugin-wide settings
      ├── iptv_archive_custom_providers.json  custom provider list (archive)
      ├── iptv_playlist_providers.json    playlist provider list (7 slots)
      ├── xmltv_<hash>.xml[.gz]           downloaded XMLTV file cache
      ├── LocalPlayListFromWeb/           M3U files uploaded via PC browser
      │   └── <original_filename>.m3u     created on first web upload
      ├── IPTVXtreamCreator/              upload dir for Xtream web input form
      └── <provider_name>/
          └── epg_<md5>.json             per-channel EPG cache

  /usr/lib/enigma2/python/Plugins/Extensions/CustomIPTVArchiveMakerPro/
  ├── __init__.py
  ├── plugin.py
  ├── _epg.py
  ├── _providers.py
  ├── _screens.py
  ├── _webserver.py
  ├── _codemap.py
  ├── plugin.png
  └── icons/
      ├── pause.png
      ├── rewind.png
      └── fastforward.png

Key version / compatibility notes
-----------------------------------
  • Targets OpenPLi 9.2, Python 3.
  • Py2 fallbacks retained in _epg.py (urllib2, urlparse, unichr).
  • xxh32 is a pure-Python implementation; no C extension required.
  • eTimer.timeout API: DreamOS uses .connect(); legacy uses .callback.append().
  • Event.updateSource() may be absent on older images — stubbed in _screens.py.
  • EPGSelection.__init__ signature varies: paramExist() checks for 'EPGtype'.
  • MessageBox.__init__ 'title' parameter varies: paramExist() guards usage.
  • FileList / getFilename / getSelectedIndex API varies: IPTVFileBrowser has
    three fallback strategies for retrieving the selected path.
  • _webserver.py uses http.server (Python 3 stdlib); guarded with try/except
    so the plugin still loads on images where it is unavailable.

Debugging
---------
  Set DEBUG = 1 in _epg.py (default) to log all EPG API requests + responses.
  Log: /etc/CustomIPTVArchiveMakerPro/iptv_archive_pro_plugin.log
  Test a provider without opening the full plugin:
    Yellow button → IPTVAddWorkflow → select "Locally" → IPTVProviderSettings → Blue (Test Provider)
"""

# ===========================================================================
# v7.4 Changes
# ===========================================================================
#
# MERGE: IPTVProviderSettings + IPTVProviderEditDialog removed.
#   Archive provider management fully merged into IPTVPlaylistProviderSettings
#   and IPTVPlaylistProviderEditDialog.
#   loadProviderConfig/saveProviderConfig fully removed from all code paths.
#   All archive lookups now use loadPlaylistProviderConfig() filtered by
#   create_archives=True.
#
# IPTVAddWorkflow:
#   - "Create IPTV Archive Programs Locally" entry removed
#   - "Create IPTV Bouquets/Channels" renamed to
#     "Create IPTV Archives Bouquets/Channels"
#
# IPTVPlaylistProviderSettings:
#   - Title: "IPTV Archives Bouquets/Playlist Creator Settings"
#   - Red: "Create Playlist" (was "Start Create") — builds bouquets
#   - Green: "Create Archives" — builds EPG cache for selected provider
#     (with Stop support and live progress; toggles to "Stop Build")
#   - Yellow: "Edit Provider" (unchanged)
#   - Blue: "Test Provider" — fetches M3U, runs test, then opens
#     Channel Browser with result stored
#   - Provider list shows [A] tag for providers with create_archives=ON
#   - [+ Add New Provider] sentinel at bottom of provider list
#
# IPTVPlaylistProviderEditDialog:
#   - Title: "Add/Edit IPTV Playlist/Archives Provider"
#   - New archive fields below "Clean Bouquets" (visible when create_archives=ON):
#     1. Create Provider Archives (on/off toggle)
#     2. Channel ID
#     3. Archive Days (1-7)
#     4. TTL Days For Cached Files (OK opens IPTVProviderTTLScreen popup)
#     5. Archive Start Offset +/-
#     6. Archive Start Offset (sec)
#     7. Stream Hostname Filter
#     8. Player Override (on/off)
#     9.  -> Player: Integrated
#     10. -> Player: StreamLink
#     11. -> Player: Receiver
#     12. Clear Cache on Save
#   - Web form: all above fields added with correct toggle sections,
#     Russian translations, prefill, sendData, _applyWebData
#
# IPTVChannelBrowserScreen:
#   - Red: toggles "Select All" / "Deselect All"
#     (propagates visually to all channels in bouquet)
#   - Yellow: "Channels ID" — opens IPTVProviderTestResultScreen with
#     stored test result (no new test run)
#   - Blue: "Save" — saves selection, closes back to main screen
#   - Unchecking bouquet propagates visually to all its channels
#
# IPTVProviderTestResultScreen ("Channels ID"):
#   - Window title: "Channels ID"
#   - Blue "Download Picons" removed
#   - All 6 toggle modes show meaningful data even without XMLTV
#   - Yellow "Channel Browser" closes back to Channel Browser
#
# Test Provider flow:
#   Blue "Test Provider" -> fetch M3U -> run test -> _testDone ->
#   open Channel Browser (with test result stored).
#   Yellow in Channel Browser -> open "Channels ID" (stored result).
#   Yellow in "Channels ID" -> close back to Channel Browser.
#   Blue "Save" in Channel Browser -> save selection -> back to main screen.
#
# Settings screens:
#   IPTVClearProvidersScreen: uses loadPlaylistProviderConfig(create_archives=True)
#   IPTVProviderPerPlayerScreen: uses loadPlaylistProviderConfig(create_archives=True)
#   _tryCustomProviders: uses loadPlaylistProviderConfig(create_archives=True)
#   _triggerAutoBuild: uses loadPlaylistProviderConfig(create_archives=True)
#   _getArchiveTimeOffset: uses loadPlaylistProviderConfig(create_archives=True)
#
# Russian translations added in _lang.py for all new strings.
# ===========================================================================

# ===========================================================================
# v7.4 Additional fixes (same release)
# ===========================================================================
#
# FIX: Archive build error reporting (_screens.py, _epg.py)
#   _buildAllChannelCaches now raises Exception when XMLTV download fails
#   instead of silently continuing. _archiveBuildThread captures the error
#   and passes it to _archiveBuildDone which shows it in the help label
#   and opens a MessageBox. "Archive build complete" no longer shown on fail.
#
# FIX: Player Override not working for playlist archive providers (_epg.py, _screens.py)
#   getEnabledPlayers() in _epg.py now accepts optional prov_data parameter.
#   eventSelected() in _screens.py looks up the correct playlist provider dict
#   via loadPlaylistProviderConfig() and passes it as prov_data so the
#   player_override / player_int_on / player_sl_on / player_rec_on flags
#   from the playlist config are respected. Previously getEnabledPlayers()
#   only checked loadProviderConfig() (old archive file) which no longer
#   contains playlist providers — so override was never applied.
#
# FIX: Test Provider flow (_screens.py)
#   _testDone now opens IPTVChannelBrowserScreen directly (with test result
#   stored as _test_result). Yellow "Channels ID" in Channel Browser shows
#   the stored result instantly. Blue "Save" closes browser back to main
#   screen. No second test run after Save.
#
# FIX: Web form for Edit/Add IPTV Playlist/Archives Provider (_webserver.py)
#   All fields now match the receiver edit dialog in exact order:
#   Clean Bouquets, Create Provider Archives (toggle), Channel ID,
#   Archive Days, Custom TTL (toggle -> TTL Days), Offset +/-, Offset sec,
#   Hostname Filter, Player Override (toggle -> Integrated/StreamLink/Receiver),
#   Clear Cache on Save. Russian translations added for all new fields.
#   _startWebServer prefill and _applyWebData updated for all archive fields.
#   Titles updated to "Add/Edit IPTV Playlist/Archives Provider".
# ===========================================================================
