# -*- coding: utf-8 -*-
"""
plugin.py — CustomIPTVArchiveMakerPro  (thin entry point)
===============================================
Registers the plugin with Enigma2.  All logic lives in the sub-modules:
  _epg.py       — EPG engine, xxh32 hash, XMLTV/M3U helpers
  _providers.py — integrated provider table + archive URL builder
  _screens.py   — all UI Screen classes + auto-build scheduler
  _codemap.py   — developer reference / code map
"""

from Plugins.Plugin import PluginDescriptor

from . import _
from ._lang import T
from ._screens import (
    iptvArchiveSelection,
    autostart as _autostart,
    _iptv_open_requested,
)
from . import _screens as _sc


def where_extensionsmenu(session, **kwargs):
    """Open the archive EPG list.  Sets _iptv_open_requested so the screen
    knows it was launched by the user (not a session restore)."""
    _sc._iptv_open_requested = True
    session.open(iptvArchiveSelection,
                 session.nav.getCurrentlyPlayingServiceReference())


def autostart(reason, session=None, **kwargs):
    """WHERE_AUTOSTART callback — delegates to _screens.autostart."""
    _autostart(reason, session=session, **kwargs)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name        = _("CustomIPTVArchiveMakerPro"),
            description = T("Watch IPTV channel archives and catchup broadcasts"),
            where       = [PluginDescriptor.WHERE_EXTENSIONSMENU,
                           PluginDescriptor.WHERE_PLUGINMENU],
            fnc         = where_extensionsmenu,
            icon        = "plugin.png",
            needsRestart = False),
        PluginDescriptor(
            name        = _("CustomIPTVArchiveMakerPro"),
            where       = PluginDescriptor.WHERE_AUTOSTART,
            fnc         = autostart,
            needsRestart = False),
    ]
