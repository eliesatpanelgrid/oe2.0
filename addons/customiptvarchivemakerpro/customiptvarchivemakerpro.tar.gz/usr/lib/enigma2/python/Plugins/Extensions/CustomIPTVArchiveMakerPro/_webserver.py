# -*- coding: utf-8 -*-
"""
_webserver.py — CustomIPTVArchiveMakerPro
==========================================
Tiny threaded HTTP server for PC-based provider entry.

When IPTVProviderEditDialog opens it starts this server.
The user visits http://<receiver-ip>:1010 on their PC browser,
fills in a form (with optional local M3U file upload), and the
submitted data is placed in a thread-safe queue. The dialog polls
the queue every 500 ms via eTimer and auto-fills all provider fields.

Endpoints
---------
  GET  /         — serve the HTML form
  POST /         — receive form fields (URL-encoded), queue them
  POST /upload   — receive a raw M3U file, save to /tmp/, return its path
"""

import os
import re
import json
import threading
import socket

try:
    from ._lang import T as _WT
except Exception:
    try:
        from Plugins.Extensions.CustomIPTVArchiveMakerPro._lang import T as _WT
    except Exception:
        def _WT(s):
            try:
                from ._lang import T as _T_lang
                return _T_lang(s)
            except Exception:
                return s

try:
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import unquote_plus
    _HTTP_AVAILABLE = True
except ImportError:
    _HTTP_AVAILABLE = False

WEB_PORT = 1010
WEB_CHANNEL_BROWSER_PORT = 1012
WEB_XTREAM_BROWSER_PORT  = 1013
WEB_CUSTOM_EPG_PORT      = 1014

_UPLOAD_DIR = '/etc/CustomIPTVArchiveMakerPro'

# ---------------------------------------------------------------------------
# Helper — find the receiver's LAN IP
# ---------------------------------------------------------------------------

def _get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return '127.0.0.1'

# ---------------------------------------------------------------------------
# HTML form served to the PC browser
# ---------------------------------------------------------------------------

_HTML = u"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Add IPTV Provider</title>
<link rel="icon" href="data:,">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#12121f;color:#dde1f0;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{background:#1a1f38;border-radius:16px;padding:36px 40px;width:100%;
      max-width:620px;box-shadow:0 12px 48px rgba(0,0,0,.7)}
h1{font-size:22px;color:#e94560;text-align:center;letter-spacing:1px;margin-bottom:4px}
.sub{text-align:center;color:#6b7599;font-size:13px;margin-bottom:28px}
label{display:block;font-size:15px;color:#f0c040;font-weight:600;
      margin-top:18px;margin-bottom:5px}
input[type=text],input[type=number],select{
  width:100%;padding:10px 14px;background:#0d1530;
  border:1.5px solid #1e3560;border-radius:8px;
  color:#dde1f0;font-size:15px;outline:none;transition:border .2s}
input[type=text]:focus,input[type=number]:focus,select:focus{border-color:#e94560}
select option{background:#0d1530}
.hint{font-size:12px;color:#4a5578;margin-top:4px}
#update_mode_section label,#picon_sub_section label,#archives_sub_section label{color:#2ecc71}
#update_mode_section label,#picon_sub_section label,#archives_sub_section label{color:#2ecc71}

/* M3U row: text input + browse button side by side */
.m3u-row{display:flex;gap:8px;align-items:stretch}
.m3u-row input{flex:1;min-width:0}
.browse-btn{
  padding:0 16px;background:#0f3460;color:#8fa0c8;
  border:1.5px solid #1e3560;border-radius:8px;
  font-size:13px;font-weight:600;white-space:nowrap;
  cursor:pointer;transition:background .2s,color .2s,border-color .2s;
  display:flex;align-items:center;gap:6px}
.browse-btn:hover{background:#1a4a80;color:#dde1f0;border-color:#e94560}
.browse-btn svg{flex-shrink:0}
input[type=file]{display:none}
.upload-status{font-size:12px;color:#4a5578;margin-top:5px;min-height:16px;
               transition:color .3s}
.upload-status.uploading{color:#f0c040}
.upload-status.done{color:#2ecc71}
.upload-status.err{color:#e94560}

.btn{margin-top:30px;width:100%;padding:14px;background:#e94560;color:#fff;
     border:none;border-radius:10px;font-size:17px;font-weight:bold;
     cursor:pointer;letter-spacing:.5px;transition:background .2s}
.btn:hover{background:#c73652}
.ok{display:none;background:#152b1e;border:1.5px solid #2ecc71;color:#2ecc71;
    border-radius:10px;padding:18px;text-align:center;margin-top:20px;font-size:16px}
.cb-section{margin-top:18px;padding:14px 16px;background:#111628;
            border:1.5px solid #1e3560;border-radius:8px}
.cb-section .sec-lbl{font-size:12px;color:#4a5578;margin-bottom:10px}
.cb-row{display:flex;align-items:center;gap:10px;margin-top:8px}
.cb-row input[type=checkbox]{width:18px;height:18px;accent-color:#e94560;
                              flex-shrink:0;cursor:pointer}
.cb-row label{margin:0;font-size:14px;color:#dde1f0;font-weight:400;cursor:pointer}
</style>
</head>
<body>
<div class="card">
  <h1 id="h_title">&#9654; Add IPTV Provider</h1>
  <p class="sub" id="h_sub">CustomIPTVArchiveMakerPro &mdash; fill in the fields and press Send</p>

  <form id="f">
    <label for="name" id="lbl_name">Provider Name</label>
    <input type="text" id="name" name="name" placeholder="My IPTV Provider">

    <label for="xmltv_url" id="lbl_xmltv">XMLTV URL / Local File</label>
    <div class="m3u-row">
      <input type="text" id="xmltv_url" name="xmltv_url"
             placeholder="http://server/epg.xml, epg.xml.gz or local .xml file">
      <button class="browse-btn" type="button" onclick="browseXMLTV()"
              title="Browse for a local XMLTV file on your PC and upload it to the receiver">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
        </svg>
        <span id="btn_browse_xmltv">Browse&hellip;</span>
      </button>
      <input type="file" id="xmltv_file" accept=".xml,.xml.gz,.gz,.xmltv">
    </div>
    <div class="upload-status" id="xmltv_status"></div>
    <div class="hint" id="hint_xmltv">Leave blank if you have no separate EPG feed</div>

    <label for="m3u_source" id="lbl_m3u">M3U URL / M3U Playlist</label>
    <div class="m3u-row">
      <input type="text" id="m3u_source" name="m3u_source"
             placeholder="http://server/playlist.m3u8  or  /media/hdd/playlist.m3u">
      <button class="browse-btn" type="button" onclick="browseM3U()"
              title="Browse for a local M3U file on your PC and upload it to the receiver">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
        </svg>
        <span id="btn_browse_m3u">Browse&hellip;</span>
      </button>
      <input type="file" id="m3u_file" accept=".m3u,.m3u8,.txt">
    </div>
    <div class="upload-status" id="upload_status"></div>

    <label for="days" id="lbl_days">Archive Days (1&ndash;7)</label>
    <input type="number" id="days" name="days" value="7" min="1" max="7">

    <label id="lbl_ttl_section">TTL Days For Cached Files (Insert Available Archives Days Number)</label>
    <div class="cb-section">
      <div class="sec-lbl" id="hint_ttl">When enabled, this provider's cache files are refreshed after the selected number of days instead of the global default (7 days).</div>
      <div class="cb-row">
        <input type="checkbox" id="cache_ttl_custom" name="cache_ttl_custom">
        <label for="cache_ttl_custom" id="lbl_ttl_custom">Use custom TTL for this provider</label>
      </div>
    </div>
    <label for="cache_ttl_days" id="lbl_ttl_days">&nbsp;&nbsp;TTL Days (1&ndash;7)</label>
    <input type="number" id="cache_ttl_days" name="cache_ttl_days" value="7" min="1" max="7">

    <label for="time_offset_sign" id="lbl_sign">Archive Start Offset &mdash; Sign</label>
    <select id="time_offset_sign" name="time_offset_sign">
      <option value="+" selected id="opt_plus">+&nbsp;&nbsp;start later</option>
      <option value="-" id="opt_minus">-&nbsp;&nbsp;start earlier &nbsp;(corrects a fast receiver clock)</option>
    </select>

    <label for="time_offset_abs" id="lbl_abs">Archive Start Offset &mdash; Seconds (0&ndash;99999)</label>
    <input type="number" id="time_offset_abs" name="time_offset_abs" value="0" min="0" max="99999">
    <div class="hint" id="hint_offset">Example: Sign &ldquo;&minus;&rdquo; + 420 sec = start 7 minutes earlier</div>

    <label for="stream_hostname" id="lbl_hostname">Stream Hostname Filter (For Time Offset)</label>
    <input type="text" id="stream_hostname" name="stream_hostname"
           placeholder="e.g. myserver.com &mdash; leave blank to always apply offset">
    <div class="hint" id="hint_hostname">Offset only applies when the live stream URL hostname contains this value. Leave blank to always apply.</div>

    <label id="lbl_player_section">Player Selection (Provider Override)</label>
    <div class="cb-section">
      <div class="sec-lbl" id="lbl_player_hint">Enable override to use player settings specific to this provider instead of global settings. Active players show a choice dialog before playback.</div>
      <div class="cb-row">
        <input type="checkbox" id="player_override" name="player_override">
        <label for="player_override" id="lbl_player_override">Override global player settings for this provider</label>
      </div>
      <div class="cb-row">
        <input type="checkbox" id="player_int_on" name="player_int_on" checked>
        <label for="player_int_on" id="lbl_player_int">Integrated Player</label>
      </div>
      <div class="cb-row">
        <input type="checkbox" id="player_sl_on" name="player_sl_on">
        <label for="player_sl_on" id="lbl_player_sl">StreamLink Player</label>
      </div>
      <div class="cb-row">
        <input type="checkbox" id="player_rec_on" name="player_rec_on">
        <label for="player_rec_on" id="lbl_player_rec">Receiver Player</label>
      </div>
    </div>

    <label for="enabled" id="lbl_enabled">Enabled</label>
    <select id="enabled" name="enabled">
      <option value="1" selected id="opt_yes">Yes</option>
      <option value="0" id="opt_no">No</option>
    </select>

    <button class="btn" type="button" onclick="sendData()" id="btn_send">
      &#10148;&nbsp; Send to Receiver
    </button>
  </form>

  <div class="ok" id="ok">
    <span id="ok_msg">&#10003;&nbsp; Data sent to your receiver!<br>
    The provider fields have been filled in automatically.<br>
    You can close this tab and press <strong>Save</strong> on the receiver.</span>
  </div>
</div>

<script>
/* ---- Russian translations for the web form ---- */
var _RU_WEB = {
  'add_title':     '\u25ba\u00a0 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c IPTV-\u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'edit_title':    '\u270e\u00a0 \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'sub_add':       'CustomIPTVArchiveMakerPro \u2014 \u0437\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043f\u043e\u043b\u044f \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'sub_edit':      'CustomIPTVArchiveMakerPro \u2014 \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u0435 \u043d\u0443\u0436\u043d\u043e\u0435 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'lbl_name':      '\u0418\u043c\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_xmltv':     'XMLTV URL / \u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0444\u0430\u0439\u043b',
  'lbl_m3u':       'M3U URL / M3U-\u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442',
  'lbl_days':      '\u0414\u043d\u0435\u0439 \u0430\u0440\u0445\u0438\u0432\u0430 (1\u20137)',
  'lbl_ttl_section': '\u0421\u0440\u043e\u043a \u043a\u044d\u0448\u0430 (\u0432\u0432\u0435\u0434\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e\u0435 \u043a\u043e\u043b-\u0432\u043e \u0434\u043d\u0435\u0439 \u0430\u0440\u0445\u0438\u0432\u0430)',
  'lbl_ttl_custom':  '\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u0441\u0432\u043e\u0439 \u0441\u0440\u043e\u043a \u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f',
  'lbl_ttl_days':    '\u00a0\u00a0\u0414\u043d\u0435\u0439 \u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f (1\u20137)',
  'hint_ttl':        '\u041f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0438 \u043a\u044d\u0448 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u044f\u0435\u0442\u0441\u044f \u0447\u0435\u0440\u0435\u0437 \u0443\u043a\u0430\u0437\u0430\u043d\u043d\u043e\u0435 \u043a\u043e\u043b-\u0432\u043e \u0434\u043d\u0435\u0439 \u0432\u043c\u0435\u0441\u0442\u043e \u0433\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u044b\u0445 7 \u0434\u043d\u0435\u0439.',
  'lbl_sign':      '\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043d\u0430\u0447\u0430\u043b\u0430 \u0430\u0440\u0445\u0438\u0432\u0430 \u2014 \u0417\u043d\u0430\u043a',
  'lbl_abs':       '\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043d\u0430\u0447\u0430\u043b\u0430 \u0430\u0440\u0445\u0438\u0432\u0430 \u2014 \u0421\u0435\u043a\u0443\u043d\u0434\u044b (0\u201399999)',
  'lbl_hostname':       '\u0424\u0438\u043b\u044c\u0442\u0440 hostname \u043f\u043e\u0442\u043e\u043a\u0430 (\u0434\u043b\u044f \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u044f \u0432\u0440\u0435\u043c\u0435\u043d\u0438)',
  'lbl_player_section': '\u0412\u044b\u0431\u043e\u0440 \u043f\u043b\u0435\u0435\u0440\u0430 (\u043f\u0435\u0440\u0435\u043a\u0440\u044b\u0442\u0438\u0435 \u0434\u043b\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430)',
  'lbl_player_hint':    '\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043f\u0435\u0440\u0435\u043a\u0440\u044b\u0442\u0438\u0435, \u0447\u0442\u043e\u0431\u044b \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u0441\u0432\u043e\u0438 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u043b\u0435\u0435\u0440\u0430 \u0432\u043c\u0435\u0441\u0442\u043e \u0433\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u044b\u0445',
  'lbl_player_override':'\u041f\u0435\u0440\u0435\u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u0442\u044c \u0433\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u044b\u0439 \u0432\u044b\u0431\u043e\u0440 \u043f\u043b\u0435\u0435\u0440\u0430',
  'lbl_player_int':     '\u0412\u0441\u0442\u0440\u043e\u0435\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440',
  'lbl_player_sl':      'StreamLink',
  'lbl_player_rec':     '\u041f\u043b\u0435\u0435\u0440 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0430',
  'hint_hostname': '\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043a\u043e\u0433\u0434\u0430 hostname \u043f\u043e\u0442\u043e\u043a\u0430 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u0442 \u044d\u0442\u043e \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435. \u041e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c \u2014 \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u0432\u0441\u0435\u0433\u0434\u0430 \u0430\u043a\u0442\u0438\u0432\u043d\u043e.',
  'lbl_enabled':   '\u0412\u043a\u043b\u044e\u0447\u0451\u043d',
  'opt_plus':      '+\u00a0\u00a0\u043d\u0430\u0447\u0430\u0442\u044c \u043f\u043e\u0437\u0436\u0435',
  'opt_minus':     '-\u00a0\u00a0\u043d\u0430\u0447\u0430\u0442\u044c \u0440\u0430\u043d\u044c\u0448\u0435\u00a0\u00a0(\u0438\u0441\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0434\u0440\u0435\u0439\u0444 \u0447\u0430\u0441\u043e\u0432)',
  'opt_yes':       '\u0414\u0430',
  'opt_no':        '\u041d\u0435\u0442',
  'hint_xmltv':    '\u041e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c, \u0435\u0441\u043b\u0438 \u043d\u0435\u0442 \u043e\u0442\u0434\u0435\u043b\u044c\u043d\u043e\u0433\u043e EPG',
  'hint_offset':   '\u041f\u0440\u0438\u043c\u0435\u0440: \u0417\u043d\u0430\u043a \u00ab\u2212\u00bb + 420 \u0441\u0435\u043a = \u043d\u0430\u0447\u0430\u0442\u044c \u043d\u0430 7 \u043c\u0438\u043d\u0443\u0442 \u0440\u0430\u043d\u044c\u0448\u0435',
  'btn_browse':    '\u041e\u0431\u0437\u043e\u0440\u2026',
  'btn_send':      '\u10148\u00a0 \u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a',
  'ok_msg':        '\u2713\u00a0 \u0414\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u044b \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a!<br>\u041f\u043e\u043b\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.<br>\u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u043a\u043b\u0430\u0434\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 <strong>\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</strong> \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435.',
  'err_send':      '\u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.',
  'err_reach':     '\u041d\u0435 \u0443\u0434\u0430\u0451\u0442\u0441\u044f \u0441\u0432\u044f\u0437\u0430\u0442\u044c\u0441\u044f \u0441 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u043e\u043c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u0435\u0442\u044c.'
};

/* ---- Pre-fill fields when editing an existing provider ---- */
var PREFILL = /*PREFILL_JSON*/null/*END_PREFILL*/;
var L = /*L_JSON*/{}/*END_L*/;
var _IS_RU = (PREFILL && PREFILL.ui_language === 'RUS');
  /* ---- Multi-language translations ---- */
  var _DE={"lbl_name": "Anbieter-Name", "lbl_xmltv": "XMLTV-URL / Lokale Datei", "lbl_m3u": "M3U-URL / M3U-Playlist", "lbl_days": "Archivtage (1-7)", "lbl_ttl_section": "TTL-Tage für gecachte Dateien (verfügbare Archivtage eingeben)", "lbl_ttl_custom": "Eigene TTL", "lbl_ttl_days": "  TTL-Tage (1-7)", "lbl_sign": "Versatz Vorzeichen", "opt_plus": "+  später", "opt_minus": "-  früher", "lbl_abs": "Versatz Sekunden", "lbl_hostname": "Stream-Hostname-Filter (für Zeitversatz)", "lbl_player_section": "Player-Auswahl", "lbl_player_hint": "Player-Einstellungen überschreiben.", "lbl_player_override": "Player-Überschreibung (anbieterspezifisch)", "lbl_player_int": "Player: Integriert", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Empfänger", "lbl_enabled": "Aktiviert", "opt_yes": "Ja", "opt_no": "Nein", "lbl_epg_parse": "EPG-Datei erstellen", "opt_epg_off": "Aus", "opt_epg_dn": "Nach Anzeigename", "opt_epg_tvg": "Nach tvg-id", "lbl_strategy": "Bouquet-Erstellungsstrategie", "opt_same": "Wie in Playlist", "opt_all": "Bouquet für alle Kanäle", "opt_allg": "Bouquets für alle Kanäle und Gruppen", "opt_psub": "Bouquet mit Anbieter-Name und Sub-Bouquets", "lbl_playback": "Wiedergabe mit", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kanal-Reihenfolge nach", "opt_ord_prov": "Anbieter-Reihenfolge verwenden", "opt_ord_alpha": "Alphabetisch", "opt_ord_user": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top": "Neue Kanäle oben", "opt_upd_bot": "Neue Kanäle unten", "lbl_picon": "Picons herunterladen", "opt_picon_off": "Aus", "opt_picon_on": "Ein", "lbl_pic_naming": "Benennung", "opt_pic_dn": "Mit Anzeigename", "opt_pic_ref": "Mit Referenznummer", "lbl_pic_folder": "Mit Ordner", "opt_pic_folder_on": "Ein", "opt_pic_folder_off": "Aus", "lbl_pic_symlink": "Symlink erstellen", "opt_pic_sym_off": "Aus", "opt_pic_sym_on": "Ein", "lbl_custom_epg": "Benutzerdefiniertes EPG", "opt_cepg_on": "Ein", "opt_cepg_off": "Aus", "lbl_clean_bouquets": "Bouquets bereinigen", "opt_clean_off": "Aus", "opt_clean_on": "Ein", "lbl_create_archives": "Anbieter-Archive erstellen", "opt_arch_off": "Aus", "opt_arch_on": "Ein", "lbl_create_archive_markers": "Archiv-Markierungen erstellen", "opt_markers_off": "Aus", "opt_markers_on": "Ein", "lbl_archive_days": "Archivtage (1-7)", "lbl_cache_ttl_custom": "Eigene TTL", "opt_ttl_off": "Aus (7 Tage)", "opt_ttl_on": "Ein", "lbl_cache_ttl_days": "TTL-Tage (1-30)", "lbl_time_offset_sign": "Versatz +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Versatz (Sek.)", "lbl_stream_hostname": "Hostname-Filter aus Stream-URL", "opt_plr_off": "Aus", "opt_plr_on": "Ein", "opt_int_on": "Ein", "opt_int_off": "Aus", "opt_sl_off": "Aus", "opt_sl_on": "Ein", "opt_rec_off": "Aus", "opt_rec_on": "Ein", "lbl_clear_cache_on_save": "Cache beim Speichern leeren", "opt_ccs_off": "Aus", "opt_ccs_on": "Ein", "lbl_frag": "URL-Fragment", "lbl_arch": "Archiv-URL-Muster", "opt_std": "Standard (utc/lutc-Parameter)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "EPG-Quelle", "opt_ottp": "ottp.eu.org-Datenbank (empfohlen)", "opt_api": "Eigene API-URL des Anbieters", "lbl_epg_url": "EPG-API-URL-Vorlage", "lbl_xtream_type": "Xtream Typ", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Benutzername", "lbl_xtream_password": "Xtream Passwort", "lbl_xtream_output": "Stream-Ausgabe", "opt_xt_m3u8": "HLS / m3u8 (Empfohlen)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Bouquet-Strategie", "opt_xts_same": "Wie Anbieter", "opt_xts_folder": "Alle in einen Ordner", "opt_ord_user_xt": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_xt_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top_xt": "Neue Kanäle oben", "opt_upd_bot_xt": "Neue Kanäle unten", "lbl_xtream_show_live": "Live-TV-Bouquets erstellen", "opt_xtlive_yes": "Ja", "opt_xtlive_no": "Nein", "lbl_xtream_live_type": "Live-Typ", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "VOD-Bouquets erstellen", "opt_xtvod_yes": "Ja", "opt_xtvod_no": "Nein", "lbl_xtream_vod_type": "VOD-Typ", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Serien-Bouquets erstellen", "opt_xtser_yes": "Ja", "opt_xtser_no": "Nein", "lbl_xtream_series_type": "Serien-Typ", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Picons herunterladen", "opt_xtp_off": "Aus", "opt_xtp_dn": "Mit Anzeigename", "opt_xtp_ref": "Mit Referenznummer", "lbl_xtream_picon_folder": "Mit Ordner", "opt_xtp_folder_on": "Ein", "opt_xtp_folder_off": "Aus", "lbl_xtream_picon_symlink": "Symlink erstellen", "opt_xtp_sym_off": "Aus", "opt_xtp_sym_on": "Ein", "opt_markers_off_xt": "Aus", "opt_markers_on_xt": "Ein", "lbl_xt_custom_epg": "Benutzerdefiniertes EPG", "opt_xt_cepg_on": "Ein", "opt_xt_cepg_off": "Aus", "lbl_xtream_clean": "Bouquets bereinigen", "opt_xclean_no": "Nein", "opt_xclean_yes": "Ja", "lbl_ch_title": "Kanäle"};
  var _IT={"lbl_name": "Nome provider", "lbl_xmltv": "URL XMLTV / File locale", "lbl_m3u": "URL M3U / Playlist M3U", "lbl_days": "Giorni archivio (1-7)", "lbl_ttl_section": "Giorni TTL per file cache (inserisci il numero di giorni archivio disponibili)", "lbl_ttl_custom": "TTL personalizzato", "lbl_ttl_days": "  Giorni TTL (1-7)", "lbl_sign": "Offset segno", "opt_plus": "+  dopo", "opt_minus": "-  prima", "lbl_abs": "Offset secondi", "lbl_hostname": "Filtro hostname stream (per offset tempo)", "lbl_player_section": "Selezione player", "lbl_player_hint": "Sovrascrivere impostazioni player.", "lbl_player_override": "Override player (specifico per provider)", "lbl_player_int": "Player: Integrato", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Ricevitore", "lbl_enabled": "Abilitato", "opt_yes": "Sì", "opt_no": "No", "lbl_epg_parse": "Crea file EPG", "opt_epg_off": "Spento", "opt_epg_dn": "Per nome visualizzato", "opt_epg_tvg": "Per tvg-id", "lbl_strategy": "Strategia creazione bouquet", "opt_same": "Come nella playlist", "opt_all": "Bouquet per tutti i canali", "opt_allg": "Bouquet per tutti i canali e gruppi", "opt_psub": "Bouquet con nome provider e sotto-bouquet", "lbl_playback": "Riproduci con", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Ordinamento canali per", "opt_ord_prov": "Usa ordine provider", "opt_ord_alpha": "Alfabeticamente", "opt_ord_user": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top": "Nuovi canali in alto", "opt_upd_bot": "Nuovi canali in basso", "lbl_picon": "Scarica picon", "opt_picon_off": "Spento", "opt_picon_on": "Sì", "lbl_pic_naming": "Denominazione", "opt_pic_dn": "Con nome visualizzato", "opt_pic_ref": "Con numero di riferimento", "lbl_pic_folder": "Con cartella", "opt_pic_folder_on": "Sì", "opt_pic_folder_off": "Spento", "lbl_pic_symlink": "Crea collegamento simbolico", "opt_pic_sym_off": "Spento", "opt_pic_sym_on": "Sì", "lbl_custom_epg": "EPG Personalizzato", "opt_cepg_on": "Sì", "opt_cepg_off": "Spento", "lbl_clean_bouquets": "Pulisci bouquet", "opt_clean_off": "Spento", "opt_clean_on": "Sì", "lbl_create_archives": "Crea archivi provider", "opt_arch_off": "Spento", "opt_arch_on": "Sì", "lbl_create_archive_markers": "Crea marcatori archivio", "opt_markers_off": "Spento", "opt_markers_on": "Sì", "lbl_archive_days": "Giorni archivio (1-7)", "lbl_cache_ttl_custom": "TTL personalizzato", "opt_ttl_off": "No (7 giorni)", "opt_ttl_on": "Sì", "lbl_cache_ttl_days": "Giorni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_stream_hostname": "Filtro hostname da URL stream", "opt_plr_off": "Spento", "opt_plr_on": "Sì", "opt_int_on": "Sì", "opt_int_off": "Spento", "opt_sl_off": "Spento", "opt_sl_on": "Sì", "opt_rec_off": "Spento", "opt_rec_on": "Sì", "lbl_clear_cache_on_save": "Pulisci cache al salvataggio", "opt_ccs_off": "Spento", "opt_ccs_on": "Sì", "lbl_frag": "Frammento URL", "lbl_arch": "Schema URL archivio", "opt_std": "Standard (parametri utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Fonte EPG", "opt_ottp": "Database ottp.eu.org (consigliato)", "opt_api": "URL API proprio del provider", "lbl_epg_url": "Modello URL API EPG", "lbl_xtream_type": "Tipo Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nome utente Xtream", "lbl_xtream_password": "Password Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Uscita stream", "opt_xt_m3u8": "HLS / m3u8 (Consigliato)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bouquet", "opt_xts_same": "Come da provider", "opt_xts_folder": "Tutti in una cartella", "opt_ord_user_xt": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_xt_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top_xt": "Nuovi canali in alto", "opt_upd_bot_xt": "Nuovi canali in basso", "lbl_xtream_show_live": "Crea bouquet TV in diretta", "opt_xtlive_yes": "Sì", "opt_xtlive_no": "No", "lbl_xtream_live_type": "Tipo live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Crea bouquet VOD", "opt_xtvod_yes": "Sì", "opt_xtvod_no": "No", "lbl_xtream_vod_type": "Tipo VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Crea bouquet serie", "opt_xtser_yes": "Sì", "opt_xtser_no": "No", "lbl_xtream_series_type": "Tipo serie", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Scarica picon", "opt_xtp_off": "Spento", "opt_xtp_dn": "Con nome visualizzato", "opt_xtp_ref": "Con numero di riferimento", "lbl_xtream_picon_folder": "Con cartella", "opt_xtp_folder_on": "Sì", "opt_xtp_folder_off": "Spento", "lbl_xtream_picon_symlink": "Crea collegamento simbolico", "opt_xtp_sym_off": "Spento", "opt_xtp_sym_on": "Sì", "opt_markers_off_xt": "Spento", "opt_markers_on_xt": "Sì", "lbl_xt_custom_epg": "EPG Personalizzato", "opt_xt_cepg_on": "Sì", "opt_xt_cepg_off": "Spento", "lbl_xtream_clean": "Pulisci bouquet", "opt_xclean_no": "No", "opt_xclean_yes": "Sì", "lbl_bouquets": "Bouquet", "lbl_ch_title": "Canali"};
  var _PL={"lbl_name": "Nazwa dostawcy", "lbl_xmltv": "XMLTV URL / Plik lokalny", "lbl_m3u": "M3U URL / Playlista M3U", "lbl_days": "Dni archiwum (1-7)", "lbl_ttl_section": "Dni TTL dla plików pamięci podręcznej (wprowadź dostępną liczbę dni archiwum)", "lbl_ttl_custom": "Własny TTL", "lbl_ttl_days": "  Dni TTL (1-7)", "lbl_sign": "Przesunięcie znak", "opt_plus": "+  później", "opt_minus": "-  wcześniej", "lbl_abs": "Przesunięcie sekundy", "lbl_hostname": "Filtr nazwy hosta strumienia (dla przesunięcia czasu)", "lbl_player_section": "Wybór odtwarzacza", "lbl_player_hint": "Nadpisz ustawienia odtwarzacza.", "lbl_player_override": "Nadpisanie odtwarzacza (specyficzne dla dostawcy)", "lbl_player_int": "Odtwarzacz: Wbudowany", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Odtwarzacz: Odbiornik", "lbl_enabled": "Włączony", "opt_yes": "Tak", "opt_no": "Nie", "lbl_epg_parse": "Utwórz plik EPG", "opt_epg_off": "Wyłączone", "opt_epg_dn": "Według nazwy wyświetlanej", "opt_epg_tvg": "Według tvg-id", "lbl_strategy": "Strategia tworzenia bukietu", "opt_same": "Jak w playliście", "opt_all": "Bukiet dla wszystkich kanałów", "opt_allg": "Bukiety dla wszystkich kanałów i grup", "opt_psub": "Bukiet z nazwą dostawcy i podbukietami", "lbl_playback": "Odtwarzanie przez", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kolejność kanałów według", "opt_ord_prov": "Użyj kolejności dostawcy", "opt_ord_alpha": "Alfabetycznie", "opt_ord_user": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top": "Nowe kanały na górze", "opt_upd_bot": "Nowe kanały na dole", "lbl_picon": "Pobierz pikony", "opt_picon_off": "Wyłączone", "opt_picon_on": "Wł", "lbl_pic_naming": "Nazewnictwo", "opt_pic_dn": "Z nazwą wyświetlaną", "opt_pic_ref": "Z numerem referencyjnym", "lbl_pic_folder": "Z folderem", "opt_pic_folder_on": "Wł", "opt_pic_folder_off": "Wyłączone", "lbl_pic_symlink": "Utwórz dowiązanie symboliczne", "opt_pic_sym_off": "Wyłączone", "opt_pic_sym_on": "Wł", "lbl_custom_epg": "Niestandardowy EPG", "opt_cepg_on": "Wł", "opt_cepg_off": "Wyłączone", "lbl_clean_bouquets": "Wyczyść bukiety", "opt_clean_off": "Wyłączone", "opt_clean_on": "Wł", "lbl_create_archives": "Utwórz archiwa dostawcy", "opt_arch_off": "Wyłączone", "opt_arch_on": "Wł", "lbl_create_archive_markers": "Utwórz znaczniki archiwum", "opt_markers_off": "Wyłączone", "opt_markers_on": "Wł", "lbl_archive_days": "Dni archiwum (1-7)", "lbl_cache_ttl_custom": "Własny TTL", "opt_ttl_off": "Wył (7 dni)", "opt_ttl_on": "Wł", "lbl_cache_ttl_days": "Dni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Przesunięcie (sek)", "lbl_stream_hostname": "Filtr hosta z URL strumienia", "opt_plr_off": "Wyłączone", "opt_plr_on": "Wł", "opt_int_on": "Wł", "opt_int_off": "Wyłączone", "opt_sl_off": "Wyłączone", "opt_sl_on": "Wł", "opt_rec_off": "Wyłączone", "opt_rec_on": "Wł", "lbl_clear_cache_on_save": "Wyczyść pamięć podręczną przy zapisie", "opt_ccs_off": "Wyłączone", "opt_ccs_on": "Wł", "lbl_frag": "Fragment URL", "lbl_arch": "Wzorzec URL archiwum", "opt_std": "Standardowy (parametry utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Źródło EPG", "opt_ottp": "Baza danych ottp.eu.org (zalecana)", "opt_api": "Własny URL API dostawcy", "lbl_epg_url": "Szablon URL API EPG", "lbl_xtream_type": "Typ Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nazwa użytkownika Xtream", "lbl_xtream_password": "Hasło Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Wyjście strumienia", "opt_xt_m3u8": "HLS / m3u8 (Zalecane)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bukietu", "opt_xts_same": "Tak jak u dostawcy", "opt_xts_folder": "Wszystko do jednego folderu", "opt_ord_user_xt": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_xt_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top_xt": "Nowe kanały na górze", "opt_upd_bot_xt": "Nowe kanały na dole", "lbl_xtream_show_live": "Buduj bukiety telewizji na żywo", "opt_xtlive_yes": "Tak", "opt_xtlive_no": "Nie", "lbl_xtream_live_type": "Typ live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Buduj bukiety VOD", "opt_xtvod_yes": "Tak", "opt_xtvod_no": "Nie", "lbl_xtream_vod_type": "Typ VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Buduj bukiety seriali", "opt_xtser_yes": "Tak", "opt_xtser_no": "Nie", "lbl_xtream_series_type": "Typ seriali", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Pobierz pikony", "opt_xtp_off": "Wyłączone", "opt_xtp_dn": "Z nazwą wyświetlaną", "opt_xtp_ref": "Z numerem referencyjnym", "lbl_xtream_picon_folder": "Z folderem", "opt_xtp_folder_on": "Wł", "opt_xtp_folder_off": "Wyłączone", "lbl_xtream_picon_symlink": "Utwórz dowiązanie symboliczne", "opt_xtp_sym_off": "Wyłączone", "opt_xtp_sym_on": "Wł", "opt_markers_off_xt": "Wyłączone", "opt_markers_on_xt": "Wł", "lbl_xt_custom_epg": "Niestandardowy EPG", "opt_xt_cepg_on": "Wł", "opt_xt_cepg_off": "Wyłączone", "lbl_xtream_clean": "Wyczyść bukiety", "opt_xclean_no": "Nie", "opt_xclean_yes": "Tak", "lbl_bouquets": "Bukiety", "lbl_ch_title": "Kanały"};
  var _RU={"lbl_name": "Имя провайдера", "lbl_xmltv": "XMLTV URL / Локальный файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дней архива (1-7)", "lbl_ttl_section": "Срок кэша (введите доступное кол-во дней архива)", "lbl_ttl_custom": "Свой TTL", "lbl_ttl_days": "  Дней хранения (1-7)", "lbl_sign": "Смещение знак", "opt_plus": "+  позже", "opt_minus": "-  раньше", "lbl_abs": "Смещение секунды", "lbl_hostname": "Фильтр hostname потока (для смещения времени)", "lbl_player_section": "Выбор плеера", "lbl_player_hint": "Переопределить настройки плеера.", "lbl_player_override": "Перекрытие плеера (для провайдера)", "lbl_player_int": "Плеер: встроенный", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеер: приёмника", "lbl_enabled": "Включён", "opt_yes": "Да", "opt_no": "Нет", "lbl_epg_parse": "Создать файл EPG", "opt_epg_off": "Выключено", "opt_epg_dn": "По отображаемому имени", "opt_epg_tvg": "По tvg-id", "lbl_strategy": "Стратегия создания букета", "opt_same": "Как в плейлисте", "opt_all": "Букет для всех каналов", "opt_allg": "Букеты для всех каналов и групп", "opt_psub": "Букет с именем провайдера и суббукеты", "lbl_playback": "Воспроизведение через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналов", "opt_ord_prov": "Порядок из провайдера", "opt_ord_alpha": "По алфавиту", "opt_ord_user": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_update_mode": "Только обновить M3U плейлист", "opt_upd_top": "Новые каналы сверху", "opt_upd_bot": "Новые каналы снизу", "lbl_picon": "Скачать Пиконы", "opt_picon_off": "Выключено", "opt_picon_on": "Вкл", "lbl_pic_naming": "Именование", "opt_pic_dn": "С отображаемым именем", "opt_pic_ref": "С номером ссылки", "lbl_pic_folder": "С папкой провайдера", "opt_pic_folder_on": "Вкл", "opt_pic_folder_off": "Выключено", "lbl_pic_symlink": "Создать симлинк", "opt_pic_sym_off": "Выключено", "opt_pic_sym_on": "Вкл", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Вкл", "opt_cepg_off": "Выключено", "lbl_clean_bouquets": "Очистить букеты", "opt_clean_off": "Выключено", "opt_clean_on": "Вкл", "lbl_create_archives": "Создать Архивы Провайдера", "opt_arch_off": "Выключено", "opt_arch_on": "Вкл", "lbl_create_archive_markers": "Создать маркеры архива", "opt_markers_off": "Выключено", "opt_markers_on": "Вкл", "lbl_archive_days": "Дней архива (1-7)", "lbl_cache_ttl_custom": "Свой срок хранения", "opt_ttl_off": "Выкл (7 дней)", "opt_ttl_on": "Вкл", "lbl_cache_ttl_days": "Дней кэша (1-30)", "lbl_time_offset_sign": "Смещение +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Смещение (сек)", "lbl_stream_hostname": "Hostname фильтр из URL потока", "opt_plr_off": "Выключено", "opt_plr_on": "Вкл", "opt_int_on": "Вкл", "opt_int_off": "Выключено", "opt_sl_off": "Выключено", "opt_sl_on": "Вкл", "opt_rec_off": "Выключено", "opt_rec_on": "Вкл", "lbl_clear_cache_on_save": "Очистить кэш при сохранении", "opt_ccs_off": "Выключено", "opt_ccs_on": "Вкл", "lbl_frag": "URL фрагмент", "lbl_arch": "Шаблон URL архива", "opt_std": "Стандартный (utc/lutc параметры)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Источник EPG", "opt_ottp": "База ottp.eu.org (рекомендуется)", "opt_api": "Свой URL API провайдера", "lbl_epg_url": "Шаблон URL EPG API", "lbl_xtream_type": "Xtream Тип", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Имя пользователя", "lbl_xtream_password": "Xtream Пароль", "lbl_xtream_token": "Xtream Токен", "lbl_xtream_output": "Выходной формат потока", "opt_xt_m3u8": "HLS / m3u8 (Рекомендуется)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегия создания букетов", "opt_xts_same": "Как у провайдера", "opt_xts_folder": "Все в одну папку", "opt_ord_user_xt": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_xt_update_mode": "Только обновить M3U плейлист", "opt_upd_top_xt": "Новые каналы сверху", "opt_upd_bot_xt": "Новые каналы снизу", "lbl_xtream_show_live": "Создавать букеты Live TV", "opt_xtlive_yes": "Да", "opt_xtlive_no": "Нет", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Создавать букеты VOD", "opt_xtvod_yes": "Да", "opt_xtvod_no": "Нет", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Создавать букеты Сериалов", "opt_xtser_yes": "Да", "opt_xtser_no": "Нет", "lbl_xtream_series_type": "Тип серий", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Скачать Пиконы", "opt_xtp_off": "Выключено", "opt_xtp_dn": "С отображаемым именем", "opt_xtp_ref": "С номером ссылки", "lbl_xtream_picon_folder": "С папкой провайдера", "opt_xtp_folder_on": "Вкл", "opt_xtp_folder_off": "Выключено", "lbl_xtream_picon_symlink": "Создать симлинк", "opt_xtp_sym_off": "Выключено", "opt_xtp_sym_on": "Вкл", "opt_markers_off_xt": "Выключено", "opt_markers_on_xt": "Вкл", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Вкл", "opt_xt_cepg_off": "Выключено", "lbl_xtream_clean": "Очистить букеты", "opt_xclean_no": "Нет", "opt_xclean_yes": "Да", "lbl_bouquets": "Букеты", "lbl_ch_title": "Каналы"};
  var _UK={"lbl_name": "Назва провайдера", "lbl_xmltv": "XMLTV URL / Локальний файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дні архіву (1-7)", "lbl_ttl_section": "TTL-дні для кешованих файлів (введіть доступну кількість днів архіву)", "lbl_ttl_custom": "Власний TTL", "lbl_ttl_days": "  TTL-дні (1-7)", "lbl_sign": "Зміщення знак", "opt_plus": "+  пізніше", "opt_minus": "-  раніше", "lbl_abs": "Зміщення секунди", "lbl_hostname": "Фільтр імені хоста потоку (для зсуву часу)", "lbl_player_section": "Вибір плеєра", "lbl_player_hint": "Перевизначити налаштування плеєра.", "lbl_player_override": "Перевизначення плеєра (для провайдера)", "lbl_player_int": "Плеєр: вбудований", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеєр: приймача", "lbl_enabled": "Увімкнено", "opt_yes": "Так", "opt_no": "Ні", "lbl_epg_parse": "Створити EPG-файл", "opt_epg_off": "Вимк", "opt_epg_dn": "За назвою", "opt_epg_tvg": "За tvg-id", "lbl_strategy": "Стратегія створення букетів", "opt_same": "Як у плейлисті", "opt_all": "Букет для всіх каналів", "opt_allg": "Букети для всіх каналів та груп", "opt_psub": "Букет з назвою провайдера та суб-букетами", "lbl_playback": "Відтворення через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналів за", "opt_ord_prov": "Порядок провайдера", "opt_ord_alpha": "За алфавітом", "opt_ord_user": "Користувацький (для відсортованих каналів/букетів)", "lbl_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top": "Нові канали зверху", "opt_upd_bot": "Нові канали знизу", "lbl_picon": "Завантажити пікони", "opt_picon_off": "Вимк", "opt_picon_on": "Увім", "lbl_pic_naming": "Іменування", "opt_pic_dn": "За назвою", "opt_pic_ref": "За номером посилання", "lbl_pic_folder": "З папкою", "opt_pic_folder_on": "Увім", "opt_pic_folder_off": "Вимк", "lbl_pic_symlink": "Створити симлінк", "opt_pic_sym_off": "Вимк", "opt_pic_sym_on": "Увім", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Увім", "opt_cepg_off": "Вимк", "lbl_clean_bouquets": "Очистити букети", "opt_clean_off": "Вимк", "opt_clean_on": "Увім", "lbl_create_archives": "Створити Архіви Провайдера", "opt_arch_off": "Вимк", "opt_arch_on": "Увім", "lbl_create_archive_markers": "Створити маркери архіву", "opt_markers_off": "Вимк", "opt_markers_on": "Увім", "lbl_archive_days": "Дні архіву (1-7)", "lbl_cache_ttl_custom": "Користувацький TTL", "opt_ttl_off": "Вимк (7 днів)", "opt_ttl_on": "Увім", "lbl_cache_ttl_days": "Днів кешу (1-30)", "lbl_time_offset_sign": "Зміщення +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Зсув (сек)", "lbl_stream_hostname": "Фільтр імені хоста з URL потоку", "opt_plr_off": "Вимк", "opt_plr_on": "Увім", "opt_int_on": "Увім", "opt_int_off": "Вимк", "opt_sl_off": "Вимк", "opt_sl_on": "Увім", "opt_rec_off": "Вимк", "opt_rec_on": "Увім", "lbl_clear_cache_on_save": "Очистити кеш при збереженні", "opt_ccs_off": "Вимк", "opt_ccs_on": "Увім", "lbl_frag": "Фрагмент URL", "lbl_arch": "Шаблон URL архіву", "opt_std": "Стандартний (параметри utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Джерело EPG", "opt_ottp": "База даних ottp.eu.org (рекомендовано)", "opt_api": "Власний URL API провайдера", "lbl_epg_url": "Шаблон URL API EPG", "lbl_xtream_type": "Тип Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Ім'я користувача Xtream", "lbl_xtream_password": "Пароль Xtream", "lbl_xtream_token": "Токен Xtream", "lbl_xtream_output": "Вихід потоку", "opt_xt_m3u8": "HLS / m3u8 (Рекомендовано)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегія букетів", "opt_xts_same": "Як у провайдера", "opt_xts_folder": "Все в одну теку", "opt_ord_user_xt": "Користувацький (для відсортованих каналів/букетів)", "lbl_xt_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top_xt": "Нові канали зверху", "opt_upd_bot_xt": "Нові канали знизу", "lbl_xtream_show_live": "Створювати букети Прямого ефіру", "opt_xtlive_yes": "Так", "opt_xtlive_no": "Ні", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Створювати букети VOD", "opt_xtvod_yes": "Так", "opt_xtvod_no": "Ні", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Створювати букети Серіалів", "opt_xtser_yes": "Так", "opt_xtser_no": "Ні", "lbl_xtream_series_type": "Тип серій", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Завантажити пікони", "opt_xtp_off": "Вимк", "opt_xtp_dn": "За назвою", "opt_xtp_ref": "За номером посилання", "lbl_xtream_picon_folder": "З папкою", "opt_xtp_folder_on": "Увім", "opt_xtp_folder_off": "Вимк", "lbl_xtream_picon_symlink": "Створити симлінк", "opt_xtp_sym_off": "Вимк", "opt_xtp_sym_on": "Увім", "opt_markers_off_xt": "Вимк", "opt_markers_on_xt": "Увім", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Увім", "opt_xt_cepg_off": "Вимк", "lbl_xtream_clean": "Очистити букети", "opt_xclean_no": "Ні", "opt_xclean_yes": "Так", "lbl_bouquets": "Букети", "lbl_ch_title": "Канали"};
  var _FR={"lbl_name": "Nom du fournisseur", "lbl_xmltv": "URL XMLTV / Fichier local", "lbl_m3u": "URL M3U / Liste de lecture M3U", "lbl_days": "Jours d'archive (1-7)", "lbl_ttl_section": "Jours TTL pour les fichiers en cache (entrez le nombre de jours d'archive disponibles)", "lbl_ttl_days": "  Jours TTL (1-7)", "lbl_hostname": "Filtre de nom d'hôte de flux (pour le décalage horaire)", "lbl_player_override": "Remplacement du lecteur (spécifique au fournisseur)", "lbl_enabled": "Activé", "opt_yes": "Oui", "opt_no": "Non", "lbl_epg_parse": "Créer un fichier EPG", "opt_epg_off": "Désactivé", "opt_epg_dn": "Par nom affiché", "opt_epg_tvg": "Par tvg-id", "lbl_strategy": "Stratégie de création de bouquet", "opt_same": "Comme dans la liste de lecture", "opt_all": "Bouquet pour toutes les chaînes", "opt_allg": "Bouquets pour toutes les chaînes et tous les groupes", "opt_psub": "Bouquet avec nom de fournisseur et sous-bouquets", "lbl_playback": "Lire avec", "lbl_order": "Ordre des chaînes par", "opt_ord_prov": "Utiliser l'ordre du fournisseur", "opt_ord_alpha": "Alphabétiquement", "opt_ord_user": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top": "Nouvelles chaînes en haut", "opt_upd_bot": "Nouvelles chaînes en bas", "lbl_picon": "Télécharger les Picons", "opt_picon_off": "Désactivé", "opt_picon_on": "On", "lbl_pic_naming": "Nommage", "opt_pic_dn": "Avec nom affiché", "opt_pic_ref": "Avec numéro de référence", "lbl_pic_folder": "Avec dossier du fournisseur", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Désactivé", "lbl_pic_symlink": "Créer un lien symbolique", "opt_pic_sym_off": "Désactivé", "opt_pic_sym_on": "On", "lbl_custom_epg": "Fichier EPG personnalisé", "opt_cepg_on": "On", "opt_cepg_off": "Désactivé", "lbl_clean_bouquets": "Nettoyer les bouquets", "opt_clean_off": "Désactivé", "opt_clean_on": "On", "lbl_create_archives": "Créer des archives du fournisseur", "opt_arch_off": "Désactivé", "opt_arch_on": "On", "opt_markers_off": "Désactivé", "opt_markers_on": "On", "lbl_archive_days": "Jours d'archive (1-7)", "lbl_cache_ttl_custom": "TTL personnalisé", "opt_ttl_on": "On", "lbl_time_offset_abs": "Décalage (sec)", "lbl_stream_hostname": "Filtre de nom d'hôte depuis l'URL du flux", "opt_plr_off": "Désactivé", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Désactivé", "opt_sl_off": "Désactivé", "opt_sl_on": "On", "opt_rec_off": "Désactivé", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Effacer le cache lors de l'enregistrement", "opt_ccs_off": "Désactivé", "opt_ccs_on": "On", "lbl_frag": "Fragment d'URL", "lbl_arch": "Modèle d'URL d'archive", "opt_std": "Standard (paramètres utc/lutc)", "lbl_epg": "Source EPG", "opt_ottp": "Base de données ottp.eu.org (recommandée)", "opt_api": "URL API propre du fournisseur", "lbl_epg_url": "Modèle d'URL API EPG", "lbl_xtream_type": "Type Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nom d'utilisateur Xtream", "lbl_xtream_password": "Mot de passe Xtream", "lbl_xtream_token": "Jeton Xtream", "lbl_xtream_output": "Format de sortie du flux", "opt_xt_m3u8": "HLS / m3u8 (Recommandé)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Stratégie de bouquet", "opt_xts_same": "Comme le fournisseur", "opt_ord_user_xt": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_xt_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top_xt": "Nouvelles chaînes en haut", "opt_upd_bot_xt": "Nouvelles chaînes en bas", "lbl_xtream_show_live": "Créer des bouquets TV en direct", "opt_xtlive_yes": "Oui", "opt_xtlive_no": "Non", "lbl_xtream_show_vod": "Créer des bouquets VOD", "opt_xtvod_yes": "Oui", "opt_xtvod_no": "Non", "lbl_xtream_show_series": "Créer des bouquets de séries", "opt_xtser_yes": "Oui", "opt_xtser_no": "Non", "lbl_xtream_picon": "Télécharger les Picons", "opt_xtp_off": "Désactivé", "opt_xtp_dn": "Avec nom affiché", "opt_xtp_ref": "Avec numéro de référence", "lbl_xtream_picon_folder": "Avec dossier du fournisseur", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Désactivé", "lbl_xtream_picon_symlink": "Créer un lien symbolique", "opt_xtp_sym_off": "Désactivé", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Désactivé", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Fichier EPG personnalisé", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Désactivé", "lbl_xtream_clean": "Nettoyer les bouquets", "opt_xclean_no": "Non", "opt_xclean_yes": "Oui", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Chaînes"};
  var _ES={"lbl_name": "Nombre del proveedor", "lbl_xmltv": "URL XMLTV / Archivo local", "lbl_m3u": "URL M3U / Lista de reproducción M3U", "lbl_days": "Días de archivo (1-7)", "lbl_ttl_section": "Días TTL para archivos en caché (ingrese el número de días de archivo disponibles)", "lbl_ttl_days": "  Días TTL (1-7)", "lbl_hostname": "Filtro de nombre de host de transmisión (para desplazamiento de tiempo)", "lbl_player_override": "Anulación de reproductor (específico del proveedor)", "lbl_enabled": "Habilitado", "opt_yes": "Sí", "opt_no": "No", "lbl_epg_parse": "Crear archivo EPG", "opt_epg_off": "Apagado", "opt_epg_dn": "Por nombre mostrado", "opt_epg_tvg": "Por tvg-id", "lbl_strategy": "Estrategia de creación de bouquet", "opt_same": "Igual que en la lista de reproducción", "opt_all": "Bouquet para todos los canales", "opt_allg": "Bouquets para todos los canales y grupos", "opt_psub": "Bouquet con nombre de proveedor y sub-bouquets", "lbl_playback": "Reproducir con", "lbl_order": "Orden de canales por", "opt_ord_prov": "Usar orden del proveedor", "opt_ord_alpha": "Alfabéticamente", "opt_ord_user": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top": "Nuevos canales arriba", "opt_upd_bot": "Nuevos canales abajo", "lbl_picon": "Descargar Picons", "opt_picon_off": "Apagado", "opt_picon_on": "On", "lbl_pic_naming": "Denominación", "opt_pic_dn": "Con nombre mostrado", "opt_pic_ref": "Con número de referencia", "lbl_pic_folder": "Con carpeta de proveedor", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Apagado", "lbl_pic_symlink": "Crear enlace simbólico", "opt_pic_sym_off": "Apagado", "opt_pic_sym_on": "On", "lbl_custom_epg": "Archivo EPG personalizado", "opt_cepg_on": "On", "opt_cepg_off": "Apagado", "lbl_clean_bouquets": "Limpiar bouquets", "opt_clean_off": "Apagado", "opt_clean_on": "On", "lbl_create_archives": "Crear archivos del proveedor", "opt_arch_off": "Apagado", "opt_arch_on": "On", "opt_markers_off": "Apagado", "opt_markers_on": "On", "lbl_archive_days": "Días de archivo (1-7)", "lbl_cache_ttl_custom": "TTL personalizado", "opt_ttl_on": "On", "lbl_time_offset_abs": "Desplazamiento (seg)", "lbl_stream_hostname": "Filtro de nombre de host desde URL de transmisión", "opt_plr_off": "Apagado", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Apagado", "opt_sl_off": "Apagado", "opt_sl_on": "On", "opt_rec_off": "Apagado", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Limpiar caché al guardar", "opt_ccs_off": "Apagado", "opt_ccs_on": "On", "lbl_frag": "Fragmento de URL", "lbl_arch": "Patrón de URL de archivo", "opt_std": "Estándar (parámetros utc/lutc)", "lbl_epg": "Fuente EPG", "opt_ottp": "Base de datos ottp.eu.org (recomendada)", "opt_api": "URL API propia del proveedor", "lbl_epg_url": "Plantilla de URL de API EPG", "lbl_xtream_type": "Tipo Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nombre de usuario Xtream", "lbl_xtream_password": "Contraseña Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Formato de salida de transmisión", "opt_xt_m3u8": "HLS / m3u8 (Recomendado)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Estrategia de bouquet", "opt_xts_same": "Igual que el proveedor", "opt_ord_user_xt": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_xt_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top_xt": "Nuevos canales arriba", "opt_upd_bot_xt": "Nuevos canales abajo", "lbl_xtream_show_live": "Crear bouquets de TV en vivo", "opt_xtlive_yes": "Sí", "opt_xtlive_no": "No", "lbl_xtream_show_vod": "Crear bouquets de VOD", "opt_xtvod_yes": "Sí", "opt_xtvod_no": "No", "lbl_xtream_show_series": "Crear bouquets de series", "opt_xtser_yes": "Sí", "opt_xtser_no": "No", "lbl_xtream_picon": "Descargar Picons", "opt_xtp_off": "Apagado", "opt_xtp_dn": "Con nombre mostrado", "opt_xtp_ref": "Con número de referencia", "lbl_xtream_picon_folder": "Con carpeta de proveedor", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Apagado", "lbl_xtream_picon_symlink": "Crear enlace simbólico", "opt_xtp_sym_off": "Apagado", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Apagado", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Archivo EPG personalizado", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Apagado", "lbl_xtream_clean": "Limpiar bouquets", "opt_xclean_no": "No", "opt_xclean_yes": "Sí", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Canales"};
  var _TR={"lbl_name": "Sağlayıcı Adı", "lbl_xmltv": "XMLTV URL'si / Yerel Dosya", "lbl_m3u": "M3U URL'si / M3U Oynatma Listesi", "lbl_days": "Arşiv Günleri (1-7)", "lbl_ttl_section": "Önbellek Dosyaları için TTL Günleri (Mevcut Arşiv Günleri Sayısını Girin)", "lbl_ttl_days": "  TTL Günleri (1-7)", "lbl_hostname": "Akış Hostname Filtresi (Zaman Ofseti İçin)", "lbl_player_override": "Oynatıcı Geçersiz Kılma (Sağlayıcıya Özel)", "lbl_enabled": "Etkin", "opt_yes": "Evet", "opt_no": "Hayır", "lbl_epg_parse": "EPG Dosyası Oluştur", "opt_epg_off": "Kapalı", "opt_epg_dn": "Görünen Ada göre", "opt_epg_tvg": "tvg-id'ye göre", "lbl_strategy": "Buket Oluşturma Stratejisi", "opt_same": "Oynatma Listesindeki Gibi", "opt_all": "Tüm Kanallar için Buket", "opt_allg": "Tüm Kanallar ve Gruplar için Buketler", "opt_psub": "Sağlayıcı Adı ve Alt Buketler ile Buket", "lbl_playback": "İle Oynat", "lbl_order": "Kanalları Sıralama", "opt_ord_prov": "Sağlayıcı Sırasını Kullan", "opt_ord_alpha": "Alfabetik", "opt_ord_user": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top": "Yeni Kanallar Üstte", "opt_upd_bot": "Yeni Kanallar Altta", "lbl_picon": "Pikonları İndir", "opt_picon_off": "Kapalı", "opt_picon_on": "Açık", "lbl_pic_naming": "Adlandırma", "opt_pic_dn": "Görünen Ad ile", "opt_pic_ref": "Referans Numarası ile", "lbl_pic_folder": "Sağlayıcı Klasörü ile", "opt_pic_folder_on": "Açık", "opt_pic_folder_off": "Kapalı", "lbl_pic_symlink": "Sembolik Bağlantı Oluştur", "opt_pic_sym_off": "Kapalı", "opt_pic_sym_on": "Açık", "lbl_custom_epg": "Özel EPG Dosyası", "opt_cepg_on": "Açık", "opt_cepg_off": "Kapalı", "lbl_clean_bouquets": "Buketleri Temizle", "opt_clean_off": "Kapalı", "opt_clean_on": "Açık", "lbl_create_archives": "Sağlayıcı Arşivleri Oluştur", "opt_arch_off": "Kapalı", "opt_arch_on": "Açık", "opt_markers_off": "Kapalı", "opt_markers_on": "Açık", "lbl_archive_days": "Arşiv Günleri (1-7)", "lbl_cache_ttl_custom": "Özel TTL", "opt_ttl_on": "Açık", "lbl_time_offset_abs": "Ofset (sn)", "lbl_stream_hostname": "Akış URL'sinden Hostname Filtresi", "opt_plr_off": "Kapalı", "opt_plr_on": "Açık", "opt_int_on": "Açık", "opt_int_off": "Kapalı", "opt_sl_off": "Kapalı", "opt_sl_on": "Açık", "opt_rec_off": "Kapalı", "opt_rec_on": "Açık", "lbl_clear_cache_on_save": "Kaydetmede Önbelleği Temizle", "opt_ccs_off": "Kapalı", "opt_ccs_on": "Açık", "lbl_frag": "URL Parçası", "lbl_arch": "Arşiv URL Deseni", "opt_std": "Standart (utc/lutc parametreleri)", "lbl_epg": "EPG Kaynağı", "opt_ottp": "ottp.eu.org veritabanı (önerilir)", "opt_api": "Sağlayıcının kendi API URL'si", "lbl_epg_url": "EPG API URL Şablonu", "lbl_xtream_type": "Xtream Türü", "lbl_xtream_url": "Xtream URL'si", "lbl_xtream_username": "Xtream Kullanıcı Adı", "lbl_xtream_password": "Xtream Parola", "lbl_xtream_token": "Xtream Simgesi", "lbl_xtream_output": "Akış Çıktısı", "opt_xt_m3u8": "HLS / m3u8 (Önerilir)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Buket Stratejisi", "opt_xts_same": "Sağlayıcı ile Aynı", "opt_ord_user_xt": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_xt_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top_xt": "Yeni Kanallar Üstte", "opt_upd_bot_xt": "Yeni Kanallar Altta", "lbl_xtream_show_live": "Canlı TV Buketleri Oluştur", "opt_xtlive_yes": "Evet", "opt_xtlive_no": "Hayır", "lbl_xtream_show_vod": "VOD Buketleri Oluştur", "opt_xtvod_yes": "Evet", "opt_xtvod_no": "Hayır", "lbl_xtream_show_series": "Dizi Buketleri Oluştur", "opt_xtser_yes": "Evet", "opt_xtser_no": "Hayır", "lbl_xtream_picon": "Pikonları İndir", "opt_xtp_off": "Kapalı", "opt_xtp_dn": "Görünen Ad ile", "opt_xtp_ref": "Referans Numarası ile", "lbl_xtream_picon_folder": "Sağlayıcı Klasörü ile", "opt_xtp_folder_on": "Açık", "opt_xtp_folder_off": "Kapalı", "lbl_xtream_picon_symlink": "Sembolik Bağlantı Oluştur", "opt_xtp_sym_off": "Kapalı", "opt_xtp_sym_on": "Açık", "opt_markers_off_xt": "Kapalı", "opt_markers_on_xt": "Açık", "lbl_xt_custom_epg": "Özel EPG Dosyası", "opt_xt_cepg_on": "Açık", "opt_xt_cepg_off": "Kapalı", "lbl_xtream_clean": "Buketleri Temizle", "opt_xclean_no": "Hayır", "opt_xclean_yes": "Evet", "lbl_bouquets": "Buketler", "lbl_ch_title": "Kanallar"};
  var _T={'DE':_DE,'FR':_FR,'ES':_ES,'IT':_IT,'PL':_PL,'RU':_RU,'TR':_TR,'UK':_UK};
  var _LM={'DEU':'DE','GER':'DE','FRA':'FR','FRE':'FR','ESP':'ES','ITA':'IT','POL':'PL','RUS':'RU','TUR':'TR','UKR':'UK'};
  function _applyLang(){
    if(!L)return;
    for(var id in L){
      if(!L.hasOwnProperty(id))continue;
      var el=document.getElementById(id);
      if(el&&L[id])el.textContent=L[id];
    }
  }


function _t(id, html) {
  var el = document.getElementById(id);
  if (el) { if (html) el.innerHTML = html; }
}
function _txt(id, txt) {
  var el = document.getElementById(id);
  if (el) el.textContent = txt;
}

window.addEventListener('DOMContentLoaded', function() {
  /* Apply Russian labels if language is RUS */
  if (_IS_RU) {
    var r = _RU_WEB;
    document.querySelector('h1').innerHTML = r['add_title'];
    document.querySelector('.sub').textContent = r['sub_add'];
    _txt('lbl_name',    r['lbl_name']);
    _txt('lbl_xmltv',   r['lbl_xmltv']);
    _txt('lbl_m3u',     r['lbl_m3u']);
    _txt('lbl_days',       r['lbl_days']);
    _txt('lbl_ttl_section',r['lbl_ttl_section']);
    _txt('lbl_ttl_custom', r['lbl_ttl_custom']);
    _txt('lbl_ttl_days',   r['lbl_ttl_days']);
    _txt('hint_ttl',       r['hint_ttl']);
    _txt('lbl_sign',    r['lbl_sign']);
    _txt('lbl_abs',      r['lbl_abs']);
    _txt('lbl_hostname',       r['lbl_hostname']);
    _txt('hint_hostname',      r['hint_hostname']);
    _txt('lbl_player_section', r['lbl_player_section']);
    _txt('lbl_player_hint',    r['lbl_player_hint']);
    _txt('lbl_player_override',r['lbl_player_override']);
    _txt('lbl_player_int',     r['lbl_player_int']);
    _txt('lbl_player_sl',      r['lbl_player_sl']);
    _txt('lbl_player_rec',     r['lbl_player_rec']);
    _txt('lbl_enabled',        r['lbl_enabled']);
    _txt('opt_plus',    r['opt_plus']);
    _txt('opt_minus',   r['opt_minus']);
    _txt('opt_yes',     r['opt_yes']);
    _txt('opt_no',      r['opt_no']);
    _txt('hint_xmltv',  r['hint_xmltv']);
    _txt('hint_offset', r['hint_offset']);
    _txt('btn_browse_xmltv', r['btn_browse']);
    _txt('btn_browse_m3u',   r['btn_browse']);
    document.getElementById('btn_send').innerHTML = '&#10148;\u00a0 ' + '\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a';
    document.getElementById('ok_msg').innerHTML = r['ok_msg'];
  }

  if (!PREFILL) return;
  ['name','xmltv_url','m3u_source','days','enabled',
   'time_offset_sign','time_offset_abs','stream_hostname','cache_ttl_days'].forEach(function(k) {
    var el = document.getElementById(k);
    if (el && PREFILL[k] !== undefined && PREFILL[k] !== null) el.value = PREFILL[k];
  });
  ['player_override','player_int_on','player_sl_on','player_rec_on','cache_ttl_custom'].forEach(function(k) {
    var el = document.getElementById(k);
    if (el && PREFILL[k] !== undefined)
      el.checked = (PREFILL[k] === '1' || PREFILL[k] === 1 || PREFILL[k] === true);
  });
  if (PREFILL._is_edit) {
    if (_IS_RU) {
      document.querySelector('h1').innerHTML = _RU_WEB['edit_title'];
      document.querySelector('.sub').textContent = _RU_WEB['sub_edit'];
    } else {
      document.querySelector('h1').innerHTML = '&#9998;&nbsp;Edit Provider';
      document.querySelector('.sub').textContent =
        'CustomIPTVArchiveMakerPro \u2014 change what you need and press Send';
    }
  }
  _applyLang();
});

/* ---- Browse + upload M3U file ---- */
function browseM3U() {
  document.getElementById('m3u_file').click();
}

/* ---- Browse + upload XMLTV file ---- */
function browseXMLTV() {
  document.getElementById('xmltv_file').click();
}

/* ---- Generic upload helper (used by both XMLTV and M3U) ---- */
function _doUpload(file, statusId, targetInputId, extraHeaders) {
  var status = document.getElementById(statusId);
  status.className = 'upload-status uploading';
  status.textContent = _IS_RU
    ? ('\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u00ab' + file.name + '\u00bb \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u2026')
    : ('Uploading \u201c' + file.name + '\u201d to receiver\u2026');
  var reader = new FileReader();
  reader.onload = function(e) {
    var safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    var hdrs = {
      'Content-Type': 'application/octet-stream',
      'X-Filename': encodeURIComponent(safeName),
      'X-ProviderName': encodeURIComponent(document.getElementById('name').value || '')
    };
    if (extraHeaders) { Object.assign(hdrs, extraHeaders); }
    fetch('/upload', {
      method: 'POST',
      headers: hdrs,
      body: e.target.result
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.path) {
        document.getElementById(targetInputId).value = data.path;
        status.className = 'upload-status done';
        status.textContent = _IS_RU
          ? ('\u2713 \u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u043e \u2014 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435: ' + data.path)
          : ('\u2713 Uploaded \u2014 saved on receiver as: ' + data.path);
      } else {
        throw new Error(data.error || (_IS_RU ? '\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f \u043e\u0448\u0438\u0431\u043a\u0430' : 'unknown error'));
      }
    })
    .catch(function(err) {
      status.className = 'upload-status err';
      status.textContent = _IS_RU
        ? ('\u2717 \u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438: ' + err.message)
        : ('\u2717 Upload failed: ' + err.message);
    });
  };
  reader.onerror = function() {
    status.className = 'upload-status err';
    status.textContent = _IS_RU
      ? '\u2717 \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u0444\u0430\u0439\u043b.'
      : '\u2717 Could not read the file.';
  };
  reader.readAsArrayBuffer(file);
}

document.getElementById('xmltv_file').addEventListener('change', function() {
  var file = this.files[0];
  if (!file) return;
  _doUpload(file, 'xmltv_status', 'xmltv_url', {'X-FileType': 'epg'});
  this.value = '';
});

document.getElementById('m3u_file').addEventListener('change', function() {
  var file = this.files[0];
  if (!file) return;
  _doUpload(file, 'upload_status', 'm3u_source');
  /* reset so the same file can be re-selected */
  this.value = '';
});

/* ---- Send form to receiver ---- */
function sendData() {
  var fields = ['name','xmltv_url','m3u_source','days','enabled',
                'time_offset_sign','time_offset_abs','stream_hostname','cache_ttl_days'];
  var parts = fields.map(function(k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(document.getElementById(k).value);
  });
  ['player_override','player_int_on','player_sl_on','player_rec_on','cache_ttl_custom'].forEach(function(k) {
    var el = document.getElementById(k);
    parts.push(encodeURIComponent(k) + '=' + (el && el.checked ? '1' : '0'));
  });
  fetch('/', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: parts.join('&')
  }).then(function(r) {
    if (r.ok) {
      document.getElementById('f').style.display = 'none';
      document.getElementById('ok').style.display = 'block';
    } else {
      alert(_IS_RU ? '\u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.' : 'Error sending data. Please try again.');
    }
  }).catch(function() {
    alert(_IS_RU ? '\u041d\u0435 \u0443\u0434\u0430\u0451\u0442\u0441\u044f \u0441\u0432\u044f\u0437\u0430\u0442\u044c\u0441\u044f \u0441 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u043e\u043c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u0435\u0442\u044c.' : 'Could not reach receiver. Check that you are on the same network.');
  });
}
</script>
</body>
</html>"""

# ---------------------------------------------------------------------------
# HTML form for Playlist Provider (IPTV Playlist Creator)
# ---------------------------------------------------------------------------

_HTML_PLAYLIST = u"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>IPTV Playlist Provider</title>
<link rel="icon" href="data:,">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#12121f;color:#dde1f0;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{background:#1a1f38;border-radius:16px;padding:36px 40px;width:100%;
      max-width:620px;box-shadow:0 12px 48px rgba(0,0,0,.7)}
h1{font-size:22px;color:#e94560;text-align:center;letter-spacing:1px;margin-bottom:4px}
.sub{text-align:center;color:#6b7599;font-size:13px;margin-bottom:28px}
label{display:block;font-size:15px;color:#f0c040;font-weight:600;
      margin-top:18px;margin-bottom:5px}
input[type=text],select{
  width:100%;padding:10px 14px;background:#0d1530;
  border:1.5px solid #1e3560;border-radius:8px;
  color:#dde1f0;font-size:15px;outline:none;transition:border .2s}
input[type=text]:focus,select:focus{border-color:#e94560}
select option{background:#0d1530}
.hint{font-size:12px;color:#4a5578;margin-top:4px}
#update_mode_section label,#picon_sub_section label,#archives_sub_section label{color:#2ecc71}
.m3u-row{display:flex;gap:8px;align-items:stretch}
.m3u-row input{flex:1;min-width:0}
.browse-btn{
  padding:0 16px;background:#0f3460;color:#8fa0c8;
  border:1.5px solid #1e3560;border-radius:8px;
  font-size:13px;font-weight:600;white-space:nowrap;
  cursor:pointer;transition:background .2s,color .2s,border-color .2s;
  display:flex;align-items:center;gap:6px}
.browse-btn:hover{background:#1a4a80;color:#dde1f0;border-color:#e94560}
.browse-btn svg{flex-shrink:0}
input[type=file]{display:none}
.upload-status{font-size:12px;color:#4a5578;margin-top:5px;min-height:16px;transition:color .3s}
.upload-status.uploading{color:#f0c040}
.upload-status.done{color:#2ecc71}
.upload-status.err{color:#e94560}
.btn{margin-top:30px;width:100%;padding:14px;background:#e94560;color:#fff;
     border:none;border-radius:10px;font-size:17px;font-weight:bold;
     cursor:pointer;letter-spacing:.5px;transition:background .2s}
.btn:hover{background:#c73652}
.ok{display:none;background:#152b1e;border:1.5px solid #2ecc71;color:#2ecc71;
    border-radius:10px;padding:18px;text-align:center;margin-top:20px;font-size:16px}
</style>
</head>
<body>
<div class="card">
  <h1 id="h_title">&#9654; Add IPTV Playlist/Archives Provider</h1>
  <p class="sub" id="h_sub">IPTV Playlist Creator &mdash; fill in the fields and press Send</p>

  <form id="f">
    <label for="name" id="lbl_name">Provider Name</label>
    <input type="text" id="name" name="name" placeholder="My IPTV Playlist Provider">

    <label for="m3u_source" id="lbl_m3u">M3U URL / M3U Playlist</label>
    <div class="m3u-row">
      <input type="text" id="m3u_source" name="m3u_source"
             placeholder="http://server/playlist.m3u8  or  /media/hdd/playlist.m3u">
      <button class="browse-btn" type="button" onclick="browseM3U()"
              title="Browse for a local M3U file on your PC and upload it to the receiver">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
        </svg>
        <span id="btn_browse_m3u">Browse&hellip;</span>
      </button>
      <input type="file" id="m3u_file" accept=".m3u,.m3u8,.txt">
    </div>
    <div class="upload-status" id="upload_status"></div>

    <label for="xmltv_url" id="lbl_xmltv">XMLTV URL / Local File</label>
    <div class="m3u-row">
      <input type="text" id="xmltv_url" name="xmltv_url"
             placeholder="http://server/epg.xml  or  /media/hdd/epg.xml  (optional)">
      <button class="browse-btn" type="button" onclick="browseXMLTV()"
              title="Browse for a local XMLTV file on your PC and upload it to the receiver">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
        </svg>
        <span id="btn_browse_xmltv">Browse&hellip;</span>
      </button>
      <input type="file" id="xmltv_file" accept=".xml,.xml.gz,.gz,.xmltv">
    </div>
    <div class="upload-status" id="xmltv_status"></div>
    <div class="hint" id="hint_xmltv">Leave blank if you have no separate EPG feed</div>

    <label for="epg_parse_type" id="lbl_epg_parse">Create EPG File</label>
    <select id="epg_parse_type" name="epg_parse_type">
      <option value="off"          id="opt_epg_off">Off</option>
      <option value="display_name" id="opt_epg_dn">By Display Name</option>
      <option value="tvg_id"       id="opt_epg_tvg">By tvg-id</option>
    </select>
    <div class="hint" id="hint_epg_parse">Creates /etc/epgimport/CustomIPTV/ files for use with EPGImport plugin</div>

    <label for="bouquet_strategy" id="lbl_strategy">Bouquet Creation Strategy</label>
    <select id="bouquet_strategy" name="bouquet_strategy">
      <option value="same_playlist"  id="opt_same">Same in Playlist</option>
      <option value="all_channels"   id="opt_all">Bouquet for All Channels</option>
      <option value="all_and_groups" id="opt_allg">Bouquets for All Channels and Groups</option>
      <option value="parent_sub"     id="opt_psub">Bouquet with Provider Name and Sub-Bouquets</option>
    </select>

    <label for="playback_with" id="lbl_playback">Playback With</label>
    <select id="playback_with" name="playback_with">
      <option value="gstplayer"   id="opt_gst">GStreamer Player</option>
      <option value="gst_player"  id="opt_gstp">GstPlayer</option>
      <option value="exteplayer3" id="opt_ext">ExtEplayer3</option>
      <option value="dvb"         id="opt_dvb">DVB</option>
    </select>

    <label for="channel_order" id="lbl_order">Channels Ordering By</label>
    <select id="channel_order" name="channel_order" onchange="toggleUpdateMode()">
      <option value="provider"     id="opt_ord_prov">Use Provider Order</option>
      <option value="alphabetical" id="opt_ord_alpha">Alphabetically</option>
      <option value="user_defined" id="opt_ord_user">User Defined (Use for Sorted Channels/Bouquets)</option>
    </select>

    <div id="update_mode_section" style="display:none; border-left: 3px solid #2ecc71; padding-left: 12px; margin-left: 8px;">
      <label for="update_mode_sub" id="lbl_update_mode">Update M3U Playlist Only</label>
      <select id="update_mode_sub" name="update_mode_sub">
        <option value="top"    id="opt_upd_top">New Channels on Top</option>
        <option value="bottom" id="opt_upd_bot">New Channels on Bottom</option>
      </select>
    </div>

    <label for="picon_enabled" id="lbl_picon">Download Picons</label>
    <select id="picon_enabled" name="picon_enabled" onchange="togglePiconSection()">
      <option value="0" id="opt_picon_off">Off</option>
      <option value="1" id="opt_picon_on">On</option>
    </select>
    <div id="picon_sub_section" style="display:none; border-left: 3px solid #2ecc71; padding-left: 12px; margin-left: 8px;">
      <label for="picon_naming" id="lbl_pic_naming">Naming</label>
      <select id="picon_naming" name="picon_naming">
        <option value="display_name" id="opt_pic_dn">With Display Name</option>
        <option value="reference"    id="opt_pic_ref">With Reference Number</option>
      </select>
      <label for="picon_with_folder" id="lbl_pic_folder">With Folder</label>
      <select id="picon_with_folder" name="picon_with_folder">
        <option value="1" id="opt_pic_folder_on">On</option>
        <option value="0" id="opt_pic_folder_off">Off</option>
      </select>
      <label for="picon_symlink" id="lbl_pic_symlink">Create Symlink</label>
      <select id="picon_symlink" name="picon_symlink">
        <option value="0" id="opt_pic_sym_off">Off</option>
        <option value="1" id="opt_pic_sym_on">On</option>
      </select>
      <p id="lbl_pic_mount_note" style="font-size:0.85em;opacity:0.7;margin:4px 0 0 0">
        &#8505; Mount point is configured on the receiver
      </p>
    </div>

    <label for="custom_epg_enabled" id="lbl_custom_epg">Custom EPG File</label>
    <select id="custom_epg_enabled" name="custom_epg_enabled">
      <option value="1" id="opt_cepg_on">On</option>
      <option value="0" id="opt_cepg_off">Off</option>
    </select>

    <label for="clean_bouquets" id="lbl_clean_bouquets">Clean Bouquets</label>
    <select id="clean_bouquets" name="clean_bouquets">
      <option value="0" id="opt_clean_off">Off</option>
      <option value="1" id="opt_clean_on">On</option>
    </select>

    <label for="create_archives" id="lbl_create_archives">Create Provider Archives</label>
    <select id="create_archives" name="create_archives" onchange="toggleArchivesSection()">
      <option value="0" id="opt_arch_off">Off</option>
      <option value="1" id="opt_arch_on">On</option>
    </select>
    <div id="archives_sub_section" style="display:none; border-left: 3px solid #2ecc71; padding-left: 12px; margin-left: 8px;">
      <label for="create_archive_markers" id="lbl_create_archive_markers">Create Archive Markers ( ▶ )</label>
      <select id="create_archive_markers" name="create_archive_markers">
        <option value="0" id="opt_markers_off">Off</option>
        <option value="1" id="opt_markers_on">On</option>
      </select>

      <label for="archive_days" id="lbl_archive_days">Archive Days (1&ndash;7)</label>
      <input type="text" id="archive_days" name="archive_days" placeholder="7">

      <label for="cache_ttl_custom" id="lbl_cache_ttl_custom">Custom TTL</label>
      <select id="cache_ttl_custom" name="cache_ttl_custom" onchange="toggleTTLDays()">
        <option value="0" id="opt_ttl_off">Off (Default 7 days)</option>
        <option value="1" id="opt_ttl_on">On</option>
      </select>
      <div id="ttl_days_section" style="display:none">
        <label for="cache_ttl_days" id="lbl_cache_ttl_days">TTL Days (1&ndash;30)</label>
        <input type="text" id="cache_ttl_days" name="cache_ttl_days" placeholder="7">
      </div>

      <label id="lbl_offset_section" style="color:#aaa;font-size:12px">&#9654; Archive Start Offset (+/- sec)</label>
      <label for="time_offset_sign" id="lbl_time_offset_sign">Offset +/-</label>
      <select id="time_offset_sign" name="time_offset_sign">
        <option value="+" id="opt_off_plus">+</option>
        <option value="-" id="opt_off_minus">-</option>
      </select>

      <label for="time_offset_abs" id="lbl_time_offset_abs">Offset (sec)</label>
      <input type="text" id="time_offset_abs" name="time_offset_abs" placeholder="0">

      <label for="stream_hostname" id="lbl_stream_hostname">Hostname Filter From Stream URL</label>
      <input type="text" id="stream_hostname" name="stream_hostname" placeholder="">

      <label for="player_override" id="lbl_player_override">Player Override (Provider-Specific)</label>
      <select id="player_override" name="player_override" onchange="togglePlayerSection()">
        <option value="0" id="opt_plr_off">Off</option>
        <option value="1" id="opt_plr_on">On</option>
      </select>
      <div id="player_sub_section" style="display:none">
        <label for="player_int_on" id="lbl_player_int">Player: Integrated</label>
        <select id="player_int_on" name="player_int_on">
          <option value="1" id="opt_int_on">On</option>
          <option value="0" id="opt_int_off">Off</option>
        </select>
        <label for="player_sl_on" id="lbl_player_sl">Player: StreamLink</label>
        <select id="player_sl_on" name="player_sl_on">
          <option value="0" id="opt_sl_off">Off</option>
          <option value="1" id="opt_sl_on">On</option>
        </select>
        <label for="player_rec_on" id="lbl_player_rec">Player: Receiver</label>
        <select id="player_rec_on" name="player_rec_on">
          <option value="0" id="opt_rec_off">Off</option>
          <option value="1" id="opt_rec_on">On</option>
        </select>
      </div>

      <label for="clear_cache_on_save" id="lbl_clear_cache_on_save">Clear Cache on Save</label>
      <select id="clear_cache_on_save" name="clear_cache_on_save">
        <option value="0" id="opt_ccs_off">Off</option>
        <option value="1" id="opt_ccs_on">On</option>
      </select>
    </div>

    <label for="enabled" id="lbl_enabled">Enabled</label>
    <select id="enabled" name="enabled">
      <option value="1" id="opt_yes">Yes</option>
      <option value="0" id="opt_no">No</option>
    </select>

    <button class="btn" type="button" onclick="sendData()" id="btn_send">
      &#10148;&nbsp; Send to Receiver
    </button>
  </form>

  <div class="ok" id="ok">
    <span id="ok_msg">&#10003;&nbsp; Data sent to your receiver!<br>
    The playlist provider fields have been filled in automatically.<br>
    You can close this tab and press <strong>Save</strong> on the receiver.</span>
  </div>
</div>

<script>
/* ---- Russian translations for the playlist web form ---- */
var _RU_PL = {
  'add_title':    '\u25ba\u00a0 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0430',
  'edit_title':   '\u270e\u00a0 \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0430',
  'sub_add':      'IPTV Playlist Creator \u2014 \u0437\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043f\u043e\u043b\u044f \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'sub_edit':     'IPTV Playlist Creator \u2014 \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u0435 \u043d\u0443\u0436\u043d\u043e\u0435 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'lbl_name':     '\u0418\u043c\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_m3u':      'M3U URL / M3U-\u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442',
  'lbl_xmltv':    'XMLTV URL / \u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0444\u0430\u0439\u043b',
  'hint_xmltv':   '\u041e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c, \u0435\u0441\u043b\u0438 \u043d\u0435\u0442 \u043e\u0442\u0434\u0435\u043b\u044c\u043d\u043e\u0433\u043e EPG',
  'lbl_epg_parse':'\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0444\u0430\u0439\u043b EPG',
  'hint_epg_parse':'\u0421\u043e\u0437\u0434\u0430\u0451\u0442 \u0444\u0430\u0439\u043b\u044b /etc/epgimport/CustomIPTV/ \u0434\u043b\u044f \u043f\u043b\u0430\u0433\u0438\u043d\u0430 EPGImport',
  'opt_epg_off':  '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_strategy': '\u0421\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u044f \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u044f \u0431\u0443\u043a\u0435\u0442\u0430',
  'opt_same':     '\u041a\u0430\u043a \u0432 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0435',
  'opt_all':      '\u0411\u0443\u043a\u0435\u0442 \u0434\u043b\u044f \u0432\u0441\u0435\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432',
  'opt_allg':     '\u0411\u0443\u043a\u0435\u0442\u044b \u0434\u043b\u044f \u0432\u0441\u0435\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432 \u0438 \u0433\u0440\u0443\u043f\u043f',
  'opt_psub':     '\u0411\u0443\u043a\u0435\u0442 \u0441 \u0438\u043c\u0435\u043d\u0435\u043c \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0438 \u0441\u0443\u0431\u0431\u0443\u043a\u0435\u0442\u044b',
  'opt_epg_tvg':  '\u041f\u043e tvg-id',
  'opt_epg_dn':   '\u041f\u043e \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u043c\u043e\u043c\u0443 \u0438\u043c\u0435\u043d\u0438',
  'lbl_playback': '\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u0447\u0435\u0440\u0435\u0437',
  'lbl_order':       '\u041f\u043e\u0440\u044f\u0434\u043e\u043a \u043a\u0430\u043d\u0430\u043b\u043e\u0432',
  'opt_ord_prov':    '\u041f\u043e\u0440\u044f\u0434\u043e\u043a \u0438\u0437 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_ord_alpha':   '\u041f\u043e \u0430\u043b\u0444\u0430\u0432\u0438\u0442\u0443',
  'opt_ord_user':    '\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 (\u0438\u0441\u043f. \u0434\u043b\u044f \u0441\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432/\u0431\u0443\u043a\u0435\u0442\u043e\u0432)',
  'lbl_update_mode': '\u0422\u043e\u043b\u044c\u043a\u043e \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u044c M3U \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442',
  'opt_upd_top':     '\u041d\u043e\u0432\u044b\u0435 \u043a\u0430\u043d\u0430\u043b\u044b \u0441\u0432\u0435\u0440\u0445\u0443',
  'opt_upd_bot':     '\u041d\u043e\u0432\u044b\u0435 \u043a\u0430\u043d\u0430\u043b\u044b \u0441\u043d\u0438\u0437\u0443',
  'lbl_picon':           '\u0421\u043a\u0430\u0447\u0430\u0442\u044c \u041f\u0438\u043a\u043e\u043d\u044b',
  'opt_picon_off':       '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_picon_on':        '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_pic_naming':      '\u0418\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435',
  'opt_pic_dn':          '\u0421 \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u043c\u044b\u043c \u0438\u043c\u0435\u043d\u0435\u043c',
  'opt_pic_ref':         '\u0421 \u043d\u043e\u043c\u0435\u0440\u043e\u043c \u0441\u0441\u044b\u043b\u043a\u0438',
  'lbl_pic_folder':      '\u0421 \u043f\u0430\u043f\u043a\u043e\u0439 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_pic_folder_on':   '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_pic_folder_off':  '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_pic_symlink':     '\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0441\u0438\u043c\u043b\u0438\u043d\u043a',
  'opt_pic_sym_off':     '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_pic_sym_on':      '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_pic_mount_note':  '\u2139 \u0422\u043e\u0447\u043a\u0430 \u043c\u043e\u043d\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435',
  'opt_gstp':            'GstPlayer',
  'opt_dvb':             'DVB',
  'lbl_enabled':  '\u0412\u043a\u043b\u044e\u0447\u0451\u043d',
  'opt_yes':      '\u0414\u0430',
  'opt_no':       '\u041d\u0435\u0442',
  'btn_browse':   '\u041e\u0431\u0437\u043e\u0440\u2026',
  'lbl_clean_bouquets':   '\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0431\u0443\u043a\u0435\u0442\u044b',
  'opt_clean_off':        '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_clean_on':         '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_create_archives':  '\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0430\u0440\u0445\u0438\u0432\u044b \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_arch_off':         '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_arch_on':          '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_create_archive_markers': '\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u043c\u0430\u0440\u043a\u0435\u0440\u044b \u0430\u0440\u0445\u0438\u0432\u0430',
  'opt_markers_off':      '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_markers_on':       '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_archive_days':     '\u0414\u043d\u0435\u0439 \u0430\u0440\u0445\u0438\u0432\u0430 (1\u20137)',
  'lbl_cache_ttl_custom': '\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 TTL',
  'opt_ttl_off':          '\u0412\u044b\u043a\u043b (7 \u0434\u043d\u0435\u0439 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e)',
  'opt_ttl_on':           '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_cache_ttl_days':   'TTL \u0434\u043d\u0435\u0439 (1\u201330)',
  'lbl_offset_section':   '&#9654; \u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043d\u0430\u0447\u0430\u043b\u0430 \u0430\u0440\u0445\u0438\u0432\u0430 (+/- \u0441\u0435\u043a)',
  'lbl_time_offset_sign': '\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 +/-',
  'lbl_time_offset_abs':  '\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 (\u0441\u0435\u043a)',
  'lbl_stream_hostname':  'Hostname \u0444\u0438\u043b\u044c\u0442\u0440 \u0438\u0437 URL \u043f\u043e\u0442\u043e\u043a\u0430',
  'lbl_player_override':  '\u041e\u0432\u0435\u0440\u0440\u0430\u0439\u0434 \u043f\u043b\u0435\u0435\u0440\u0430',
  'opt_plr_off':          '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_plr_on':           '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_player_int':       '\u041f\u043b\u0435\u0435\u0440: \u0432\u0441\u0442\u0440\u043e\u0435\u043d\u043d\u044b\u0439',
  'lbl_player_sl':        '\u041f\u043b\u0435\u0435\u0440: StreamLink',
  'lbl_player_rec':       '\u041f\u043b\u0435\u0435\u0440: \u0440\u0435\u0441\u0438\u0432\u0435\u0440',
  'lbl_clear_cache_on_save': '\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u043a\u0435\u0448 \u043f\u0440\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u0438',
  'opt_ccs_off':          '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_ccs_on':           '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'btn_send':     '&#10148;\u00a0 \u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a',
  'ok_msg':       '\u2713\u00a0 \u0414\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u044b \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a!<br>\u041f\u043e\u043b\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.<br>\u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u043a\u043b\u0430\u0434\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 <strong>\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</strong> \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435.'
};

var PREFILL = /*PREFILL_JSON*/null/*END_PREFILL*/;
var L = /*L_JSON*/{}/*END_L*/;
var _IS_RU = (PREFILL && PREFILL.ui_language === 'RUS');
  /* ---- Multi-language translations ---- */
  var _DE={"lbl_name": "Anbieter-Name", "lbl_xmltv": "XMLTV-URL / Lokale Datei", "lbl_m3u": "M3U-URL / M3U-Playlist", "lbl_days": "Archivtage (1-7)", "lbl_ttl_section": "TTL-Tage für gecachte Dateien (verfügbare Archivtage eingeben)", "lbl_ttl_custom": "Eigene TTL", "lbl_ttl_days": "  TTL-Tage (1-7)", "lbl_sign": "Versatz Vorzeichen", "opt_plus": "+  später", "opt_minus": "-  früher", "lbl_abs": "Versatz Sekunden", "lbl_hostname": "Stream-Hostname-Filter (für Zeitversatz)", "lbl_player_section": "Player-Auswahl", "lbl_player_hint": "Player-Einstellungen überschreiben.", "lbl_player_override": "Player-Überschreibung (anbieterspezifisch)", "lbl_player_int": "Player: Integriert", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Empfänger", "lbl_enabled": "Aktiviert", "opt_yes": "Ja", "opt_no": "Nein", "lbl_epg_parse": "EPG-Datei erstellen", "opt_epg_off": "Aus", "opt_epg_dn": "Nach Anzeigename", "opt_epg_tvg": "Nach tvg-id", "lbl_strategy": "Bouquet-Erstellungsstrategie", "opt_same": "Wie in Playlist", "opt_all": "Bouquet für alle Kanäle", "opt_allg": "Bouquets für alle Kanäle und Gruppen", "opt_psub": "Bouquet mit Anbieter-Name und Sub-Bouquets", "lbl_playback": "Wiedergabe mit", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kanal-Reihenfolge nach", "opt_ord_prov": "Anbieter-Reihenfolge verwenden", "opt_ord_alpha": "Alphabetisch", "opt_ord_user": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top": "Neue Kanäle oben", "opt_upd_bot": "Neue Kanäle unten", "lbl_picon": "Picons herunterladen", "opt_picon_off": "Aus", "opt_picon_on": "Ein", "lbl_pic_naming": "Benennung", "opt_pic_dn": "Mit Anzeigename", "opt_pic_ref": "Mit Referenznummer", "lbl_pic_folder": "Mit Ordner", "opt_pic_folder_on": "Ein", "opt_pic_folder_off": "Aus", "lbl_pic_symlink": "Symlink erstellen", "opt_pic_sym_off": "Aus", "opt_pic_sym_on": "Ein", "lbl_custom_epg": "Benutzerdefiniertes EPG", "opt_cepg_on": "Ein", "opt_cepg_off": "Aus", "lbl_clean_bouquets": "Bouquets bereinigen", "opt_clean_off": "Aus", "opt_clean_on": "Ein", "lbl_create_archives": "Anbieter-Archive erstellen", "opt_arch_off": "Aus", "opt_arch_on": "Ein", "lbl_create_archive_markers": "Archiv-Markierungen erstellen", "opt_markers_off": "Aus", "opt_markers_on": "Ein", "lbl_archive_days": "Archivtage (1-7)", "lbl_cache_ttl_custom": "Eigene TTL", "opt_ttl_off": "Aus (7 Tage)", "opt_ttl_on": "Ein", "lbl_cache_ttl_days": "TTL-Tage (1-30)", "lbl_time_offset_sign": "Versatz +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Versatz (Sek.)", "lbl_stream_hostname": "Hostname-Filter aus Stream-URL", "opt_plr_off": "Aus", "opt_plr_on": "Ein", "opt_int_on": "Ein", "opt_int_off": "Aus", "opt_sl_off": "Aus", "opt_sl_on": "Ein", "opt_rec_off": "Aus", "opt_rec_on": "Ein", "lbl_clear_cache_on_save": "Cache beim Speichern leeren", "opt_ccs_off": "Aus", "opt_ccs_on": "Ein", "lbl_frag": "URL-Fragment", "lbl_arch": "Archiv-URL-Muster", "opt_std": "Standard (utc/lutc-Parameter)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "EPG-Quelle", "opt_ottp": "ottp.eu.org-Datenbank (empfohlen)", "opt_api": "Eigene API-URL des Anbieters", "lbl_epg_url": "EPG-API-URL-Vorlage", "lbl_xtream_type": "Xtream Typ", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Benutzername", "lbl_xtream_password": "Xtream Passwort", "lbl_xtream_output": "Stream-Ausgabe", "opt_xt_m3u8": "HLS / m3u8 (Empfohlen)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Bouquet-Strategie", "opt_xts_same": "Wie Anbieter", "opt_xts_folder": "Alle in einen Ordner", "opt_ord_user_xt": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_xt_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top_xt": "Neue Kanäle oben", "opt_upd_bot_xt": "Neue Kanäle unten", "lbl_xtream_show_live": "Live-TV-Bouquets erstellen", "opt_xtlive_yes": "Ja", "opt_xtlive_no": "Nein", "lbl_xtream_live_type": "Live-Typ", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "VOD-Bouquets erstellen", "opt_xtvod_yes": "Ja", "opt_xtvod_no": "Nein", "lbl_xtream_vod_type": "VOD-Typ", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Serien-Bouquets erstellen", "opt_xtser_yes": "Ja", "opt_xtser_no": "Nein", "lbl_xtream_series_type": "Serien-Typ", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Picons herunterladen", "opt_xtp_off": "Aus", "opt_xtp_dn": "Mit Anzeigename", "opt_xtp_ref": "Mit Referenznummer", "lbl_xtream_picon_folder": "Mit Ordner", "opt_xtp_folder_on": "Ein", "opt_xtp_folder_off": "Aus", "lbl_xtream_picon_symlink": "Symlink erstellen", "opt_xtp_sym_off": "Aus", "opt_xtp_sym_on": "Ein", "opt_markers_off_xt": "Aus", "opt_markers_on_xt": "Ein", "lbl_xt_custom_epg": "Benutzerdefiniertes EPG", "opt_xt_cepg_on": "Ein", "opt_xt_cepg_off": "Aus", "lbl_xtream_clean": "Bouquets bereinigen", "opt_xclean_no": "Nein", "opt_xclean_yes": "Ja", "lbl_ch_title": "Kanäle"};
  var _IT={"lbl_name": "Nome provider", "lbl_xmltv": "URL XMLTV / File locale", "lbl_m3u": "URL M3U / Playlist M3U", "lbl_days": "Giorni archivio (1-7)", "lbl_ttl_section": "Giorni TTL per file cache (inserisci il numero di giorni archivio disponibili)", "lbl_ttl_custom": "TTL personalizzato", "lbl_ttl_days": "  Giorni TTL (1-7)", "lbl_sign": "Offset segno", "opt_plus": "+  dopo", "opt_minus": "-  prima", "lbl_abs": "Offset secondi", "lbl_hostname": "Filtro hostname stream (per offset tempo)", "lbl_player_section": "Selezione player", "lbl_player_hint": "Sovrascrivere impostazioni player.", "lbl_player_override": "Override player (specifico per provider)", "lbl_player_int": "Player: Integrato", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Ricevitore", "lbl_enabled": "Abilitato", "opt_yes": "Sì", "opt_no": "No", "lbl_epg_parse": "Crea file EPG", "opt_epg_off": "Spento", "opt_epg_dn": "Per nome visualizzato", "opt_epg_tvg": "Per tvg-id", "lbl_strategy": "Strategia creazione bouquet", "opt_same": "Come nella playlist", "opt_all": "Bouquet per tutti i canali", "opt_allg": "Bouquet per tutti i canali e gruppi", "opt_psub": "Bouquet con nome provider e sotto-bouquet", "lbl_playback": "Riproduci con", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Ordinamento canali per", "opt_ord_prov": "Usa ordine provider", "opt_ord_alpha": "Alfabeticamente", "opt_ord_user": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top": "Nuovi canali in alto", "opt_upd_bot": "Nuovi canali in basso", "lbl_picon": "Scarica picon", "opt_picon_off": "Spento", "opt_picon_on": "Sì", "lbl_pic_naming": "Denominazione", "opt_pic_dn": "Con nome visualizzato", "opt_pic_ref": "Con numero di riferimento", "lbl_pic_folder": "Con cartella", "opt_pic_folder_on": "Sì", "opt_pic_folder_off": "Spento", "lbl_pic_symlink": "Crea collegamento simbolico", "opt_pic_sym_off": "Spento", "opt_pic_sym_on": "Sì", "lbl_custom_epg": "EPG Personalizzato", "opt_cepg_on": "Sì", "opt_cepg_off": "Spento", "lbl_clean_bouquets": "Pulisci bouquet", "opt_clean_off": "Spento", "opt_clean_on": "Sì", "lbl_create_archives": "Crea archivi provider", "opt_arch_off": "Spento", "opt_arch_on": "Sì", "lbl_create_archive_markers": "Crea marcatori archivio", "opt_markers_off": "Spento", "opt_markers_on": "Sì", "lbl_archive_days": "Giorni archivio (1-7)", "lbl_cache_ttl_custom": "TTL personalizzato", "opt_ttl_off": "No (7 giorni)", "opt_ttl_on": "Sì", "lbl_cache_ttl_days": "Giorni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_stream_hostname": "Filtro hostname da URL stream", "opt_plr_off": "Spento", "opt_plr_on": "Sì", "opt_int_on": "Sì", "opt_int_off": "Spento", "opt_sl_off": "Spento", "opt_sl_on": "Sì", "opt_rec_off": "Spento", "opt_rec_on": "Sì", "lbl_clear_cache_on_save": "Pulisci cache al salvataggio", "opt_ccs_off": "Spento", "opt_ccs_on": "Sì", "lbl_frag": "Frammento URL", "lbl_arch": "Schema URL archivio", "opt_std": "Standard (parametri utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Fonte EPG", "opt_ottp": "Database ottp.eu.org (consigliato)", "opt_api": "URL API proprio del provider", "lbl_epg_url": "Modello URL API EPG", "lbl_xtream_type": "Tipo Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nome utente Xtream", "lbl_xtream_password": "Password Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Uscita stream", "opt_xt_m3u8": "HLS / m3u8 (Consigliato)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bouquet", "opt_xts_same": "Come da provider", "opt_xts_folder": "Tutti in una cartella", "opt_ord_user_xt": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_xt_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top_xt": "Nuovi canali in alto", "opt_upd_bot_xt": "Nuovi canali in basso", "lbl_xtream_show_live": "Crea bouquet TV in diretta", "opt_xtlive_yes": "Sì", "opt_xtlive_no": "No", "lbl_xtream_live_type": "Tipo live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Crea bouquet VOD", "opt_xtvod_yes": "Sì", "opt_xtvod_no": "No", "lbl_xtream_vod_type": "Tipo VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Crea bouquet serie", "opt_xtser_yes": "Sì", "opt_xtser_no": "No", "lbl_xtream_series_type": "Tipo serie", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Scarica picon", "opt_xtp_off": "Spento", "opt_xtp_dn": "Con nome visualizzato", "opt_xtp_ref": "Con numero di riferimento", "lbl_xtream_picon_folder": "Con cartella", "opt_xtp_folder_on": "Sì", "opt_xtp_folder_off": "Spento", "lbl_xtream_picon_symlink": "Crea collegamento simbolico", "opt_xtp_sym_off": "Spento", "opt_xtp_sym_on": "Sì", "opt_markers_off_xt": "Spento", "opt_markers_on_xt": "Sì", "lbl_xt_custom_epg": "EPG Personalizzato", "opt_xt_cepg_on": "Sì", "opt_xt_cepg_off": "Spento", "lbl_xtream_clean": "Pulisci bouquet", "opt_xclean_no": "No", "opt_xclean_yes": "Sì", "lbl_bouquets": "Bouquet", "lbl_ch_title": "Canali"};
  var _PL={"lbl_name": "Nazwa dostawcy", "lbl_xmltv": "XMLTV URL / Plik lokalny", "lbl_m3u": "M3U URL / Playlista M3U", "lbl_days": "Dni archiwum (1-7)", "lbl_ttl_section": "Dni TTL dla plików pamięci podręcznej (wprowadź dostępną liczbę dni archiwum)", "lbl_ttl_custom": "Własny TTL", "lbl_ttl_days": "  Dni TTL (1-7)", "lbl_sign": "Przesunięcie znak", "opt_plus": "+  później", "opt_minus": "-  wcześniej", "lbl_abs": "Przesunięcie sekundy", "lbl_hostname": "Filtr nazwy hosta strumienia (dla przesunięcia czasu)", "lbl_player_section": "Wybór odtwarzacza", "lbl_player_hint": "Nadpisz ustawienia odtwarzacza.", "lbl_player_override": "Nadpisanie odtwarzacza (specyficzne dla dostawcy)", "lbl_player_int": "Odtwarzacz: Wbudowany", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Odtwarzacz: Odbiornik", "lbl_enabled": "Włączony", "opt_yes": "Tak", "opt_no": "Nie", "lbl_epg_parse": "Utwórz plik EPG", "opt_epg_off": "Wyłączone", "opt_epg_dn": "Według nazwy wyświetlanej", "opt_epg_tvg": "Według tvg-id", "lbl_strategy": "Strategia tworzenia bukietu", "opt_same": "Jak w playliście", "opt_all": "Bukiet dla wszystkich kanałów", "opt_allg": "Bukiety dla wszystkich kanałów i grup", "opt_psub": "Bukiet z nazwą dostawcy i podbukietami", "lbl_playback": "Odtwarzanie przez", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kolejność kanałów według", "opt_ord_prov": "Użyj kolejności dostawcy", "opt_ord_alpha": "Alfabetycznie", "opt_ord_user": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top": "Nowe kanały na górze", "opt_upd_bot": "Nowe kanały na dole", "lbl_picon": "Pobierz pikony", "opt_picon_off": "Wyłączone", "opt_picon_on": "Wł", "lbl_pic_naming": "Nazewnictwo", "opt_pic_dn": "Z nazwą wyświetlaną", "opt_pic_ref": "Z numerem referencyjnym", "lbl_pic_folder": "Z folderem", "opt_pic_folder_on": "Wł", "opt_pic_folder_off": "Wyłączone", "lbl_pic_symlink": "Utwórz dowiązanie symboliczne", "opt_pic_sym_off": "Wyłączone", "opt_pic_sym_on": "Wł", "lbl_custom_epg": "Niestandardowy EPG", "opt_cepg_on": "Wł", "opt_cepg_off": "Wyłączone", "lbl_clean_bouquets": "Wyczyść bukiety", "opt_clean_off": "Wyłączone", "opt_clean_on": "Wł", "lbl_create_archives": "Utwórz archiwa dostawcy", "opt_arch_off": "Wyłączone", "opt_arch_on": "Wł", "lbl_create_archive_markers": "Utwórz znaczniki archiwum", "opt_markers_off": "Wyłączone", "opt_markers_on": "Wł", "lbl_archive_days": "Dni archiwum (1-7)", "lbl_cache_ttl_custom": "Własny TTL", "opt_ttl_off": "Wył (7 dni)", "opt_ttl_on": "Wł", "lbl_cache_ttl_days": "Dni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Przesunięcie (sek)", "lbl_stream_hostname": "Filtr hosta z URL strumienia", "opt_plr_off": "Wyłączone", "opt_plr_on": "Wł", "opt_int_on": "Wł", "opt_int_off": "Wyłączone", "opt_sl_off": "Wyłączone", "opt_sl_on": "Wł", "opt_rec_off": "Wyłączone", "opt_rec_on": "Wł", "lbl_clear_cache_on_save": "Wyczyść pamięć podręczną przy zapisie", "opt_ccs_off": "Wyłączone", "opt_ccs_on": "Wł", "lbl_frag": "Fragment URL", "lbl_arch": "Wzorzec URL archiwum", "opt_std": "Standardowy (parametry utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Źródło EPG", "opt_ottp": "Baza danych ottp.eu.org (zalecana)", "opt_api": "Własny URL API dostawcy", "lbl_epg_url": "Szablon URL API EPG", "lbl_xtream_type": "Typ Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nazwa użytkownika Xtream", "lbl_xtream_password": "Hasło Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Wyjście strumienia", "opt_xt_m3u8": "HLS / m3u8 (Zalecane)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bukietu", "opt_xts_same": "Tak jak u dostawcy", "opt_xts_folder": "Wszystko do jednego folderu", "opt_ord_user_xt": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_xt_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top_xt": "Nowe kanały na górze", "opt_upd_bot_xt": "Nowe kanały na dole", "lbl_xtream_show_live": "Buduj bukiety telewizji na żywo", "opt_xtlive_yes": "Tak", "opt_xtlive_no": "Nie", "lbl_xtream_live_type": "Typ live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Buduj bukiety VOD", "opt_xtvod_yes": "Tak", "opt_xtvod_no": "Nie", "lbl_xtream_vod_type": "Typ VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Buduj bukiety seriali", "opt_xtser_yes": "Tak", "opt_xtser_no": "Nie", "lbl_xtream_series_type": "Typ seriali", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Pobierz pikony", "opt_xtp_off": "Wyłączone", "opt_xtp_dn": "Z nazwą wyświetlaną", "opt_xtp_ref": "Z numerem referencyjnym", "lbl_xtream_picon_folder": "Z folderem", "opt_xtp_folder_on": "Wł", "opt_xtp_folder_off": "Wyłączone", "lbl_xtream_picon_symlink": "Utwórz dowiązanie symboliczne", "opt_xtp_sym_off": "Wyłączone", "opt_xtp_sym_on": "Wł", "opt_markers_off_xt": "Wyłączone", "opt_markers_on_xt": "Wł", "lbl_xt_custom_epg": "Niestandardowy EPG", "opt_xt_cepg_on": "Wł", "opt_xt_cepg_off": "Wyłączone", "lbl_xtream_clean": "Wyczyść bukiety", "opt_xclean_no": "Nie", "opt_xclean_yes": "Tak", "lbl_bouquets": "Bukiety", "lbl_ch_title": "Kanały"};
  var _RU={"lbl_name": "Имя провайдера", "lbl_xmltv": "XMLTV URL / Локальный файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дней архива (1-7)", "lbl_ttl_section": "Срок кэша (введите доступное кол-во дней архива)", "lbl_ttl_custom": "Свой TTL", "lbl_ttl_days": "  Дней хранения (1-7)", "lbl_sign": "Смещение знак", "opt_plus": "+  позже", "opt_minus": "-  раньше", "lbl_abs": "Смещение секунды", "lbl_hostname": "Фильтр hostname потока (для смещения времени)", "lbl_player_section": "Выбор плеера", "lbl_player_hint": "Переопределить настройки плеера.", "lbl_player_override": "Перекрытие плеера (для провайдера)", "lbl_player_int": "Плеер: встроенный", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеер: приёмника", "lbl_enabled": "Включён", "opt_yes": "Да", "opt_no": "Нет", "lbl_epg_parse": "Создать файл EPG", "opt_epg_off": "Выключено", "opt_epg_dn": "По отображаемому имени", "opt_epg_tvg": "По tvg-id", "lbl_strategy": "Стратегия создания букета", "opt_same": "Как в плейлисте", "opt_all": "Букет для всех каналов", "opt_allg": "Букеты для всех каналов и групп", "opt_psub": "Букет с именем провайдера и суббукеты", "lbl_playback": "Воспроизведение через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналов", "opt_ord_prov": "Порядок из провайдера", "opt_ord_alpha": "По алфавиту", "opt_ord_user": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_update_mode": "Только обновить M3U плейлист", "opt_upd_top": "Новые каналы сверху", "opt_upd_bot": "Новые каналы снизу", "lbl_picon": "Скачать Пиконы", "opt_picon_off": "Выключено", "opt_picon_on": "Вкл", "lbl_pic_naming": "Именование", "opt_pic_dn": "С отображаемым именем", "opt_pic_ref": "С номером ссылки", "lbl_pic_folder": "С папкой провайдера", "opt_pic_folder_on": "Вкл", "opt_pic_folder_off": "Выключено", "lbl_pic_symlink": "Создать симлинк", "opt_pic_sym_off": "Выключено", "opt_pic_sym_on": "Вкл", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Вкл", "opt_cepg_off": "Выключено", "lbl_clean_bouquets": "Очистить букеты", "opt_clean_off": "Выключено", "opt_clean_on": "Вкл", "lbl_create_archives": "Создать Архивы Провайдера", "opt_arch_off": "Выключено", "opt_arch_on": "Вкл", "lbl_create_archive_markers": "Создать маркеры архива", "opt_markers_off": "Выключено", "opt_markers_on": "Вкл", "lbl_archive_days": "Дней архива (1-7)", "lbl_cache_ttl_custom": "Свой срок хранения", "opt_ttl_off": "Выкл (7 дней)", "opt_ttl_on": "Вкл", "lbl_cache_ttl_days": "Дней кэша (1-30)", "lbl_time_offset_sign": "Смещение +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Смещение (сек)", "lbl_stream_hostname": "Hostname фильтр из URL потока", "opt_plr_off": "Выключено", "opt_plr_on": "Вкл", "opt_int_on": "Вкл", "opt_int_off": "Выключено", "opt_sl_off": "Выключено", "opt_sl_on": "Вкл", "opt_rec_off": "Выключено", "opt_rec_on": "Вкл", "lbl_clear_cache_on_save": "Очистить кэш при сохранении", "opt_ccs_off": "Выключено", "opt_ccs_on": "Вкл", "lbl_frag": "URL фрагмент", "lbl_arch": "Шаблон URL архива", "opt_std": "Стандартный (utc/lutc параметры)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Источник EPG", "opt_ottp": "База ottp.eu.org (рекомендуется)", "opt_api": "Свой URL API провайдера", "lbl_epg_url": "Шаблон URL EPG API", "lbl_xtream_type": "Xtream Тип", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Имя пользователя", "lbl_xtream_password": "Xtream Пароль", "lbl_xtream_token": "Xtream Токен", "lbl_xtream_output": "Выходной формат потока", "opt_xt_m3u8": "HLS / m3u8 (Рекомендуется)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегия создания букетов", "opt_xts_same": "Как у провайдера", "opt_xts_folder": "Все в одну папку", "opt_ord_user_xt": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_xt_update_mode": "Только обновить M3U плейлист", "opt_upd_top_xt": "Новые каналы сверху", "opt_upd_bot_xt": "Новые каналы снизу", "lbl_xtream_show_live": "Создавать букеты Live TV", "opt_xtlive_yes": "Да", "opt_xtlive_no": "Нет", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Создавать букеты VOD", "opt_xtvod_yes": "Да", "opt_xtvod_no": "Нет", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Создавать букеты Сериалов", "opt_xtser_yes": "Да", "opt_xtser_no": "Нет", "lbl_xtream_series_type": "Тип серий", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Скачать Пиконы", "opt_xtp_off": "Выключено", "opt_xtp_dn": "С отображаемым именем", "opt_xtp_ref": "С номером ссылки", "lbl_xtream_picon_folder": "С папкой провайдера", "opt_xtp_folder_on": "Вкл", "opt_xtp_folder_off": "Выключено", "lbl_xtream_picon_symlink": "Создать симлинк", "opt_xtp_sym_off": "Выключено", "opt_xtp_sym_on": "Вкл", "opt_markers_off_xt": "Выключено", "opt_markers_on_xt": "Вкл", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Вкл", "opt_xt_cepg_off": "Выключено", "lbl_xtream_clean": "Очистить букеты", "opt_xclean_no": "Нет", "opt_xclean_yes": "Да", "lbl_bouquets": "Букеты", "lbl_ch_title": "Каналы"};
  var _UK={"lbl_name": "Назва провайдера", "lbl_xmltv": "XMLTV URL / Локальний файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дні архіву (1-7)", "lbl_ttl_section": "TTL-дні для кешованих файлів (введіть доступну кількість днів архіву)", "lbl_ttl_custom": "Власний TTL", "lbl_ttl_days": "  TTL-дні (1-7)", "lbl_sign": "Зміщення знак", "opt_plus": "+  пізніше", "opt_minus": "-  раніше", "lbl_abs": "Зміщення секунди", "lbl_hostname": "Фільтр імені хоста потоку (для зсуву часу)", "lbl_player_section": "Вибір плеєра", "lbl_player_hint": "Перевизначити налаштування плеєра.", "lbl_player_override": "Перевизначення плеєра (для провайдера)", "lbl_player_int": "Плеєр: вбудований", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеєр: приймача", "lbl_enabled": "Увімкнено", "opt_yes": "Так", "opt_no": "Ні", "lbl_epg_parse": "Створити EPG-файл", "opt_epg_off": "Вимк", "opt_epg_dn": "За назвою", "opt_epg_tvg": "За tvg-id", "lbl_strategy": "Стратегія створення букетів", "opt_same": "Як у плейлисті", "opt_all": "Букет для всіх каналів", "opt_allg": "Букети для всіх каналів та груп", "opt_psub": "Букет з назвою провайдера та суб-букетами", "lbl_playback": "Відтворення через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналів за", "opt_ord_prov": "Порядок провайдера", "opt_ord_alpha": "За алфавітом", "opt_ord_user": "Користувацький (для відсортованих каналів/букетів)", "lbl_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top": "Нові канали зверху", "opt_upd_bot": "Нові канали знизу", "lbl_picon": "Завантажити пікони", "opt_picon_off": "Вимк", "opt_picon_on": "Увім", "lbl_pic_naming": "Іменування", "opt_pic_dn": "За назвою", "opt_pic_ref": "За номером посилання", "lbl_pic_folder": "З папкою", "opt_pic_folder_on": "Увім", "opt_pic_folder_off": "Вимк", "lbl_pic_symlink": "Створити симлінк", "opt_pic_sym_off": "Вимк", "opt_pic_sym_on": "Увім", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Увім", "opt_cepg_off": "Вимк", "lbl_clean_bouquets": "Очистити букети", "opt_clean_off": "Вимк", "opt_clean_on": "Увім", "lbl_create_archives": "Створити Архіви Провайдера", "opt_arch_off": "Вимк", "opt_arch_on": "Увім", "lbl_create_archive_markers": "Створити маркери архіву", "opt_markers_off": "Вимк", "opt_markers_on": "Увім", "lbl_archive_days": "Дні архіву (1-7)", "lbl_cache_ttl_custom": "Користувацький TTL", "opt_ttl_off": "Вимк (7 днів)", "opt_ttl_on": "Увім", "lbl_cache_ttl_days": "Днів кешу (1-30)", "lbl_time_offset_sign": "Зміщення +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Зсув (сек)", "lbl_stream_hostname": "Фільтр імені хоста з URL потоку", "opt_plr_off": "Вимк", "opt_plr_on": "Увім", "opt_int_on": "Увім", "opt_int_off": "Вимк", "opt_sl_off": "Вимк", "opt_sl_on": "Увім", "opt_rec_off": "Вимк", "opt_rec_on": "Увім", "lbl_clear_cache_on_save": "Очистити кеш при збереженні", "opt_ccs_off": "Вимк", "opt_ccs_on": "Увім", "lbl_frag": "Фрагмент URL", "lbl_arch": "Шаблон URL архіву", "opt_std": "Стандартний (параметри utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Джерело EPG", "opt_ottp": "База даних ottp.eu.org (рекомендовано)", "opt_api": "Власний URL API провайдера", "lbl_epg_url": "Шаблон URL API EPG", "lbl_xtream_type": "Тип Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Ім'я користувача Xtream", "lbl_xtream_password": "Пароль Xtream", "lbl_xtream_token": "Токен Xtream", "lbl_xtream_output": "Вихід потоку", "opt_xt_m3u8": "HLS / m3u8 (Рекомендовано)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегія букетів", "opt_xts_same": "Як у провайдера", "opt_xts_folder": "Все в одну теку", "opt_ord_user_xt": "Користувацький (для відсортованих каналів/букетів)", "lbl_xt_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top_xt": "Нові канали зверху", "opt_upd_bot_xt": "Нові канали знизу", "lbl_xtream_show_live": "Створювати букети Прямого ефіру", "opt_xtlive_yes": "Так", "opt_xtlive_no": "Ні", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Створювати букети VOD", "opt_xtvod_yes": "Так", "opt_xtvod_no": "Ні", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Створювати букети Серіалів", "opt_xtser_yes": "Так", "opt_xtser_no": "Ні", "lbl_xtream_series_type": "Тип серій", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Завантажити пікони", "opt_xtp_off": "Вимк", "opt_xtp_dn": "За назвою", "opt_xtp_ref": "За номером посилання", "lbl_xtream_picon_folder": "З папкою", "opt_xtp_folder_on": "Увім", "opt_xtp_folder_off": "Вимк", "lbl_xtream_picon_symlink": "Створити симлінк", "opt_xtp_sym_off": "Вимк", "opt_xtp_sym_on": "Увім", "opt_markers_off_xt": "Вимк", "opt_markers_on_xt": "Увім", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Увім", "opt_xt_cepg_off": "Вимк", "lbl_xtream_clean": "Очистити букети", "opt_xclean_no": "Ні", "opt_xclean_yes": "Так", "lbl_bouquets": "Букети", "lbl_ch_title": "Канали"};
  var _FR={"lbl_name": "Nom du fournisseur", "lbl_xmltv": "URL XMLTV / Fichier local", "lbl_m3u": "URL M3U / Liste de lecture M3U", "lbl_days": "Jours d'archive (1-7)", "lbl_ttl_section": "Jours TTL pour les fichiers en cache (entrez le nombre de jours d'archive disponibles)", "lbl_ttl_days": "  Jours TTL (1-7)", "lbl_hostname": "Filtre de nom d'hôte de flux (pour le décalage horaire)", "lbl_player_override": "Remplacement du lecteur (spécifique au fournisseur)", "lbl_enabled": "Activé", "opt_yes": "Oui", "opt_no": "Non", "lbl_epg_parse": "Créer un fichier EPG", "opt_epg_off": "Désactivé", "opt_epg_dn": "Par nom affiché", "opt_epg_tvg": "Par tvg-id", "lbl_strategy": "Stratégie de création de bouquet", "opt_same": "Comme dans la liste de lecture", "opt_all": "Bouquet pour toutes les chaînes", "opt_allg": "Bouquets pour toutes les chaînes et tous les groupes", "opt_psub": "Bouquet avec nom de fournisseur et sous-bouquets", "lbl_playback": "Lire avec", "lbl_order": "Ordre des chaînes par", "opt_ord_prov": "Utiliser l'ordre du fournisseur", "opt_ord_alpha": "Alphabétiquement", "opt_ord_user": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top": "Nouvelles chaînes en haut", "opt_upd_bot": "Nouvelles chaînes en bas", "lbl_picon": "Télécharger les Picons", "opt_picon_off": "Désactivé", "opt_picon_on": "On", "lbl_pic_naming": "Nommage", "opt_pic_dn": "Avec nom affiché", "opt_pic_ref": "Avec numéro de référence", "lbl_pic_folder": "Avec dossier du fournisseur", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Désactivé", "lbl_pic_symlink": "Créer un lien symbolique", "opt_pic_sym_off": "Désactivé", "opt_pic_sym_on": "On", "lbl_custom_epg": "Fichier EPG personnalisé", "opt_cepg_on": "On", "opt_cepg_off": "Désactivé", "lbl_clean_bouquets": "Nettoyer les bouquets", "opt_clean_off": "Désactivé", "opt_clean_on": "On", "lbl_create_archives": "Créer des archives du fournisseur", "opt_arch_off": "Désactivé", "opt_arch_on": "On", "opt_markers_off": "Désactivé", "opt_markers_on": "On", "lbl_archive_days": "Jours d'archive (1-7)", "lbl_cache_ttl_custom": "TTL personnalisé", "opt_ttl_on": "On", "lbl_time_offset_abs": "Décalage (sec)", "lbl_stream_hostname": "Filtre de nom d'hôte depuis l'URL du flux", "opt_plr_off": "Désactivé", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Désactivé", "opt_sl_off": "Désactivé", "opt_sl_on": "On", "opt_rec_off": "Désactivé", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Effacer le cache lors de l'enregistrement", "opt_ccs_off": "Désactivé", "opt_ccs_on": "On", "lbl_frag": "Fragment d'URL", "lbl_arch": "Modèle d'URL d'archive", "opt_std": "Standard (paramètres utc/lutc)", "lbl_epg": "Source EPG", "opt_ottp": "Base de données ottp.eu.org (recommandée)", "opt_api": "URL API propre du fournisseur", "lbl_epg_url": "Modèle d'URL API EPG", "lbl_xtream_type": "Type Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nom d'utilisateur Xtream", "lbl_xtream_password": "Mot de passe Xtream", "lbl_xtream_token": "Jeton Xtream", "lbl_xtream_output": "Format de sortie du flux", "opt_xt_m3u8": "HLS / m3u8 (Recommandé)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Stratégie de bouquet", "opt_xts_same": "Comme le fournisseur", "opt_ord_user_xt": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_xt_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top_xt": "Nouvelles chaînes en haut", "opt_upd_bot_xt": "Nouvelles chaînes en bas", "lbl_xtream_show_live": "Créer des bouquets TV en direct", "opt_xtlive_yes": "Oui", "opt_xtlive_no": "Non", "lbl_xtream_show_vod": "Créer des bouquets VOD", "opt_xtvod_yes": "Oui", "opt_xtvod_no": "Non", "lbl_xtream_show_series": "Créer des bouquets de séries", "opt_xtser_yes": "Oui", "opt_xtser_no": "Non", "lbl_xtream_picon": "Télécharger les Picons", "opt_xtp_off": "Désactivé", "opt_xtp_dn": "Avec nom affiché", "opt_xtp_ref": "Avec numéro de référence", "lbl_xtream_picon_folder": "Avec dossier du fournisseur", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Désactivé", "lbl_xtream_picon_symlink": "Créer un lien symbolique", "opt_xtp_sym_off": "Désactivé", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Désactivé", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Fichier EPG personnalisé", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Désactivé", "lbl_xtream_clean": "Nettoyer les bouquets", "opt_xclean_no": "Non", "opt_xclean_yes": "Oui", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Chaînes"};
  var _ES={"lbl_name": "Nombre del proveedor", "lbl_xmltv": "URL XMLTV / Archivo local", "lbl_m3u": "URL M3U / Lista de reproducción M3U", "lbl_days": "Días de archivo (1-7)", "lbl_ttl_section": "Días TTL para archivos en caché (ingrese el número de días de archivo disponibles)", "lbl_ttl_days": "  Días TTL (1-7)", "lbl_hostname": "Filtro de nombre de host de transmisión (para desplazamiento de tiempo)", "lbl_player_override": "Anulación de reproductor (específico del proveedor)", "lbl_enabled": "Habilitado", "opt_yes": "Sí", "opt_no": "No", "lbl_epg_parse": "Crear archivo EPG", "opt_epg_off": "Apagado", "opt_epg_dn": "Por nombre mostrado", "opt_epg_tvg": "Por tvg-id", "lbl_strategy": "Estrategia de creación de bouquet", "opt_same": "Igual que en la lista de reproducción", "opt_all": "Bouquet para todos los canales", "opt_allg": "Bouquets para todos los canales y grupos", "opt_psub": "Bouquet con nombre de proveedor y sub-bouquets", "lbl_playback": "Reproducir con", "lbl_order": "Orden de canales por", "opt_ord_prov": "Usar orden del proveedor", "opt_ord_alpha": "Alfabéticamente", "opt_ord_user": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top": "Nuevos canales arriba", "opt_upd_bot": "Nuevos canales abajo", "lbl_picon": "Descargar Picons", "opt_picon_off": "Apagado", "opt_picon_on": "On", "lbl_pic_naming": "Denominación", "opt_pic_dn": "Con nombre mostrado", "opt_pic_ref": "Con número de referencia", "lbl_pic_folder": "Con carpeta de proveedor", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Apagado", "lbl_pic_symlink": "Crear enlace simbólico", "opt_pic_sym_off": "Apagado", "opt_pic_sym_on": "On", "lbl_custom_epg": "Archivo EPG personalizado", "opt_cepg_on": "On", "opt_cepg_off": "Apagado", "lbl_clean_bouquets": "Limpiar bouquets", "opt_clean_off": "Apagado", "opt_clean_on": "On", "lbl_create_archives": "Crear archivos del proveedor", "opt_arch_off": "Apagado", "opt_arch_on": "On", "opt_markers_off": "Apagado", "opt_markers_on": "On", "lbl_archive_days": "Días de archivo (1-7)", "lbl_cache_ttl_custom": "TTL personalizado", "opt_ttl_on": "On", "lbl_time_offset_abs": "Desplazamiento (seg)", "lbl_stream_hostname": "Filtro de nombre de host desde URL de transmisión", "opt_plr_off": "Apagado", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Apagado", "opt_sl_off": "Apagado", "opt_sl_on": "On", "opt_rec_off": "Apagado", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Limpiar caché al guardar", "opt_ccs_off": "Apagado", "opt_ccs_on": "On", "lbl_frag": "Fragmento de URL", "lbl_arch": "Patrón de URL de archivo", "opt_std": "Estándar (parámetros utc/lutc)", "lbl_epg": "Fuente EPG", "opt_ottp": "Base de datos ottp.eu.org (recomendada)", "opt_api": "URL API propia del proveedor", "lbl_epg_url": "Plantilla de URL de API EPG", "lbl_xtream_type": "Tipo Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nombre de usuario Xtream", "lbl_xtream_password": "Contraseña Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Formato de salida de transmisión", "opt_xt_m3u8": "HLS / m3u8 (Recomendado)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Estrategia de bouquet", "opt_xts_same": "Igual que el proveedor", "opt_ord_user_xt": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_xt_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top_xt": "Nuevos canales arriba", "opt_upd_bot_xt": "Nuevos canales abajo", "lbl_xtream_show_live": "Crear bouquets de TV en vivo", "opt_xtlive_yes": "Sí", "opt_xtlive_no": "No", "lbl_xtream_show_vod": "Crear bouquets de VOD", "opt_xtvod_yes": "Sí", "opt_xtvod_no": "No", "lbl_xtream_show_series": "Crear bouquets de series", "opt_xtser_yes": "Sí", "opt_xtser_no": "No", "lbl_xtream_picon": "Descargar Picons", "opt_xtp_off": "Apagado", "opt_xtp_dn": "Con nombre mostrado", "opt_xtp_ref": "Con número de referencia", "lbl_xtream_picon_folder": "Con carpeta de proveedor", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Apagado", "lbl_xtream_picon_symlink": "Crear enlace simbólico", "opt_xtp_sym_off": "Apagado", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Apagado", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Archivo EPG personalizado", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Apagado", "lbl_xtream_clean": "Limpiar bouquets", "opt_xclean_no": "No", "opt_xclean_yes": "Sí", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Canales"};
  var _TR={"lbl_name": "Sağlayıcı Adı", "lbl_xmltv": "XMLTV URL'si / Yerel Dosya", "lbl_m3u": "M3U URL'si / M3U Oynatma Listesi", "lbl_days": "Arşiv Günleri (1-7)", "lbl_ttl_section": "Önbellek Dosyaları için TTL Günleri (Mevcut Arşiv Günleri Sayısını Girin)", "lbl_ttl_days": "  TTL Günleri (1-7)", "lbl_hostname": "Akış Hostname Filtresi (Zaman Ofseti İçin)", "lbl_player_override": "Oynatıcı Geçersiz Kılma (Sağlayıcıya Özel)", "lbl_enabled": "Etkin", "opt_yes": "Evet", "opt_no": "Hayır", "lbl_epg_parse": "EPG Dosyası Oluştur", "opt_epg_off": "Kapalı", "opt_epg_dn": "Görünen Ada göre", "opt_epg_tvg": "tvg-id'ye göre", "lbl_strategy": "Buket Oluşturma Stratejisi", "opt_same": "Oynatma Listesindeki Gibi", "opt_all": "Tüm Kanallar için Buket", "opt_allg": "Tüm Kanallar ve Gruplar için Buketler", "opt_psub": "Sağlayıcı Adı ve Alt Buketler ile Buket", "lbl_playback": "İle Oynat", "lbl_order": "Kanalları Sıralama", "opt_ord_prov": "Sağlayıcı Sırasını Kullan", "opt_ord_alpha": "Alfabetik", "opt_ord_user": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top": "Yeni Kanallar Üstte", "opt_upd_bot": "Yeni Kanallar Altta", "lbl_picon": "Pikonları İndir", "opt_picon_off": "Kapalı", "opt_picon_on": "Açık", "lbl_pic_naming": "Adlandırma", "opt_pic_dn": "Görünen Ad ile", "opt_pic_ref": "Referans Numarası ile", "lbl_pic_folder": "Sağlayıcı Klasörü ile", "opt_pic_folder_on": "Açık", "opt_pic_folder_off": "Kapalı", "lbl_pic_symlink": "Sembolik Bağlantı Oluştur", "opt_pic_sym_off": "Kapalı", "opt_pic_sym_on": "Açık", "lbl_custom_epg": "Özel EPG Dosyası", "opt_cepg_on": "Açık", "opt_cepg_off": "Kapalı", "lbl_clean_bouquets": "Buketleri Temizle", "opt_clean_off": "Kapalı", "opt_clean_on": "Açık", "lbl_create_archives": "Sağlayıcı Arşivleri Oluştur", "opt_arch_off": "Kapalı", "opt_arch_on": "Açık", "opt_markers_off": "Kapalı", "opt_markers_on": "Açık", "lbl_archive_days": "Arşiv Günleri (1-7)", "lbl_cache_ttl_custom": "Özel TTL", "opt_ttl_on": "Açık", "lbl_time_offset_abs": "Ofset (sn)", "lbl_stream_hostname": "Akış URL'sinden Hostname Filtresi", "opt_plr_off": "Kapalı", "opt_plr_on": "Açık", "opt_int_on": "Açık", "opt_int_off": "Kapalı", "opt_sl_off": "Kapalı", "opt_sl_on": "Açık", "opt_rec_off": "Kapalı", "opt_rec_on": "Açık", "lbl_clear_cache_on_save": "Kaydetmede Önbelleği Temizle", "opt_ccs_off": "Kapalı", "opt_ccs_on": "Açık", "lbl_frag": "URL Parçası", "lbl_arch": "Arşiv URL Deseni", "opt_std": "Standart (utc/lutc parametreleri)", "lbl_epg": "EPG Kaynağı", "opt_ottp": "ottp.eu.org veritabanı (önerilir)", "opt_api": "Sağlayıcının kendi API URL'si", "lbl_epg_url": "EPG API URL Şablonu", "lbl_xtream_type": "Xtream Türü", "lbl_xtream_url": "Xtream URL'si", "lbl_xtream_username": "Xtream Kullanıcı Adı", "lbl_xtream_password": "Xtream Parola", "lbl_xtream_token": "Xtream Simgesi", "lbl_xtream_output": "Akış Çıktısı", "opt_xt_m3u8": "HLS / m3u8 (Önerilir)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Buket Stratejisi", "opt_xts_same": "Sağlayıcı ile Aynı", "opt_ord_user_xt": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_xt_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top_xt": "Yeni Kanallar Üstte", "opt_upd_bot_xt": "Yeni Kanallar Altta", "lbl_xtream_show_live": "Canlı TV Buketleri Oluştur", "opt_xtlive_yes": "Evet", "opt_xtlive_no": "Hayır", "lbl_xtream_show_vod": "VOD Buketleri Oluştur", "opt_xtvod_yes": "Evet", "opt_xtvod_no": "Hayır", "lbl_xtream_show_series": "Dizi Buketleri Oluştur", "opt_xtser_yes": "Evet", "opt_xtser_no": "Hayır", "lbl_xtream_picon": "Pikonları İndir", "opt_xtp_off": "Kapalı", "opt_xtp_dn": "Görünen Ad ile", "opt_xtp_ref": "Referans Numarası ile", "lbl_xtream_picon_folder": "Sağlayıcı Klasörü ile", "opt_xtp_folder_on": "Açık", "opt_xtp_folder_off": "Kapalı", "lbl_xtream_picon_symlink": "Sembolik Bağlantı Oluştur", "opt_xtp_sym_off": "Kapalı", "opt_xtp_sym_on": "Açık", "opt_markers_off_xt": "Kapalı", "opt_markers_on_xt": "Açık", "lbl_xt_custom_epg": "Özel EPG Dosyası", "opt_xt_cepg_on": "Açık", "opt_xt_cepg_off": "Kapalı", "lbl_xtream_clean": "Buketleri Temizle", "opt_xclean_no": "Hayır", "opt_xclean_yes": "Evet", "lbl_bouquets": "Buketler", "lbl_ch_title": "Kanallar"};
  var _T={'DE':_DE,'FR':_FR,'ES':_ES,'IT':_IT,'PL':_PL,'RU':_RU,'TR':_TR,'UK':_UK};
  var _LM={'DEU':'DE','GER':'DE','FRA':'FR','FRE':'FR','ESP':'ES','ITA':'IT','POL':'PL','RUS':'RU','TUR':'TR','UKR':'UK'};
  function _applyLang(){
    if(!L)return;
    for(var id in L){
      if(!L.hasOwnProperty(id))continue;
      var el=document.getElementById(id);
      if(el&&L[id])el.textContent=L[id];
    }
  }


function _txt(id, txt) {
  var el = document.getElementById(id);
  if (el) el.textContent = txt;
}
function _html(id, h) {
  var el = document.getElementById(id);
  if (el) el.innerHTML = h;
}

window.addEventListener('DOMContentLoaded', function() {
  if (_IS_RU) {
    var r = _RU_PL;
    document.querySelector('h1').innerHTML = r['add_title'];
    document.querySelector('.sub').textContent = r['sub_add'];
    _txt('lbl_name',      r['lbl_name']);
    _txt('lbl_m3u',       r['lbl_m3u']);
    _txt('lbl_xmltv',     r['lbl_xmltv']);
    _txt('hint_xmltv',    r['hint_xmltv']);
    _txt('lbl_epg_parse', r['lbl_epg_parse']);
    _txt('hint_epg_parse',r['hint_epg_parse']);
    _txt('opt_epg_off',   r['opt_epg_off']);
    _txt('opt_epg_dn',    r['opt_epg_dn']);
    _txt('opt_epg_tvg',   r['opt_epg_tvg']);
    _txt('lbl_strategy',  r['lbl_strategy']);
    _txt('opt_same',      r['opt_same']);
    _txt('opt_all',       r['opt_all']);
    _txt('opt_allg',      r['opt_allg']);
    _txt('opt_psub',      r['opt_psub']);
    _txt('lbl_playback',  r['lbl_playback']);
    _txt('lbl_order',        r['lbl_order']);
    _txt('opt_ord_prov',     r['opt_ord_prov']);
    _txt('opt_ord_alpha',    r['opt_ord_alpha']);
    _txt('opt_ord_user',     r['opt_ord_user']);
    _txt('lbl_update_mode',  r['lbl_update_mode']);
    _txt('opt_upd_top',      r['opt_upd_top']);
    _txt('opt_upd_bot',      r['opt_upd_bot']);
    _txt('lbl_picon',          r['lbl_picon']);
    _txt('opt_picon_off',      r['opt_picon_off']);
    _txt('opt_picon_on',       r['opt_picon_on']);
    _txt('lbl_pic_naming',     r['lbl_pic_naming']);
    _txt('opt_pic_dn',         r['opt_pic_dn']);
    _txt('opt_pic_ref',        r['opt_pic_ref']);
    _txt('lbl_pic_folder',     r['lbl_pic_folder']);
    _txt('opt_pic_folder_on',  r['opt_pic_folder_on']);
    _txt('opt_pic_folder_off', r['opt_pic_folder_off']);
    _txt('lbl_pic_symlink',    r['lbl_pic_symlink']);
    _txt('opt_pic_sym_off',    r['opt_picon_off']);
    _txt('opt_pic_sym_on',     r['opt_picon_on']);
    _txt('lbl_pic_mount_note', r['lbl_pic_mount_note']);
    _txt('opt_gstp',           r['opt_gstp']);
    _txt('opt_dvb',            r['opt_dvb']);
    _txt('lbl_clean_bouquets',   r['lbl_clean_bouquets']);
    _txt('opt_clean_off',        r['opt_clean_off']);
    _txt('opt_clean_on',         r['opt_clean_on']);
    _txt('lbl_create_archives',  r['lbl_create_archives']);
    _txt('opt_arch_off',         r['opt_arch_off']);
    _txt('opt_arch_on',          r['opt_arch_on']);
    _txt('lbl_create_archive_markers', r['lbl_create_archive_markers']);
    _txt('opt_markers_off',      r['opt_markers_off']);
    _txt('opt_markers_on',       r['opt_markers_on']);
    _txt('lbl_archive_days',     r['lbl_archive_days']);
    _txt('lbl_cache_ttl_custom', r['lbl_cache_ttl_custom']);
    _txt('opt_ttl_off',          r['opt_ttl_off']);
    _txt('opt_ttl_on',           r['opt_ttl_on']);
    _txt('lbl_cache_ttl_days',   r['lbl_cache_ttl_days']);
    _txt('lbl_offset_section',   r['lbl_offset_section']);
    _txt('lbl_time_offset_sign', r['lbl_time_offset_sign']);
    _txt('lbl_time_offset_abs',  r['lbl_time_offset_abs']);
    _txt('lbl_stream_hostname',  r['lbl_stream_hostname']);
    _txt('lbl_player_override',  r['lbl_player_override']);
    _txt('opt_plr_off',          r['opt_plr_off']);
    _txt('opt_plr_on',           r['opt_plr_on']);
    _txt('lbl_player_int',       r['lbl_player_int']);
    _txt('lbl_player_sl',        r['lbl_player_sl']);
    _txt('lbl_player_rec',       r['lbl_player_rec']);
    _txt('lbl_clear_cache_on_save', r['lbl_clear_cache_on_save']);
    _txt('opt_ccs_off',          r['opt_ccs_off']);
    _txt('opt_ccs_on',           r['opt_ccs_on']);
    _txt('lbl_enabled',   r['lbl_enabled']);
    _txt('opt_yes',       r['opt_yes']);
    _txt('opt_no',        r['opt_no']);
    _txt('btn_browse_m3u',   r['btn_browse']);
    _txt('btn_browse_xmltv', r['btn_browse']);
    _html('btn_send', r['btn_send']);
    _html('ok_msg',   r['ok_msg']);
  }

  if (!PREFILL) { toggleUpdateMode(); togglePiconSection(); return; }
  ['name','xmltv_url','m3u_source','bouquet_strategy',
   'epg_parse_type','playback_with','channel_order','update_mode_sub',
   'picon_enabled','picon_naming','picon_with_folder','picon_symlink',
   'custom_epg_enabled',
   'clean_bouquets','create_archives','create_archive_markers','archive_days',
   'cache_ttl_custom','cache_ttl_days','time_offset_sign','time_offset_abs',
   'stream_hostname','player_override','player_int_on','player_sl_on','player_rec_on',
   'clear_cache_on_save','enabled'].forEach(function(k) {
    var el = document.getElementById(k);
    if (el && PREFILL[k] !== undefined && PREFILL[k] !== null) {
      if (k === 'create_archive_markers' || k === 'custom_epg_enabled' ||
          k === 'picon_enabled' || k === 'picon_with_folder' || k === 'picon_symlink' ||
          k === 'create_archives' || k === 'clean_bouquets' || k === 'enabled') {
        el.value = (PREFILL[k] === true || PREFILL[k] === '1' || PREFILL[k] === 'true') ? '1' : '0';
      } else {
        el.value = PREFILL[k];
      }
    }
  });
  toggleUpdateMode();
  togglePiconSection();
  toggleArchivesSection();
  toggleTTLDays();
  togglePlayerSection();
  if (PREFILL._is_edit) {
    if (_IS_RU) {
      document.querySelector('h1').innerHTML = _RU_PL['edit_title'];
      document.querySelector('.sub').textContent = _RU_PL['sub_edit'];
    } else {
      document.querySelector('h1').innerHTML = '&#9998;&nbsp;Edit IPTV Playlist/Archives Provider';
      document.querySelector('.sub').textContent =
        'IPTV Playlist/Archives Creator \u2014 change what you need and press Send';
    }
  }
  _applyLang();
});

function browseM3U()   { document.getElementById('m3u_file').click(); }
function browseXMLTV() { document.getElementById('xmltv_file').click(); }

function togglePiconSection() {
  var en = document.getElementById('picon_enabled');
  var sec = document.getElementById('picon_sub_section');
  if (!sec) return;
  if (en && en.value === '1') {
    sec.style.display = 'block';
  } else {
    sec.style.display = 'none';
  }
}

function toggleXtreamUpdateMode() {
  var ord = document.getElementById('channel_order');
  var sec = document.getElementById('xtream_update_mode_section');
  if (!sec) return;
  sec.style.display = (ord && ord.value === 'user_defined') ? 'block' : 'none';
}

function toggleXtreamPiconSection() {
  var val = document.getElementById('xtream_picon');
  var sec = document.getElementById('xtream_picon_sub_section');
  if (!sec) return;
  if (val && val.value !== 'off') {
    sec.style.display = 'block';
  } else {
    sec.style.display = 'none';
  }
}

function toggleUpdateMode() {
  var isUser = document.getElementById('channel_order').value === 'user_defined';
  document.getElementById('update_mode_section').style.display = isUser ? '' : 'none';
}

function toggleArchivesSection() {
  var en  = document.getElementById('create_archives');
  var sec = document.getElementById('archives_sub_section');
  if (!sec) return;
  sec.style.display = (en && en.value === '1') ? 'block' : 'none';
  toggleTTLDays();
  togglePlayerSection();
}

function toggleTTLDays() {
  var en  = document.getElementById('cache_ttl_custom');
  var sec = document.getElementById('ttl_days_section');
  if (!sec) return;
  sec.style.display = (en && en.value === '1') ? 'block' : 'none';
}

function togglePlayerSection() {
  var en  = document.getElementById('player_override');
  var sec = document.getElementById('player_sub_section');
  if (!sec) return;
  sec.style.display = (en && en.value === '1') ? 'block' : 'none';
}

function _doUpload(file, statusId, targetInputId, extraHeaders) {
  var status = document.getElementById(statusId);
  status.className = 'upload-status uploading';
  status.textContent = _IS_RU
    ? ('\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u00ab' + file.name + '\u00bb \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u2026')
    : ('Uploading \u201c' + file.name + '\u201d to receiver\u2026');
  var reader = new FileReader();
  reader.onload = function(e) {
    var safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    var hdrs = {
      'Content-Type': 'application/octet-stream',
      'X-Filename': encodeURIComponent(safeName),
      'X-ProviderName': encodeURIComponent(document.getElementById('name').value || '')
    };
    if (extraHeaders) { Object.assign(hdrs, extraHeaders); }
    fetch('/upload', {
      method: 'POST',
      headers: hdrs,
      body: e.target.result
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.path) {
        document.getElementById(targetInputId).value = data.path;
        status.className = 'upload-status done';
        status.textContent = _IS_RU
          ? ('\u2713 \u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u043e \u2014 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435: ' + data.path)
          : ('\u2713 Uploaded \u2014 saved on receiver as: ' + data.path);
      } else {
        throw new Error(data.error || (_IS_RU ? '\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f \u043e\u0448\u0438\u0431\u043a\u0430' : 'unknown error'));
      }
    })
    .catch(function(err) {
      status.className = 'upload-status err';
      status.textContent = _IS_RU
        ? ('\u2717 \u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438: ' + err.message)
        : ('\u2717 Upload failed: ' + err.message);
    });
  };
  reader.onerror = function() {
    status.className = 'upload-status err';
    status.textContent = _IS_RU
      ? '\u2717 \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u0444\u0430\u0439\u043b.'
      : '\u2717 Could not read the file.';
  };
  reader.readAsArrayBuffer(file);
}

document.getElementById('xmltv_file').addEventListener('change', function() {
  var f = this.files[0]; if (!f) return;
  _doUpload(f, 'xmltv_status', 'xmltv_url', {'X-FileType': 'epg'}); this.value = '';
});
document.getElementById('m3u_file').addEventListener('change', function() {
  var f = this.files[0]; if (!f) return;
  _doUpload(f, 'upload_status', 'm3u_source'); this.value = '';
});

function sendData() {
  var fields = ['name','xmltv_url','m3u_source','epg_parse_type','bouquet_strategy',
                'playback_with','channel_order','update_mode_sub',
                'picon_enabled','picon_naming','picon_with_folder','picon_symlink',
                'custom_epg_enabled',
                'clean_bouquets','create_archives','create_archive_markers','archive_days',
                'cache_ttl_custom','cache_ttl_days','time_offset_sign','time_offset_abs',
                'stream_hostname','player_override','player_int_on','player_sl_on',
                'player_rec_on','clear_cache_on_save','enabled'];
  var parts = fields.map(function(k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(document.getElementById(k).value);
  });
  fetch('/', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: parts.join('&')
  }).then(function(r) {
    if (r.ok) {
      document.getElementById('f').style.display = 'none';
      document.getElementById('ok').style.display = 'block';
    } else {
      alert(_IS_RU ? '\u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.' : 'Error sending data. Please try again.');
    }
  }).catch(function() {
    alert(_IS_RU ? '\u041d\u0435 \u0443\u0434\u0430\u0451\u0442\u0441\u044f \u0441\u0432\u044f\u0437\u0430\u0442\u044c\u0441\u044f \u0441 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u043e\u043c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u0435\u0442\u044c.' : 'Could not reach receiver. Check that you are on the same network.');
  });
}
</script>
</body>
</html>"""

# ---------------------------------------------------------------------------
# HTML form for Integrated Provider editor (Edit Archives From Provider)
# ---------------------------------------------------------------------------

_HTML_INTEGRATED = u"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edit Archives From Provider</title>
<link rel="icon" href="data:,">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#12121f;color:#dde1f0;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{background:#1a1f38;border-radius:16px;padding:36px 40px;width:100%;
      max-width:620px;box-shadow:0 12px 48px rgba(0,0,0,.7)}
h1{font-size:22px;color:#e94560;text-align:center;letter-spacing:1px;margin-bottom:4px}
.sub{text-align:center;color:#6b7599;font-size:13px;margin-bottom:28px}
label{display:block;font-size:15px;color:#f0c040;font-weight:600;
      margin-top:18px;margin-bottom:5px}
input[type=text],input[type=number],select{
  width:100%;padding:10px 14px;background:#0d1530;
  border:1.5px solid #1e3560;border-radius:8px;
  color:#dde1f0;font-size:15px;outline:none;transition:border .2s}
input[type=text]:focus,input[type=number]:focus,select:focus{border-color:#e94560}
select option{background:#0d1530}
.hint{font-size:12px;color:#4a5578;margin-top:4px}
#update_mode_section label,#picon_sub_section label,#archives_sub_section label{color:#2ecc71}
.btn{margin-top:30px;width:100%;padding:14px;background:#e94560;color:#fff;
     border:none;border-radius:10px;font-size:17px;font-weight:bold;
     cursor:pointer;letter-spacing:.5px;transition:background .2s}
.btn:hover{background:#c73652}
.ok{display:none;background:#152b1e;border:1.5px solid #2ecc71;color:#2ecc71;
    border-radius:10px;padding:18px;text-align:center;margin-top:20px;font-size:16px}
</style>
</head>
<body>
<div class="card">
  <h1 id="h_title">&#9998; Edit Archives From Provider</h1>
  <p class="sub" id="h_sub">CustomIPTVArchiveMakerPro &mdash; fill in the fields and press Send</p>

  <form id="f">
    <label for="name" id="lbl_name">Provider Name</label>
    <input type="text" id="name" name="name" placeholder="My IPTV Provider">

    <label for="url_fragment" id="lbl_frag">URL Fragment</label>
    <input type="text" id="url_fragment" name="url_fragment"
           placeholder="unique part of the stream URL, e.g. myserver.com">
    <div class="hint" id="hint_frag">A unique substring of the stream URL that identifies this provider</div>

    <label for="days" id="lbl_days">Archive Days (1&ndash;7)</label>
    <input type="number" id="days" name="days" value="7" min="1" max="7">

    <label for="archive_pattern" id="lbl_arch">Archive URL Pattern</label>
    <select id="archive_pattern" name="archive_pattern">
      <option value="standard"       id="opt_std">Standard (utc/lutc params)</option>
      <option value="path_archive"   id="opt_pa">Path Archive (archive-start-dur.m3u8)</option>
      <option value="path_timeshift" id="opt_pts">Path Timeshift (video-timeshift_abs-start.m3u8)</option>
      <option value="simple_offset"  id="opt_so">Simple Offset (archive=start)</option>
    </select>

    <label for="epg_pattern" id="lbl_epg">EPG Source</label>
    <select id="epg_pattern" name="epg_pattern">
      <option value="ottp"         id="opt_ottp">ottp.eu.org database (recommended)</option>
      <option value="provider_api" id="opt_api">Provider own API URL</option>
    </select>

    <label for="epg_url_template" id="lbl_epg_url">EPG API URL Template</label>
    <input type="text" id="epg_url_template" name="epg_url_template"
           placeholder="https://api.myprovider.com/epg/{channel_id}">
    <div class="hint" id="hint_epg_url">{channel_id} is replaced with the actual channel identifier</div>

    <label for="enabled" id="lbl_enabled">Enabled</label>
    <select id="enabled" name="enabled">
      <option value="1" id="opt_yes">Yes</option>
      <option value="0" id="opt_no">No</option>
    </select>

    <button class="btn" type="button" onclick="sendData()" id="btn_send">
      &#10148;&nbsp; Send to Receiver
    </button>
  </form>

  <div class="ok" id="ok">
    <span id="ok_msg">&#10003;&nbsp; Data sent to your receiver!<br>
    The provider fields have been filled in automatically.<br>
    You can close this tab and press <strong>Save</strong> on the receiver.</span>
  </div>
</div>

<script>
var _RU_INT = {
  'h_title':     '\u270e\u00a0 \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0430\u0440\u0445\u0438\u0432\u044b \u043e\u0442 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'h_sub':       'CustomIPTVArchiveMakerPro \u2014 \u0437\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043f\u043e\u043b\u044f \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'lbl_name':    '\u0418\u043c\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_frag':    'URL \u0444\u0440\u0430\u0433\u043c\u0435\u043d\u0442',
  'hint_frag':   '\u0423\u043d\u0438\u043a\u0430\u043b\u044c\u043d\u0430\u044f \u0447\u0430\u0441\u0442\u044c URL \u043f\u043e\u0442\u043e\u043a\u0430, \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u044f\u044e\u0449\u0430\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_days':    '\u0414\u043d\u0435\u0439 \u0430\u0440\u0445\u0438\u0432\u0430 (1\u20137)',
  'lbl_arch':    '\u0428\u0430\u0431\u043b\u043e\u043d URL \u0430\u0440\u0445\u0438\u0432\u0430',
  'opt_std':     '\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 (utc/lutc \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b)',
  'opt_pa':      '\u041f\u0443\u0442\u044c \u0430\u0440\u0445\u0438\u0432\u0430 (archive-start-dur.m3u8)',
  'opt_pts':     '\u041f\u0443\u0442\u044c \u0442\u0430\u0439\u043c\u0448\u0438\u0444\u0442 (video-timeshift_abs-start.m3u8)',
  'opt_so':      '\u041f\u0440\u043e\u0441\u0442\u043e\u0435 \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0435 (archive=start)',
  'lbl_epg':     '\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a EPG',
  'opt_ottp':    '\u0411\u0430\u0437\u0430 ottp.eu.org (\u0440\u0435\u043a\u043e\u043c\u0435\u043d\u0434\u0443\u0435\u0442\u0441\u044f)',
  'opt_api':     '\u0421\u0432\u043e\u0439 URL API \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_epg_url': '\u0428\u0430\u0431\u043b\u043e\u043d URL EPG API',
  'hint_epg_url':'{channel_id} \u0437\u0430\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0438\u0434\u0435\u043d\u0442\u0438\u0444\u0438\u043a\u0430\u0442\u043e\u0440\u043e\u043c \u043a\u0430\u043d\u0430\u043b\u0430',
  'lbl_enabled': '\u0412\u043a\u043b\u044e\u0447\u0451\u043d',
  'opt_yes':     '\u0414\u0430',
  'opt_no':      '\u041d\u0435\u0442',
  'btn_send':    '&#10148;\u00a0 \u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a',
  'ok_msg':      '\u2713\u00a0 \u0414\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u044b!<br>\u041f\u043e\u043b\u044f \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.<br>\u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u043a\u043b\u0430\u0434\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 <strong>\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</strong> \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435.'
};

var PREFILL = /*PREFILL_JSON*/null/*END_PREFILL*/;
var L = /*L_JSON*/{}/*END_L*/;
var _IS_RU  = (PREFILL && PREFILL.ui_language === 'RUS');

function _txt(id, txt) { var e = document.getElementById(id); if (e) e.textContent = txt; }
function _html(id, h)  { var e = document.getElementById(id); if (e) e.innerHTML = h; }

window.addEventListener('DOMContentLoaded', function() {
  if (_IS_RU) {
    var r = _RU_INT;
    _html('h_title',     r['h_title']);
    _txt('h_sub',        r['h_sub']);
    _txt('lbl_name',     r['lbl_name']);
    _txt('lbl_frag',     r['lbl_frag']);
    _txt('hint_frag',    r['hint_frag']);
    _txt('lbl_days',     r['lbl_days']);
    _txt('lbl_arch',     r['lbl_arch']);
    _txt('opt_std',      r['opt_std']);
    _txt('opt_pa',       r['opt_pa']);
    _txt('opt_pts',      r['opt_pts']);
    _txt('opt_so',       r['opt_so']);
    _txt('lbl_epg',      r['lbl_epg']);
    _txt('opt_ottp',     r['opt_ottp']);
    _txt('opt_api',      r['opt_api']);
    _txt('lbl_epg_url',  r['lbl_epg_url']);
    _txt('hint_epg_url', r['hint_epg_url']);
    _txt('lbl_enabled',  r['lbl_enabled']);
    _txt('opt_yes',      r['opt_yes']);
    _txt('opt_no',       r['opt_no']);
    _html('btn_send',    r['btn_send']);
    _html('ok_msg',      r['ok_msg']);
  }
  if (!PREFILL) { return; }
  ['name','url_fragment','days','archive_pattern','epg_pattern',
   'epg_url_template','enabled'].forEach(function(k) {
    var el = document.getElementById(k);
    if (el && PREFILL[k] !== undefined && PREFILL[k] !== null) el.value = PREFILL[k];
  });
  _applyLang();
});

function sendData() {
  var parts = ['name','url_fragment','days','archive_pattern','epg_pattern',
               'epg_url_template','enabled'].map(function(k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(document.getElementById(k).value);
  });
  fetch('/', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: parts.join('&')
  }).then(function(r) {
    if (r.ok) {
      document.getElementById('f').style.display = 'none';
      document.getElementById('ok').style.display = 'block';
    } else {
      alert(_IS_RU ? '\u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.' : 'Error sending data. Please try again.');
    }
  }).catch(function() {
    alert(_IS_RU ? '\u041d\u0435 \u0443\u0434\u0430\u0451\u0442\u0441\u044f \u0441\u0432\u044f\u0437\u0430\u0442\u044c\u0441\u044f \u0441 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u043e\u043c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u0435\u0442\u044c.' : 'Could not reach receiver. Check that you are on the same network.');
  });
}
</script>
</body>
</html>"""

# ---------------------------------------------------------------------------
# HTML form for Xtream Provider (Xtream Media Creator — Xtream-only fields)
# ---------------------------------------------------------------------------

_HTML_XTREAM = u"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Xtream Media Provider</title>
<link rel="icon" href="data:,">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#12121f;color:#dde1f0;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{background:#1a1f38;border-radius:16px;padding:36px 40px;width:100%;
      max-width:620px;box-shadow:0 12px 48px rgba(0,0,0,.7)}
h1{font-size:22px;color:#e94560;text-align:center;letter-spacing:1px;margin-bottom:4px}
.sub{text-align:center;color:#6b7599;font-size:13px;margin-bottom:28px}
label{display:block;font-size:15px;color:#f0c040;font-weight:600;
      margin-top:18px;margin-bottom:5px}
input[type=text],select{
  width:100%;padding:10px 14px;background:#0d1530;
  border:1.5px solid #1e3560;border-radius:8px;
  color:#dde1f0;font-size:15px;outline:none;transition:border .2s}
input[type=text]:focus,select:focus{border-color:#e94560}
select option{background:#0d1530}
.hint{font-size:12px;color:#4a5578;margin-top:4px}
#update_mode_section label,#picon_sub_section label,#archives_sub_section label{color:#2ecc71}
.divider{border:none;border-top:1px solid #252d50;margin-top:22px}
.sec{font-size:11px;font-weight:700;color:#e94560;letter-spacing:.08em;
     text-transform:uppercase;margin-top:24px;margin-bottom:2px}
.btn{margin-top:30px;width:100%;padding:14px;background:#e94560;color:#fff;
     border:none;border-radius:10px;font-size:17px;font-weight:bold;
     cursor:pointer;letter-spacing:.5px;transition:background .2s}
.btn:hover{background:#c73652}
.ok{display:none;background:#152b1e;border:1.5px solid #2ecc71;color:#2ecc71;
    border-radius:10px;padding:18px;text-align:center;margin-top:20px;font-size:16px}
</style>
</head>
<body>
<div class="card">
  <h1 id="h_title">&#9654; Add Xtream Provider</h1>
  <p class="sub" id="h_sub">Xtream Media Creator &mdash; fill in the fields and press Send</p>

  <form id="f">

    <!-- ── General ─────────────────────────────────────────────────────── -->
    <p class="sec" id="sec_general">General</p>

    <label for="name" id="lbl_name">Provider Name</label>
    <input type="text" id="name" name="name" placeholder="My Xtream Provider">

    <label for="enabled" id="lbl_enabled">Enabled</label>
    <select id="enabled" name="enabled">
      <option value="1" id="opt_yes">Yes</option>
      <option value="0" id="opt_no">No</option>
    </select>

    <!-- ── Credentials ──────────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_creds">Credentials</p>

    <label for="xtream_type" id="lbl_xtream_type">Xtream Type</label>
    <select id="xtream_type" name="xtream_type" onchange="toggleXtreamType()">
      <option value="user_pass" id="opt_xt_up">Xtream Codes (Username / Password)</option>
      <option value="token"     id="opt_xt_tok">Xtream (Token)</option>
    </select>

    <label for="xtream_url" id="lbl_xtream_url">Xtream URL</label>
    <input type="text" id="xtream_url" name="xtream_url"
           placeholder="http://provider.com:8080">

    <div id="xtream_userpass_div">
      <label for="xtream_username" id="lbl_xtream_username">Xtream Username</label>
      <input type="text" id="xtream_username" name="xtream_username" placeholder="username">
      <label for="xtream_password" id="lbl_xtream_password">Xtream Password</label>
      <input type="text" id="xtream_password" name="xtream_password" placeholder="password">
    </div>

    <div id="xtream_token_div" style="display:none">
      <label for="xtream_token" id="lbl_xtream_token">Xtream Token</label>
      <input type="text" id="xtream_token" name="xtream_token" placeholder="token">
    </div>

    <!-- ── Bouquet Options ───────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_bouquet">Bouquet Options</p>

    <label for="xtream_output" id="lbl_xtream_output">Stream Output</label>
    <select id="xtream_output" name="xtream_output">
      <option value="m3u8" id="opt_xt_m3u8">HLS / m3u8 (Recommended)</option>
      <option value="ts"   id="opt_xt_ts">TS</option>
    </select>

    <label for="xtream_strategy" id="lbl_xtream_strategy">Bouquet Strategy</label>
    <select id="xtream_strategy" name="xtream_strategy">
      <option value="same_as_provider"  id="opt_xts_same">Same As Provider</option>
      <option value="group_into_folder" id="opt_xts_folder">Group All Into One Folder</option>
    </select>

    <label for="channel_order" id="lbl_order">Channels Ordering By</label>
    <select id="channel_order" name="channel_order" onchange="toggleXtreamUpdateMode()">
      <option value="provider"     id="opt_ord_prov">Use Provider Order</option>
      <option value="alphabetical" id="opt_ord_alpha">Alphabetically</option>
      <option value="user_defined" id="opt_ord_user_xt">User Defined (Use for Sorted Channels/Bouquets)</option>
    </select>
    <div id="xtream_update_mode_section" style="display:none">
      <label for="update_mode_sub" id="lbl_xt_update_mode">Update M3U Playlist Only</label>
      <select id="update_mode_sub" name="update_mode_sub">
        <option value="top"    id="opt_upd_top_xt">New Channels on Top</option>
        <option value="bottom" id="opt_upd_bot_xt">New Channels on Bottom</option>
      </select>
    </div>

    <!-- ── Live TV ───────────────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_live">Live TV</p>

    <label for="xtream_show_live" id="lbl_xtream_show_live">Build Live TV Bouquets</label>
    <select id="xtream_show_live" name="xtream_show_live" onchange="toggleStreamSubrows()">
      <option value="1" id="opt_xtlive_yes">Yes</option>
      <option value="0" id="opt_xtlive_no">No</option>
    </select>

    <div id="live_type_row">
      <label for="xtream_live_type" id="lbl_xtream_live_type">Live Stream Type</label>
      <select id="xtream_live_type" name="xtream_live_type">
        <option value="4097" id="opt_lt_4097">GStreamer (4097)</option>
        <option value="5001" id="opt_lt_5001">GstPlayer (5001)</option>
        <option value="5002" id="opt_lt_5002">ExtePlayer3 (5002)</option>
      </select>
    </div>

    <!-- ── VOD ───────────────────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_vod">VOD</p>

    <label for="xtream_show_vod" id="lbl_xtream_show_vod">Build VOD Bouquets</label>
    <select id="xtream_show_vod" name="xtream_show_vod" onchange="toggleStreamSubrows()">
      <option value="1" id="opt_xtvod_yes">Yes</option>
      <option value="0" id="opt_xtvod_no">No</option>
    </select>

    <div id="vod_type_row">
      <label for="xtream_vod_type" id="lbl_xtream_vod_type">VOD Stream Type</label>
      <select id="xtream_vod_type" name="xtream_vod_type">
        <option value="4097" id="opt_vt_4097">GStreamer (4097)</option>
        <option value="5001" id="opt_vt_5001">GstPlayer (5001)</option>
        <option value="5002" id="opt_vt_5002">ExtePlayer3 (5002)</option>
      </select>
    </div>

    <!-- ── Series ────────────────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_series">Series</p>

    <label for="xtream_show_series" id="lbl_xtream_show_series">Build Series Bouquets</label>
    <select id="xtream_show_series" name="xtream_show_series" onchange="toggleStreamSubrows()">
      <option value="1" id="opt_xtser_yes">Yes</option>
      <option value="0" id="opt_xtser_no">No</option>
    </select>

    <div id="series_type_row">
      <label for="xtream_series_type" id="lbl_xtream_series_type">Series Stream Type</label>
      <select id="xtream_series_type" name="xtream_series_type">
        <option value="4097" id="opt_st_4097">GStreamer (4097)</option>
        <option value="5001" id="opt_st_5001">GstPlayer (5001)</option>
        <option value="5002" id="opt_st_5002">ExtePlayer3 (5002)</option>
      </select>
    </div>

    <!-- ── Picons ────────────────────────────────────────────────────────── -->
    <hr class="divider">
    <p class="sec" id="sec_picons">Picons</p>

    <label for="xtream_picon" id="lbl_xtream_picon">Download Picons</label>
    <select id="xtream_picon" name="xtream_picon" onchange="toggleXtreamPiconSection()">
      <option value="off"          id="opt_xtp_off">Off</option>
      <option value="display_name" id="opt_xtp_dn">With Display Name</option>
      <option value="reference"    id="opt_xtp_ref">With Reference Number</option>
    </select>
    <div id="xtream_picon_sub_section" style="display:none">
      <label for="xtream_picon_with_folder" id="lbl_xtream_picon_folder">With Folder</label>
      <select id="xtream_picon_with_folder" name="xtream_picon_with_folder">
        <option value="1" id="opt_xtp_folder_on">On</option>
        <option value="0" id="opt_xtp_folder_off">Off</option>
      </select>
      <label for="xtream_picon_symlink" id="lbl_xtream_picon_symlink">Create Symlink</label>
      <select id="xtream_picon_symlink" name="xtream_picon_symlink">
        <option value="0" id="opt_xtp_sym_off">Off</option>
        <option value="1" id="opt_xtp_sym_on">On</option>
      </select>
      <p id="lbl_xtream_mount_note" style="font-size:0.85em;opacity:0.7;margin:4px 0 0 0">
        &#8505; Mount point is configured on the receiver
      </p>
    </div>

    <!-- ── Clean Bouquets ───────────────────────────────────────────────── -->
    <hr class="divider">
    <label for="create_archive_markers" id="lbl_create_archive_markers">Create Archive Markers ( &#9654; )</label>
    <select id="create_archive_markers" name="create_archive_markers">
      <option value="0" id="opt_markers_off_xt">Off</option>
      <option value="1" id="opt_markers_on_xt">On</option>
    </select>

    <label for="custom_epg_enabled" id="lbl_xt_custom_epg">Custom EPG File</label>
    <select id="custom_epg_enabled" name="custom_epg_enabled">
      <option value="1" id="opt_xt_cepg_on">On</option>
      <option value="0" id="opt_xt_cepg_off">Off</option>
    </select>

    <label for="xtream_clean_bouquets" id="lbl_xtream_clean">Clean Bouquets</label>
    <select id="xtream_clean_bouquets" name="xtream_clean_bouquets">
      <option value="0" id="opt_xclean_no">No</option>
      <option value="1" id="opt_xclean_yes">Yes</option>
    </select>

    <button class="btn" type="button" onclick="sendData()" id="btn_send">
      &#10148;&nbsp; Send to Receiver
    </button>
  </form>

  <div class="ok" id="ok">
    <span id="ok_msg">&#10003;&nbsp; Data sent to your receiver!<br>
    The Xtream provider fields have been filled in automatically.<br>
    You can close this tab and press <strong>Save</strong> on the receiver.</span>
  </div>
</div>

<script>
/* ---- Russian translations for the Xtream web form ---- */
var _RU_XT = {
  'add_title':                   '\u25ba\u00a0 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c Xtream-\u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'edit_title':                  '\u270e\u00a0 \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c Xtream-\u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'sub_add':                     'Xtream Media Creator \u2014 \u0437\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043f\u043e\u043b\u044f \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'sub_edit':                    'Xtream Media Creator \u2014 \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u0435 \u043d\u0443\u0436\u043d\u043e\u0435 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u00bb',
  'sec_general':                 '\u041e\u0431\u0449\u0435\u0435',
  'lbl_name':                    '\u0418\u043c\u044f \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'lbl_enabled':                 '\u0412\u043a\u043b\u044e\u0447\u0451\u043d',
  'opt_yes':                     '\u0414\u0430',
  'opt_no':                      '\u041d\u0435\u0442',
  'sec_creds':                   '\u0414\u0430\u043d\u043d\u044b\u0435 \u0434\u043e\u0441\u0442\u0443\u043f\u0430',
  'lbl_xtream_type':             'Xtream \u0422\u0438\u043f',
  'opt_xt_up':                   'Xtream Codes (\u0418\u043c\u044f/\u041f\u0430\u0440\u043e\u043b\u044c)',
  'opt_xt_tok':                  'Xtream (\u0422\u043e\u043a\u0435\u043d)',
  'lbl_xtream_url':              'Xtream URL',
  'lbl_xtream_username':         'Xtream \u0418\u043c\u044f \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f',
  'lbl_xtream_password':         'Xtream \u041f\u0430\u0440\u043e\u043b\u044c',
  'lbl_xtream_token':            'Xtream \u0422\u043e\u043a\u0435\u043d',
  'sec_bouquet':                 '\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0431\u0443\u043a\u0435\u0442\u043e\u0432',
  'lbl_xtream_output':           '\u0424\u043e\u0440\u043c\u0430\u0442 \u043f\u043e\u0442\u043e\u043a\u0430',
  'opt_xt_m3u8':                 'HLS / m3u8 (\u0420\u0435\u043a\u043e\u043c\u0435\u043d\u0434\u0443\u0435\u0442\u0441\u044f)',
  'opt_xt_ts':                   'TS',
  'lbl_xtream_strategy':         '\u0421\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u044f \u0431\u0443\u043a\u0435\u0442\u043e\u0432',
  'opt_xts_same':                '\u041a\u0430\u043a \u0443 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_xts_folder':              '\u0413\u0440\u0443\u043f\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0432\u0441\u0451 \u0432 \u043e\u0434\u043d\u0443 \u043f\u0430\u043f\u043a\u0443',
  'lbl_order':                   '\u041f\u043e\u0440\u044f\u0434\u043e\u043a \u043a\u0430\u043d\u0430\u043b\u043e\u0432',
  'opt_ord_prov':                '\u041f\u043e\u0440\u044f\u0434\u043e\u043a \u0438\u0437 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_ord_alpha':               '\u041f\u043e \u0430\u043b\u0444\u0430\u0432\u0438\u0442\u0443',
  'opt_ord_user_xt':             '\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 (\u0438\u0441\u043f. \u0434\u043b\u044f \u0441\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432/\u0431\u0443\u043a\u0435\u0442\u043e\u0432)',
  'lbl_xt_update_mode':          '\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442',
  'opt_upd_top_xt':              '\u041d\u043e\u0432\u044b\u0435 \u043a\u0430\u043d\u0430\u043b\u044b \u0441\u0432\u0435\u0440\u0445\u0443',
  'opt_upd_bot_xt':              '\u041d\u043e\u0432\u044b\u0435 \u043a\u0430\u043d\u0430\u043b\u044b \u0441\u043d\u0438\u0437\u0443',
  'sec_live':                    'Live TV',
  'lbl_xtream_show_live':        '\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u0431\u0443\u043a\u0435\u0442\u044b Live TV',
  'lbl_xtream_live_type':        '\u0422\u0438\u043f \u043f\u043e\u0442\u043e\u043a\u0430 Live',
  'opt_gst_4097':                'GStreamer (4097)',
  'opt_gst_5001':                'GstPlayer (5001)',
  'opt_gst_5002':                'ExtePlayer3 (5002)',
  'sec_vod':                     'VOD',
  'lbl_xtream_show_vod':         '\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u0431\u0443\u043a\u0435\u0442\u044b VOD',
  'lbl_xtream_vod_type':         '\u0422\u0438\u043f \u043f\u043e\u0442\u043e\u043a\u0430 VOD',
  'sec_series':                  '\u0421\u0435\u0440\u0438\u0430\u043b\u044b',
  'lbl_xtream_show_series':      '\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u0431\u0443\u043a\u0435\u0442\u044b \u0441\u0435\u0440\u0438\u0430\u043b\u043e\u0432',
  'lbl_xtream_series_type':      '\u0422\u0438\u043f \u043f\u043e\u0442\u043e\u043a\u0430 \u0441\u0435\u0440\u0438\u0430\u043b\u043e\u0432',
  'sec_picons':                  '\u041f\u0438\u043a\u043e\u043d\u044b',
  'lbl_xtream_picon':            '\u0421\u043a\u0430\u0447\u0430\u0442\u044c \u043f\u0438\u043a\u043e\u043d\u044b',
  'opt_xtp_off':                 '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_xtp_dn':                  '\u0421 \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u043c\u044b\u043c \u0438\u043c\u0435\u043d\u0435\u043c',
  'opt_xtp_ref':                 '\u0421 \u043d\u043e\u043c\u0435\u0440\u043e\u043c \u0441\u0441\u044b\u043b\u043a\u0438',
  'lbl_xtream_picon_folder':     '\u0421 \u043f\u0430\u043f\u043a\u043e\u0439 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430',
  'opt_xtp_folder_on':           '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_xtp_folder_off':          '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_xtream_picon_symlink':    '\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0441\u0438\u043c\u043b\u0438\u043d\u043a',
  'opt_xtp_sym_off':             '\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'opt_xtp_sym_on':              '\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e',
  'lbl_xtream_clean':           '\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0431\u0443\u043a\u0435\u0442\u044b',
  'opt_xclean_no':              '\u041d\u0435\u0442',
  'opt_xclean_yes':             '\u0414\u0430',
  'lbl_xtream_mount_note':       '\u2139 \u0422\u043e\u0447\u043a\u0430 \u043c\u043e\u043d\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435',
  'btn_send':                    '&#10148;\u00a0 \u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a',
  'ok_msg':                      '\u2713\u00a0 \u0414\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u044b \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a!<br>\u041f\u043e\u043b\u044f Xtream-\u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.<br>\u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u043a\u043b\u0430\u0434\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 <strong>\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</strong> \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435.'
};

var PREFILL = /*PREFILL_JSON*/null/*END_PREFILL*/;
var L = /*L_JSON*/{}/*END_L*/;
var _IS_RU = (PREFILL && PREFILL.ui_language === 'RUS');
  /* ---- Multi-language translations ---- */
  var _DE={"lbl_name": "Anbieter-Name", "lbl_xmltv": "XMLTV-URL / Lokale Datei", "lbl_m3u": "M3U-URL / M3U-Playlist", "lbl_days": "Archivtage (1-7)", "lbl_ttl_section": "TTL-Tage für gecachte Dateien (verfügbare Archivtage eingeben)", "lbl_ttl_custom": "Eigene TTL", "lbl_ttl_days": "  TTL-Tage (1-7)", "lbl_sign": "Versatz Vorzeichen", "opt_plus": "+  später", "opt_minus": "-  früher", "lbl_abs": "Versatz Sekunden", "lbl_hostname": "Stream-Hostname-Filter (für Zeitversatz)", "lbl_player_section": "Player-Auswahl", "lbl_player_hint": "Player-Einstellungen überschreiben.", "lbl_player_override": "Player-Überschreibung (anbieterspezifisch)", "lbl_player_int": "Player: Integriert", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Empfänger", "lbl_enabled": "Aktiviert", "opt_yes": "Ja", "opt_no": "Nein", "lbl_epg_parse": "EPG-Datei erstellen", "opt_epg_off": "Aus", "opt_epg_dn": "Nach Anzeigename", "opt_epg_tvg": "Nach tvg-id", "lbl_strategy": "Bouquet-Erstellungsstrategie", "opt_same": "Wie in Playlist", "opt_all": "Bouquet für alle Kanäle", "opt_allg": "Bouquets für alle Kanäle und Gruppen", "opt_psub": "Bouquet mit Anbieter-Name und Sub-Bouquets", "lbl_playback": "Wiedergabe mit", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kanal-Reihenfolge nach", "opt_ord_prov": "Anbieter-Reihenfolge verwenden", "opt_ord_alpha": "Alphabetisch", "opt_ord_user": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top": "Neue Kanäle oben", "opt_upd_bot": "Neue Kanäle unten", "lbl_picon": "Picons herunterladen", "opt_picon_off": "Aus", "opt_picon_on": "Ein", "lbl_pic_naming": "Benennung", "opt_pic_dn": "Mit Anzeigename", "opt_pic_ref": "Mit Referenznummer", "lbl_pic_folder": "Mit Ordner", "opt_pic_folder_on": "Ein", "opt_pic_folder_off": "Aus", "lbl_pic_symlink": "Symlink erstellen", "opt_pic_sym_off": "Aus", "opt_pic_sym_on": "Ein", "lbl_custom_epg": "Benutzerdefiniertes EPG", "opt_cepg_on": "Ein", "opt_cepg_off": "Aus", "lbl_clean_bouquets": "Bouquets bereinigen", "opt_clean_off": "Aus", "opt_clean_on": "Ein", "lbl_create_archives": "Anbieter-Archive erstellen", "opt_arch_off": "Aus", "opt_arch_on": "Ein", "lbl_create_archive_markers": "Archiv-Markierungen erstellen", "opt_markers_off": "Aus", "opt_markers_on": "Ein", "lbl_archive_days": "Archivtage (1-7)", "lbl_cache_ttl_custom": "Eigene TTL", "opt_ttl_off": "Aus (7 Tage)", "opt_ttl_on": "Ein", "lbl_cache_ttl_days": "TTL-Tage (1-30)", "lbl_time_offset_sign": "Versatz +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Versatz (Sek.)", "lbl_stream_hostname": "Hostname-Filter aus Stream-URL", "opt_plr_off": "Aus", "opt_plr_on": "Ein", "opt_int_on": "Ein", "opt_int_off": "Aus", "opt_sl_off": "Aus", "opt_sl_on": "Ein", "opt_rec_off": "Aus", "opt_rec_on": "Ein", "lbl_clear_cache_on_save": "Cache beim Speichern leeren", "opt_ccs_off": "Aus", "opt_ccs_on": "Ein", "lbl_frag": "URL-Fragment", "lbl_arch": "Archiv-URL-Muster", "opt_std": "Standard (utc/lutc-Parameter)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "EPG-Quelle", "opt_ottp": "ottp.eu.org-Datenbank (empfohlen)", "opt_api": "Eigene API-URL des Anbieters", "lbl_epg_url": "EPG-API-URL-Vorlage", "lbl_xtream_type": "Xtream Typ", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Benutzername", "lbl_xtream_password": "Xtream Passwort", "lbl_xtream_output": "Stream-Ausgabe", "opt_xt_m3u8": "HLS / m3u8 (Empfohlen)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Bouquet-Strategie", "opt_xts_same": "Wie Anbieter", "opt_xts_folder": "Alle in einen Ordner", "opt_ord_user_xt": "Benutzerdefiniert (für sortierte Kanäle/Bouquets)", "lbl_xt_update_mode": "Nur M3U-Playlist aktualisieren", "opt_upd_top_xt": "Neue Kanäle oben", "opt_upd_bot_xt": "Neue Kanäle unten", "lbl_xtream_show_live": "Live-TV-Bouquets erstellen", "opt_xtlive_yes": "Ja", "opt_xtlive_no": "Nein", "lbl_xtream_live_type": "Live-Typ", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "VOD-Bouquets erstellen", "opt_xtvod_yes": "Ja", "opt_xtvod_no": "Nein", "lbl_xtream_vod_type": "VOD-Typ", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Serien-Bouquets erstellen", "opt_xtser_yes": "Ja", "opt_xtser_no": "Nein", "lbl_xtream_series_type": "Serien-Typ", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Picons herunterladen", "opt_xtp_off": "Aus", "opt_xtp_dn": "Mit Anzeigename", "opt_xtp_ref": "Mit Referenznummer", "lbl_xtream_picon_folder": "Mit Ordner", "opt_xtp_folder_on": "Ein", "opt_xtp_folder_off": "Aus", "lbl_xtream_picon_symlink": "Symlink erstellen", "opt_xtp_sym_off": "Aus", "opt_xtp_sym_on": "Ein", "opt_markers_off_xt": "Aus", "opt_markers_on_xt": "Ein", "lbl_xt_custom_epg": "Benutzerdefiniertes EPG", "opt_xt_cepg_on": "Ein", "opt_xt_cepg_off": "Aus", "lbl_xtream_clean": "Bouquets bereinigen", "opt_xclean_no": "Nein", "opt_xclean_yes": "Ja", "lbl_ch_title": "Kanäle", "sec_general": "Allgemein", "sec_creds": "Zugangsdaten", "sec_bouquet": "Bouquet-Einstellungen", "sec_live": "Live TV", "sec_vod": "VOD", "sec_series": "Serien", "sec_picons": "Picons", "btn_send": "An Receiver senden"};
  var _IT={"lbl_name": "Nome provider", "lbl_xmltv": "URL XMLTV / File locale", "lbl_m3u": "URL M3U / Playlist M3U", "lbl_days": "Giorni archivio (1-7)", "lbl_ttl_section": "Giorni TTL per file cache (inserisci il numero di giorni archivio disponibili)", "lbl_ttl_custom": "TTL personalizzato", "lbl_ttl_days": "  Giorni TTL (1-7)", "lbl_sign": "Offset segno", "opt_plus": "+  dopo", "opt_minus": "-  prima", "lbl_abs": "Offset secondi", "lbl_hostname": "Filtro hostname stream (per offset tempo)", "lbl_player_section": "Selezione player", "lbl_player_hint": "Sovrascrivere impostazioni player.", "lbl_player_override": "Override player (specifico per provider)", "lbl_player_int": "Player: Integrato", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Player: Ricevitore", "lbl_enabled": "Abilitato", "opt_yes": "Sì", "opt_no": "No", "lbl_epg_parse": "Crea file EPG", "opt_epg_off": "Spento", "opt_epg_dn": "Per nome visualizzato", "opt_epg_tvg": "Per tvg-id", "lbl_strategy": "Strategia creazione bouquet", "opt_same": "Come nella playlist", "opt_all": "Bouquet per tutti i canali", "opt_allg": "Bouquet per tutti i canali e gruppi", "opt_psub": "Bouquet con nome provider e sotto-bouquet", "lbl_playback": "Riproduci con", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Ordinamento canali per", "opt_ord_prov": "Usa ordine provider", "opt_ord_alpha": "Alfabeticamente", "opt_ord_user": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top": "Nuovi canali in alto", "opt_upd_bot": "Nuovi canali in basso", "lbl_picon": "Scarica picon", "opt_picon_off": "Spento", "opt_picon_on": "Sì", "lbl_pic_naming": "Denominazione", "opt_pic_dn": "Con nome visualizzato", "opt_pic_ref": "Con numero di riferimento", "lbl_pic_folder": "Con cartella", "opt_pic_folder_on": "Sì", "opt_pic_folder_off": "Spento", "lbl_pic_symlink": "Crea collegamento simbolico", "opt_pic_sym_off": "Spento", "opt_pic_sym_on": "Sì", "lbl_custom_epg": "EPG Personalizzato", "opt_cepg_on": "Sì", "opt_cepg_off": "Spento", "lbl_clean_bouquets": "Pulisci bouquet", "opt_clean_off": "Spento", "opt_clean_on": "Sì", "lbl_create_archives": "Crea archivi provider", "opt_arch_off": "Spento", "opt_arch_on": "Sì", "lbl_create_archive_markers": "Crea marcatori archivio", "opt_markers_off": "Spento", "opt_markers_on": "Sì", "lbl_archive_days": "Giorni archivio (1-7)", "lbl_cache_ttl_custom": "TTL personalizzato", "opt_ttl_off": "No (7 giorni)", "opt_ttl_on": "Sì", "lbl_cache_ttl_days": "Giorni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_stream_hostname": "Filtro hostname da URL stream", "opt_plr_off": "Spento", "opt_plr_on": "Sì", "opt_int_on": "Sì", "opt_int_off": "Spento", "opt_sl_off": "Spento", "opt_sl_on": "Sì", "opt_rec_off": "Spento", "opt_rec_on": "Sì", "lbl_clear_cache_on_save": "Pulisci cache al salvataggio", "opt_ccs_off": "Spento", "opt_ccs_on": "Sì", "lbl_frag": "Frammento URL", "lbl_arch": "Schema URL archivio", "opt_std": "Standard (parametri utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Fonte EPG", "opt_ottp": "Database ottp.eu.org (consigliato)", "opt_api": "URL API proprio del provider", "lbl_epg_url": "Modello URL API EPG", "lbl_xtream_type": "Tipo Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nome utente Xtream", "lbl_xtream_password": "Password Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Uscita stream", "opt_xt_m3u8": "HLS / m3u8 (Consigliato)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bouquet", "opt_xts_same": "Come da provider", "opt_xts_folder": "Tutti in una cartella", "opt_ord_user_xt": "Definito dall'utente (per canali/bouquet ordinati)", "lbl_xt_update_mode": "Solo aggiorna playlist M3U", "opt_upd_top_xt": "Nuovi canali in alto", "opt_upd_bot_xt": "Nuovi canali in basso", "lbl_xtream_show_live": "Crea bouquet TV in diretta", "opt_xtlive_yes": "Sì", "opt_xtlive_no": "No", "lbl_xtream_live_type": "Tipo live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Crea bouquet VOD", "opt_xtvod_yes": "Sì", "opt_xtvod_no": "No", "lbl_xtream_vod_type": "Tipo VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Crea bouquet serie", "opt_xtser_yes": "Sì", "opt_xtser_no": "No", "lbl_xtream_series_type": "Tipo serie", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Scarica picon", "opt_xtp_off": "Spento", "opt_xtp_dn": "Con nome visualizzato", "opt_xtp_ref": "Con numero di riferimento", "lbl_xtream_picon_folder": "Con cartella", "opt_xtp_folder_on": "Sì", "opt_xtp_folder_off": "Spento", "lbl_xtream_picon_symlink": "Crea collegamento simbolico", "opt_xtp_sym_off": "Spento", "opt_xtp_sym_on": "Sì", "opt_markers_off_xt": "Spento", "opt_markers_on_xt": "Sì", "lbl_xt_custom_epg": "EPG Personalizzato", "opt_xt_cepg_on": "Sì", "opt_xt_cepg_off": "Spento", "lbl_xtream_clean": "Pulisci bouquet", "opt_xclean_no": "No", "opt_xclean_yes": "Sì", "lbl_bouquets": "Bouquet", "lbl_ch_title": "Canali", "sec_general": "Generale", "sec_creds": "Credenziali", "sec_bouquet": "Opzioni bouquet", "sec_live": "TV in diretta", "sec_vod": "VOD", "sec_series": "Serie", "sec_picons": "Picons", "btn_send": "Invia al ricevitore"};
  var _PL={"lbl_name": "Nazwa dostawcy", "lbl_xmltv": "XMLTV URL / Plik lokalny", "lbl_m3u": "M3U URL / Playlista M3U", "lbl_days": "Dni archiwum (1-7)", "lbl_ttl_section": "Dni TTL dla plików pamięci podręcznej (wprowadź dostępną liczbę dni archiwum)", "lbl_ttl_custom": "Własny TTL", "lbl_ttl_days": "  Dni TTL (1-7)", "lbl_sign": "Przesunięcie znak", "opt_plus": "+  później", "opt_minus": "-  wcześniej", "lbl_abs": "Przesunięcie sekundy", "lbl_hostname": "Filtr nazwy hosta strumienia (dla przesunięcia czasu)", "lbl_player_section": "Wybór odtwarzacza", "lbl_player_hint": "Nadpisz ustawienia odtwarzacza.", "lbl_player_override": "Nadpisanie odtwarzacza (specyficzne dla dostawcy)", "lbl_player_int": "Odtwarzacz: Wbudowany", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Odtwarzacz: Odbiornik", "lbl_enabled": "Włączony", "opt_yes": "Tak", "opt_no": "Nie", "lbl_epg_parse": "Utwórz plik EPG", "opt_epg_off": "Wyłączone", "opt_epg_dn": "Według nazwy wyświetlanej", "opt_epg_tvg": "Według tvg-id", "lbl_strategy": "Strategia tworzenia bukietu", "opt_same": "Jak w playliście", "opt_all": "Bukiet dla wszystkich kanałów", "opt_allg": "Bukiety dla wszystkich kanałów i grup", "opt_psub": "Bukiet z nazwą dostawcy i podbukietami", "lbl_playback": "Odtwarzanie przez", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Kolejność kanałów według", "opt_ord_prov": "Użyj kolejności dostawcy", "opt_ord_alpha": "Alfabetycznie", "opt_ord_user": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top": "Nowe kanały na górze", "opt_upd_bot": "Nowe kanały na dole", "lbl_picon": "Pobierz pikony", "opt_picon_off": "Wyłączone", "opt_picon_on": "Wł", "lbl_pic_naming": "Nazewnictwo", "opt_pic_dn": "Z nazwą wyświetlaną", "opt_pic_ref": "Z numerem referencyjnym", "lbl_pic_folder": "Z folderem", "opt_pic_folder_on": "Wł", "opt_pic_folder_off": "Wyłączone", "lbl_pic_symlink": "Utwórz dowiązanie symboliczne", "opt_pic_sym_off": "Wyłączone", "opt_pic_sym_on": "Wł", "lbl_custom_epg": "Niestandardowy EPG", "opt_cepg_on": "Wł", "opt_cepg_off": "Wyłączone", "lbl_clean_bouquets": "Wyczyść bukiety", "opt_clean_off": "Wyłączone", "opt_clean_on": "Wł", "lbl_create_archives": "Utwórz archiwa dostawcy", "opt_arch_off": "Wyłączone", "opt_arch_on": "Wł", "lbl_create_archive_markers": "Utwórz znaczniki archiwum", "opt_markers_off": "Wyłączone", "opt_markers_on": "Wł", "lbl_archive_days": "Dni archiwum (1-7)", "lbl_cache_ttl_custom": "Własny TTL", "opt_ttl_off": "Wył (7 dni)", "opt_ttl_on": "Wł", "lbl_cache_ttl_days": "Dni TTL (1-30)", "lbl_time_offset_sign": "Offset +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Przesunięcie (sek)", "lbl_stream_hostname": "Filtr hosta z URL strumienia", "opt_plr_off": "Wyłączone", "opt_plr_on": "Wł", "opt_int_on": "Wł", "opt_int_off": "Wyłączone", "opt_sl_off": "Wyłączone", "opt_sl_on": "Wł", "opt_rec_off": "Wyłączone", "opt_rec_on": "Wł", "lbl_clear_cache_on_save": "Wyczyść pamięć podręczną przy zapisie", "opt_ccs_off": "Wyłączone", "opt_ccs_on": "Wł", "lbl_frag": "Fragment URL", "lbl_arch": "Wzorzec URL archiwum", "opt_std": "Standardowy (parametry utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Źródło EPG", "opt_ottp": "Baza danych ottp.eu.org (zalecana)", "opt_api": "Własny URL API dostawcy", "lbl_epg_url": "Szablon URL API EPG", "lbl_xtream_type": "Typ Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nazwa użytkownika Xtream", "lbl_xtream_password": "Hasło Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Wyjście strumienia", "opt_xt_m3u8": "HLS / m3u8 (Zalecane)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Strategia bukietu", "opt_xts_same": "Tak jak u dostawcy", "opt_xts_folder": "Wszystko do jednego folderu", "opt_ord_user_xt": "Zdefiniowana przez użytkownika (dla posortowanych kanałów/bukietów)", "lbl_xt_update_mode": "Tylko aktualizuj playlistę M3U", "opt_upd_top_xt": "Nowe kanały na górze", "opt_upd_bot_xt": "Nowe kanały na dole", "lbl_xtream_show_live": "Buduj bukiety telewizji na żywo", "opt_xtlive_yes": "Tak", "opt_xtlive_no": "Nie", "lbl_xtream_live_type": "Typ live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Buduj bukiety VOD", "opt_xtvod_yes": "Tak", "opt_xtvod_no": "Nie", "lbl_xtream_vod_type": "Typ VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Buduj bukiety seriali", "opt_xtser_yes": "Tak", "opt_xtser_no": "Nie", "lbl_xtream_series_type": "Typ seriali", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Pobierz pikony", "opt_xtp_off": "Wyłączone", "opt_xtp_dn": "Z nazwą wyświetlaną", "opt_xtp_ref": "Z numerem referencyjnym", "lbl_xtream_picon_folder": "Z folderem", "opt_xtp_folder_on": "Wł", "opt_xtp_folder_off": "Wyłączone", "lbl_xtream_picon_symlink": "Utwórz dowiązanie symboliczne", "opt_xtp_sym_off": "Wyłączone", "opt_xtp_sym_on": "Wł", "opt_markers_off_xt": "Wyłączone", "opt_markers_on_xt": "Wł", "lbl_xt_custom_epg": "Niestandardowy EPG", "opt_xt_cepg_on": "Wł", "opt_xt_cepg_off": "Wyłączone", "lbl_xtream_clean": "Wyczyść bukiety", "opt_xclean_no": "Nie", "opt_xclean_yes": "Tak", "lbl_bouquets": "Bukiety", "lbl_ch_title": "Kanały", "sec_general": "Ogólne", "sec_creds": "Dane dostępu", "sec_bouquet": "Ustawienia bukietu", "sec_live": "TV na żywo", "sec_vod": "VOD", "sec_series": "Seriale", "sec_picons": "Picons", "btn_send": "Wyślij do odbiornika"};
  var _RU={"lbl_name": "Имя провайдера", "lbl_xmltv": "XMLTV URL / Локальный файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дней архива (1-7)", "lbl_ttl_section": "Срок кэша (введите доступное кол-во дней архива)", "lbl_ttl_custom": "Свой TTL", "lbl_ttl_days": "  Дней хранения (1-7)", "lbl_sign": "Смещение знак", "opt_plus": "+  позже", "opt_minus": "-  раньше", "lbl_abs": "Смещение секунды", "lbl_hostname": "Фильтр hostname потока (для смещения времени)", "lbl_player_section": "Выбор плеера", "lbl_player_hint": "Переопределить настройки плеера.", "lbl_player_override": "Перекрытие плеера (для провайдера)", "lbl_player_int": "Плеер: встроенный", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеер: приёмника", "lbl_enabled": "Включён", "opt_yes": "Да", "opt_no": "Нет", "lbl_epg_parse": "Создать файл EPG", "opt_epg_off": "Выключено", "opt_epg_dn": "По отображаемому имени", "opt_epg_tvg": "По tvg-id", "lbl_strategy": "Стратегия создания букета", "opt_same": "Как в плейлисте", "opt_all": "Букет для всех каналов", "opt_allg": "Букеты для всех каналов и групп", "opt_psub": "Букет с именем провайдера и суббукеты", "lbl_playback": "Воспроизведение через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналов", "opt_ord_prov": "Порядок из провайдера", "opt_ord_alpha": "По алфавиту", "opt_ord_user": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_update_mode": "Только обновить M3U плейлист", "opt_upd_top": "Новые каналы сверху", "opt_upd_bot": "Новые каналы снизу", "lbl_picon": "Скачать Пиконы", "opt_picon_off": "Выключено", "opt_picon_on": "Вкл", "lbl_pic_naming": "Именование", "opt_pic_dn": "С отображаемым именем", "opt_pic_ref": "С номером ссылки", "lbl_pic_folder": "С папкой провайдера", "opt_pic_folder_on": "Вкл", "opt_pic_folder_off": "Выключено", "lbl_pic_symlink": "Создать симлинк", "opt_pic_sym_off": "Выключено", "opt_pic_sym_on": "Вкл", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Вкл", "opt_cepg_off": "Выключено", "lbl_clean_bouquets": "Очистить букеты", "opt_clean_off": "Выключено", "opt_clean_on": "Вкл", "lbl_create_archives": "Создать Архивы Провайдера", "opt_arch_off": "Выключено", "opt_arch_on": "Вкл", "lbl_create_archive_markers": "Создать маркеры архива", "opt_markers_off": "Выключено", "opt_markers_on": "Вкл", "lbl_archive_days": "Дней архива (1-7)", "lbl_cache_ttl_custom": "Свой срок хранения", "opt_ttl_off": "Выкл (7 дней)", "opt_ttl_on": "Вкл", "lbl_cache_ttl_days": "Дней кэша (1-30)", "lbl_time_offset_sign": "Смещение +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Смещение (сек)", "lbl_stream_hostname": "Hostname фильтр из URL потока", "opt_plr_off": "Выключено", "opt_plr_on": "Вкл", "opt_int_on": "Вкл", "opt_int_off": "Выключено", "opt_sl_off": "Выключено", "opt_sl_on": "Вкл", "opt_rec_off": "Выключено", "opt_rec_on": "Вкл", "lbl_clear_cache_on_save": "Очистить кэш при сохранении", "opt_ccs_off": "Выключено", "opt_ccs_on": "Вкл", "lbl_frag": "URL фрагмент", "lbl_arch": "Шаблон URL архива", "opt_std": "Стандартный (utc/lutc параметры)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Источник EPG", "opt_ottp": "База ottp.eu.org (рекомендуется)", "opt_api": "Свой URL API провайдера", "lbl_epg_url": "Шаблон URL EPG API", "lbl_xtream_type": "Xtream Тип", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "Xtream URL", "lbl_xtream_username": "Xtream Имя пользователя", "lbl_xtream_password": "Xtream Пароль", "lbl_xtream_token": "Xtream Токен", "lbl_xtream_output": "Выходной формат потока", "opt_xt_m3u8": "HLS / m3u8 (Рекомендуется)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегия создания букетов", "opt_xts_same": "Как у провайдера", "opt_xts_folder": "Все в одну папку", "opt_ord_user_xt": "Пользовательский (исп. для сортированных каналов/букетов)", "lbl_xt_update_mode": "Только обновить M3U плейлист", "opt_upd_top_xt": "Новые каналы сверху", "opt_upd_bot_xt": "Новые каналы снизу", "lbl_xtream_show_live": "Создавать букеты Live TV", "opt_xtlive_yes": "Да", "opt_xtlive_no": "Нет", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Создавать букеты VOD", "opt_xtvod_yes": "Да", "opt_xtvod_no": "Нет", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Создавать букеты Сериалов", "opt_xtser_yes": "Да", "opt_xtser_no": "Нет", "lbl_xtream_series_type": "Тип серий", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Скачать Пиконы", "opt_xtp_off": "Выключено", "opt_xtp_dn": "С отображаемым именем", "opt_xtp_ref": "С номером ссылки", "lbl_xtream_picon_folder": "С папкой провайдера", "opt_xtp_folder_on": "Вкл", "opt_xtp_folder_off": "Выключено", "lbl_xtream_picon_symlink": "Создать симлинк", "opt_xtp_sym_off": "Выключено", "opt_xtp_sym_on": "Вкл", "opt_markers_off_xt": "Выключено", "opt_markers_on_xt": "Вкл", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Вкл", "opt_xt_cepg_off": "Выключено", "lbl_xtream_clean": "Очистить букеты", "opt_xclean_no": "Нет", "opt_xclean_yes": "Да", "lbl_bouquets": "Букеты", "lbl_ch_title": "Каналы", "sec_general": "Общее", "sec_creds": "Данные доступа", "sec_bouquet": "Настройки букетов", "sec_live": "Live TV", "sec_vod": "VOD", "sec_series": "Сериалы", "sec_picons": "Пиконы", "btn_send": "Отправить на приёмник"};
  var _UK={"lbl_name": "Назва провайдера", "lbl_xmltv": "XMLTV URL / Локальний файл", "lbl_m3u": "M3U URL / M3U-плейлист", "lbl_days": "Дні архіву (1-7)", "lbl_ttl_section": "TTL-дні для кешованих файлів (введіть доступну кількість днів архіву)", "lbl_ttl_custom": "Власний TTL", "lbl_ttl_days": "  TTL-дні (1-7)", "lbl_sign": "Зміщення знак", "opt_plus": "+  пізніше", "opt_minus": "-  раніше", "lbl_abs": "Зміщення секунди", "lbl_hostname": "Фільтр імені хоста потоку (для зсуву часу)", "lbl_player_section": "Вибір плеєра", "lbl_player_hint": "Перевизначити налаштування плеєра.", "lbl_player_override": "Перевизначення плеєра (для провайдера)", "lbl_player_int": "Плеєр: вбудований", "lbl_player_sl": "Player: StreamLink", "lbl_player_rec": "Плеєр: приймача", "lbl_enabled": "Увімкнено", "opt_yes": "Так", "opt_no": "Ні", "lbl_epg_parse": "Створити EPG-файл", "opt_epg_off": "Вимк", "opt_epg_dn": "За назвою", "opt_epg_tvg": "За tvg-id", "lbl_strategy": "Стратегія створення букетів", "opt_same": "Як у плейлисті", "opt_all": "Букет для всіх каналів", "opt_allg": "Букети для всіх каналів та груп", "opt_psub": "Букет з назвою провайдера та суб-букетами", "lbl_playback": "Відтворення через", "opt_gst": "GStreamer", "opt_gstp": "GstPlayer", "opt_ext": "ExtEplayer3", "opt_dvb": "DVB", "lbl_order": "Порядок каналів за", "opt_ord_prov": "Порядок провайдера", "opt_ord_alpha": "За алфавітом", "opt_ord_user": "Користувацький (для відсортованих каналів/букетів)", "lbl_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top": "Нові канали зверху", "opt_upd_bot": "Нові канали знизу", "lbl_picon": "Завантажити пікони", "opt_picon_off": "Вимк", "opt_picon_on": "Увім", "lbl_pic_naming": "Іменування", "opt_pic_dn": "За назвою", "opt_pic_ref": "За номером посилання", "lbl_pic_folder": "З папкою", "opt_pic_folder_on": "Увім", "opt_pic_folder_off": "Вимк", "lbl_pic_symlink": "Створити симлінк", "opt_pic_sym_off": "Вимк", "opt_pic_sym_on": "Увім", "lbl_custom_epg": "Пользовательский EPG", "opt_cepg_on": "Увім", "opt_cepg_off": "Вимк", "lbl_clean_bouquets": "Очистити букети", "opt_clean_off": "Вимк", "opt_clean_on": "Увім", "lbl_create_archives": "Створити Архіви Провайдера", "opt_arch_off": "Вимк", "opt_arch_on": "Увім", "lbl_create_archive_markers": "Створити маркери архіву", "opt_markers_off": "Вимк", "opt_markers_on": "Увім", "lbl_archive_days": "Дні архіву (1-7)", "lbl_cache_ttl_custom": "Користувацький TTL", "opt_ttl_off": "Вимк (7 днів)", "opt_ttl_on": "Увім", "lbl_cache_ttl_days": "Днів кешу (1-30)", "lbl_time_offset_sign": "Зміщення +/-", "opt_off_plus": "+", "opt_off_minus": "-", "lbl_time_offset_abs": "Зсув (сек)", "lbl_stream_hostname": "Фільтр імені хоста з URL потоку", "opt_plr_off": "Вимк", "opt_plr_on": "Увім", "opt_int_on": "Увім", "opt_int_off": "Вимк", "opt_sl_off": "Вимк", "opt_sl_on": "Увім", "opt_rec_off": "Вимк", "opt_rec_on": "Увім", "lbl_clear_cache_on_save": "Очистити кеш при збереженні", "opt_ccs_off": "Вимк", "opt_ccs_on": "Увім", "lbl_frag": "Фрагмент URL", "lbl_arch": "Шаблон URL архіву", "opt_std": "Стандартний (параметри utc/lutc)", "opt_pa": "Path Archive", "opt_pts": "Path Timeshift", "opt_so": "Simple Offset", "lbl_epg": "Джерело EPG", "opt_ottp": "База даних ottp.eu.org (рекомендовано)", "opt_api": "Власний URL API провайдера", "lbl_epg_url": "Шаблон URL API EPG", "lbl_xtream_type": "Тип Xtream", "opt_xt_up": "Xtream Codes", "opt_xt_tok": "Xtream (Token)", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Ім'я користувача Xtream", "lbl_xtream_password": "Пароль Xtream", "lbl_xtream_token": "Токен Xtream", "lbl_xtream_output": "Вихід потоку", "opt_xt_m3u8": "HLS / m3u8 (Рекомендовано)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Стратегія букетів", "opt_xts_same": "Як у провайдера", "opt_xts_folder": "Все в одну теку", "opt_ord_user_xt": "Користувацький (для відсортованих каналів/букетів)", "lbl_xt_update_mode": "Лише оновити M3U-плейлист", "opt_upd_top_xt": "Нові канали зверху", "opt_upd_bot_xt": "Нові канали знизу", "lbl_xtream_show_live": "Створювати букети Прямого ефіру", "opt_xtlive_yes": "Так", "opt_xtlive_no": "Ні", "lbl_xtream_live_type": "Тип live", "opt_lt_4097": "GStreamer (4097)", "opt_lt_5001": "GstPlayer (5001)", "opt_lt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_vod": "Створювати букети VOD", "opt_xtvod_yes": "Так", "opt_xtvod_no": "Ні", "lbl_xtream_vod_type": "Тип VOD", "opt_vt_4097": "GStreamer (4097)", "opt_vt_5001": "GstPlayer (5001)", "opt_vt_5002": "ExtePlayer3 (5002)", "lbl_xtream_show_series": "Створювати букети Серіалів", "opt_xtser_yes": "Так", "opt_xtser_no": "Ні", "lbl_xtream_series_type": "Тип серій", "opt_st_4097": "GStreamer (4097)", "opt_st_5001": "GstPlayer (5001)", "opt_st_5002": "ExtePlayer3 (5002)", "lbl_xtream_picon": "Завантажити пікони", "opt_xtp_off": "Вимк", "opt_xtp_dn": "За назвою", "opt_xtp_ref": "За номером посилання", "lbl_xtream_picon_folder": "З папкою", "opt_xtp_folder_on": "Увім", "opt_xtp_folder_off": "Вимк", "lbl_xtream_picon_symlink": "Створити симлінк", "opt_xtp_sym_off": "Вимк", "opt_xtp_sym_on": "Увім", "opt_markers_off_xt": "Вимк", "opt_markers_on_xt": "Увім", "lbl_xt_custom_epg": "Пользовательский EPG", "opt_xt_cepg_on": "Увім", "opt_xt_cepg_off": "Вимк", "lbl_xtream_clean": "Очистити букети", "opt_xclean_no": "Ні", "opt_xclean_yes": "Так", "lbl_bouquets": "Букети", "lbl_ch_title": "Канали", "sec_general": "Загальне", "sec_creds": "Дані доступу", "sec_bouquet": "Налаштування букетів", "sec_live": "Живе ТБ", "sec_vod": "VOD", "sec_series": "Серіали", "sec_picons": "Піконіи", "btn_send": "Надіслати на приймач"};
  var _FR={"lbl_name": "Nom du fournisseur", "lbl_xmltv": "URL XMLTV / Fichier local", "lbl_m3u": "URL M3U / Liste de lecture M3U", "lbl_days": "Jours d'archive (1-7)", "lbl_ttl_section": "Jours TTL pour les fichiers en cache (entrez le nombre de jours d'archive disponibles)", "lbl_ttl_days": "  Jours TTL (1-7)", "lbl_hostname": "Filtre de nom d'hôte de flux (pour le décalage horaire)", "lbl_player_override": "Remplacement du lecteur (spécifique au fournisseur)", "lbl_enabled": "Activé", "opt_yes": "Oui", "opt_no": "Non", "lbl_epg_parse": "Créer un fichier EPG", "opt_epg_off": "Désactivé", "opt_epg_dn": "Par nom affiché", "opt_epg_tvg": "Par tvg-id", "lbl_strategy": "Stratégie de création de bouquet", "opt_same": "Comme dans la liste de lecture", "opt_all": "Bouquet pour toutes les chaînes", "opt_allg": "Bouquets pour toutes les chaînes et tous les groupes", "opt_psub": "Bouquet avec nom de fournisseur et sous-bouquets", "lbl_playback": "Lire avec", "lbl_order": "Ordre des chaînes par", "opt_ord_prov": "Utiliser l'ordre du fournisseur", "opt_ord_alpha": "Alphabétiquement", "opt_ord_user": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top": "Nouvelles chaînes en haut", "opt_upd_bot": "Nouvelles chaînes en bas", "lbl_picon": "Télécharger les Picons", "opt_picon_off": "Désactivé", "opt_picon_on": "On", "lbl_pic_naming": "Nommage", "opt_pic_dn": "Avec nom affiché", "opt_pic_ref": "Avec numéro de référence", "lbl_pic_folder": "Avec dossier du fournisseur", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Désactivé", "lbl_pic_symlink": "Créer un lien symbolique", "opt_pic_sym_off": "Désactivé", "opt_pic_sym_on": "On", "lbl_custom_epg": "Fichier EPG personnalisé", "opt_cepg_on": "On", "opt_cepg_off": "Désactivé", "lbl_clean_bouquets": "Nettoyer les bouquets", "opt_clean_off": "Désactivé", "opt_clean_on": "On", "lbl_create_archives": "Créer des archives du fournisseur", "opt_arch_off": "Désactivé", "opt_arch_on": "On", "opt_markers_off": "Désactivé", "opt_markers_on": "On", "lbl_archive_days": "Jours d'archive (1-7)", "lbl_cache_ttl_custom": "TTL personnalisé", "opt_ttl_on": "On", "lbl_time_offset_abs": "Décalage (sec)", "lbl_stream_hostname": "Filtre de nom d'hôte depuis l'URL du flux", "opt_plr_off": "Désactivé", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Désactivé", "opt_sl_off": "Désactivé", "opt_sl_on": "On", "opt_rec_off": "Désactivé", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Effacer le cache lors de l'enregistrement", "opt_ccs_off": "Désactivé", "opt_ccs_on": "On", "lbl_frag": "Fragment d'URL", "lbl_arch": "Modèle d'URL d'archive", "opt_std": "Standard (paramètres utc/lutc)", "lbl_epg": "Source EPG", "opt_ottp": "Base de données ottp.eu.org (recommandée)", "opt_api": "URL API propre du fournisseur", "lbl_epg_url": "Modèle d'URL API EPG", "lbl_xtream_type": "Type Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nom d'utilisateur Xtream", "lbl_xtream_password": "Mot de passe Xtream", "lbl_xtream_token": "Jeton Xtream", "lbl_xtream_output": "Format de sortie du flux", "opt_xt_m3u8": "HLS / m3u8 (Recommandé)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Stratégie de bouquet", "opt_xts_same": "Comme le fournisseur", "opt_ord_user_xt": "Défini par l'utilisateur (à utiliser pour les chaînes/bouquets triés)", "lbl_xt_update_mode": "Mettre à jour uniquement la liste de lecture M3U", "opt_upd_top_xt": "Nouvelles chaînes en haut", "opt_upd_bot_xt": "Nouvelles chaînes en bas", "lbl_xtream_show_live": "Créer des bouquets TV en direct", "opt_xtlive_yes": "Oui", "opt_xtlive_no": "Non", "lbl_xtream_show_vod": "Créer des bouquets VOD", "opt_xtvod_yes": "Oui", "opt_xtvod_no": "Non", "lbl_xtream_show_series": "Créer des bouquets de séries", "opt_xtser_yes": "Oui", "opt_xtser_no": "Non", "lbl_xtream_picon": "Télécharger les Picons", "opt_xtp_off": "Désactivé", "opt_xtp_dn": "Avec nom affiché", "opt_xtp_ref": "Avec numéro de référence", "lbl_xtream_picon_folder": "Avec dossier du fournisseur", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Désactivé", "lbl_xtream_picon_symlink": "Créer un lien symbolique", "opt_xtp_sym_off": "Désactivé", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Désactivé", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Fichier EPG personnalisé", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Désactivé", "lbl_xtream_clean": "Nettoyer les bouquets", "opt_xclean_no": "Non", "opt_xclean_yes": "Oui", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Chaînes", "sec_general": "Général", "sec_creds": "Identifiants", "sec_bouquet": "Options bouquet", "sec_live": "TV en direct", "sec_vod": "VOD", "sec_series": "Séries", "sec_picons": "Picons", "btn_send": "Envoyer au récepteur"};
  var _ES={"lbl_name": "Nombre del proveedor", "lbl_xmltv": "URL XMLTV / Archivo local", "lbl_m3u": "URL M3U / Lista de reproducción M3U", "lbl_days": "Días de archivo (1-7)", "lbl_ttl_section": "Días TTL para archivos en caché (ingrese el número de días de archivo disponibles)", "lbl_ttl_days": "  Días TTL (1-7)", "lbl_hostname": "Filtro de nombre de host de transmisión (para desplazamiento de tiempo)", "lbl_player_override": "Anulación de reproductor (específico del proveedor)", "lbl_enabled": "Habilitado", "opt_yes": "Sí", "opt_no": "No", "lbl_epg_parse": "Crear archivo EPG", "opt_epg_off": "Apagado", "opt_epg_dn": "Por nombre mostrado", "opt_epg_tvg": "Por tvg-id", "lbl_strategy": "Estrategia de creación de bouquet", "opt_same": "Igual que en la lista de reproducción", "opt_all": "Bouquet para todos los canales", "opt_allg": "Bouquets para todos los canales y grupos", "opt_psub": "Bouquet con nombre de proveedor y sub-bouquets", "lbl_playback": "Reproducir con", "lbl_order": "Orden de canales por", "opt_ord_prov": "Usar orden del proveedor", "opt_ord_alpha": "Alfabéticamente", "opt_ord_user": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top": "Nuevos canales arriba", "opt_upd_bot": "Nuevos canales abajo", "lbl_picon": "Descargar Picons", "opt_picon_off": "Apagado", "opt_picon_on": "On", "lbl_pic_naming": "Denominación", "opt_pic_dn": "Con nombre mostrado", "opt_pic_ref": "Con número de referencia", "lbl_pic_folder": "Con carpeta de proveedor", "opt_pic_folder_on": "On", "opt_pic_folder_off": "Apagado", "lbl_pic_symlink": "Crear enlace simbólico", "opt_pic_sym_off": "Apagado", "opt_pic_sym_on": "On", "lbl_custom_epg": "Archivo EPG personalizado", "opt_cepg_on": "On", "opt_cepg_off": "Apagado", "lbl_clean_bouquets": "Limpiar bouquets", "opt_clean_off": "Apagado", "opt_clean_on": "On", "lbl_create_archives": "Crear archivos del proveedor", "opt_arch_off": "Apagado", "opt_arch_on": "On", "opt_markers_off": "Apagado", "opt_markers_on": "On", "lbl_archive_days": "Días de archivo (1-7)", "lbl_cache_ttl_custom": "TTL personalizado", "opt_ttl_on": "On", "lbl_time_offset_abs": "Desplazamiento (seg)", "lbl_stream_hostname": "Filtro de nombre de host desde URL de transmisión", "opt_plr_off": "Apagado", "opt_plr_on": "On", "opt_int_on": "On", "opt_int_off": "Apagado", "opt_sl_off": "Apagado", "opt_sl_on": "On", "opt_rec_off": "Apagado", "opt_rec_on": "On", "lbl_clear_cache_on_save": "Limpiar caché al guardar", "opt_ccs_off": "Apagado", "opt_ccs_on": "On", "lbl_frag": "Fragmento de URL", "lbl_arch": "Patrón de URL de archivo", "opt_std": "Estándar (parámetros utc/lutc)", "lbl_epg": "Fuente EPG", "opt_ottp": "Base de datos ottp.eu.org (recomendada)", "opt_api": "URL API propia del proveedor", "lbl_epg_url": "Plantilla de URL de API EPG", "lbl_xtream_type": "Tipo Xtream", "lbl_xtream_url": "URL Xtream", "lbl_xtream_username": "Nombre de usuario Xtream", "lbl_xtream_password": "Contraseña Xtream", "lbl_xtream_token": "Token Xtream", "lbl_xtream_output": "Formato de salida de transmisión", "opt_xt_m3u8": "HLS / m3u8 (Recomendado)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Estrategia de bouquet", "opt_xts_same": "Igual que el proveedor", "opt_ord_user_xt": "Definido por el usuario (usar para canales/bouquets ordenados)", "lbl_xt_update_mode": "Actualizar solo lista de reproducción M3U", "opt_upd_top_xt": "Nuevos canales arriba", "opt_upd_bot_xt": "Nuevos canales abajo", "lbl_xtream_show_live": "Crear bouquets de TV en vivo", "opt_xtlive_yes": "Sí", "opt_xtlive_no": "No", "lbl_xtream_show_vod": "Crear bouquets de VOD", "opt_xtvod_yes": "Sí", "opt_xtvod_no": "No", "lbl_xtream_show_series": "Crear bouquets de series", "opt_xtser_yes": "Sí", "opt_xtser_no": "No", "lbl_xtream_picon": "Descargar Picons", "opt_xtp_off": "Apagado", "opt_xtp_dn": "Con nombre mostrado", "opt_xtp_ref": "Con número de referencia", "lbl_xtream_picon_folder": "Con carpeta de proveedor", "opt_xtp_folder_on": "On", "opt_xtp_folder_off": "Apagado", "lbl_xtream_picon_symlink": "Crear enlace simbólico", "opt_xtp_sym_off": "Apagado", "opt_xtp_sym_on": "On", "opt_markers_off_xt": "Apagado", "opt_markers_on_xt": "On", "lbl_xt_custom_epg": "Archivo EPG personalizado", "opt_xt_cepg_on": "On", "opt_xt_cepg_off": "Apagado", "lbl_xtream_clean": "Limpiar bouquets", "opt_xclean_no": "No", "opt_xclean_yes": "Sí", "lbl_bouquets": "Bouquets", "lbl_ch_title": "Canales", "sec_general": "General", "sec_creds": "Credenciales", "sec_bouquet": "Opciones de bouquet", "sec_live": "TV en vivo", "sec_vod": "VOD", "sec_series": "Series", "sec_picons": "Picons", "btn_send": "Enviar al receptor"};
  var _TR={"lbl_name": "Sağlayıcı Adı", "lbl_xmltv": "XMLTV URL'si / Yerel Dosya", "lbl_m3u": "M3U URL'si / M3U Oynatma Listesi", "lbl_days": "Arşiv Günleri (1-7)", "lbl_ttl_section": "Önbellek Dosyaları için TTL Günleri (Mevcut Arşiv Günleri Sayısını Girin)", "lbl_ttl_days": "  TTL Günleri (1-7)", "lbl_hostname": "Akış Hostname Filtresi (Zaman Ofseti İçin)", "lbl_player_override": "Oynatıcı Geçersiz Kılma (Sağlayıcıya Özel)", "lbl_enabled": "Etkin", "opt_yes": "Evet", "opt_no": "Hayır", "lbl_epg_parse": "EPG Dosyası Oluştur", "opt_epg_off": "Kapalı", "opt_epg_dn": "Görünen Ada göre", "opt_epg_tvg": "tvg-id'ye göre", "lbl_strategy": "Buket Oluşturma Stratejisi", "opt_same": "Oynatma Listesindeki Gibi", "opt_all": "Tüm Kanallar için Buket", "opt_allg": "Tüm Kanallar ve Gruplar için Buketler", "opt_psub": "Sağlayıcı Adı ve Alt Buketler ile Buket", "lbl_playback": "İle Oynat", "lbl_order": "Kanalları Sıralama", "opt_ord_prov": "Sağlayıcı Sırasını Kullan", "opt_ord_alpha": "Alfabetik", "opt_ord_user": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top": "Yeni Kanallar Üstte", "opt_upd_bot": "Yeni Kanallar Altta", "lbl_picon": "Pikonları İndir", "opt_picon_off": "Kapalı", "opt_picon_on": "Açık", "lbl_pic_naming": "Adlandırma", "opt_pic_dn": "Görünen Ad ile", "opt_pic_ref": "Referans Numarası ile", "lbl_pic_folder": "Sağlayıcı Klasörü ile", "opt_pic_folder_on": "Açık", "opt_pic_folder_off": "Kapalı", "lbl_pic_symlink": "Sembolik Bağlantı Oluştur", "opt_pic_sym_off": "Kapalı", "opt_pic_sym_on": "Açık", "lbl_custom_epg": "Özel EPG Dosyası", "opt_cepg_on": "Açık", "opt_cepg_off": "Kapalı", "lbl_clean_bouquets": "Buketleri Temizle", "opt_clean_off": "Kapalı", "opt_clean_on": "Açık", "lbl_create_archives": "Sağlayıcı Arşivleri Oluştur", "opt_arch_off": "Kapalı", "opt_arch_on": "Açık", "opt_markers_off": "Kapalı", "opt_markers_on": "Açık", "lbl_archive_days": "Arşiv Günleri (1-7)", "lbl_cache_ttl_custom": "Özel TTL", "opt_ttl_on": "Açık", "lbl_time_offset_abs": "Ofset (sn)", "lbl_stream_hostname": "Akış URL'sinden Hostname Filtresi", "opt_plr_off": "Kapalı", "opt_plr_on": "Açık", "opt_int_on": "Açık", "opt_int_off": "Kapalı", "opt_sl_off": "Kapalı", "opt_sl_on": "Açık", "opt_rec_off": "Kapalı", "opt_rec_on": "Açık", "lbl_clear_cache_on_save": "Kaydetmede Önbelleği Temizle", "opt_ccs_off": "Kapalı", "opt_ccs_on": "Açık", "lbl_frag": "URL Parçası", "lbl_arch": "Arşiv URL Deseni", "opt_std": "Standart (utc/lutc parametreleri)", "lbl_epg": "EPG Kaynağı", "opt_ottp": "ottp.eu.org veritabanı (önerilir)", "opt_api": "Sağlayıcının kendi API URL'si", "lbl_epg_url": "EPG API URL Şablonu", "lbl_xtream_type": "Xtream Türü", "lbl_xtream_url": "Xtream URL'si", "lbl_xtream_username": "Xtream Kullanıcı Adı", "lbl_xtream_password": "Xtream Parola", "lbl_xtream_token": "Xtream Simgesi", "lbl_xtream_output": "Akış Çıktısı", "opt_xt_m3u8": "HLS / m3u8 (Önerilir)", "opt_xt_ts": "TS", "lbl_xtream_strategy": "Buket Stratejisi", "opt_xts_same": "Sağlayıcı ile Aynı", "opt_ord_user_xt": "Kullanıcı Tanımlı (Sıralanmış Kanallar/Buketler için kullanın)", "lbl_xt_update_mode": "Yalnızca M3U Oynatma Listesini Güncelle", "opt_upd_top_xt": "Yeni Kanallar Üstte", "opt_upd_bot_xt": "Yeni Kanallar Altta", "lbl_xtream_show_live": "Canlı TV Buketleri Oluştur", "opt_xtlive_yes": "Evet", "opt_xtlive_no": "Hayır", "lbl_xtream_show_vod": "VOD Buketleri Oluştur", "opt_xtvod_yes": "Evet", "opt_xtvod_no": "Hayır", "lbl_xtream_show_series": "Dizi Buketleri Oluştur", "opt_xtser_yes": "Evet", "opt_xtser_no": "Hayır", "lbl_xtream_picon": "Pikonları İndir", "opt_xtp_off": "Kapalı", "opt_xtp_dn": "Görünen Ad ile", "opt_xtp_ref": "Referans Numarası ile", "lbl_xtream_picon_folder": "Sağlayıcı Klasörü ile", "opt_xtp_folder_on": "Açık", "opt_xtp_folder_off": "Kapalı", "lbl_xtream_picon_symlink": "Sembolik Bağlantı Oluştur", "opt_xtp_sym_off": "Kapalı", "opt_xtp_sym_on": "Açık", "opt_markers_off_xt": "Kapalı", "opt_markers_on_xt": "Açık", "lbl_xt_custom_epg": "Özel EPG Dosyası", "opt_xt_cepg_on": "Açık", "opt_xt_cepg_off": "Kapalı", "lbl_xtream_clean": "Buketleri Temizle", "opt_xclean_no": "Hayır", "opt_xclean_yes": "Evet", "lbl_bouquets": "Buketler", "lbl_ch_title": "Kanallar", "sec_general": "Genel", "sec_creds": "Kimlik Bilgileri", "sec_bouquet": "Buket Ayarları", "sec_live": "Canlı TV", "sec_vod": "VOD", "sec_series": "Diziler", "sec_picons": "Picons", "btn_send": "Alıcıya gönder"};
  var _T={'DE':_DE,'FR':_FR,'ES':_ES,'IT':_IT,'PL':_PL,'RU':_RU,'TR':_TR,'UK':_UK};
  var _LM={'DEU':'DE','GER':'DE','FRA':'FR','FRE':'FR','ESP':'ES','ITA':'IT','POL':'PL','RUS':'RU','TUR':'TR','UKR':'UK'};
  function _applyLang(){
    if(!L)return;
    for(var id in L){
      if(!L.hasOwnProperty(id))continue;
      var el=document.getElementById(id);
      if(el&&L[id])el.textContent=L[id];
    }
  }


function _txt(id, txt) {
  var el = document.getElementById(id);
  if (el) el.textContent = txt;
}
function _html(id, h) {
  var el = document.getElementById(id);
  if (el) el.innerHTML = h;
}

window.addEventListener('DOMContentLoaded', function() {
  if (_IS_RU) {
    var r = _RU_XT;
    document.querySelector('h1').innerHTML = r['add_title'];
    document.querySelector('.sub').textContent = r['sub_add'];
    _txt('sec_general',                r['sec_general']);
    _txt('lbl_name',                   r['lbl_name']);
    _txt('lbl_enabled',                r['lbl_enabled']);
    _txt('opt_yes',                    r['opt_yes']);
    _txt('opt_no',                     r['opt_no']);
    _txt('sec_creds',                  r['sec_creds']);
    _txt('lbl_xtream_type',            r['lbl_xtream_type']);
    _txt('opt_xt_up',                  r['opt_xt_up']);
    _txt('opt_xt_tok',                 r['opt_xt_tok']);
    _txt('lbl_xtream_url',             r['lbl_xtream_url']);
    _txt('lbl_xtream_username',        r['lbl_xtream_username']);
    _txt('lbl_xtream_password',        r['lbl_xtream_password']);
    _txt('lbl_xtream_token',           r['lbl_xtream_token']);
    _txt('sec_bouquet',                r['sec_bouquet']);
    _txt('lbl_xtream_output',          r['lbl_xtream_output']);
    _txt('opt_xt_m3u8',                r['opt_xt_m3u8']);
    _txt('opt_xt_ts',                  r['opt_xt_ts']);
    _txt('lbl_xtream_strategy',        r['lbl_xtream_strategy']);
    _txt('opt_xts_same',               r['opt_xts_same']);
    _txt('opt_xts_folder',             r['opt_xts_folder']);
    _txt('lbl_order',                  r['lbl_order']);
    _txt('opt_ord_prov',               r['opt_ord_prov']);
    _txt('opt_ord_alpha',              r['opt_ord_alpha']);
    _txt('opt_ord_user_xt',            r['opt_ord_user_xt']);
    _txt('lbl_xt_update_mode',         r['lbl_xt_update_mode']);
    _txt('opt_upd_top_xt',             r['opt_upd_top_xt']);
    _txt('opt_upd_bot_xt',             r['opt_upd_bot_xt']);
    _txt('sec_live',                   r['sec_live']);
    _txt('lbl_xtream_show_live',       r['lbl_xtream_show_live']);
    _txt('opt_xtlive_yes',             r['opt_yes']);
    _txt('opt_xtlive_no',              r['opt_no']);
    _txt('lbl_xtream_live_type',       r['lbl_xtream_live_type']);
    _txt('opt_lt_4097',                r['opt_gst_4097']);
    _txt('opt_lt_5001',                r['opt_gst_5001']);
    _txt('opt_lt_5002',                r['opt_gst_5002']);
    _txt('sec_vod',                    r['sec_vod']);
    _txt('lbl_xtream_show_vod',        r['lbl_xtream_show_vod']);
    _txt('opt_xtvod_yes',              r['opt_yes']);
    _txt('opt_xtvod_no',               r['opt_no']);
    _txt('lbl_xtream_vod_type',        r['lbl_xtream_vod_type']);
    _txt('opt_vt_4097',                r['opt_gst_4097']);
    _txt('opt_vt_5001',                r['opt_gst_5001']);
    _txt('opt_vt_5002',                r['opt_gst_5002']);
    _txt('sec_series',                 r['sec_series']);
    _txt('lbl_xtream_show_series',     r['lbl_xtream_show_series']);
    _txt('opt_xtser_yes',              r['opt_yes']);
    _txt('opt_xtser_no',               r['opt_no']);
    _txt('lbl_xtream_series_type',     r['lbl_xtream_series_type']);
    _txt('opt_st_4097',                r['opt_gst_4097']);
    _txt('opt_st_5001',                r['opt_gst_5001']);
    _txt('opt_st_5002',                r['opt_gst_5002']);
    _txt('sec_picons',                 r['sec_picons']);
    _txt('lbl_xtream_picon',           r['lbl_xtream_picon']);
    _txt('opt_xtp_off',                r['opt_xtp_off']);
    _txt('opt_xtp_dn',                 r['opt_xtp_dn']);
    _txt('opt_xtp_ref',                r['opt_xtp_ref']);
    _txt('lbl_xtream_picon_folder',    r['lbl_xtream_picon_folder']);
    _txt('opt_xtp_folder_on',          r['opt_xtp_folder_on']);
    _txt('opt_xtp_folder_off',         r['opt_xtp_folder_off']);
    _txt('lbl_xtream_picon_symlink',   r['lbl_xtream_picon_symlink']);
    _txt('opt_xtp_sym_off',            r['opt_xtp_sym_off']);
    _txt('opt_xtp_sym_on',             r['opt_xtp_sym_on']);
    _txt('lbl_xtream_clean',           r['lbl_xtream_clean']);
    _txt('opt_xclean_no',              r['opt_xclean_no']);
    _txt('opt_xclean_yes',             r['opt_xclean_yes']);
    _txt('lbl_xtream_mount_note',      r['lbl_xtream_mount_note']);
    _html('btn_send',                  r['btn_send']);
    _html('ok_msg',                    r['ok_msg']);
  }

  if (!PREFILL) { toggleXtreamType(); toggleXtreamPiconSection(); toggleStreamSubrows(); toggleXtreamUpdateMode(); return; }
  ['name', 'enabled', 'xtream_type', 'xtream_url',
   'xtream_username', 'xtream_password', 'xtream_token',
   'xtream_output', 'xtream_strategy', 'channel_order',
   'xtream_show_live',   'xtream_live_type',
   'xtream_show_vod',    'xtream_vod_type',
   'xtream_show_series', 'xtream_series_type',
   'xtream_picon', 'xtream_picon_with_folder', 'xtream_picon_symlink',
   'create_archive_markers', 'custom_epg_enabled',
   'xtream_clean_bouquets', 'update_mode_sub'
  ].forEach(function(k) {
    var el = document.getElementById(k);
    if (el && PREFILL[k] !== undefined && PREFILL[k] !== null) {
      if (k === 'xtream_picon_symlink' || k === 'xtream_picon_with_folder' ||
          k === 'xtream_show_live' || k === 'xtream_show_vod' ||
          k === 'xtream_show_series' || k === 'xtream_clean_bouquets' ||
          k === 'create_archive_markers' || k === 'custom_epg_enabled') {
        el.value = (PREFILL[k] === true || PREFILL[k] === '1' || PREFILL[k] === 'true') ? '1' : '0';
      } else {
        el.value = PREFILL[k];
      }
    }
  });
  _applyLang();
  toggleXtreamType();
  toggleStreamSubrows();
  toggleXtreamPiconSection();
  toggleXtreamUpdateMode();
  if (PREFILL._is_edit) {
    if (_IS_RU) {
      document.querySelector('h1').innerHTML = _RU_XT['edit_title'];
      document.querySelector('.sub').textContent = _RU_XT['sub_edit'];
    } else {
      document.querySelector('h1').innerHTML = '&#9998;&nbsp; Edit Xtream Provider';
      document.querySelector('.sub').textContent =
        'Xtream Media Creator \u2014 change what you need and press Send';
    }
  }
});

function toggleStreamSubrows() {
  var live   = document.getElementById('xtream_show_live');
  var vod    = document.getElementById('xtream_show_vod');
  var series = document.getElementById('xtream_show_series');
  var liveT  = document.getElementById('live_type_row');
  var vodT   = document.getElementById('vod_type_row');
  var serT   = document.getElementById('series_type_row');
  if (liveT)  liveT.style.display  = (live   && live.value   === '1') ? 'block' : 'none';
  if (vodT)   vodT.style.display   = (vod    && vod.value    === '1') ? 'block' : 'none';
  if (serT)   serT.style.display   = (series && series.value === '1') ? 'block' : 'none';
}

function toggleXtreamPiconSection() {
  var val = document.getElementById('xtream_picon');
  var sec = document.getElementById('xtream_picon_sub_section');
  if (!sec) return;
  if (val && val.value !== 'off') {
    sec.style.display = 'block';
  } else {
    sec.style.display = 'none';
  }
}

function toggleXtreamType() {
  var t = document.getElementById('xtream_type');
  var up  = document.getElementById('xtream_userpass_div');
  var tok = document.getElementById('xtream_token_div');
  if (!t) return;
  if (t.value === 'token') {
    if (up)  up.style.display  = 'none';
    if (tok) tok.style.display = 'block';
  } else {
    if (up)  up.style.display  = 'block';
    if (tok) tok.style.display = 'none';
  }
}

function sendData() {
  var fields = ['name', 'enabled', 'xtream_type', 'xtream_url',
                'xtream_username', 'xtream_password', 'xtream_token',
                'xtream_output', 'xtream_strategy', 'channel_order',
                'xtream_show_live',   'xtream_live_type',
                'xtream_show_vod',    'xtream_vod_type',
                'xtream_show_series', 'xtream_series_type',
                'xtream_picon', 'xtream_picon_with_folder', 'xtream_picon_symlink',
                'create_archive_markers', 'custom_epg_enabled',
                'xtream_clean_bouquets', 'update_mode_sub'];
  var parts = fields.map(function(k) {
    var el = document.getElementById(k);
    return encodeURIComponent(k) + '=' + encodeURIComponent(el ? el.value : '');
  });
  fetch('/', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: parts.join('&')
  }).then(function(r) {
    if (r.ok) {
      document.getElementById('f').style.display = 'none';
      document.getElementById('ok').style.display = 'block';
    } else {
      alert(_IS_RU ? '\u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.' : 'Error sending data. Please try again.');
    }
  }).catch(function() {
    alert(_IS_RU ? '\u041d\u0435 \u0443\u0434\u0430\u0451\u0442\u0441\u044f \u0441\u0432\u044f\u0437\u0430\u0442\u044c\u0441\u044f \u0441 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u043e\u043c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u0435\u0442\u044c.' : 'Could not reach receiver. Check that you are on the same network.');
  });
}
</script>
</body>
</html>"""

# ---------------------------------------------------------------------------
# IPTVWebInputServer
# ---------------------------------------------------------------------------


_LABEL_MAP = {
    "lbl_name": "Provider Name",
    "lbl_xmltv": "XMLTV URL / Local File",
    "btn_browse_xmltv": "Browse&hellip;",
    "hint_xmltv": "Leave blank if you have no separate EPG feed",
    "lbl_m3u": "M3U URL / M3U Playlist",
    "btn_browse_m3u": "Browse&hellip;",
    "lbl_days": "Archive Days (1-7)",
    "lbl_ttl_section": "TTL Days For Cached Files (Insert Available Archives Days Number)",
    "lbl_ttl_custom": "Use custom TTL for this provider",
    "lbl_ttl_days": "  TTL Days (1-7)",
    "lbl_sign": "Archive Start Offset &mdash; Sign",
    "opt_plus": "+  start later",
    "opt_minus": "-  start earlier  (corrects a fast receiver clock)",
    "lbl_abs": "Archive Start Offset &mdash; Seconds (0-99999)",
    "hint_offset": "Example: Sign &ldquo;&minus;&rdquo; + 420 sec = start 7 minutes earlier",
    "lbl_hostname": "Stream Hostname Filter (For Time Offset)",
    "hint_hostname": "Offset only applies when the live stream URL hostname contains this value. Leave blank to always apply.",
    "lbl_player_section": "Player Selection (Provider Override)",
    "lbl_player_override": "Player Override (Provider-Specific)",
    "lbl_player_int": "Player: Integrated",
    "lbl_player_sl": "Player: StreamLink",
    "lbl_player_rec": "Player: Receiver",
    "lbl_enabled": "Enabled",
    "opt_yes": "Yes",
    "opt_no": "No",
    "lbl_epg_parse": "Create EPG File",
    "opt_epg_off": "Off",
    "opt_epg_dn": "By Display Name",
    "opt_epg_tvg": "By tvg-id",
    "hint_epg_parse": "Creates /etc/epgimport/CustomIPTV/ files for use with EPGImport plugin",
    "lbl_strategy": "Bouquet Creation Strategy",
    "opt_same": "Same in Playlist",
    "opt_all": "Bouquet for All Channels",
    "opt_allg": "Bouquets for All Channels and Groups",
    "opt_psub": "Bouquet with Provider Name and Sub-Bouquets",
    "lbl_playback": "Playback With",
    "opt_gst": "GStreamer Player",
    "opt_gstp": "GstPlayer",
    "opt_ext": "ExtEplayer3",
    "opt_dvb": "DVB",
    "lbl_order": "Channels Ordering By",
    "opt_ord_prov": "Use Provider Order",
    "opt_ord_alpha": "Alphabetically",
    "opt_ord_user": "User Defined (Use for Sorted Channels/Bouquets)",
    "lbl_update_mode": "Update M3U Playlist Only",
    "opt_upd_top": "New Channels on Top",
    "opt_upd_bot": "New Channels on Bottom",
    "lbl_picon": "Download Picons",
    "opt_picon_off": "Off",
    "opt_picon_on": "On",
    "lbl_pic_naming": "Naming",
    "opt_pic_dn": "With Display Name",
    "opt_pic_ref": "With Reference Number",
    "lbl_pic_folder": "With Folder",
    "opt_pic_folder_on": "On",
    "opt_pic_folder_off": "Off",
    "lbl_pic_symlink": "Create Symlink",
    "opt_pic_sym_off": "Off",
    "opt_pic_sym_on": "On",
    "lbl_custom_epg": "Custom EPG File",
    "opt_cepg_on": "On",
    "opt_cepg_off": "Off",
    "lbl_clean_bouquets": "Clean Bouquets",
    "opt_clean_off": "Off",
    "opt_clean_on": "On",
    "lbl_create_archives": "Create Provider Archives",
    "opt_arch_off": "Off",
    "opt_arch_on": "On",
    "lbl_create_archive_markers": "Create Archive Markers ( ▶ )",
    "opt_markers_off": "Off",
    "opt_markers_on": "On",
    "lbl_archive_days": "Archive Days (1-7)",
    "lbl_cache_ttl_custom": "Custom TTL",
    "opt_ttl_off": "Off (Default 7 days)",
    "opt_ttl_on": "On",
    "lbl_cache_ttl_days": "TTL Days (1-30)",
    "lbl_time_offset_sign": "Offset +/-",
    "lbl_time_offset_abs": "Offset (sec)",
    "lbl_stream_hostname": "Hostname Filter From Stream URL",
    "opt_plr_off": "Off",
    "opt_plr_on": "On",
    "opt_int_on": "On",
    "opt_int_off": "Off",
    "opt_sl_off": "Off",
    "opt_sl_on": "On",
    "opt_rec_off": "Off",
    "opt_rec_on": "On",
    "lbl_clear_cache_on_save": "Clear Cache on Save",
    "opt_ccs_off": "Off",
    "opt_ccs_on": "On",
    "lbl_frag": "URL Fragment",
    "hint_frag": "A unique substring of the stream URL that identifies this provider",
    "lbl_arch": "Archive URL Pattern",
    "opt_std": "Standard (utc/lutc params)",
    "opt_pa": "Path Archive (archive-start-dur.m3u8)",
    "opt_pts": "Path Timeshift (video-timeshift_abs-start.m3u8)",
    "opt_so": "Simple Offset (archive=start)",
    "lbl_epg": "EPG Source",
    "opt_ottp": "ottp.eu.org database (recommended)",
    "opt_api": "Provider own API URL",
    "lbl_epg_url": "EPG API URL Template",
    "hint_epg_url": "{channel_id} is replaced with the actual channel identifier",
    "sec_general": "General",
    "sec_creds": "Credentials",
    "lbl_xtream_type": "Xtream Type",
    "opt_xt_up": "Xtream Codes (Username / Password)",
    "opt_xt_tok": "Xtream (Token)",
    "lbl_xtream_url": "Xtream URL",
    "lbl_xtream_username": "Xtream Username",
    "lbl_xtream_password": "Xtream Password",
    "lbl_xtream_token": "Xtream Token",
    "sec_bouquet": "Bouquet Options",
    "lbl_xtream_output": "Stream Output",
    "opt_xt_m3u8": "HLS / m3u8 (Recommended)",
    "opt_xt_ts": "TS",
    "lbl_xtream_strategy": "Bouquet Strategy",
    "opt_xts_same": "Same As Provider",
    "opt_xts_folder": "Group All Into One Folder",
    "opt_ord_user_xt": "User Defined (Use for Sorted Channels/Bouquets)",
    "lbl_xt_update_mode": "Update M3U Playlist Only",
    "opt_upd_top_xt": "New Channels on Top",
    "opt_upd_bot_xt": "New Channels on Bottom",
    "sec_live": "Live TV",
    "lbl_xtream_show_live": "Build Live TV Bouquets",
    "opt_xtlive_yes": "Yes",
    "opt_xtlive_no": "No",
    "lbl_xtream_live_type": "Live Stream Type",
    "opt_lt_4097": "GStreamer (4097)",
    "opt_lt_5001": "GstPlayer (5001)",
    "opt_lt_5002": "ExtePlayer3 (5002)",
    "sec_vod": "VOD",
    "lbl_xtream_show_vod": "Build VOD Bouquets",
    "opt_xtvod_yes": "Yes",
    "opt_xtvod_no": "No",
    "lbl_xtream_vod_type": "VOD Stream Type",
    "opt_vt_4097": "GStreamer (4097)",
    "opt_vt_5001": "GstPlayer (5001)",
    "opt_vt_5002": "ExtePlayer3 (5002)",
    "sec_series": "Series",
    "lbl_xtream_show_series": "Build Series Bouquets",
    "opt_xtser_yes": "Yes",
    "opt_xtser_no": "No",
    "lbl_xtream_series_type": "Series Stream Type",
    "opt_st_4097": "GStreamer (4097)",
    "opt_st_5001": "GstPlayer (5001)",
    "opt_st_5002": "ExtePlayer3 (5002)",
    "sec_picons": "Picons",
    "lbl_xtream_picon": "Download Picons",
    "opt_xtp_off": "Off",
    "opt_xtp_dn": "With Display Name",
    "opt_xtp_ref": "With Reference Number",
    "lbl_xtream_picon_folder": "With Folder",
    "opt_xtp_folder_on": "On",
    "opt_xtp_folder_off": "Off",
    "lbl_xtream_picon_symlink": "Create Symlink",
    "opt_xtp_sym_off": "Off",
    "opt_xtp_sym_on": "On",
    "opt_markers_off_xt": "Off",
    "opt_markers_on_xt": "On",
    "lbl_xt_custom_epg": "Custom EPG File",
    "opt_xt_cepg_on": "On",
    "opt_xt_cepg_off": "Off",
    "lbl_xtream_clean": "Clean Bouquets",
    "opt_xclean_no": "No",
    "opt_xclean_yes": "Yes"
}

class IPTVWebInputServer(object):
    """
    Start with .start() — runs in a daemon thread.
    Call .poll() from the Enigma2 main thread to check for submitted data.
    Call .stop() when the dialog closes.
    """

    def __init__(self, port=WEB_PORT, upload_dir=None):
        self._port        = port
        self._httpd       = None
        self._thread      = None
        self._queue       = []
        self._lock        = threading.Lock()
        self._actual_port = port
        self._upload_dir  = upload_dir or _UPLOAD_DIR

    # ------------------------------------------------------------------

    def start(self, prefill=None, form_type='archive'):
        """Start the HTTP server. Returns (True, ip, port) or (False, '', 0).

        prefill   — optional dict of current provider values to pre-fill the
                    browser form (used when editing an existing provider).
        form_type — 'archive' (default) for the archive provider form,
                    'playlist' for the IPTV Playlist Creator form.
        """
        if not _HTTP_AVAILABLE:
            return False, '', 0

        lock       = self._lock
        queue      = self._queue
        upload_dir = self._upload_dir

        # Inject prefill data as a JSON literal into the HTML template
        if prefill:
            prefill_json = json.dumps(prefill)
            ui_lang = prefill.get('ui_language', 'ENG')
        else:
            prefill_json = 'null'
            ui_lang = 'ENG'
        try:
            from . import _lang as _lng
            _lmap2 = {'DEU':'de','FRA':'fr','FRE':'fr','ESP':'es','ITA':'it','POL':'pl','RUS':'ru','TUR':'tr','UKR':'uk'}
            _lcode2 = _lmap2.get(ui_lang)
            _ldict2 = _lng._LANGS.get(_lcode2, {}) if _lcode2 else {}
            _l_out = {}
            for _id2, _en2 in _LABEL_MAP.items():
                _tr2 = _ldict2.get(_en2)
                if _tr2:
                    _l_out[_id2] = _tr2
            l_json = json.dumps(_l_out, ensure_ascii=False)
        except Exception as _le:
            try:
                from ._epg import iptvLogWrite; iptvLogWrite('[WebTrans] ERROR: %s' % _le)
            except: pass
            l_json = '{}'

        template   = (_HTML_XTREAM      if form_type == 'xtream'
                      else _HTML_PLAYLIST   if form_type == 'playlist'
                      else _HTML_INTEGRATED if form_type == 'integrated'
                      else _HTML)
        html_str = template.replace(
            '/*PREFILL_JSON*/null/*END_PREFILL*/', prefill_json
        )
        html_str = html_str.replace('/*L_JSON*/{}/*END_L*/', l_json)
        html_bytes = html_str.encode('utf-8')

        class _ReuseHTTPServer(HTTPServer):
            allow_reuse_address = True

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass  # silence access log

            # --------------------------------------------------------------
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html_bytes)))
                self.end_headers()
                self.wfile.write(html_bytes)

            # --------------------------------------------------------------
            def do_POST(self):
                try:
                    path = self.path.split('?')[0].rstrip('/')
                    if path == '/upload':
                        self._handle_upload()
                    else:
                        self._handle_form(lock, queue)
                except Exception:
                    try:
                        self.send_response(500)
                        self.end_headers()
                    except Exception:
                        pass

            def _handle_form(self, lock, queue):
                clen = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(clen).decode('utf-8', errors='replace')
                data = {}
                for pair in body.split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        data[unquote_plus(k)] = unquote_plus(v)
                with lock:
                    queue.append(data)
                resp = b'{"ok":true}'
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(resp)))
                self.end_headers()
                self.wfile.write(resp)

            def _handle_upload(self):
                clen = int(self.headers.get('Content-Length', 0))
                raw  = self.rfile.read(clen)

                # Decode original filename from header — keep it as-is,
                # only strip path separators to prevent directory traversal
                raw_name = self.headers.get('X-Filename', 'upload.m3u')
                try:
                    raw_name = unquote_plus(raw_name)
                except Exception:
                    pass
                # Remove any path components, keep only the bare filename
                safe_name = os.path.basename(raw_name).strip() or 'upload.m3u'
                # Strip null bytes and forward/back slashes just in case
                safe_name = safe_name.replace('/', '').replace('\\', '').replace('\x00', '')
                if not safe_name:
                    safe_name = 'upload.m3u'

                # X-FileType: epg  → EPG/XMLTV file, save to EPG_SourceFiles/
                # anything else    → M3U file, save to <ProviderName>_FromWebLocal/
                file_type = self.headers.get('X-FileType', '').strip().lower()
                if file_type == 'epg':
                    dest_dir = os.path.join(upload_dir, 'EPG_SourceFiles')
                else:
                    # Determine destination subfolder from the provider name the
                    # user has already typed in the browser form.  The JS sends
                    # the current value of the "name" field as X-ProviderName.
                    prov_raw = self.headers.get('X-ProviderName', '')
                    try:
                        prov_raw = unquote_plus(prov_raw)
                    except Exception:
                        pass
                    import re as _re
                    prov_safe = _re.sub(r'[^\w\-]', '_', prov_raw.strip()).strip('_')
                    if prov_safe:
                        dest_dir = os.path.join(upload_dir, '%s_FromWebLocal' % prov_safe)
                    else:
                        dest_dir = os.path.join(upload_dir, '_FromWebLocal')

                if not os.path.isdir(dest_dir):
                    os.makedirs(dest_dir)

                save_path = os.path.join(dest_dir, safe_name)
                with open(save_path, 'wb') as fh:
                    fh.write(raw)

                resp = json.dumps({'ok': True, 'path': save_path}).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(resp)))
                self.end_headers()
                self.wfile.write(resp)

        # Try the requested port, then a few fallbacks
        for port in range(self._port, self._port + 10):
            try:
                self._httpd = _ReuseHTTPServer(('', port), _Handler)
                self._actual_port = port
                break
            except OSError:
                self._httpd = None

        if self._httpd is None:
            return False, '', 0

        self._thread = threading.Thread(target=self._httpd.serve_forever)
        self._thread.daemon = True
        self._thread.start()
        return True, _get_local_ip(), self._actual_port

    # ------------------------------------------------------------------

    def stop(self):
        try:
            if self._httpd:
                self._httpd.shutdown()
                self._httpd = None
        except Exception:
            pass

    # ------------------------------------------------------------------

    def poll(self):
        """Return the next submitted form dict, or None if nothing yet."""
        with self._lock:
            if self._queue:
                return self._queue.pop(0)
        return None


# ---------------------------------------------------------------------------
# HTML page for PC-based Channel Browser
# ---------------------------------------------------------------------------

_HTML_CHANNEL_BROWSER = u"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Channel Browser</title>
<link rel="icon" href="data:,">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{font-family:'Segoe UI',Arial,sans-serif;background:#12121f;color:#dde1f0;
     display:flex;flex-direction:column;height:100vh;overflow:hidden}
#hdr{background:#1a1f38;padding:10px 18px;display:flex;
     align-items:center;justify-content:space-between;
     border-bottom:2px solid #e94560;flex-shrink:0}
#hdr h1{font-size:18px;color:#e94560;letter-spacing:.5px}
#stats{font-size:13px;color:#6b7599}
#panels{display:flex;flex:1;overflow:hidden;gap:0}
#bq_panel{width:290px;flex-shrink:0;display:flex;flex-direction:column;
          border-right:2px solid #252d50;background:#161b30}
#ch_panel{flex:1;display:flex;flex-direction:column;background:#12121f}
.ph{padding:8px 12px;background:#1e2540;display:flex;
    align-items:center;gap:6px;flex-shrink:0;border-bottom:1px solid #252d50}
.ph span{flex:1;font-size:13px;font-weight:700;color:#8fa0c8;
         text-transform:uppercase;letter-spacing:.5px}
.ph button{font-size:11px;padding:3px 9px;border:1px solid #2e3d6e;
           border-radius:5px;background:#0d1530;color:#8fa0c8;
           cursor:pointer;transition:background .15s}
.ph button:hover{background:#e94560;color:#fff;border-color:#e94560}
.list{flex:1;overflow-y:auto;padding:4px 0}
.list::-webkit-scrollbar{width:5px}
.list::-webkit-scrollbar-track{background:#0d1530}
.list::-webkit-scrollbar-thumb{background:#2e3d6e;border-radius:3px}
.bq-row{display:flex;align-items:center;gap:8px;padding:7px 12px;
        cursor:pointer;border-bottom:1px solid #1a1f38;
        transition:background .1s;user-select:none}
.bq-row:hover{background:#1e2540}
.bq-row.active{background:#1e2f60;border-left:3px solid #e94560}
.bq-row input[type=checkbox]{width:16px;height:16px;accent-color:#e94560;
                              flex-shrink:0;cursor:pointer}
.bq-name{flex:1;font-size:14px;white-space:nowrap;overflow:hidden;
         text-overflow:ellipsis}
.bq-cnt{font-size:12px;color:#8899cc;flex-shrink:0;font-weight:500}
.ch-row{display:flex;align-items:center;gap:8px;padding:6px 14px;
        cursor:pointer;border-bottom:1px solid #161b30;
        transition:background .1s;user-select:none}
.ch-row:hover{background:#1a1f38}
.ch-row input[type=checkbox]{width:15px;height:15px;accent-color:#e94560;
                              flex-shrink:0;cursor:pointer}
.ch-name{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ftr{padding:12px 18px;background:#1a1f38;border-top:2px solid #252d50;
     display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
#ftr .hint{font-size:12px;color:#4a5578}
.btn-save{padding:11px 38px;background:#e94560;color:#fff;border:none;
          border-radius:9px;font-size:15px;font-weight:bold;cursor:pointer;
          letter-spacing:.4px;transition:background .2s}
.btn-save:hover{background:#c73652}
.btn-save:disabled{background:#4a5578;cursor:default}
#ok{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);
    align-items:center;justify-content:center}
#ok.show{display:flex}
.ok-card{background:#152b1e;border:2px solid #2ecc71;border-radius:14px;
         padding:36px 48px;text-align:center;color:#2ecc71;font-size:17px;
         max-width:400px;line-height:1.6}
</style>
</head>
<body>
<div id="hdr">
  <h1 id="h_title">&#128250; Channel Browser</h1>
  <div id="stats" id="h_stats">...</div>
</div>
<div id="panels">
  <div id="bq_panel">
    <div class="ph">
      <span id="lbl_bouquets">Bouquets</span>
      <button onclick="bqAll()" id="btn_bq_all">All</button>
      <button onclick="bqNone()" id="btn_bq_none">None</button>
    </div>
    <div class="list" id="bq_list"></div>
  </div>
  <div id="ch_panel">
    <div class="ph">
      <span id="lbl_ch_title">Channels</span>
      <button onclick="chAll()" id="btn_ch_all">All</button>
      <button onclick="chNone()" id="btn_ch_none">None</button>
    </div>
    <div class="list" id="ch_list"></div>
  </div>
</div>
<div id="ftr">
  <div class="hint" id="h_hint">Select channels to include in the archive, then click Save.</div>
  <button class="btn-save" id="btn_save" onclick="saveSelection()">&#10148;&nbsp; Save Selection</button>
</div>
<div id="ok">
  <div class="ok-card" id="ok_msg">
    &#10003;&nbsp; Selection saved!<br>
    You can close this tab and press <strong>Add Selected</strong> on the receiver.
  </div>
</div>

<script>
var DATA   = /*DATA_JSON*/null/*END_DATA_JSON*/;
var _IS_RU = (DATA && DATA.is_ru === true);

var _RU = {
  'h_title':      '\u0422\u0412 \u0411\u0440\u0430\u0443\u0437\u0435\u0440 \u043a\u0430\u043d\u0430\u043b\u043e\u0432',
  'lbl_bouquets': '\u0411\u0443\u043a\u0435\u0442\u044b',
  'btn_bq_all':   '\u0412\u0441\u0435',
  'btn_bq_none':  '\u041d\u0438\u0447\u0442\u043e',
  'btn_ch_all':   '\u0412\u0441\u0435',
  'btn_ch_none':  '\u041d\u0438\u0447\u0442\u043e',
  'btn_save':     '&#10148;\u00a0 \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0432\u044b\u0431\u043e\u0440',
  'h_hint':       '\u041e\u0442\u043c\u0435\u0442\u044c\u0442\u0435 \u043d\u0443\u0436\u043d\u044b\u0435 \u043a\u0430\u043d\u0430\u043b\u044b \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u00ab\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c\u00bb.',
  'ok_msg':       '\u2713\u00a0 \u0412\u044b\u0431\u043e\u0440 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d!<br>\u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u043a\u043b\u0430\u0434\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 <strong>\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0435</strong> \u043d\u0430 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a\u0435.',
  'err_save':     '\u041e\u0448\u0438\u0431\u043a\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.',
  'sel_label':    '\u043a\u0430\u043d. \u0432\u044b\u0431\u0440\u0430\u043d\u043e'
};

function _t(id) { return _IS_RU ? (_RU[id] || '') : ''; }
function _txt(id, t) { var e=document.getElementById(id); if(e&&t) e.textContent=t; }
function _html(id, h) { var e=document.getElementById(id); if(e&&h) e.innerHTML=h; }

var groups      = (DATA && DATA.groups) ? DATA.groups : [];
var bqChecked   = [];
var chChecked   = {};
var activeBq    = 0;

function _initState() {
  var selUrls = (DATA && DATA.selected_urls) ? DATA.selected_urls : null;
  bqChecked = groups.map(function() { return true; });
  groups.forEach(function(g, i) {
    g.channels.forEach(function(c) { chChecked[c.url] = true; });
    if (selUrls) {
      var anyChecked = false;
      g.channels.forEach(function(c) {
        chChecked[c.url] = (selUrls.indexOf(c.url) !== -1);
        if (chChecked[c.url]) anyChecked = true;
      });
      bqChecked[i] = anyChecked;
    }
  });
}

function _countSelected() {
  var n = 0;
  groups.forEach(function(g, i) {
    if (!bqChecked[i]) return;
    g.channels.forEach(function(c) { if (chChecked[c.url]) n++; });
  });
  return n;
}

function _updateStats() {
  var total = 0;
  groups.forEach(function(g) { total += g.channels.length; });
  var sel   = _countSelected();
  var bqSel = bqChecked.filter(Boolean).length;
  var txt;
  if (_IS_RU) {
    txt = bqSel + '/' + groups.length + ' \u0431\u0443\u043a\u0435\u0442\u043e\u0432  \u2022  ' + sel + '/' + total + ' ' + _RU['sel_label'];
  } else {
    txt = bqSel + '/' + groups.length + ' bouquets  \u2022  ' + sel + '/' + total + ' channels selected';
  }
  var e = document.getElementById('stats'); if (e) e.textContent = txt;
}

function _renderBouquets() {
  var el = document.getElementById('bq_list');
  if (!el) return;
  el.innerHTML = '';
  groups.forEach(function(g, i) {
    var row = document.createElement('div');
    row.className = 'bq-row' + (i === activeBq ? ' active' : '');
    var cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = bqChecked[i];
    cb.onclick = function(e) { e.stopPropagation(); bqChecked[i] = cb.checked; _renderBouquets(); _renderChannels(); _updateStats(); };
    var nm = document.createElement('span'); nm.className = 'bq-name'; nm.textContent = g.grp;
    var cnt = document.createElement('span'); cnt.className = 'bq-cnt'; cnt.textContent = '(' + g.channels.length + ')';
    row.appendChild(cb); row.appendChild(nm); row.appendChild(cnt);
    row.onclick = function() { activeBq = i; _renderBouquets(); _renderChannels(); _updateChTitle(); };
    el.appendChild(row);
  });
}

function _updateChTitle() {
  var g = groups[activeBq];
  var base = _IS_RU ? '\u041a\u0430\u043d\u0430\u043b\u044b' : 'Channels';
  var el = document.getElementById('lbl_ch_title');
  if (el) el.textContent = g ? (base + ' \u2014 ' + g.grp) : base;
}

function _renderChannels() {
  var el = document.getElementById('ch_list');
  if (!el) return;
  el.innerHTML = '';
  var g = groups[activeBq];
  if (!g) return;
  g.channels.forEach(function(c) {
    var row = document.createElement('div'); row.className = 'ch-row';
    var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!chChecked[c.url];
    cb.onclick = function(e) { e.stopPropagation(); chChecked[c.url] = cb.checked; _renderChannels(); _updateStats(); };
    var nm = document.createElement('span'); nm.className = 'ch-name'; nm.textContent = c.name;
    row.appendChild(cb); row.appendChild(nm);
    row.onclick = function() { chChecked[c.url] = !chChecked[c.url]; _renderChannels(); _updateStats(); };
    el.appendChild(row);
  });
}

function bqAll()  { bqChecked = bqChecked.map(function(){return true;});  _renderBouquets(); _updateStats(); }
function bqNone() { bqChecked = bqChecked.map(function(){return false;}); _renderBouquets(); _updateStats(); }

function chAll() {
  var g = groups[activeBq]; if (!g) return;
  g.channels.forEach(function(c) { chChecked[c.url] = true; });
  _renderChannels(); _updateStats();
}
function chNone() {
  var g = groups[activeBq]; if (!g) return;
  g.channels.forEach(function(c) { chChecked[c.url] = false; });
  _renderChannels(); _updateStats();
}

function saveSelection() {
  var selected = [];
  groups.forEach(function(g, i) {
    if (!bqChecked[i]) return;
    g.channels.forEach(function(c) { if (chChecked[c.url]) selected.push(c.url); });
  });
  document.getElementById('btn_save').disabled = true;
  fetch('/save', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({selected: selected})
  }).then(function(r) {
    if (r.ok) {
      var ok = document.getElementById('ok');
      ok.className = 'show';
    } else {
      document.getElementById('btn_save').disabled = false;
      alert(_IS_RU ? _RU['err_save'] : 'Error saving selection. Please try again.');
    }
  }).catch(function() {
    document.getElementById('btn_save').disabled = false;
    alert(_IS_RU ? _RU['err_save'] : 'Could not reach receiver. Check your network.');
  });
}

window.addEventListener('DOMContentLoaded', function() {
  if (_IS_RU) {
    _html('h_title',      _RU['h_title']);
    _txt('lbl_bouquets',  _RU['lbl_bouquets']);
    _txt('btn_bq_all',    _RU['btn_bq_all']);
    _txt('btn_bq_none',   _RU['btn_bq_none']);
    _txt('btn_ch_all',    _RU['btn_ch_all']);
    _txt('btn_ch_none',   _RU['btn_ch_none']);
    _html('btn_save',     _RU['btn_save']);
    _txt('h_hint',        _RU['h_hint']);
    _html('ok_msg',       _RU['ok_msg']);
  }
  if (DATA && DATA.provider) {
    var title = _IS_RU
      ? ('\u0411\u0440\u0430\u0443\u0437\u0435\u0440 \u043a\u0430\u043d\u0430\u043b\u043e\u0432 \u2014 ' + DATA.provider)
      : ('Channel Browser \u2014 ' + DATA.provider);
    _html('h_title', '&#128250;&nbsp;' + title);
  }
  _initState();
  _renderBouquets();
  _renderChannels();
  _updateChTitle();
  _updateStats();
});
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# IPTVChannelBrowserWebServer
# ---------------------------------------------------------------------------

class IPTVChannelBrowserWebServer(object):
    """
    HTTP server for PC-based channel selection in IPTVChannelBrowserScreen.

    Start with .start(channels, is_ru=False) — runs in a daemon thread.
    Serves a two-panel bouquet/channel browser page at GET /.
    POST /save receives JSON {"selected": [url, ...]} and stores in queue.
    Call .poll() from the Enigma2 main thread — returns list of selected
    URLs or None if nothing submitted yet.
    Call .stop() when the screen closes.
    """

    def __init__(self, port=WEB_CHANNEL_BROWSER_PORT):
        self._port        = port
        self._httpd       = None
        self._thread      = None
        self._queue       = []
        self._lock        = threading.Lock()
        self._actual_port = port

    # ------------------------------------------------------------------

    def start(self, channels, is_ru=False, selected_urls=None):
        """Build groups from channels list and start the HTTP server.

        Returns (True, ip, port) on success, (False, '', 0) on failure.
        """
        if not _HTTP_AVAILABLE:
            return False, '', 0

        # Build groups structure from raw channel list
        groups_order = []
        groups_map   = {}
        for ch in (channels or []):
            grp = (ch.get('group_title') or ch.get('group') or '').strip() or '(no group)'
            if grp not in groups_map:
                groups_map[grp] = []
                groups_order.append(grp)
            name = (ch.get('tvg_name') or ch.get('name') or '').strip()
            url  = (ch.get('url') or '').strip()
            if url:
                groups_map[grp].append({'name': name or url, 'url': url})

        groups_list = [
            {'grp': g, 'channels': groups_map[g]}
            for g in groups_order if groups_map[g]
        ]

        provider = ''
        if channels:
            first = channels[0]
            provider = (first.get('provider_name') or first.get('provider') or '').strip()

        data = {'provider': provider, 'is_ru': bool(is_ru), 'groups': groups_list,
                'selected_urls': list(selected_urls) if selected_urls is not None else None}
        data_json  = json.dumps(data, ensure_ascii=False)
        html_bytes = _HTML_CHANNEL_BROWSER.replace(
            '/*DATA_JSON*/null/*END_DATA_JSON*/', data_json
        ).encode('utf-8')

        lock  = self._lock
        queue = self._queue

        class _ReuseHTTPServer(HTTPServer):
            allow_reuse_address = True

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass

            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html_bytes)))
                self.end_headers()
                self.wfile.write(html_bytes)

            def do_POST(self):
                try:
                    path = self.path.split('?')[0].rstrip('/')
                    if path == '/save':
                        self._handle_save(lock, queue)
                    else:
                        self.send_response(404)
                        self.end_headers()
                except Exception:
                    try:
                        self.send_response(500)
                        self.end_headers()
                    except Exception:
                        pass

            def _handle_save(self, lock, queue):
                clen = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(clen).decode('utf-8', errors='replace')
                try:
                    data_in = json.loads(body)
                    selected = data_in.get('selected', [])
                    if not isinstance(selected, list):
                        selected = []
                except Exception:
                    selected = []
                with lock:
                    queue.append(selected)
                resp = b'{"ok":true}'
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(resp)))
                self.end_headers()
                self.wfile.write(resp)

        for port in range(self._port, self._port + 10):
            try:
                self._httpd = _ReuseHTTPServer(('', port), _Handler)
                self._actual_port = port
                break
            except OSError:
                self._httpd = None

        if self._httpd is None:
            return False, '', 0

        self._thread = threading.Thread(target=self._httpd.serve_forever)
        self._thread.daemon = True
        self._thread.start()
        return True, _get_local_ip(), self._actual_port

    # ------------------------------------------------------------------

    def stop(self):
        try:
            if self._httpd:
                self._httpd.shutdown()
                self._httpd = None
        except Exception:
            pass

    # ------------------------------------------------------------------

    def poll(self):
        """Return the next submitted selected-URL list, or None if nothing yet."""
        with self._lock:
            if self._queue:
                return self._queue.pop(0)
        return None


# ===========================================================================
# IPTVCustomEPGWebServer — web interface for CustomEPGScreen
# Port 1014 — serves a 4-column EPG assignment page
# ===========================================================================

_HTML_CUSTOM_EPG = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Custom EPG Manager</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:sans-serif;background:#1a1a2e;color:#eee;height:100vh;display:flex;flex-direction:column}
h1{background:#16213e;padding:10px 20px;font-size:17px;color:#e94560;border-bottom:1px solid #0f3460;display:flex;align-items:center;justify-content:space-between}
#ip-info{font-size:13px;color:#aef;font-weight:normal}
#toolbar{background:#16213e;padding:8px 20px;display:flex;gap:8px;flex-wrap:wrap;border-bottom:1px solid #0f3460}
.btn{padding:6px 14px;border:none;border-radius:4px;cursor:pointer;font-size:13px;transition:opacity .15s}
.btn-green{background:#27ae60;color:#fff}.btn-yellow{background:#f39c12;color:#000}
.btn-red{background:#e74c3c;color:#fff}.btn-blue{background:#2980b9;color:#fff}
.btn-send{background:#8e44ad;color:#fff}
.btn:hover{opacity:.8}.btn:active{opacity:.6}
#status{background:#0f3460;padding:6px 20px;font-size:12px;color:#aef;min-height:28px}
#infobar{background:#0a1628;padding:7px 20px;font-size:16px;color:#eee;min-height:36px;display:flex;gap:24px;flex-wrap:wrap;border-bottom:1px solid #0f3460}
#infobar span{white-space:nowrap}
#infobar .ib-lbl{color:#e94560;margin-right:5px}
#infobar .ib-val{color:#ffcc00}
#cols{display:flex;flex:1;overflow:hidden}
.col{flex:1;display:flex;flex-direction:column;border-right:1px solid #0f3460}
.col:last-child{border-right:none}
.col-hdr{background:#0f3460;padding:8px 12px;font-size:13px;font-weight:bold;color:#e94560}
.col-list{flex:1;overflow-y:auto;list-style:none}
.col-list li{padding:7px 12px;font-size:13px;cursor:pointer;border-bottom:1px solid #0d0d1a;transition:background .1s}
.col-list li:hover{background:#1e3a5f}
.col-list li.sel{background:#2a70a4;color:#fff;font-weight:bold;border-left:3px solid #e94560}
.col-list li.assigned{color:#2ecc71}
.col-list li.assigned.sel{color:#fff}
.col-list .divider{color:#555;font-size:11px;padding:4px 12px;cursor:default;background:#111}
.col-search{padding:5px 8px;background:#0f3460;border:none;border-bottom:1px solid #0f3460;color:#eee;font-size:13px;width:100%;outline:none;}
.col-search:focus{background:#1e3a5f;border-bottom:1px solid #e94560;}
.col-search::placeholder{color:#888;}
#src-form{display:none;background:#16213e;padding:10px 20px;border-bottom:1px solid #0f3460;gap:8px;flex-wrap:wrap;align-items:center}
#src-form.open{display:flex}
#src-form input{background:#0f3460;border:1px solid #2980b9;color:#eee;padding:5px 8px;border-radius:3px;width:200px}
#src-form input:focus{outline:1px solid #e94560}
</style>
</head>
<body>
<h1><span id="title">Custom EPG File</span><span id="ip-info"></span></h1>
<div id="toolbar">
  <button class="btn btn-green" onclick="assignEPG()">&#10003; Assign EPG</button>
  <button class="btn btn-red"   onclick="unassignEPG()">&#10007; Unassign EPG</button>
  <button class="btn btn-blue"  onclick="unassignAll()">&#10007; Unassign All</button>
  <button class="btn btn-yellow" onclick="toggleSrcForm()">+ Add Source</button>
  <button class="btn btn-yellow" onclick="updateSource()">&#8635; Update Source</button>
  <button class="btn btn-red"   onclick="deleteSource()">&#128465; Delete Source</button>
  <button class="btn btn-send"  onclick="saveAndSend()">&#10003; Save &amp; Send to Receiver</button>
  <button class="btn btn-blue" id="btn-shownames" onclick="toggleShowNames()">&#128065; Show by Name</button>
</div>
<div id="src-form">
  <input id="new-src-name" placeholder="Source name (no spaces)">
  <input id="new-src-url"  placeholder="http://..." style="width:320px">
  <button class="btn btn-green" onclick="addSource()">Add</button>
</div>
<div id="status">Loading...</div>
<div id="infobar"><span><span class="ib-lbl" id="lbl-ib-bouquet">Bouquet:</span><span class="ib-val" id="ib-bouquet">—</span></span><span><span class="ib-lbl" id="lbl-ib-channel">Channel:</span><span class="ib-val" id="ib-channel">—</span></span><span><span class="ib-lbl" id="lbl-ib-epgid">EPG Assigned:</span><span class="ib-val" id="ib-epgid">—</span></span><span><span class="ib-lbl" id="lbl-ib-epgsrc">EPG Source:</span><span class="ib-val" id="ib-epgsrc">—</span></span><span><span class="ib-lbl" id="lbl-ib-epgdisp">EPG Display Name:</span><span class="ib-val" id="ib-epgdisp">—</span></span></div>
<div id="cols">
  <div class="col"><div class="col-hdr">Bouquets</div><ul class="col-list" id="l1"></ul></div>
  <div class="col"><div class="col-hdr">Channels</div><input class="col-search" id="ch-search" placeholder="&#128269; Filter channels..." oninput="filterChannels()"><ul class="col-list" id="l2"></ul></div>
  <div class="col"><div class="col-hdr">EPG Sources</div><ul class="col-list" id="l3"></ul></div>
  <div class="col"><div class="col-hdr">EPG Selection</div><input class="col-search" id="epg-search" placeholder="&#128269; Filter EPG IDs..." oninput="filterEpgIds()"><ul class="col-list" id="l4"></ul></div>
</div>
<script>
var selBouquet=null, selBouquetSub=false, selBouquetPath=null;

function filterChannels(){
  var q=document.getElementById('ch-search').value.toLowerCase();
  var filtered=q?_chData.filter(function(it){return it.label.toLowerCase().indexOf(q)>=0;}):_chData;
  renderList('l2',filtered,selChannel,onChannelClick);
}

function filterEpgIds(){
  var q=document.getElementById('epg-search').value.toLowerCase();
  var filtered=q?_epgData.filter(function(it){return it.divider||it.label.toLowerCase().indexOf(q)>=0;}):_epgData;
  // Remove leading divider if first non-divider match is below it
  if(filtered.length>0 && filtered[0].divider) filtered=filtered.slice(1);
  renderList('l4',filtered,selEpgId,onEpgClick,_selEpgIdx);
}

var selChannel=null, selChannelSref=null, selChannelName=null, selChannelEpg=null, _selChIdx=-1;
var selSource=null, selSourceUrl=null;
var selEpgId=null, selEpgDisplay=null, _selEpgIdx=-1;
var parentPath=null;
var showNames=true;  // mirrors plugin _showNames default

function setStatus(msg){document.getElementById('status').textContent=msg}

function toggleShowNames(){
  showNames=!showNames;
  var btn=document.getElementById('btn-shownames');
  btn.textContent=(showNames?'\uD83D\uDC41 '+(L.show_by_id||'Show by ID'):'\uD83D\uDC41 '+(L.show_by_name||'Show by Name'));
  btn.style.background=showNames?'#27ae60':'#7f8c8d';
  if(selSource) loadEpgIds(selSource);
}


function api(url,method,body,cb){
  var opts={method:method||'GET',headers:{'Content-Type':'application/json'}};
  if(body) opts.body=JSON.stringify(body);
  fetch(url,opts).then(function(r){return r.json()}).then(cb).catch(function(e){setStatus('Error: '+e)});
}

// Stored data for re-render on click
var _bqData=[], _chData=[], _srcData=[], _epgData=[];

function renderList(id,items,sel,onclick,selIdx){
  var ul=document.getElementById(id); ul.innerHTML='';
  var idx=0;
  items.forEach(function(it){
    var li=document.createElement('li');
    if(it.divider){li.className='divider';li.textContent=it.label;ul.appendChild(li);return;}
    li.textContent=it.label;
    if(it.assigned) li.classList.add('assigned');
    if(selIdx!=null && selIdx>=0 ? idx===selIdx : (sel && it.id===sel)) li.classList.add('sel');
    (function(i,item){li.onclick=function(){onclick(item,i);};})(idx,it);
    idx++;
    ul.appendChild(li);
  });
}

// Re-render a list with updated sel without reloading data
function rerender(listId, data, sel, onclick, selIdx){
  renderList(listId, data, sel, onclick, selIdx);
}

function loadBouquets(){
  api('/api/bouquets','GET',null,function(d){
    document.getElementById('title').textContent=(L.title||'Custom EPG')+(d.provider?' — '+d.provider:'');
    if(d.ip && d.port) document.getElementById('ip-info').textContent='http://'+d.ip+':'+d.port;
    _bqData=d.bouquets;
    renderList('l1',_bqData,selBouquet,onBouquetClick);
    setStatus(d.provider?'Provider: '+d.provider:(L.ready||'Ready'));
    // Load sources once on startup
    if(!_sourcesLoaded){ _sourcesLoaded=true; loadSources(); }
  });
}

var selBouquetLabel=null;
function onBouquetClick(it){
  selBouquet=it.id; selBouquetPath=it.path; selBouquetSub=it.has_sub;
  selBouquetLabel=it.label;
  rerender('l1',_bqData,selBouquet,onBouquetClick);
  if(it.has_sub){ loadSubBouquets(it.path); }
  else { loadChannels(it.path); }
}

function loadSubBouquets(path){
  parentPath=path;
  api('/api/subbouquets?path='+encodeURIComponent(path),'GET',null,function(d){
    _bqData=d.bouquets;
    selBouquet=null; selChannel=null; selChannelSref=null;
    renderList('l1',_bqData,selBouquet,onBouquetClick);
    document.getElementById('l2').innerHTML='';
    document.getElementById('l4').innerHTML='';
  });
}

var _chCache={};
var _sourcesLoaded=false;
function loadChannels(bpath){
  selChannel=null; selChannelSref=null; selChannelName=null; selChannelEpg=null; _selChIdx=-1;
  var cs=document.getElementById('ch-search'); if(cs) cs.value='';
  // Use client-side cache — only fetch if not already loaded
  if(_chCache[bpath]){
    _chData=_chCache[bpath];
    renderList('l2',_chData,selChannel,onChannelClick);
    return;
  }
  api('/api/channels?bouquet='+encodeURIComponent(bpath),'GET',null,function(d){
    _chData=d.channels;
    _chCache[bpath]=_chData;  // cache it
    renderList('l2',_chData,selChannel,onChannelClick);
  });
}

function onChannelClick(it,idx){
  selChannel=it.id; selChannelSref=it.sref;
  selChannelName=it.name; selChannelEpg=it.epg;
  _selChIdx=(idx!=null?idx:-1);
  selEpgId=null; selEpgDisplay=null; _selEpgIdx=-1;
  document.getElementById('ib-bouquet').textContent  = selBouquetLabel || selBouquet || '—';
  document.getElementById('ib-channel').textContent  = it.name   || '—';
  document.getElementById('ib-epgid').textContent    = it.epg    || '—';
  document.getElementById('ib-epgsrc').textContent   = it.epgsrc || '—';
  document.getElementById('ib-epgdisp').textContent  = it.epgdisp|| '—';
  // Re-render with current filter still active
  var q=document.getElementById('ch-search').value.toLowerCase();
  var filtered=q?_chData.filter(function(x){return x.label.toLowerCase().indexOf(q)>=0;}):_chData;
  rerender('l2',filtered,selChannel,onChannelClick,_selChIdx);
  // Load EPG IDs for this channel if source already selected
  if(selSource) loadEpgIds(selSource);
}

function loadSources(){
  api('/api/sources','GET',null,function(d){
    _srcData=d.sources;
    renderList('l3',_srcData,selSource,onSourceClick);
    if(_srcData.length>0 && !selSource){
      selSource=_srcData[0].id; selSourceUrl=_srcData[0].url;
      rerender('l3',_srcData,selSource,onSourceClick);
      loadEpgIds(selSource);
    }
  });
}

function onSourceClick(it){
  selSource=it.id; selSourceUrl=it.url;
  rerender('l3',_srcData,selSource,onSourceClick);
  loadEpgIds(it.id);
}

function epgLabel(entry){
  if(showNames && entry.display) return entry.id+'  |  '+entry.display;
  return entry.id;
}

function loadEpgIds(srcName){
  var es=document.getElementById('epg-search'); if(es) es.value='';
  selEpgId=null; selEpgDisplay=null; _selEpgIdx=-1;
  var chParam=selChannelName?'&channel='+encodeURIComponent(selChannelName):'';
  var snParam='&show_names='+(showNames?'1':'0');
  api('/api/epgids?source='+encodeURIComponent(srcName)+chParam+snParam,'GET',null,function(d){
    _epgData=[];
    d.matches.forEach(function(e){_epgData.push({id:e.id,label:epgLabel(e),display:e.display,assigned:false});});
    if(d.matches.length>0) _epgData.push({divider:true,label:'─────────────────────'});
    d.all.forEach(function(e){_epgData.push({id:e.id,label:epgLabel(e),display:e.display,assigned:false});});
    renderList('l4',_epgData,null,onEpgClick,-1);
  });
}

function onEpgClick(it,idx){
  selEpgId=it.id;
  selEpgDisplay=it.display||'';
  _selEpgIdx=(idx!=null?idx:-1);
  // Re-render with current filter still active
  var q=document.getElementById('epg-search').value.toLowerCase();
  var filtered=q?_epgData.filter(function(x){return x.divider||x.label.toLowerCase().indexOf(q)>=0;}):_epgData;
  if(filtered.length>0 && filtered[0].divider) filtered=filtered.slice(1);
  rerender('l4',filtered,selEpgId,onEpgClick,_selEpgIdx);
}

function assignEPG(){
  if(!selBouquetPath||!selChannelSref||!selSource||!selEpgId){setStatus(L.select_all||'Select Bouquet, Channel, Source and EPG ID first');return;}
  api('/api/assign','POST',{bouquet:selBouquetPath,sref:selChannelSref,chname:selChannelName,
    src_name:selSource,src_url:selSourceUrl,epg_id:selEpgId,epg_display:selEpgDisplay||selEpgId},function(d){
    setStatus(d.ok?(L.epg_assigned||'EPG assigned')+': '+selEpgId:'Error: '+d.error);
    if(d.ok){delete _chCache[selBouquetPath]; loadChannels(selBouquetPath);}
  });
}

function unassignEPG(){
  if(!selBouquetPath||!selChannelSref){setStatus(L.sel_channel||'Select a channel first');return;}
  api('/api/unassign','POST',{bouquet:selBouquetPath,sref:selChannelSref,chname:selChannelName},function(d){
    setStatus(d.ok?(L.epg_unassigned||'EPG unassigned'):'Error: '+d.error);
    if(d.ok){delete _chCache[selBouquetPath]; loadChannels(selBouquetPath);}
  });
}

function unassignAll(){
  if(!selBouquetPath){setStatus(L.sel_bouquet||'Select a bouquet first');return;}
  api('/api/unassign_all','POST',{bouquet:selBouquetPath},function(d){
    setStatus(d.ok?(L.all_removed||'All EPG removed from bouquet'):'Error: '+d.error);
    if(d.ok){delete _chCache[selBouquetPath]; loadChannels(selBouquetPath);}
  });
}

function toggleSrcForm(){
  var f=document.getElementById('src-form');
  f.classList.toggle('open');
}

function addSource(){
  var name=document.getElementById('new-src-name').value.trim().replace(/\s+/g,'_');
  var url=document.getElementById('new-src-url').value.trim();
  if(!name||!url){setStatus(L.enter_name_url||'Enter name and URL');return;}
  api('/api/addsource','POST',{name:name,url:url},function(d){
    setStatus(d.ok?(L.src_added||'Source added'):'Error: '+d.error);
    if(d.ok){loadSources();document.getElementById('src-form').classList.remove('open');}
  });
}

function updateSource(){
  if(!selSource){setStatus(L.sel_source||L.sel_source||'Select a source first');return;}
  setStatus((L.downloading||'Downloading and parsing')+': '+selSource+' ...');
  api('/api/updatesource','POST',{name:selSource,url:selSourceUrl},function(d){
    setStatus(d.ok?(L.src_updated||'Source updated')+': '+d.count+' EPG IDs':'Error: '+d.error);
    if(d.ok) loadEpgIds(selSource);
  });
}

function deleteSource(){
  if(!selSource){setStatus('Select a source first');return;}
  api('/api/deletesource','POST',{name:selSource,url:selSourceUrl},function(d){
    setStatus(d.ok?(L.src_deleted||'Source deleted'):'Error: '+d.error);
    if(d.ok){selSource=null;selSourceUrl=null;loadSources();}
  });
}

function saveAndSend(){
  setStatus(L.saving||'Saving and sending to receiver...');
  api('/api/save_and_send','POST',{},function(d){
    setStatus(d.ok?(L.saved||'Saved and sent to receiver'):'Error: '+(d.error||'unknown'));
  });
}

loadBouquets();

// ── i18n ─────────────────────────────────────────────────────────────
if(typeof L==='undefined') var L={};
function _initLang(){
  if(!L||!L.bouquets) return;
  var el;
  el=document.querySelector('[onclick="assignEPG()"]');    if(el) el.innerHTML='&#10003; '+L.assign_epg;
  el=document.querySelector('[onclick="unassignEPG()"]');  if(el) el.innerHTML='&#10007; '+L.unassign_epg;
  el=document.querySelector('[onclick="unassignAll()"]');  if(el) el.innerHTML='&#10007; '+L.unassign_all;
  el=document.querySelector('[onclick="toggleSrcForm()"]');if(el) el.innerHTML='+ '+L.add_source;
  el=document.querySelector('[onclick="updateSource()"]'); if(el) el.innerHTML='&#8635; '+L.update_source;
  el=document.querySelector('[onclick="deleteSource()"]'); if(el) el.innerHTML='&#128465; '+L.delete_source;
  el=document.querySelector('[onclick="saveAndSend()"]');  if(el) el.innerHTML='&#10003; '+L.save_send;
  el=document.querySelector('[onclick="addSource()"]');    if(el) el.textContent=L.add_btn;
  el=document.getElementById('btn-shownames');               if(el) el.innerHTML='&#128065; '+L.show_by_name;
  el=document.getElementById('ch-search');   if(el) el.placeholder='\uD83D\uDD0D '+L.filter_channels;
  el=document.getElementById('epg-search');  if(el) el.placeholder='\uD83D\uDD0D '+L.filter_epg;
  el=document.getElementById('status');      if(el) el.textContent=L.loading;
  el=document.getElementById('new-src-name');if(el) el.placeholder=L.src_name_hint;
  var el2;
  el2=document.getElementById('lbl-ib-bouquet');   if(el2&&L.ib_bouquet)   el2.textContent=L.ib_bouquet+':';
  el2=document.getElementById('lbl-ib-channel');   if(el2&&L.ib_channel)   el2.textContent=L.ib_channel+':';
  el2=document.getElementById('lbl-ib-epgid');     if(el2&&L.ib_epg_assigned) el2.textContent=L.ib_epg_assigned+':';
  el2=document.getElementById('lbl-ib-epgsrc');    if(el2&&L.ib_epg_source)   el2.textContent=L.ib_epg_source+':';
  el2=document.getElementById('lbl-ib-epgdisp');   if(el2&&L.ib_epg_display)  el2.textContent=L.ib_epg_display+':';
  var hdrs=document.querySelectorAll('.col-hdr');
  if(hdrs[0]) hdrs[0].textContent=L.bouquets;
  if(hdrs[1]) hdrs[1].textContent=L.channels;
  if(hdrs[2]) hdrs[2].textContent=L.epg_sources;
  if(hdrs[3]) hdrs[3].textContent=L.epg_selection;
}
document.addEventListener('DOMContentLoaded',_initLang);
</script>
</body></html>
"""


class IPTVCustomEPGWebServer(object):
    """Web server for the CustomEPG screen. Port 1014."""

    def __init__(self, port=WEB_CUSTOM_EPG_PORT):
        self._port    = port
        self._httpd   = None
        self._thread  = None
        self._workdir = ''
        self._json_file = ''
        self._sources_file = ''
        self._provider = {}
        self._lock = threading.Lock()

    def start(self, provider, workdir, json_file, sources_file, refresh_callback=None, channel_refresh_callback=None):
        if not _HTTP_AVAILABLE:
            return False, '', 0
        self._provider         = provider or {}
        self._workdir          = workdir
        self._json_file        = json_file
        self._sources_file     = sources_file
        self._refresh_callback         = refresh_callback
        self._channel_refresh_callback = channel_refresh_callback
        # Translations captured here in Enigma2 main thread — T() works here
        self._L = {
            'assign_epg':      _WT('Assign EPG'),
            'unassign_epg':    _WT('Unassign EPG'),
            'unassign_all':    _WT('Unassign All'),
            'add_source':      _WT('Add Source'),
            'update_source':   _WT('Update Source'),
            'delete_source':   _WT('Delete Source'),
            'save_send':       _WT('Save & Send to Receiver'),
            'show_by_name':    _WT('Show by Name'),
            'show_by_id':      _WT('Show by ID'),
            'filter_channels': _WT('Filter channels...'),
            'filter_epg':      _WT('Filter EPG IDs...'),
            'loading':         _WT('Loading...'),
            'bouquets':        _WT('Bouquets'),
            'channels':        _WT('Channels'),
            'epg_sources':     _WT('EPG Sources'),
            'epg_selection':   _WT('EPG Selection'),
            'src_name_hint':   _WT('Source name (no spaces)'),
            'add_btn':         _WT('Add'),
            'ready':           _WT('Ready'),
            'title':           _WT('Custom EPG'),
            'select_all':      _WT('Select Bouquet, Channel, Source and EPG ID first'),
            'epg_assigned':    _WT('EPG assigned'),
            'sel_channel':     _WT('Select a channel first'),
            'epg_unassigned':  _WT('EPG unassigned'),
            'sel_bouquet':     _WT('Select a bouquet first'),
            'all_removed':     _WT('All EPG removed from bouquet'),
            'enter_name_url':  _WT('Enter name and URL'),
            'src_added':       _WT('Source added'),
            'downloading':     _WT('Downloading and parsing'),
            'src_updated':     _WT('Source updated'),
            'sel_source':      _WT('Select a source first'),
            'src_deleted':     _WT('Source deleted'),
            'saving':          _WT('Saving and sending to receiver...'),
            'saved':           _WT('Saved and sent to receiver'),
            'ib_bouquet':      _WT('Bouquets'),
            'ib_channel':      _WT('Channel'),
            'ib_epg_assigned': _WT('EPG Assigned'),
            'ib_epg_source':   _WT('EPG Source'),
            'ib_epg_display':  _WT('EPG Display Name'),
        }

        srv  = self
        lock = self._lock

        class _ReuseHTTPServer(HTTPServer):
            allow_reuse_address = True

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass

            def _send_json(self, data, status=200):
                body = json.dumps(data, ensure_ascii=False).encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(body)

            def _read_json(self):
                try:
                    if os.path.isfile(srv._json_file):
                        with open(srv._json_file) as f:
                            return json.load(f)
                except Exception:
                    pass
                return {'Sources': [], 'Bouquets': []}

            def _write_json(self, data):
                # Prune Sources not referenced by any remaining channel
                used = set()
                for b in data.get('Bouquets', []):
                    for ch in b.get('channel', []):
                        if ch.get('sourcename'): used.add(ch['sourcename'])
                data['Sources'] = [s for s in data.get('Sources', []) if s.get('name') in used]
                with open(srv._json_file, 'w') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)

            def _build_xml(self, epg_data):
                src_file = os.path.join(srv._workdir, 'custom_epg.sources.xml')
                ch_file  = os.path.join(srv._workdir, 'custom_epg_channels.xml')
                try:
                    with open(src_file, 'w') as f:
                        f.write('<?xml version="1.0" encoding="utf-8"?>\n<sources>\n')
                        f.write('<sourcecat sourcecatname="Custom EPG">\n')
                        for src in epg_data.get('Sources', []):
                            f.write('<source type="gen_xmltv" nocheck="1" channels="%s">\n' % ch_file)
                            f.write('<description>%s</description>\n' % src['name'])
                            f.write('<url><![CDATA[%s]]></url>\n</source>\n' % src['source'])
                        f.write('</sourcecat>\n</sources>\n')
                    with open(ch_file, 'w') as f:
                        f.write('<?xml version="1.0" encoding="utf-8"?>\n<channels>\n')
                        for bouquet in epg_data.get('Bouquets', []):
                            for ch in bouquet.get('channel', []):
                                sref    = ch['serviceid']
                                name    = (ch['description']
                                           .replace('<','').replace('>','').replace('&','and'))
                                disp    = (ch.get('epg_display_name') or '').replace('<','').replace('>','').replace('&','and').strip()
                                comment = ('%s | -> %s' % (name, disp)) if disp else name
                                f.write('<channel id="%s">%s</channel>'
                                        ' <!-- %s -->\n' % (ch['epgid'], sref, comment))
                        f.write('</channels>\n')
                except Exception:
                    pass

            def _read_bouquet(self, bpath):
                channels = []
                full = '/etc/enigma2/' + bpath
                if not os.path.isfile(full):
                    return channels
                epg_data = self._read_json()
                bq_entry = next((b for b in epg_data.get('Bouquets', [])
                                 if b['bouquet'] == bpath), None)
                chname = ''
                sref   = ''
                try:
                    with open(full) as f:
                        for line in f:
                            line = line.rstrip('\n')
                            if line.startswith('#SERVICE'):
                                if 'FROM BOUQUET' in line:
                                    chname = ''; sref = ''; continue
                                sref = line.split(' ', 1)[-1].strip()  # full sref incl URL
                                parts = line.split(':')
                                desc  = parts[-1].strip() if len(parts) > 10 else ''
                                chname = desc if desc and 'http' not in desc and '%' not in desc else ''
                            elif line.startswith('#DESCRIPTION'):
                                chname = line.replace('#DESCRIPTION', '', 1).lstrip(' ').lstrip('~#-<^').strip()
                            if sref and chname:
                                _sref = sref.strip()
                                epgid = ''; epgsrc = ''; epgdisp = ''
                                if bq_entry:
                                    for jc in bq_entry.get('channel', []):
                                        if jc['serviceid'] == _sref:
                                            epgid  = jc.get('epgid', '')
                                            epgsrc = jc.get('sourcename', '')
                                            epgdisp= jc.get('epg_display_name', '')
                                            break
                                channels.append({'id': chname.strip(), 'label': chname.strip() + ('  [' + epgid + ']' if epgid else ''),
                                                 'sref': _sref, 'name': chname.strip(), 'epg': epgid,
                                                 'epgsrc': epgsrc, 'epgdisp': epgdisp, 'assigned': bool(epgid)})
                                chname = ''; sref = ''
                except Exception:
                    pass
                # Sort same as plugin: assigned on top, unassigned below, divider between
                assigned   = [c for c in channels if c['assigned']]
                unassigned = [c for c in channels if not c['assigned']]
                assigned.sort(key=lambda x: x['name'].lower())
                unassigned.sort(key=lambda x: x['name'].lower())
                if assigned and unassigned:
                    channels = assigned + [{'id':'','label':'─'*28,'sref':'','name':'','epg':'','epgsrc':'','epgdisp':'','assigned':False,'divider':True}] + unassigned
                else:
                    channels = assigned + unassigned
                return channels

            def do_GET(self):
                path = self.path.split('?')[0].rstrip('/')

                if path in ('', '/'):
                    _ljs = '<script>var L='+json.dumps(srv._L,ensure_ascii=False)+';</script>\n'
                    body = (_ljs + _HTML_CUSTOM_EPG).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html; charset=utf-8')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return

                if path == '/api/bouquets':
                    prov_name = (srv._provider.get('name') or '').strip().lower()
                    skip = ('userbouquet.abm','#SERVICE 1:519','userbouquet.favourites',
                            'userbouquet.LastScanned','_vod_','_series_')
                    bqs = []
                    try:
                        with open('/etc/enigma2/bouquets.tv') as f:
                            for line in f:
                                if not (line.startswith('#SERVICE') and 'FROM BOUQUET' in line): continue
                                if any(t in line for t in skip): continue
                                bpath = line.split('"')[1::2][0]
                                bname = ''; has_sub = False
                                with open('/etc/enigma2/' + bpath) as bf:
                                    for bl in bf:
                                        if '#NAME' in bl: bname = ' '.join(bl.split()[1:])
                                        if 'subbouquet' in bl: has_sub = True
                                if not bname: continue
                                if prov_name:
                                    import re as _re
                                    # Same logic as plugin _safe_prov_name
                                    safe_prov = _re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', prov_name.strip()))).strip('_-').lower()
                                    bpath_lc = bpath.lower()
                                    bname_lc = bname.lower()
                                    # Anchored prefix match on filename
                                    file_match = bool(_re.match(r'(?:userbouquet|subbouquet)\.%s[_.]' % _re.escape(safe_prov), bpath_lc))
                                    # Exact or section name match
                                    name_match = (bname_lc == prov_name.lower() or
                                                  bname_lc.startswith(prov_name.lower() + ' - '))
                                    if not name_match and not file_match: continue
                                    # Longest-match exclusion: skip if another provider owns this file
                                    if file_match:
                                        try:
                                            from Plugins.Extensions.CustomIPTVArchiveMakerPro._screens import loadPlaylistProviderConfig, loadXtreamProviderConfig
                                            all_safes = [_re.sub(r'_+', '_', _re.sub(r'[^\w\-]', '', _re.sub(r'\s+', '_', (p.get('name','')).strip()))).strip('_-').lower()
                                                         for p in (list(loadPlaylistProviderConfig()) + list(loadXtreamProviderConfig()))]
                                            skip_bq = False
                                            for _other in all_safes:
                                                if _other == safe_prov or not _other: continue
                                                if (_re.match(r'(?:userbouquet|subbouquet)\.%s[_.]' % _re.escape(_other), bpath_lc)
                                                        and len(_other) > len(safe_prov)):
                                                    skip_bq = True; break
                                            if skip_bq: continue
                                        except Exception:
                                            pass
                                disp = bname.partition(' - ')[-1] if ' - ' in bname else bname
                                bqs.append({'id': bpath, 'label': disp + (' [+]' if has_sub else ''),
                                            'path': bpath, 'has_sub': has_sub})
                    except Exception:
                        pass
                    # Fallback: if provider filter matched nothing, return all bouquets
                    if prov_name and not bqs:
                        try:
                            with open('/etc/enigma2/bouquets.tv') as f:
                                for line in f:
                                    if not (line.startswith('#SERVICE') and 'FROM BOUQUET' in line): continue
                                    if any(t in line for t in skip): continue
                                    bpath = line.split('"')[1::2][0]
                                    bname = ''; has_sub = False
                                    with open('/etc/enigma2/' + bpath) as bf:
                                        for bl in bf:
                                            if '#NAME' in bl: bname = ' '.join(bl.split()[1:])
                                            if 'subbouquet' in bl: has_sub = True
                                    if not bname: continue
                                    disp = bname.partition(' - ')[-1] if ' - ' in bname else bname
                                    bqs.append({'id': bpath, 'label': disp + (' [+]' if has_sub else ''),
                                                'path': bpath, 'has_sub': has_sub})
                        except Exception: pass
                    import socket as _sock
                    try: _ip = _sock.gethostbyname(_sock.gethostname())
                    except Exception: _ip = ''
                    self._send_json({'provider': srv._provider.get('name',''),
                                     'bouquets': bqs, 'ip': _ip, 'port': srv._port})
                    return

                if path == '/api/subbouquets':
                    from urllib.parse import urlparse, parse_qs
                    qs = parse_qs(urlparse(self.path).query)
                    parent = qs.get('path', [''])[0]
                    bqs = []
                    try:
                        with open('/etc/enigma2/' + parent) as f:
                            for line in f:
                                if not line.startswith('#SERVICE'): continue
                                bpath = line.split('"')[1::2][0]
                                bname = ''
                                with open('/etc/enigma2/' + bpath) as bf:
                                    for bl in bf:
                                        if '#NAME' in bl:
                                            bname = ' '.join(bl.split()[1:])
                                            if ' - ' in bname: bname = bname.partition(' - ')[-1]
                                            break
                                if bname:
                                    bqs.append({'id': bpath, 'label': bname, 'path': bpath, 'has_sub': False})
                    except Exception:
                        pass
                    self._send_json({'bouquets': bqs})
                    return

                if path == '/api/channels':
                    from urllib.parse import urlparse, parse_qs
                    qs = parse_qs(urlparse(self.path).query)
                    bpath = qs.get('bouquet', [''])[0]
                    self._send_json({'channels': self._read_bouquet(bpath)})
                    return

                if path == '/api/sources':
                    sources = []
                    if os.path.isfile(srv._sources_file):
                        with open(srv._sources_file) as f:
                            for line in f:
                                line = line.strip()
                                if not line or line.startswith('#'): continue
                                if ' ' in line:
                                    n, u = line.split(' ', 1)
                                    sources.append({'id': n.strip(), 'label': n.strip(), 'url': u.strip()})
                    self._send_json({'sources': sources})
                    return

                if path == '/api/epgids':
                    from urllib.parse import urlparse, parse_qs
                    import re as _re
                    qs = parse_qs(urlparse(self.path).query)
                    src_name   = qs.get('source',  [''])[0]
                    channel    = qs.get('channel', [''])[0]
                    show_names = qs.get('show_names', ['1'])[0] == '1'
                    txt = os.path.join(srv._workdir, src_name + '.txt')
                    raw = []  # list of (epg_id, display_name)
                    if os.path.isfile(txt):
                        with open(txt) as f:
                            for line in f:
                                line = line.strip()
                                if not line: continue
                                if '|' in line:
                                    eid, _, dn = line.partition('|')
                                    raw.append((eid.strip(), dn.strip()))
                                else:
                                    raw.append((line, ''))

                    matched = []; rest = []
                    if channel and raw:
                        QUAL = {'hd','sd','fhd','4k','uhd','orig','am','de','uk',
                                'us','ru','fr','it','pl','il','ua','by','kz','plus','int','tv','the'}

                        def _norm(s):
                            s2 = _re.sub(r'[()]', '', s).lower().strip()
                            s2 = _re.sub(r'[^\w\s]', ' ', s2)
                            return _re.sub(r'\s+', ' ', s2).strip()

                        def _core(s):
                            words = _norm(s).split()
                            core = [w for w in words if w not in QUAL]
                            return ' '.join(core) if core else _norm(s)

                        if not show_names:
                            # Hide Names: fuzzy against EPG IDs (exact plugin logic)
                            epgids = [r[0].lower().strip() for r in raw]
                            namelist = []
                            try:
                                from fuzzywuzzy import fuzz, process as fproc
                                results = fproc.extract(channel, epgids, limit=42,
                                                        scorer=fuzz.token_sort_ratio)
                                namelist = [m[0] for m in results if m[1] >= 55]
                            except Exception:
                                from difflib import get_close_matches
                                q = channel.lower().replace(' ','')
                                namelist = get_close_matches(q, epgids, n=42, cutoff=0.40)
                            q_low = channel.lower().strip()
                            for eid_low in epgids:
                                if eid_low not in namelist:
                                    if q_low in eid_low or eid_low in q_low:
                                        namelist.append(eid_low)
                            matched_set = set(namelist)
                            matched = [(eid,dn) for eid,dn in raw if eid.lower().strip() in matched_set]
                            rest    = [(eid,dn) for eid,dn in raw if eid.lower().strip() not in matched_set]
                        else:
                            # Show Names: substring match against display names (exact plugin logic)
                            q_full = _norm(channel); q_core = _core(channel)
                            exact=[]; starts=[]; contains=[]; core_m=[]
                            for eid, dn in raw:
                                t_full = _norm(dn if dn else eid)
                                t_core = _core(dn if dn else eid)
                                if t_full == q_full: exact.append((eid,dn))
                                elif t_full.startswith(q_full) or q_full.startswith(t_full): starts.append((eid,dn))
                                elif q_full in t_full or t_full in q_full: contains.append((eid,dn))
                                elif q_core and t_core and (q_core==t_core or
                                     t_core.startswith(q_core) or q_core.startswith(t_core) or
                                     q_core in t_core or t_core in q_core): core_m.append((eid,dn))
                                else: rest.append((eid,dn))
                            matched = exact + starts + contains + core_m
                    else:
                        rest = raw

                    # Return structured data: matched and all entries with id+display_name
                    def _fmt(pairs):
                        return [{'id': eid, 'display': dn} for eid,dn in pairs]
                    self._send_json({'matches': _fmt(matched), 'all': _fmt(rest)})
                    return

                self.send_response(404)
                self.end_headers()

            def do_POST(self):
                length = int(self.headers.get('Content-Length', 0))
                body   = json.loads(self.rfile.read(length) or b'{}')
                path   = self.path.split('?')[0].rstrip('/')

                if path == '/api/assign':
                    with lock:
                        epg_data = self._read_json()
                        bpath  = body.get('bouquet','')
                        sref   = body.get('sref','')
                        chname = body.get('chname','')
                        sname  = body.get('src_name','')
                        surl   = body.get('src_url','')
                        epgid  = body.get('epg_id','')
                        if not any(s['name']==sname and s['source']==surl for s in epg_data['Sources']):
                            epg_data['Sources'].append({'name':sname,'source':surl})
                        b_entry = next((b for b in epg_data['Bouquets'] if b['bouquet']==bpath), None)
                        epg_display = body.get('epg_display', epgid)
                        new_ch = {'serviceid':sref,'description':chname,'epgid':epgid,'epg_display_name':epg_display,'source':surl,'sourcename':sname}
                        if b_entry is None:
                            epg_data['Bouquets'].append({'bouquet':bpath,'channel':[new_ch]})
                        else:
                            ce = next((c for c in b_entry['channel'] if c['serviceid']==sref),None)
                            if ce: ce.update(new_ch)
                            else: b_entry['channel'].append(new_ch)
                        self._write_json(epg_data)
                        self._build_xml(epg_data)
                    if srv._channel_refresh_callback:
                        try: srv._channel_refresh_callback(body.get('bouquet',''))
                        except Exception: pass
                    self._send_json({'ok': True})
                    return

                if path == '/api/unassign':
                    with lock:
                        epg_data = self._read_json()
                        bpath  = body.get('bouquet','')
                        sref   = body.get('sref','')
                        chname = body.get('chname','')
                        for jb in epg_data.get('Bouquets',[]):
                            if jb['bouquet'] == bpath:
                                # Match by serviceid only (same as plugin _unassignEPG)
                                jb['channel'] = [c for c in jb['channel']
                                                 if c['serviceid'] != sref]
                                if not jb['channel']:
                                    epg_data['Bouquets'].remove(jb)
                                break
                        self._write_json(epg_data)
                        self._build_xml(epg_data)
                    if srv._channel_refresh_callback:
                        try: srv._channel_refresh_callback(body.get('bouquet',''))
                        except Exception: pass
                    self._send_json({'ok': True})
                    return

                if path == '/api/unassign_all':
                    with lock:
                        epg_data = self._read_json()
                        bpath = body.get('bouquet','')
                        epg_data['Bouquets'] = [b for b in epg_data.get('Bouquets',[]) if b['bouquet']!=bpath]
                        self._write_json(epg_data)
                        self._build_xml(epg_data)
                    if srv._channel_refresh_callback:
                        try: srv._channel_refresh_callback(body.get('bouquet',''))
                        except Exception: pass
                    self._send_json({'ok': True})
                    return

                if path == '/api/addsource':
                    name = body.get('name','').strip().replace(' ','_')
                    url  = body.get('url','').strip()
                    if name and url:
                        try:
                            existing_lines = []
                            if os.path.isfile(srv._sources_file):
                                with open(srv._sources_file) as f:
                                    existing_lines = [l.rstrip('\n') for l in f if l.strip()]
                            # Add only if this exact name+url combo not already present
                            _own_entry = any(
                                l.split(' ', 1) == [name, url]
                                for l in existing_lines if ' ' in l
                            )
                            if not _own_entry:
                                with open(srv._sources_file,'a') as f:
                                    f.write('%s %s\n' % (name, url))
                        except Exception as e:
                            self._send_json({'ok': False, 'error': str(e)[:80]})
                            return
                        if srv._refresh_callback:
                            try: srv._refresh_callback()
                            except Exception: pass
                        self._send_json({'ok': True})
                    else:
                        self._send_json({'ok': False, 'error': 'name and url required'})
                    return

                if path == '/api/updatesource':
                    name = body.get('name','')
                    url  = body.get('url','')
                    try:
                        import urllib.request, gzip, shutil
                        dest = os.path.join(srv._workdir, name + '.tmp')
                        hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l)', 'Accept': '*/*'}
                        req = urllib.request.Request(url, headers=hdr)
                        with urllib.request.urlopen(req, timeout=60) as resp:
                            with open(dest, 'wb') as fd:
                                shutil.copyfileobj(resp, fd, 65536)
                        # Detect format by magic bytes — URL extension is unreliable
                        with open(dest, 'rb') as _mf: _magic = _mf.read(6)
                        xml_file = os.path.join(srv._workdir, name + '.xml')
                        if _magic[:2] == b'\x1f\x8b':
                            with gzip.open(dest,'rb') as src, open(xml_file,'wb') as dst:
                                shutil.copyfileobj(src, dst, 65536)
                            os.remove(dest)
                        elif _magic[:6] == b'\xfd7zXZ\x00' or url.endswith('.xz'):
                            import lzma
                            with lzma.open(dest,'rb') as src, open(xml_file,'wb') as dst:
                                shutil.copyfileobj(src, dst, 65536)
                            os.remove(dest)
                        else:
                            os.rename(dest, xml_file)
                        import re as _re
                        pat_id   = _re.compile(r'<channel[^>]+id="([^"]+)"')
                        pat_name = _re.compile(r'<display-name[^>]*>([^<]+)</display-name>')
                        entries = []; seen = set()
                        cur_id = None; cur_has_names = False
                        with open(xml_file,'r',errors='replace') as f:
                            for line in f:
                                m_id = pat_id.search(line)
                                if m_id:
                                    cur_id = m_id.group(1).strip()
                                    cur_has_names = False
                                m_name = pat_name.search(line)
                                if m_name and cur_id:
                                    dn = _re.sub(r'\[.*?\]','',m_name.group(1)).strip()
                                    if dn:
                                        key = (cur_id, dn)
                                        if key not in seen:
                                            entries.append(key); seen.add(key)
                                            cur_has_names = True
                                if '</channel>' in line:
                                    if cur_id and not cur_has_names:
                                        key = (cur_id, '')
                                        if key not in seen:
                                            entries.append(key); seen.add(key)
                                    cur_id = None; cur_has_names = False
                        entries.sort(key=lambda x: (x[0].lower(), x[1].lower()))
                        txt = os.path.join(srv._workdir, name + '.txt')
                        with open(txt,'w') as f:
                            for eid, dn in entries: f.write(eid+'|'+dn+'\n')
                        try: os.remove(xml_file)
                        except Exception: pass
                        self._send_json({'ok': True, 'count': len(entries)})
                    except Exception as e:
                        self._send_json({'ok': False, 'error': str(e)[:120]})
                    return

                if path == '/api/deletesource':
                    name = body.get('name','')
                    url  = body.get('url','')
                    if os.path.isfile(srv._sources_file):
                        with open(srv._sources_file) as f: lines = f.readlines()
                        with open(srv._sources_file,'w') as f:
                            for line in lines:
                                if not (name in line and url in line): f.write(line)
                    txt = os.path.join(srv._workdir, name+'.txt')
                    if os.path.isfile(txt): os.remove(txt)
                    if os.path.isfile(srv._json_file): os.remove(srv._json_file)
                    if srv._refresh_callback:
                        try: srv._refresh_callback()
                        except Exception: pass
                    self._send_json({'ok': True})
                    return

                if path == '/api/save_and_send':
                    with lock:
                        epg_data = self._read_json()
                        self._build_xml(epg_data)
                    if srv._channel_refresh_callback:
                        try: srv._channel_refresh_callback('')
                        except Exception: pass
                    self._send_json({'ok': True})
                    return

                self.send_response(404)
                self.end_headers()

        try:
            httpd = _ReuseHTTPServer(('', self._port), _Handler)
        except OSError:
            try:
                httpd = _ReuseHTTPServer(('', self._port + 1), _Handler)
                self._port += 1
            except OSError:
                return False, '', 0

        self._httpd = httpd
        self._thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        self._thread.start()
        ip = _get_local_ip()
        return True, ip, self._port

    def stop(self):
        if self._httpd:
            try:
                self._httpd.shutdown()
            except Exception:
                pass
            self._httpd = None
