# -*- coding: utf-8 -*-
import os as _os, glob as _glob, shutil as _shutil

# Remove stale bytecode so Python always compiles from the current .py files.
# Covers Python 2 (.pyc alongside .py) AND Python 3 (__pycache__ folder).
try:
    _plugin_dir = _os.path.dirname(_os.path.abspath(__file__))
    # Python 2: flat *.pyc files
    for _pyc in _glob.glob(_os.path.join(_plugin_dir, '*.pyc')):
        try:
            _os.remove(_pyc)
        except Exception:
            pass
    # Python 3: __pycache__ directory
    _cache_dir = _os.path.join(_plugin_dir, '__pycache__')
    if _os.path.isdir(_cache_dir):
        try:
            _shutil.rmtree(_cache_dir)
        except Exception:
            pass
except Exception:
    pass

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
import gettext
from os import environ as os_environ

PLUGIN_VERSION = "8.1"

plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/CustomIPTVArchiveMakerPro/'
PluginLanguageDomain = 'CustomIPTVArchiveMakerPro'
PluginLanguagePath = plugin_path + 'locale'

try:
    from enigma import eMediaDatabase
    isDreamOS = True
except:
    isDreamOS = False

def localeInit():
    if isDreamOS:
        lang = language.getLanguage()[:2]
        os_environ['LANGUAGE'] = lang
    gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

if isDreamOS:
    _ = lambda txt: (gettext.dgettext(PluginLanguageDomain, txt) if txt else '')
    localeInit()
    language.addCallback(localeInit)
else:

    def _(txt):
        if gettext.dgettext(PluginLanguageDomain, txt):
            return gettext.dgettext(PluginLanguageDomain, txt)
        else:
            return gettext.gettext(txt)

    language.addCallback(localeInit)
