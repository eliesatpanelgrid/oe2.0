# -*- coding: utf-8 -*-
"""
_providers.py — CustomIPTVArchiveMakerPro
==============================
Integrated IPTV provider detection and archive URL construction.

Exports
-------
  IPTV_PROVIDERS        — dict mapping URL fragment → (provider_tag, archive_days)
  getArchiveUrl(url)    — convert a live stream URL to an archive/catchup URL
  myStartTime           — mutable int: epoch of the selected programme's start
  myDuration            — mutable int: duration in seconds of the selected programme
  myTimeStamp           — mutable int: epoch when playback/seek was last triggered
"""

import os, time, re, datetime
from hashlib import md5

from . import _
from ._epg import (
    iptvLogWrite, currTime, DEBUG, HEADERS, PROVIDERS_CFG_FILE,
    query_get, xml_unescape,
    urlparse, parse_qs, parse_qsl, urlencode, unquote, quote,
    PY3,
)

# ---------------------------------------------------------------------------
# Global playback state  (mutated by iptvArchiveInfoBar and iptvArchiveSelection)
# ---------------------------------------------------------------------------

myStartTime         = 0
myDuration          = 0
myTimeStamp         = 0
myStartStr          = ''
myCustomIntProvider = None
myXtreamEpgOffset   = 0

# ---------------------------------------------------------------------------
# Integrated provider table
# ---------------------------------------------------------------------------
#
# Key   — a substring that uniquely identifies the provider in the stream URL.
# Value — (provider_tag, archive_depth_in_days)
#
# The provider_tag is used by onCreate() to pick the correct EPG API endpoint.
# 'undefined' is the sentinel for "no match".

IPTV_PROVIDERS = {
    'tvshka.net'    : ('shura',      7),   # shura.tv
    '1ott.'         : ('1ott',       8),   # my.1ott.net
    'only4.tv'      : ('only4',      7),   # 1cent.tv
    'satbiling.com' : ('iptvx.one',  7),   # iptv.satbilling.com
    '.crd-s.'       : ('iptvx.one',  3),   # crdru.net
    '/live/s.'      : ('shara.club', 2),   # shara.club
    '/live/u.'      : ('ipstream',   3),   # ipstream.one
    '/iptv/'        : ('ilook',      3),   # ilook.tv / it999.tv / tvclub.xyz
    'edem.tv'       : ('edem',       3),   # edem.tv (same backend as ilook.tv)
    '.ottg.'        : ('iptvx.one',  7),   # glanz (ottg.tv)
    '.fox-tv.'      : ('fox-tv',     5),   # fox-tv.fun
    '.iptv.'        : ('online',     1),   # iptv.online
    '.mymagic.'     : ('magic',      7),   # mymagic.tv
    'tvfor.pro'     : ('shara-tv',   5),   # shara-tv.org
    'uz-tv'         : ('uz-tv',      5),   # uz-tv.net
    '.bcumedia.pro' : ('bcu',        2),   # bcumedia.pro
    '.antifriz.'    : ('antifriz',   7),   # antifriz.tv
    'app-greatiptv' : ('app-greatiptv', 7),# app.greatiptv.cc
    '.zala.'        : ('zala',       2),   # zala.by
    '/zatv/'        : ('zala',       2),   # ZMedia Proxy → zala.by
    '178.124.183.'  : ('zala',       2),   # zala.by IP
    'zabava'        : ('zabava',     3),   # zabava.tv
    'cdn.ngenix.net': ('zabava',     3),   # zabava.tv CDN
    '.spr24.'       : ('sharavoz',   3),   # sharavoz.tv
    '.onlineott.'   : ('tvoetv',     5),   # tvoetv.in.ua
    '85.143.191.'   : ('ttv',        5),   # ttv.run
    'myott.top'     : ('ottclub',    5),   # ottclub.cc
    '.itv.'         : ('itv',        3),   # itv.live
    'cdn.wf'        : ('itv',        3),   # itv.live CDN
    'iptvx.tv'      : ('cbilling',   7),   # cbilling.me
    'wsbof.com'     : ('cbilling',   7),   # cbilling.me (wsbof servers)
    'tv.team'       : ('tvteam',     7),   # tv.team
    'troya.tv'      : ('tvteam',     7),   # tv.team (rebranded)
    '1usd.tv'       : ('tvteam',     7),   # tv.team (rebranded)
    'cdntv.online'  : ('viplime',    3),   # viplime.fun
    '.tvdosug.'     : ('propg.net',  1),   # tvdosug.tv
    '.lightiptv.'   : ('lightiptv',  5),   # lightiptv.cc
    '.mitv.'        : ('mitv',       5),   # mitv.cc
    '.uztv.'        : ('uztv',       5),   # uztv.tv
    'reflex.fun'    : ('reflexfun',  3),   # reflex.fun
    'protected-api.': ('protected-api', 3), # protected-api.com
    'gazoni'        : ('gazoni',     3),   # gazoni.com
    '/channel/'     : ('zmedia',     3),   # ZMedia Proxy (wink/Zabava)
    '/rmtv/'        : ('iptvx.one',  7),   # ZMedia Proxy local
    'undefined'     : (None,         0),   # sentinel — no provider matched
}

# ---------------------------------------------------------------------------
# Archive URL builder
# ---------------------------------------------------------------------------

def getArchiveUrl(url, title=''):
    """Convert a live stream URL to a time-shifted archive URL.

    Uses myStartTime, myDuration, myTimeStamp, myStartStr from this module.
    The *title* parameter is only used by the bcumedia path.
    """
    global myStartTime, myDuration, myTimeStamp, myStartStr

    parsed_url   = urlparse(url)
    splittedpath = parsed_url.path.split('/')
    token        = query_get(parsed_url.query, 'token')

    # Custom integrated provider — apply the selected archive URL pattern
    if myCustomIntProvider is not None:
        # If channel has catchup-source template, use it directly
        try:
            from ._epg import _matched_catchup_source as _cs
        except Exception:
            _cs = ''
        catchup_src = _cs or myCustomIntProvider.get('catchup_source', '')
        if catchup_src:
            import datetime as _dt
            _start = _dt.datetime.utcfromtimestamp(myStartTime)
            _end   = _dt.datetime.utcfromtimestamp(myStartTime + myDuration)
            _fmt   = '%Y%m%d%H%M%S'
            _su    = _start.strftime(_fmt)
            _eu    = _end.strftime(_fmt)
            archive_url = catchup_src
            archive_url = re.sub(r'\$\{[\(\[]?b[\)\]]?[^\}]*\}', _su, archive_url)
            archive_url = re.sub(r'\$\{[\(\[]?e[\)\]]?[^\}]*\}', _eu, archive_url)
            archive_url = re.sub(r'\{utc[^}]*\}',    str(myStartTime),               archive_url)
            archive_url = re.sub(r'\{utcend[^}]*\}', str(myStartTime + myDuration),   archive_url)
            if DEBUG:
                iptvLogWrite('[Archive] catchup-source URL: %s' % archive_url)
            return archive_url
        pattern = myCustomIntProvider.get('archive_pattern', 'standard')
        if pattern == 'path_archive':
            url = parsed_url._replace(
                path='%s/archive-%d-%d.m3u8' % (splittedpath[1], myStartTime, myDuration))
        elif pattern == 'path_timeshift':
            url = parsed_url._replace(
                path='%s/video-timeshift_abs-%d.m3u8' % (splittedpath[1], myStartTime))
        elif pattern == 'simple_offset':
            url = parsed_url._replace(query='archive=%d' % myStartTime)
        else:  # standard
            url = (parsed_url._replace(
                       query='token=%s&utc=%d&lutc=%d' % (token, myStartTime, myTimeStamp))
                   if token
                   else parsed_url._replace(
                       query='utc=%d&lutc=%d' % (myStartTime, myTimeStamp)))
        if DEBUG:
            iptvLogWrite(url.geturl())
        return url.geturl()

    if DEBUG:
        iptvLogWrite('Title: %s' % title)

    # cbilling
    if 'iptvx.tv' in url:
        if 'video-timeshift' not in splittedpath[-1]:
            if not token: token = splittedpath[2]
            if parsed_url.scheme == 'rtmp':
                parsed_url = parsed_url._replace(scheme='http')
            url = (parsed_url
                   ._replace(netloc='%s' % parsed_url.netloc.split(':')[0])
                   ._replace(query='token=%s' % token)
                   ._replace(path='%s/video-timeshift_abs-%d.m3u8' % (
                       splittedpath[2] if 'static' in splittedpath
                       else splittedpath[-1].split('.')[0] if 's' in splittedpath
                       else splittedpath[1],
                       myStartTime)))
        else:
            url = parsed_url._replace(
                path='%s/video-timeshift_abs-%d.m3u8' % (splittedpath[1], myStartTime))

    # antifriz
    elif '.antifriz.' in url:
        if not token: token = splittedpath[2]
        if 'static' in splittedpath:
            splittedpath.append('video.m3u8')
            splittedpath.remove('static')
            parsed_url = (parsed_url
                          ._replace(scheme='http')
                          ._replace(path='/'.join(splittedpath)))
        url = (parsed_url
               ._replace(netloc='%s:80' % parsed_url.hostname)
               ._replace(query='token=%s' % token)
               ._replace(path='%s/archive-%d-%d.m3u8' % (
                   splittedpath[-2], myStartTime, myDuration)))

    # ZMediaProxy — RT / Zabava / wink / zala
    elif any(x in url for x in ['/channel/', '/rmtv/', '/zatv/']):
        q   = query_get(parsed_url.query, 'q')
        url = parsed_url._replace(
            query='q=%s&offset=%d&utcstart=%s' % (q, myStartTime - currTime(), myTimeStamp))

    # zala.by & zabava.tv
    elif any(x in url for x in ['.zala.', '178.124.183.', 'zabava', 'cdn.ngenix.net']):
        url = parsed_url._replace(query='version=2&offset=%d' % (myStartTime - currTime()))

    # 1ott
    elif '1ott.' in url:
        url = parsed_url._replace(query='archive=%d' % myStartTime)

    # tvoetv.in.ua
    elif any(x in url for x in ['.onlineott.', '46.174.189']):
        login = query_get(parsed_url.query, 'login')
        key   = query_get(parsed_url.query, 'key')
        if '46.174.189.' not in url:
            parsed_url   = urlparse(unquote(query_get(parsed_url.query, 'url')))._replace(netloc='46.174.189.2:8091')
            splittedpath = parsed_url.path.split('/')
        url = (parsed_url
               ._replace(path='%s/archive-%d-%d.m3u8' % (splittedpath[1], myStartTime, myDuration))
               ._replace(query='login=%s&key=%s' % (login, key)))

    # bcumedia
    elif any(x in url for x in ['.bcumedia.pro', '5.9.10.135']) and PROVIDERS_CFG_FILE:
        if '.bcumedia.pro' in url:
            token    = ''
            cfg_file = PROVIDERS_CFG_FILE
            if os.path.isfile(cfg_file):
                with open(cfg_file, 'r') as f:
                    token = re.findall(r"\[(https:\/\/bcumedia.pro.+?)\]", f.read())
            if token:
                token = os.path.splitext(os.path.basename(token[0]))[0]
            url = urlparse('http://5.9.10.135:8080/%s/video-%s-%s.m3u8?token=%s' % (
                md5(title.encode('utf-8')).hexdigest()[:9],
                myStartTime, myDuration, token))
        else:
            url = parsed_url._replace(
                path='%s/video-%s-%s.m3u8' % (splittedpath[1], myStartTime, myDuration))

    # itv.live & glanz & flussonic-type
    elif any(x in url for x in ['.itv.', 'cdn.wf', '.ottg.']):
        url = parsed_url._replace(
            path='%s/index-%d-%d.m3u8' % (splittedpath[1], myStartTime, myDuration))

    # Xtream Codes — /live/user/pass/STREAM_ID.ext → /timeshift/user/pass/DURATION_MIN/DATETIME/STREAM_ID.ext
    elif (len(splittedpath) >= 5 and splittedpath[1] == 'live'
          and '.' in splittedpath[4]):
        dur_min  = max(1, myDuration // 60)
        # Use the raw server-local-time string from the Xtream EPG 'start' field when
        # available (set by _loadXtreamEPG via eventSelected).  This matches what BMX
        # does and avoids epoch/timezone conversion errors.  For seeks myStartStr is
        # cleared so we fall back to the epoch-based local time.
        if myStartStr:
            start_dt  = myStartStr
            myStartStr = ''
        else:
            start_dt = datetime.datetime.fromtimestamp(myStartTime).strftime('%Y-%m-%d:%H-%M')
        url = parsed_url._replace(
            path='/timeshift/%s/%s/%d/%s/%s' % (
                splittedpath[2], splittedpath[3], dur_min, start_dt, splittedpath[4]))

    # tv.team / 1cent / shura / ottclub / ilook / shara.club / fox-tv / generic shift/append
    else:
        if any(x in url for x in ['tv.team', 'troya.tv', '1usd.tv']) and 'static' in splittedpath:
            splittedpath.append('mono.m3u8')
            splittedpath.remove('static')
            parsed_url = (parsed_url
                          ._replace(netloc='%s:24000' % parsed_url.netloc.split(':')[0])
                          ._replace(scheme='http')
                          ._replace(path='/'.join(splittedpath)))
        if any(x in url for x in ['satbiling.com', 'only4.tv']) and '82' not in parsed_url.netloc:
            parsed_url = parsed_url._replace(netloc='%s:82' % parsed_url.netloc.split(':')[0])
        url = (parsed_url._replace(query='token=%s&utc=%d&lutc=%d' % (token, myStartTime, myTimeStamp))
               if token
               else parsed_url._replace(query='utc=%d&lutc=%d' % (myStartTime, myTimeStamp)))

    if DEBUG:
        iptvLogWrite(url.geturl())

    return url.geturl()
