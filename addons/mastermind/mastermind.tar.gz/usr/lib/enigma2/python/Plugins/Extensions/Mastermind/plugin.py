# -*- coding: utf-8 -*-
import os
import random
import json
from collections import Counter

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import getDesktop

from . import _, __version__


PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_PATH = "/etc/enigma2/mastermind.json"

try:
    from skin import loadSkin
    desk_w = getDesktop(0).size().width()
    if desk_w >= 2560:
        loadSkin(os.path.join(PLUGIN_DIR, "skin_2560.xml"))
    elif desk_w >= 1920:
        loadSkin(os.path.join(PLUGIN_DIR, "skin_1920.xml"))
    else:
        loadSkin(os.path.join(PLUGIN_DIR, "skin.xml"))
except Exception:
    pass

LEVELS = [
    {"colors": 4, "tries": 10, "repeats": False},
    {"colors": 5, "tries": 10, "repeats": False},
    {"colors": 6, "tries": 10, "repeats": False},
    {"colors": 7, "tries": 10, "repeats": True},
    {"colors": 8, "tries": 10, "repeats": True},
    {"colors": 4, "tries": 8,  "repeats": True},
    {"colors": 5, "tries": 8,  "repeats": True},
    {"colors": 6, "tries": 8,  "repeats": True},
    {"colors": 7, "tries": 8,  "repeats": True},
    {"colors": 8, "tries": 8,  "repeats": True},
]

COLORS_HEX = [
    "#e74c3c", "#3498db", "#2ecc71", "#f1c40f",
    "#e67e22", "#9b59b6", "#1abc9c", "#ecf0f1",
]


def generate_board_svg(rows, pegs, max_tries, cur_row, cur_guess,
                       secret, game_over, cur_peg, widget_w, widget_h, filepath):
    """Generate the game board SVG."""
    PAD = 2
    ch = widget_h // (max_tries + 1)
    FEED_R = max(5, ch // 6)
    FSTEP = FEED_R * 2 + max(4, ch // 12)
    NUM_W = int(ch * 0.75)

    cw = widget_w
    for _cw in range(widget_w, 0, -1):
        _BW = PAD + NUM_W + pegs * _cw + max(8, _cw // 8) + 2 * FSTEP + PAD
        if _BW <= widget_w:
            cw = _cw
            break

    GAP = max(8, cw // 8)
    PEG_R = ch // 2 - 7
    BW = PAD + NUM_W + pegs * cw + GAP + 2 * FSTEP + PAD
    BH = (max_tries + 1) * ch

    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{BW}" height="{BH}">')
    lines.append('  <rect width="100%" height="100%" fill="#000000"/>')

    sx0 = PAD + NUM_W
    lines.append(f'  <rect x="{sx0}" y="2" width="{pegs * cw}" height="{ch - 4}" fill="none" rx="3"/>')

    # Secret row (only visible if game over)
    for p in range(pegs):
        cx = sx0 + p * cw + cw // 2
        cy = ch // 2
        fill = COLORS_HEX[secret[p]] if game_over else "#000000"
        stroke = "#777777" if game_over else "#000000"
        lines.append(f'  <circle cx="{cx}" cy="{cy}" r="{PEG_R}" fill="{fill}" stroke="{stroke}" stroke-width="1"/>')

    # Rows (guesses)
    for r in range(max_tries):
        display_row = max_tries - 1 - r
        y = ch + display_row * ch
        is_active = (r == cur_row and not game_over)
        num_size = ch // 2 - 2
        num_col = "#f1c40f" if is_active else "#bababa"
        num_weight = "bold" if is_active else "normal"
        lines.append(f'  <text x="{PAD + 2}" y="{y + ch // 2 + num_size // 2}" font-family="sans-serif" font-size="{num_size}" font-weight="{num_weight}" fill="{num_col}">{r + 1}.</text>')

        if r < len(rows):
            guess = rows[r]["guess"]
        elif is_active:
            guess = cur_guess
        else:
            guess = [None] * pegs

        for p in range(pegs):
            cx = sx0 + p * cw + cw // 2
            cy = y + ch // 2
            fill = COLORS_HEX[guess[p]] if guess[p] is not None else None
            if fill:
                lines.append(f'  <circle cx="{cx}" cy="{cy}" r="{PEG_R}" fill="{fill}" stroke="#333" stroke-width="2"/>')
            else:
                lines.append(f'  <circle cx="{cx}" cy="{cy}" r="{PEG_R}" fill="none" stroke="#bababa" stroke-width="2" stroke-dasharray="3,2"/>')
            if is_active and p == cur_peg:
                lines.append(f'  <circle cx="{cx}" cy="{cy}" r="{PEG_R + 4}" fill="none" stroke="white" stroke-width="2" opacity="0.9"/>')

        # Feedback pegs (black/white)
        if r < len(rows):
            feed = (["#111111"] * rows[r]["hits"] +
                    ["#eeeeee"] * rows[r]["nears"] +
                    ["none"] * (pegs - rows[r]["hits"] - rows[r]["nears"]))
        else:
            feed = ["none"] * pegs

        fx0 = sx0 + pegs * cw + GAP
        rows2 = (pegs + 1) // 2
        total_h = rows2 * FSTEP
        start_y = y + (ch - total_h) // 2 + FEED_R

        for fp in range(pegs):
            fx = fx0 + (fp % 2) * FSTEP + FEED_R
            fy = start_y + (fp // 2) * FSTEP
            if feed[fp] == "none":
                lines.append(f'  <circle cx="{fx}" cy="{fy}" r="{FEED_R}" fill="none" stroke="#bababa" stroke-width="2" stroke-dasharray="2,2"/>')
            else:
                stroke = "#555555" if feed[fp] == "#111111" else "#aaaaaa"
                lines.append(f'  <circle cx="{fx}" cy="{fy}" r="{FEED_R}" fill="{feed[fp]}" stroke="{stroke}" stroke-width="2"/>')

    lines.append('</svg>')
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines))


class MastermindScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self._level_idx = 0

        self["bg"] = Pixmap()
        self["background"] = Pixmap()
        self["w_info"] = Label("")
        self["w_legend"] = Label("")
        self["w_levelinfo"] = Label("")
        self["w_status"] = Label("")
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Restart"))
        self["key_yellow"] = Label(_("Copy"))
        self["key_blue"] = Label("")
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "ShortcutActions"],
            {"left": self._prev_peg,
             "right": self._next_peg,
             "up": self._color_up,
             "down": self._color_down,
             "ok": self._confirm,
             "cancel": self.close,
             "red": self.close,
             "green": self._restart_level,
             "yellow": self._copy_last,
             "blue": self._change_level}, -10)

        self.onClose.append(self._cleanup)
        self.onLayoutFinish.append(self._on_layout)

        self._new_game(delete_save=False)
        self._load_game()

    def _cleanup(self):
        self._save_game()
        try:
            for f in ["/tmp/mastermind_board.svg", "/tmp/mastermind_black.png"]:
                if os.path.exists(f):
                    os.remove(f)
        except Exception:
            pass

    def _save_game(self):
        try:
            if not self._game_over and (self._rows or any(g != 0 for g in self._cur_guess)):
                data = {
                    "level_idx": self._level_idx,
                    "secret": self._secret,
                    "rows": self._rows,
                    "cur_guess": self._cur_guess,
                    "cur_peg": self._cur_peg
                }
                with open(SAVE_PATH, "w") as f:
                    json.dump(data, f)
            else:
                if os.path.exists(SAVE_PATH):
                    os.remove(SAVE_PATH)
        except Exception:
            pass

    def _load_game(self):
        if os.path.exists(SAVE_PATH):
            try:
                with open(SAVE_PATH, "r") as f:
                    data = json.load(f)
                self._level_idx = data.get("level_idx", 0)
                self._cfg = LEVELS[self._level_idx]
                self._secret = data.get("secret", self._secret)
                self._rows = data.get("rows", [])
                self._cur_guess = data.get("cur_guess", [0] * 4)
                self._cur_peg = data.get("cur_peg", 0)
                self._game_over = False
                self._won = False
            except Exception:
                self._new_game(delete_save=True)

    def _on_layout(self):
        if not self["bg"].instance:
            return
        sz = self["bg"].instance.size()
        w, h = sz.width(), sz.height()
        if w <= 0 or h <= 0:
            return

        black_png = "/tmp/mastermind_black.png"
        try:
            from PIL import Image
            img = Image.new('RGB', (w, h), color='black')
            img.save(black_png, 'PNG')
        except ImportError:
            import base64
            png_data = base64.b64decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
            )
            with open(black_png, 'wb') as f:
                f.write(png_data)

        if self["background"].instance:
            self["background"].instance.setPixmapFromFile(black_png)
            self["background"].show()

        self._render()

    def _new_game(self, delete_save=True):
        self._cfg = LEVELS[self._level_idx]
        pegs = 4
        colors = self._cfg["colors"]

        if self._cfg["repeats"]:
            self._secret = [random.randint(0, colors - 1) for _ in range(pegs)]
        else:
            pool = list(range(colors))
            random.shuffle(pool)
            self._secret = pool[:pegs]

        self._rows = []
        self._cur_guess = [0] * pegs
        self._cur_peg = 0
        self._game_over = False
        self._won = False

        if delete_save and os.path.exists(SAVE_PATH):
            try:
                os.remove(SAVE_PATH)
            except Exception:
                pass

    def _render(self):
        try:
            sz = self["bg"].instance.size()
            svg_path = "/tmp/mastermind_board.svg"
            generate_board_svg(
                self._rows, 4, self._cfg["tries"],
                len(self._rows), self._cur_guess,
                self._secret, self._game_over,
                self._cur_peg,
                sz.width(), sz.height(),
                svg_path
            )
            if self["bg"].instance:
                self["bg"].instance.setPixmapFromFile(svg_path)
                self["bg"].show()
        except Exception as e:
            print(f"[Mastermind] Render error: {e}")
        self._update_hud()

    def _update_hud(self):
        level_list = []
        for i, lvl in enumerate(LEVELS):
            prefix = "• " if i == self._level_idx else "  "
            line = f"{prefix}_(Level ) {i + 1}.  {lvl['colors']} {_('Colors')}, {lvl['tries']} {_('Tries')}"
            level_list.append(line)
        self["w_levelinfo"].setText("\n".join(level_list))

        if not self._game_over:
            info_txt = _("Try %d of %d") % (len(self._rows) + 1, self._cfg["tries"])
        else:
            info_txt = _("Game Over")
        self["w_info"].setText(info_txt)

        blue_txt = _("Level %d/%d") % (self._level_idx + 1, len(LEVELS))
        self["key_blue"].setText(blue_txt)

        self["w_legend"].setText(
            _("Black: color & pos correct") + "\n" +
            _("White: only color correct")
        )

        if self._game_over:
            status = _("You won! Press OK for new game") if self._won else _("You lost! Press OK for new game")
            self["w_status"].setText(status)
        else:
            self["w_status"].setText(_("Left/Right: navigate") + "\n" + _("Up/Down: change color") + "\n" + _("OK: confirm"))

    def _prev_peg(self):
        if self._game_over:
            return
        self._cur_peg = (self._cur_peg - 1) % 4
        self._render()

    def _next_peg(self):
        if self._game_over:
            return
        self._cur_peg = (self._cur_peg + 1) % 4
        self._render()

    def _color_up(self):
        if self._game_over:
            return
        c = self._cur_guess[self._cur_peg]
        self._cur_guess[self._cur_peg] = (c + 1) % self._cfg["colors"]
        self._render()

    def _color_down(self):
        if self._game_over:
            return
        c = self._cur_guess[self._cur_peg]
        self._cur_guess[self._cur_peg] = (c - 1) % self._cfg["colors"]
        self._render()

    def _confirm(self):
        if self._game_over:
            self._new_game(delete_save=True)
            self._render()
            return

        guess = list(self._cur_guess)
        secret = self._secret
        hits = sum(g == s for g, s in zip(guess, secret))
        g_cnt = Counter(g for g, s in zip(guess, secret) if g != s)
        s_cnt = Counter(s for g, s in zip(guess, secret) if g != s)
        nears = sum((g_cnt & s_cnt).values())

        self._rows.append({"guess": guess, "hits": hits, "nears": nears})

        if hits == 4:
            self._game_over, self._won = True, True
        elif len(self._rows) >= self._cfg["tries"]:
            self._game_over, self._won = True, False
        else:
            self._cur_guess, self._cur_peg = [0] * 4, 0

        self._render()

    def _copy_last(self):
        if self._game_over:
            return
        if not self._rows:
            self["w_status"].setText(_("Nothing to copy in the first try!"))
            return
        self._cur_guess = list(self._rows[-1]["guess"])
        self._cur_peg = 0
        self._render()

    def _restart_level(self):
        self._new_game(delete_save=True)
        self._render()

    def _change_level(self):
        self._level_idx = (self._level_idx + 1) % len(LEVELS)
        self._new_game(delete_save=True)
        self._render()


def main(session, **kwargs):
    session.open(MastermindScreen)


def Plugins(**kwargs):
    return PluginDescriptor(
        name=_("Mastermind"),
        description=_("Mastermind v.%s") % __version__,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="mastermind.svg",
        fnc=main)
