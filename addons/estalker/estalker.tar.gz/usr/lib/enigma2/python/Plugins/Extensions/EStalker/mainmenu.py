#!/usr/bin/python
# -*- coding: utf-8 -*-

# Standard library imports
import json
import os
import sys

# Enigma2 components
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from enigma import eServiceReference
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.config import configfile

# Local application/library-specific imports
from . import _
from . import estalker_globals as glob
from . import processfiles as loadfiles
from .plugin import skin_directory, common_path, version, cfg
from .eStaticText import StaticText

from .utils import _get_current_aspect_ratio, clearCaches

try:
    from enigma import eAVSwitch
except Exception:
    from enigma import eAVControl as eAVSwitch


class EStalker_MainMenu(Screen):
    ALLOW_SUSPEND = True

    def __init__(self, session):
        Screen.__init__(self, session)

        clearCaches()

        self.session = session

        skin_path = os.path.join(skin_directory, cfg.skin.value)
        skin = os.path.join(skin_path, "mainmenu.xml")
        with open(skin, "r") as f:
            self.skin = f.read()

        self.list = []
        self.drawList = []
        self.playlists_all = []
        self["list"] = List(self.drawList, enableWrapAround=True)

        self.playlists_json = cfg.playlists_json.value
        self.setup_title = _("Main Menu")
        self["key_red"] = StaticText(_("Back"))
        self["key_green"] = StaticText(_("OK"))
        self["key_blue"] = StaticText(_("Reset JSON"))
        self["version"] = StaticText()

        self["actions"] = ActionMap(["EStalkerActions"], {
            "red": self.quit,
            "green": self.__next__,
            "ok": self.__next__,
            "cancel": self.quit,
            "menu": self.settings,
            "help": self.resetData,
            "blue": self.resetData,
        }, -2)

        self["version"].setText(version)

        self.key_sequence = []

        if self.session.nav.getCurrentlyPlayingServiceReference():
            glob.currentPlayingServiceRef = self.session.nav.getCurrentlyPlayingServiceReference()
            glob.currentPlayingServiceRefString = self.session.nav.getCurrentlyPlayingServiceReference().toString()
            glob.newPlayingServiceRef = self.session.nav.getCurrentlyPlayingServiceReference()
            glob.newPlayingServiceRefString = glob.newPlayingServiceRef.toString()

        glob.original_aspect_ratio = _get_current_aspect_ratio()

        self.onFirstExecBegin.append(self.check_dependencies)
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def check_python_dependencies(self):
        try:
            import requests
            from PIL import Image
            if sys.version_info < (3, 9):
                from multiprocessing.pool import ThreadPool
            return True
        except Exception as e:
            print("Failed to import dependencies:", e)
            return False

    def check_dependencies(self):
        try:
            if not cfg.location_valid.value:
                print("Playlists.txt location is invalid and has been reset.")
                self.session.open(MessageBox, _("Playlists.txt location is invalid and has been reset."), type=MessageBox.TYPE_INFO, timeout=5)
                cfg.location_valid.setValue(True)
                cfg.save()
                configfile.save()
        except Exception as e:
            print("Error checking location validity:", e)

        dependencies = self.check_python_dependencies()

        if not dependencies:
            script_file = os.path.join(os.path.dirname(__file__), "dependencies.sh")
            try:
                os.chmod(script_file, 0o755)
            except Exception as e:
                print(e)

            cmd = ". {}".format(script_file)
            self.session.openWithCallback(self.retry_check_dependencies, Console, title="Checking Python Dependencies", cmdlist=[cmd], closeOnSuccess=True)
        else:
            self.start()

    def retry_check_dependencies(self):
        dependencies = self.check_python_dependencies()

        if not dependencies:
            self.session.openWithCallback(self.close, MessageBox, _("Dependencies not installed.\n\nTrying installing older version from feeds first..."), type=MessageBox.TYPE_INFO, timeout=10)
        else:
            self.start()

    def start(self, answer=None):
        self.playlists_json = cfg.playlists_json.value
        self.playlists_all = loadfiles.process_files()
        self.createSetup()

    def createSetup(self):
        self.list = []

        if self.playlists_all:
            self.list.extend([[1, _("Playlists")], [3, _("Add Playlist")], [2, _("Main Settings")]])
        else:
            self.list.extend([[3, _("Add Playlist")], [2, _("Main Settings")]])

        self.drawList = [buildListEntry(x[0], x[1]) for x in self.list]
        self["list"].setList(self.drawList)

    def playlists(self):
        from . import playlists
        self.session.openWithCallback(self.start, playlists.EStalker_Playlists)

    def settings(self):
        from . import settings
        self.session.openWithCallback(self.start, settings.EStalker_Settings)

    def addServer(self):
        from . import server
        self.session.openWithCallback(self.start, server.EStalker_AddServer)

    def __next__(self):
        current_entry = self["list"].getCurrent()

        if current_entry:
            index = current_entry[0]
            if index == 1:
                self.playlists()
            elif index == 2:
                self.settings()
            elif index == 3:
                self.addServer()

    def quit(self, data=None):
        self.clearData()
        self.playOriginalChannel()

    def clearData(self):
        for playlist in self.playlists_all:
            playlist["data"]["live_categories"] = {}
            playlist["data"]["vod_categories"] = {}
            playlist["data"]["series_categories"] = {}
            playlist["data"]["live_streams"] = {}
            playlist["data"]["data_downloaded"] = False
            playlist["data"]["fail_count"] = 0

        try:
            with open(self.playlists_json, "w") as f:
                json.dump(self.playlists_all, f, indent=4)
        except Exception as e:
            print("JSON write error:", e)

    def playOriginalChannel(self):
        if glob.currentPlayingServiceRefString:
            if glob.currentPlayingServiceRefString != glob.newPlayingServiceRefString:
                try:
                    self.session.nav.playService(eServiceReference(glob.currentPlayingServiceRefString))
                except:
                    pass
            try:
                if glob.original_aspect_ratio is not None:
                    eAVSwitch.getInstance().setAspectRatio(glob.original_aspect_ratio)
            except Exception:
                pass

        else:
            try:
                self.session.nav.stopService()
            except:
                pass

        clearCaches()
        self.close()

    def resetData(self, answer=None):
        if answer is None:
            self.session.openWithCallback(self.resetData, MessageBox, _("Warning: delete stored json data for all playlists... Settings, favourites etc. \nPlaylists will not be deleted.\nDo you wish to continue?"))
        elif answer:
            try:
                os.remove(self.playlists_json)
                with open(self.playlists_json, "a"):
                    pass
            except OSError as e:
                print("Error deleting or recreating JSON file:", e)
            self.quit()


def buildListEntry(index, title):
    image_mapping = {
        1: "playlists.png",
        2: "settings.png",
        3: "addplaylist.png",
    }

    png = None
    if index in image_mapping:
        png = LoadPixmap(os.path.join(common_path, image_mapping[index]))

    return index, str(title), png
