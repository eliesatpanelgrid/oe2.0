#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import shutil
import sys
import twisted.python.runtime

from . import _

from Components.config import config, ConfigSubsection, ConfigSelection, ConfigDirectory, ConfigYesNo, ConfigSelectionNumber, ConfigPIN, ConfigInteger, configfile, ConfigText
from enigma import getDesktop, addFont
from Plugins.Plugin import PluginDescriptor

try:
    from multiprocessing.pool import ThreadPool
    hasMultiprocessing = True
except ImportError:
    hasMultiprocessing = False

try:
    from concurrent.futures import ThreadPoolExecutor
    if twisted.python.runtime.platform.supportsThreads():
        hasConcurrent = True
    else:
        hasConcurrent = False
except ImportError:
    hasConcurrent = False

pythonFull = float(str(sys.version_info.major) + "." + str(sys.version_info.minor))
pythonVer = sys.version_info.major

isDreambox = os.path.exists("/usr/bin/apt-get")

isVTI = os.path.exists("/etc/vtiversion.info")

debugs = False

with open("/usr/lib/enigma2/python/Plugins/Extensions/EStalker/version.txt", "r") as f:
    version = f.readline()

screenwidth = getDesktop(0).size()

dir_etc = "/etc/enigma2/estalker/"
dir_tmp = "/etc/enigma2/estalker/tmp/"
dir_plugins = "/usr/lib/enigma2/python/Plugins/Extensions/EStalker/"


if screenwidth.width() == 2560:
    skin_directory = os.path.join(dir_plugins, "skin/uhd/")
elif screenwidth.width() > 1280:
    skin_directory = os.path.join(dir_plugins, "skin/fhd/")
else:
    skin_directory = os.path.join(dir_plugins, "skin/hd/")

folders = [folder for folder in os.listdir(skin_directory) if folder != "common"]

languages = [
    ("", "English"),
    ("de-DE", "Deutsch"),
    ("es-ES", "Español"),
    ("fr-FR", "Français"),
    ("it-IT", "Italiano"),
    ("nl-NL", "Nederlands"),
    ("tr-TR", "Türkçe"),
    ("cs-CZ", "Český"),
    ("da-DK", "Dansk"),
    ("hr-HR", "Hrvatski"),
    ("hu-HU", "Magyar"),
    ("no-NO", "Norsk"),
    ("pl-PL", "Polski"),
    ("pt-PT", "Português"),
    ("ro-RO", "Română"),
    ("ru-RU", "Pусский"),
    ("sh-SH", "Srpski"),
    ("sk-SK", "Slovenčina"),
    ("fi-FI", "suomi"),
    ("sv-SE", "svenska"),
    ("uk-UA", "Український"),
    ("ar-SA", "العربية"),
    ("bg-BG", "български език"),
    ("el-GR", "ελληνικά"),
    ("sq-AL", "shqip"),
    ("zh-CN", "中文")
]

# Configurations initialization
config.plugins.EStalker = ConfigSubsection()
cfg = config.plugins.EStalker

live_streamtype_choices = [("1", "DVB(1)"), ("4097", "IPTV(4097)")]
vod_streamtype_choices = [("4097", "IPTV(4097)")]

if os.path.exists("/usr/bin/gstplayer"):
    live_streamtype_choices.append(("5001", "GStreamer(5001)"))
    vod_streamtype_choices.append(("5001", "GStreamer(5001)"))

if os.path.exists("/usr/bin/exteplayer3"):
    live_streamtype_choices.append(("5002", "ExtePlayer(5002)"))
    vod_streamtype_choices.append(("5002", "ExtePlayer(5002)"))

if os.path.exists("/usr/bin/apt-get"):
    live_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))
    vod_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))

cfg.livetype = ConfigSelection(default="4097", choices=live_streamtype_choices)
cfg.vodtype = ConfigSelection(default="4097", choices=vod_streamtype_choices)

cfg.ar_id_player = ConfigSelection(default="-1", choices=[
    ("-1", _("Auto")),
    ("0", _("4:3 Letterbox")),
    ("1", _("4:3 PanScan")),
    ("2", _("16:9")),
    ("3", _("16:9 Always")),
    ("4", _("16:10 Letterbox")),
    ("5", _("16:10 PanScan")),
    ("6", _("16:9 Letterbox")),
])

cfg.location = ConfigDirectory(default=dir_etc)
cfg.main = ConfigYesNo(default=True)
cfg.livepreview = ConfigYesNo(default=False)
cfg.stopstream = ConfigYesNo(default=False)
cfg.skin = ConfigSelection(default="default", choices=folders)
cfg.timeout = ConfigSelectionNumber(1, 20, 1, default=20, wraparound=True)
cfg.TMDBLanguage2 = ConfigSelection(default="", choices=languages)
# cfg.catchupstart = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
# cfg.catchupend = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.subs = ConfigYesNo(default=False)
cfg.skipplaylistsscreen = ConfigYesNo(default=False)
cfg.adult = ConfigYesNo(default=False)
cfg.adultpin = ConfigPIN(default=0000)
cfg.retries = ConfigSubsection()
cfg.retries.adultpin = ConfigSubsection()
cfg.retries.adultpin.tries = ConfigInteger(default=3)
cfg.retries.adultpin.time = ConfigInteger(default=3)
cfg.location_valid = ConfigYesNo(default=True)

cfg.channelpicons = ConfigYesNo(default=True)
cfg.infobarpicons = ConfigYesNo(default=True)
cfg.channelcovers = ConfigYesNo(default=True)
cfg.infobarcovers = ConfigYesNo(default=True)


# Rename old files if they exist
old_playlist_file = os.path.join(dir_etc, "playlists.txt")
new_playlist_file = os.path.join(dir_etc, "e-portals.txt")

if os.path.exists(old_playlist_file) and not os.path.exists(new_playlist_file):
    try:
        os.rename(old_playlist_file, new_playlist_file)
    except Exception as e:
        print("Failed to rename playlists.txt:", e)

old_playlists_json = os.path.join(dir_etc, "playlists-data-2.json")
new_playlists_json = os.path.join(dir_etc, "e-portals-data.json")

if os.path.exists(old_playlists_json) and not os.path.exists(new_playlists_json):
    try:
        os.rename(old_playlists_json, new_playlists_json)
    except Exception as e:
        print("Failed to rename playlists-data-2.json:", e)


# Set skin and font paths
skin_path = os.path.join(skin_directory, cfg.skin.value)
common_path = os.path.join(skin_directory, "common/")


def get_playlist_choices(location=None):
    """Return selectable text files from the configured playlist directory."""
    location = location or cfg.location.value or dir_etc
    filenames = []

    try:
        if os.path.isdir(location):
            filenames = [
                filename for filename in os.listdir(location)
                if filename.lower().endswith(".txt") and
                os.path.isfile(os.path.join(location, filename))
            ]
    except Exception:
        filenames = []

    filenames = sorted(set(filenames), key=lambda filename: filename.lower())
    if "e-portals.txt" in filenames:
        filenames.remove("e-portals.txt")
    filenames.insert(0, "e-portals.txt")

    return [(filename, filename) for filename in filenames]


cfg.playlist_name = ConfigSelection(default="e-portals.txt", choices=get_playlist_choices())


def refresh_playlist_choices(location=None):
    """Refresh the filename selector while preserving a valid selection."""
    choices = get_playlist_choices(location)
    filenames = [choice[0] for choice in choices]
    selected = os.path.basename(cfg.playlist_name.value or "e-portals.txt")

    if selected not in filenames:
        selected = "e-portals.txt"

    cfg.playlist_name.setChoices(choices, default="e-portals.txt")
    cfg.playlist_name.setValue(selected)
    return choices


def refresh_playlist_paths(create_files=True):
    """Update the active text and JSON paths without requiring a GUI restart."""
    location = cfg.location.value or dir_etc

    try:
        if not os.path.isdir(location):
            os.makedirs(location)
        cfg.location_valid.setValue(True)
    except Exception:
        location = dir_etc
        cfg.location.setValue(location)
        cfg.location_valid.setValue(False)
        if not os.path.isdir(location):
            os.makedirs(location)

    refresh_playlist_choices(location)
    filename = os.path.basename(cfg.playlist_name.value or "e-portals.txt")
    if not filename.lower().endswith(".txt"):
        filename = "e-portals.txt"
        cfg.playlist_name.setValue(filename)

    playlist_file = os.path.join(location, filename)
    file_stem = os.path.splitext(filename)[0]
    json_filename = "e-portals-data.json" if filename == "e-portals.txt" else "{}-data.json".format(file_stem)
    playlists_json = os.path.join(dir_etc, json_filename)

    cfg.playlist_file.setValue(playlist_file)
    cfg.playlists_json.setValue(playlists_json)

    if create_files:
        for path in (playlist_file, playlists_json):
            if not os.path.isfile(path):
                with open(path, "a"):
                    pass

    return playlist_file, playlists_json


cfg.playlist_file = ConfigText(default=os.path.join(dir_etc, "e-portals.txt"))
cfg.playlists_json = ConfigText(default=os.path.join(dir_etc, "e-portals-data.json"))
refresh_playlist_paths()

cfg.save()
configfile.save()

font_folder = os.path.join(dir_plugins, "fonts/")
addFont(os.path.join(font_folder, "m-plus-rounded-1c-regular.ttf"), "estalkerregular", 100, 0)
addFont(os.path.join(font_folder, "m-plus-rounded-1c-medium.ttf"), "estalkerbold", 100, 0)
addFont(os.path.join(font_folder, "slyk-medium.ttf"), "slykregular", 100, 0)
addFont(os.path.join(font_folder, "slyk-bold.ttf"), "slykbold", 100, 0)
addFont(os.path.join(font_folder, "classfont2.ttf"), "iconfont", 100, 0)

# delete temporary folder and contents
if os.path.exists("/tmp/estalker"):
    shutil.rmtree("/tmp/estalker")

# create temporary folder for downloaded files
if not os.path.exists(dir_tmp):
    os.makedirs(dir_tmp)

def main(session, **kwargs):
    from . import mainmenu
    session.open(mainmenu.EStalker_MainMenu)
    return


def mainmenu(menu_id, **kwargs):
    if menu_id == "mainmenu":
        return [(_("EStalker"), main, "EStalker", 50)]
    else:
        return []


def Plugins(**kwargs):
    iconFile = "icons/plugin-icon_sd.png"
    if screenwidth.width() > 1280:
        iconFile = "icons/plugin-icon.png"

    description = _("IPTV Ministra stalker player by KiddaC")
    pluginname = _("EStalker")

    main_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_MENU, fnc=mainmenu, needsRestart=True)

    extensions_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main, needsRestart=True)

    result = [
        PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile, fnc=main)
    ]

    result.append(extensions_menu)

    if cfg.main.value:
        result.append(main_menu)

    return result
