# -*- coding: utf-8 -*-

DVB_TO_TESS = {
    "afr": "afr", "amh": "amh", "ara": "ara", "asm": "asm", "aze": "aze",
    "bel": "bel", "ben": "ben", "bod": "bod", "tib": "bod", "bos": "bos",
    "bul": "bul", "cat": "cat", "ceb": "ceb", "ces": "ces", "cze": "ces",
    "chi": "chi_sim", "zho": "chi_sim", "chr": "chr", "cym": "cym", "wel": "cym",
    "dan": "dan", "deu": "deu", "ger": "deu", "dzo": "dzo", "ell": "ell", "gre": "ell",
    "eng": "eng", "en": "eng", "enm": "enm", "epo": "epo", "est": "est",
    "fas": "fas", "per": "fas", "fil": "fil", "fin": "fin", "fra": "fra", "fre": "fra",
    "frk": "frk", "frm": "frm", "gle": "gle", "glg": "glg", "grn": "grn", 
    "guj": "guj", "hat": "hat", "heb": "heb", "he": "heb", "hin": "hin",
    "hrv": "hrv", "hun": "hun", "hye": "hye", "arm": "hye", "iku": "iku",
    "ind": "ind", "in": "ind", "isl": "isl", "ice": "isl", "ita": "ita",
    "ita_old": "ita_old", "jav": "jav", "jpn": "jpn", "ja": "jpn", "kan": "kan",
    "kat": "kat", "geo": "kat", "kat_old": "kat_old", "kaz": "kaz", "khm": "khm",
    "kir": "kir", "kor": "kor", "ko": "kor", "kor_vert": "kor_vert", "kur": "kur",
    "lao": "lao", "lat": "lat", "lav": "lav", "lit": "lit", "ltz": "ltz",
    "mal": "mal", "mar": "mar", "mkd": "mkd", "mac": "mkd", "mlt": "mlt",
    "mon": "mon", "msa": "msa", "may": "msa", "mya": "mya", "bur": "mya",
    "nep": "nep", "nld": "nld", "dut": "nld", "nor": "nor", "ori": "ori",
    "pan": "pan", "pol": "pol", "por": "por", "pt": "por", "pus": "pus",
    "ron": "ron", "rum": "ron", "rus": "rus", "ru": "rus", "san": "san", "sin": "sin",
    "slk": "slk", "slo": "slk", "slv": "slv", "snd": "snd", "spa": "spa", "es": "spa",
    "spa_old": "spa_old", "sqi": "sqi", "alb": "sqi", "srp": "srp", "srp_latn": "srp_latn",
    "swa": "swa", "swe": "swe", "sve": "swe", "syr": "syr", "tam": "tam",
    "tel": "tel", "tgk": "tgk", "tgl": "tgl", "tha": "tha", "tir": "tir",
    "ton": "ton", "tur": "tur", "tr": "tur", "uig": "uig", "ukr": "ukr",
    "urd": "urd", "ur": "urd", "uzb": "uzb", "vie": "vie", "vi": "vie", "yid": "yid", "yor": "yor"
}

# Tesseract to Google Translate Language Mapping
OCR_TO_TRANS = {
    "afr": "af", "amh": "am", "ara": "ar", "asm": "as", "aze": "az",
    "bel": "be", "ben": "bn", "bod": "bo", "bos": "bs", "bul": "bg",
    "cat": "ca", "ceb": "ceb", "ces": "cs", "chi_sim": "zh", "chi_tra": "zh",
    "cym": "cy", "dan": "da", "deu": "de", "dzo": "dz", "ell": "el",
    "eng": "en", "epo": "eo", "est": "et", "fas": "fa", "fil": "tl",
    "fin": "fi", "fra": "fr", "gle": "ga", "glg": "gl", "guj": "gu",
    "hat": "ht", "heb": "he", "hin": "hi", "hrv": "hr", "hun": "hu",
    "hye": "hy", "ind": "id", "isl": "is", "ita": "it", "jpn": "ja",
    "kan": "kn", "kat": "ka", "kaz": "kk", "khm": "km", "kor": "ko",
    "kur": "ku", "lao": "lo", "lat": "la", "lav": "lv", "lit": "lt",
    "mal": "ml", "mar": "mr", "mkd": "mk", "mlt": "mt", "mon": "mn",
    "msa": "ms", "mya": "my", "nep": "ne", "nld": "nl", "nor": "no",
    "ori": "or", "pan": "pa", "pol": "pl", "por": "pt", "pus": "ps",
    "ron": "ro", "rus": "ru", "san": "sa", "sin": "si", "slk": "sk",
    "slv": "sl", "snd": "sd", "spa": "es", "sqi": "sq", "srp": "sr",
    "swa": "sw", "swe": "sv", "syr": "sy", "tam": "ta", "tel": "te",
    "tgk": "tg", "tgl": "tl", "tha": "th", "tir": "ti", "tur": "tr",
    "uig": "ug", "ukr": "uk", "urd": "ur", "uzb": "uz", "vie": "vi",
    "yid": "yi", "yor": "yo"
}