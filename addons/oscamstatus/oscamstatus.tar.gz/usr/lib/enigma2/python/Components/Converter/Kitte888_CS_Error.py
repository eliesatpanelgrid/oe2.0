from Components.Converter.Converter import Converter
from enigma import iServiceInformation, iPlayableService
from Components.Element import cached
from Components.Converter.Poll import Poll

from os.path import isfile


# --------------------------- Logfile -------------------------------
from os import system, path, popen, remove
import datetime
import codecs
from shutil import copyfile
from os import remove
from os.path import isfile

########################### log file loeschen ##################################

import os
#  braucht man um sich den stack anzuschauen wer es aufruft ######################
import traceback
########################### log file loeschen ##################################

myfile="/tmp/kitte888-cserrorcount.log"

## If file exists, delete it ##
if isfile(myfile):
	remove(myfile)
############################## File copieren ############################################


###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus

logstatus = "on"

# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.date.today().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return


# so muss das commando aussehen , um in den file zu schreiben
logout(data="start")


class Kitte888_CS_Error(Poll, Converter, object):
    def __init__(self, type):
        logout(data="init")
        Poll.__init__(self)
        Converter.__init__(self, type)
        self.type = type
        self.systemCaids = {
            "26" : "BiSS",
            "01" : "SEC",
            "06" : "IRD",
            "17" : "BET",
            "05" : "VIA",
            "18" : "NAG",
            "09" : "NDS",
            "0B" : "CON",
            "0D" : "CRW",
            "4A" : "DRE" }

        self.poll_interval = 7000
        self.poll_enabled = True
        self.ecmTimes = []

    @cached
    def get_caidlist(self):
        logout(data="get_caidlist")
        caidlist = {}
        service = self.source.service
        if service:
            info = service and service.info()
            if info:
                caids = info.getInfoObject(iServiceInformation.sCAIDs)
                if caids:
                    for cs in self.systemCaids:
                        caidlist[cs] = (self.systemCaids.get(cs),0)
                    for caid in caids:
                        c = "%x" % int(caid)
                        if len(c) == 3:
                            c = "0%s" % c
                        c = c[:2].upper()
                        if self.systemCaids.has_key(c):
                            caidlist[c] = (self.systemCaids.get(c),1)
                    ecm_info = self.ecmfile()
                    if ecm_info:
                        emu_caid = ecm_info.get("caid", "")
                        if emu_caid and emu_caid != "0x000":
                            c = emu_caid.lstrip("0x")
                            if len(c) == 3:
                                c = "0%s" % c
                            c = c[:2].upper()
                            caidlist[c] = (self.systemCaids.get(c),2)
        return caidlist

    getCaidlist = property(get_caidlist)

    @cached
    def getText(self):
        logout(data="getText")
        textvalue = "0"
        service = self.source.service
        if service:
            info = service and service.info()
            if info:
                if info.getInfoObject(iServiceInformation.sCAIDs):
                    ecm_info = self.ecmfile()
                    if ecm_info:
                        # caid
                        logout(data="getText1")
                        caid = ecm_info.get("caid", "")
                        caid = caid.lstrip("0x")
                        caid = caid.upper()
                        caid = caid.zfill(4)
                        caid = "Caid: %s" % caid

                        # ecm time
                        ecm_time = ecm_info.get("streamerrorcount", 0)
                        logout(data="getText2")
                        if ecm_time:
                            logout(data="getText3")
                            if "msec" in ecm_time:
                                ecm_time = " %s " % ecm_time
                            else:
                                logout(data="getText4")
                                ecm_time = " %s " % ecm_time

                            self.ecmTimes.append(ecm_time)
                            #Anzahl der ECMs
                            while len(self.ecmTimes) > 1:
                                self.ecmTimes.pop(0)
                                #" %s " =  " %s1 "



#						textvalue = "Reader  %s  " % (ecm_time)
                        ecmTimesString = " ".join(self.ecmTimes)
                        textvalue = "Errors: %s  " % (ecmTimesString)
        logout(data=str(textvalue))
        return textvalue

    text = property(getText)


    def ecmfile(self):
        logout(data="ecmfile")
        ecmfiletmp = "/tmp/ecm.info"
        ecmfilereal = "/tmp/streamerrorcount.info"
        ## If file exists, pfad setzen ##
        if os.path.isfile(ecmfilereal):
            logout(data="streamerrorcount.info file vorhanden")
            ecmfiletmp = ecmfilereal
        ecm = None
        info = {}
        service = self.source.service
        if service:
            logout(data="ecmfile1")
            frontendInfo = service.frontendInfo()
            if frontendInfo:
                try:
                    logout(data="ecmfile2")
                    ecmpath = "/tmp/ecm%s.info" % frontendInfo.getAll(False).get("tuner_number")
                    ecm = open(ecmpath, "r").readlines()
                except:
                    logout(data="ecmfile3")
                    try:
                        logout(data="ecmfile10")
                        ecm = open(ecmfiletmp, "r").readlines()
                    except: pass
            if ecm:
                logout(data="ecmfile4")
                for line in ecm:
                    logout(data="ecmfile5")
                    x = line.lower().find("msec")
                    logout(data=str(x))
                    if x != -1:
                        logout(data="ecmfile5a")
                        info["ecm time"] = line[0:x+4]
                    else:
                        logout(data="ecmfile6")
                        item = line.split(":", 1)
                        logout(data=str(item))
                        if len(item) > 1:
                            logout(data="ecmfile6a")
                            info[item[0].strip().lower()] = item[1].strip()
                            logout(data=str(info))
                        else:
                            logout(data="ecmfile7")
                            if not info.has_key("stremerrorcount"):
                                logout(data="ecmfile8")
                                x = line.lower().find("stremerrorcount")
                                if x != -1:
                                    logout(data="ecmfile9")
                                    y = line.find(",")
                                    if y != -1:
                                        info["stremerrorcount"] = line[x+5:y]
        logout(data=str(info))
        return info

    def changed(self, what):
        if (what[0] is self.CHANGED_SPECIFIC and what[1] is iPlayableService.evUpdatedInfo) or what[0] is self.CHANGED_POLL:
            Converter.changed(self, what)
