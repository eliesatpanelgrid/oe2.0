# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from enigma import iServiceInformation, iPlayableService
from Components.Element import cached
from Components.Converter.Poll import Poll
import os, time, hashlib, datetime

# --- Dein Logging-Code (unverändert) ---
from os.path import isfile, getmtime
from os import remove

myfile = "/tmp/kitte888-cs_Ecm_Reader.log"
if isfile(myfile):
    remove(myfile)

logstatus = "on"  # Zum Debuggen auf "on" lassen


def write_log(msg):
    if logstatus == "on":
        with open(myfile, "a") as log:
            log.write(datetime.datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")


def logout(data):
    if logstatus == "on":
        write_log(str(data))


logout("start")


# ----------------------------------------

class Kitte888_CS_EcmTimeReader(Poll, Converter, object):
    def __init__(self, type):
        Poll.__init__(self)
        Converter.__init__(self, type)
        self.type = type

        ## NEU: Startintervall auf 1 Sekunde setzen, um schnell den ersten ECM zu finden
        ## Der Intervall passt sich danach automatisch an.
        self.poll_interval = 1000
        self.poll_enabled = True

        self.last_reader = ""
        self.ecmTimes = []
        self.last_cw0 = ""
        self.last_cw1 = ""
        self.last_ecm_norm = ""
        self.last_md5 = None
        self.last_mtime = 0
        self.last_ecm_timestamp = time.time()

        ## NEU: Standard-Timeout für Hänger-Erkennung, wird dynamisch angepasst
        self.timeout_seconds = 15.0

    def _normalize_ecm(self, ecm_raw):
        if not ecm_raw:
            return ""
        s = ecm_raw.lower()
        for t in ["msec", "ms", "s", " "]:
            s = s.replace(t, "")
        return s.strip()

    @cached
    def getText(self):
        textvalue = ""
        service = self.source.service
        if service:
            info = service.info()
            if info and info.getInfoObject(iServiceInformation.sCAIDs):
                ecm_info = self.ecmfile()

                if ecm_info and "timeout" in ecm_info:
                    logout("Timeout erkannt, keine neue ECM-Datei seit mehr als %.1f Sekunden" % self.timeout_seconds)
                    display_ecm = (self.last_reader + " 5000 msec") if self.last_reader else "5000 msec"
                    self.ecmTimes.append(display_ecm)
                    while len(self.ecmTimes) > 4:
                        self.ecmTimes.pop(0)
                    logout("Aktuelle Anzeige ECM: " + "  ".join(self.ecmTimes))
                    return "ECM " + "  ".join(self.ecmTimes)

                if not ecm_info:
                    return ""

                # Aktuelle Daten auslesen
                current_caid = ecm_info.get("caid", "").lstrip("0x").upper().zfill(4)
                current_cw0 = ecm_info.get("cw0", "").replace(" ", "").upper()
                current_cw1 = ecm_info.get("cw1", "").replace(" ", "").upper()
                raw_ecm = ecm_info.get("ecm time", "").strip()
                reader = ecm_info.get("reader", "")
                self.last_reader = reader
                logout(f"Neue ECM Daten Reader:{reader} ECM:{raw_ecm} CW0:{current_cw0} CW1:{current_cw1}")

                current_ecm_norm = self._normalize_ecm(raw_ecm)
                display_ecm = ""

                ## ------------------------------------------------------------------------------------
                ## ENTFERNT: Die gesamte starre if/elif-Kette wird durch die dynamische Logik in ecmfile() ersetzt.
                ## Der Code wird dadurch sauberer, kürzer und intelligenter.
                ## ------------------------------------------------------------------------------------

                # Vergleich CW0/CW1 und ECM
                if current_cw0 == self.last_cw0 and current_cw1 == self.last_cw1:
                    if current_ecm_norm == self.last_ecm_norm and current_ecm_norm != "":
                        logout("Gleiche ECM Zeit erkannt, setze 5000 msec")
                        display_ecm = (reader + " 5000 msec") if reader else "5000 msec"
                    else:
                        logout("Gleiche CWs aber neue ECM Zeit")
                        display_ecm = (reader + " " + raw_ecm) if reader else raw_ecm
                        self.last_ecm_norm = current_ecm_norm
                else:
                    logout("Neuer CW0 oder CW1 erkannt")
                    display_ecm = (reader + " " + raw_ecm) if reader else raw_ecm
                    self.last_cw0 = current_cw0
                    self.last_cw1 = current_cw1
                    self.last_ecm_norm = current_ecm_norm

                # Liste begrenzen
                self.ecmTimes.append(display_ecm)
                while len(self.ecmTimes) > 4:
                    self.ecmTimes.pop(0)

                logout("Aktuelle Anzeige ECM: " + "  ".join(self.ecmTimes))
                textvalue = "ECM " + "  ".join(self.ecmTimes)

        return textvalue

    text = property(getText)

    def ecmfile(self):
        info = {}
        ecmpath = "/tmp/ecm.info"

        if not os.path.exists(ecmpath):
            return None

        try:
            mtime_now = os.path.getmtime(ecmpath)
            with open(ecmpath, "rb") as f:
                data = f.read()
            md5_now = hashlib.md5(data).hexdigest()
        except Exception as e:
            logout(f"ecmfile(): Fehler beim Lesen: {e}")
            return None

        # Wenn Dateiinhalt oder mtime neu ist -> neue ECM
        if md5_now != self.last_md5 or mtime_now != self.last_mtime:

            ## ------------------------------------------------------------------------------------
            ## NEU: Dynamische Anpassung des Poll-Intervalls und Timeouts basierend auf der Zeitdifferenz
            ## ------------------------------------------------------------------------------------
            if self.last_mtime > 0:  # Nur berechnen, wenn wir einen vorherigen Zeitstempel haben
                interval = mtime_now - self.last_mtime
                logout(f"Gemessener ECM-Intervall: {interval:.2f} Sekunden")

                # Sanity-Check: Nur realistische Intervalle zwischen 3 und 16 Sekunden verwenden
                if 3.0 < interval < 16.0:
                    # Neuen Poll-Intervall setzen (gemessene Zeit + 500ms Puffer)
                    new_poll_interval = int(interval * 1000) + 500
                    if self.poll_interval != new_poll_interval:
                        self.poll_interval = new_poll_interval
                        logout(f"-> Poll-Intervall dynamisch auf {self.poll_interval}ms gesetzt.")

                    # Timeout für Hänger dynamisch anpassen (z.B. 1.5x der ECM-Zeit)
                    self.timeout_seconds = interval * 1.5
                    logout(f"-> Hänger-Timeout dynamisch auf {self.timeout_seconds:.1f}s gesetzt.")

            # Zeitstempel und Hash für die nächste Prüfung aktualisieren
            self.last_md5 = md5_now
            self.last_mtime = mtime_now
            self.last_ecm_timestamp = time.time()

            # ECM-Datei parsen und zurückgeben
            try:
                lines = data.decode("utf-8", "ignore").splitlines()
                for line in lines:
                    if "msec" in line.lower():
                        info["ecm time"] = line.strip()
                    else:
                        parts = line.split(":", 1)
                        if len(parts) > 1:
                            info[parts[0].strip().lower()] = parts[1].strip()
            except Exception as e:
                logout(f"ecmfile(): Fehler beim Parsen: {e}")
                return {}

            logout(
                f"ecmfile(): Neue ECM-Datei erkannt, mtime {datetime.datetime.fromtimestamp(mtime_now).strftime('%Y-%m-%d %H:%M:%S')}")
            return info

        # Datei unverändert -> prüfe ob Timeout erreicht ist
        elapsed = time.time() - self.last_ecm_timestamp
        if elapsed >= self.timeout_seconds:
            logout(f"ecmfile(): Keine neue ECM-Datei seit {elapsed:.1f} Sekunden (Timeout)")
            return {"timeout": True}
        else:
            # noch innerhalb des Zeitfensters, keine Aktion nötig
            return None

    def changed(self, what):
        if (what[0] == self.CHANGED_SPECIFIC and what[1] == iPlayableService.evUpdatedInfo) or what[
            0] == self.CHANGED_POLL:
            Converter.changed(self, what)