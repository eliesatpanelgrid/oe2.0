# -*- coding: utf-8 -*-
from __future__ import print_function

from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eTimer
from socket import socket, AF_INET, SOCK_STREAM, gethostbyname
import datetime
import random
import threading

LOGFILE = "/tmp/Kitte_888TestConnectionInternet.log"
LOGSTATUS = "off"


def write_log(msg):
    if LOGSTATUS != "on":
        return
    try:
        ts = datetime.datetime.now().strftime("%Y/%m/%d, %H:%M:%S.%f")
        with open(LOGFILE, "a") as f:
            f.write("%s: %s\n" % (ts, msg))
    except:
        pass


def logout(msg):
    write_log(msg)


# ---------------------------------------------------------
# Schneller DNS-Test mit Timeout ohne Blockieren
# → nutzt WIRKLICH den eingestellten DNS der Box
# ---------------------------------------------------------
def dns_resolve_with_timeout(host, timeout=0.3):
    result = {"ok": False}

    def resolve():
        try:
            gethostbyname(host)
            result["ok"] = True
        except:
            result["ok"] = False

    t = threading.Thread(target=resolve)
    t.daemon = True
    t.start()
    t.join(timeout)

    return result["ok"]


# ---------------------------------------------------------
# Hauptklasse
# ---------------------------------------------------------
class Kitte_888TestConnectionInternet(Converter, object):
    def __init__(self, type):
        Converter.__init__(self, type)

        # Normalwerte
        self.internetOK = False
        self.dnsOK = False
        self.testPause = 2      # schneller Retry
        self.testHost = "8.8.8.8"
        self.testPort = 53
        self.testTime = 0.3     # schneller Timeout

        # Typ-Parameter lesen
        if type:
            p = type.find("://")
            if p != -1:
                type = type[p + 3:]
            parts = type.split(":")
            if len(parts[0]) > 0:
                self.testHost = parts[0]
            if len(parts) > 1 and parts[1].isdigit():
                self.testPort = int(parts[1])
            if len(parts) > 2 and parts[2].isdigit():
                self.testPause = max(1, int(parts[2]))

        # Timer initialisieren
        self.testTimer = eTimer()
        try:
            self.testTimer_conn = self.testTimer.timeout.connect(self._test_wrapper)
        except:
            self.testTimer.callback.append(self._test_wrapper)

        # Sofort testen
        self.test()
        self.testTimer.start(random.randint(100, 300), True)

    # Timer-kompatible Wrapperfunktion
    def _test_wrapper(self, *args):
        self.test()

    # ---------------------------------------------------------
    # Internet + DNS Test
    # ---------------------------------------------------------
    def test(self):
        logout("Starte Verbindungstest")

        # -------------------------
        # 1) schneller IP-Test
        # -------------------------
        s = socket(AF_INET, SOCK_STREAM)
        s.settimeout(self.testTime)
        try:
            res = s.connect_ex((self.testHost, self.testPort))
            self.internetOK = (res == 0)
            logout("Internet-Test: %s" % self.internetOK)
        except Exception as e:
            self.internetOK = False
            logout("Internet-Test Fehler: %s" % e)
        finally:
            try:
                s.close()
            except:
                pass

        # -------------------------
        # 2) DNS-Test per Timeout
        # nur wenn Internet ok
        # -------------------------
        if self.internetOK:
            self.dnsOK = dns_resolve_with_timeout("google.com", 0.3)
            logout("DNS-Test: %s" % self.dnsOK)
        else:
            self.dnsOK = False

        # -------------------------
        # Timer-Handling
        # -------------------------
        if self.internetOK and self.dnsOK:
            logout("Internet & DNS OK → Timer stop")
            try:
                self.testTimer.stop()
            except:
                pass
        else:
            logout("Nicht OK → Retry in %s Sekunden" % self.testPause)
            self.testTimer.start(self.testPause * 1000, True)

    # ---------------------------------------------------------
    # boolean für Enigma2 (Skin)
    # ---------------------------------------------------------
    def getBoolean(self):
        result = (self.internetOK and self.dnsOK)
        logout("getBoolean → %s" % result)
        return result

    boolean = property(getBoolean)
