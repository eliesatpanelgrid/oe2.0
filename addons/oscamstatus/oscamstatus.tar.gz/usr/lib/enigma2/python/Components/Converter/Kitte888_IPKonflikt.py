from Components.Converter.Converter import Converter
from Components.Element import cached
import subprocess
import re
# cd /usr/lib/enigma2/python
# python3 -c "from Components.Converter.Kitte888_IPKonflikt import Kitte888_IPKonflikt; print(Kitte888_IPKonflikt('').getText())"

# <widget source="session.CurrentService" render="Label" position="100,100" size="200,30" font="Regular;20">
#     <convert type="IPKonflikt" />
# </widget>

import datetime
import random
from os import remove
from os.path import isfile


myfile = "/tmp/Kitte888_IPKonflikt.log"
logstatus = "on"
## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)

def write_log(msg):
    if logstatus == "on":
        with open(myfile, "a") as log:
            log.write(datetime.datetime.now().strftime("%Y/%m/%d, %H:%M:%S.%f") + ": " + msg + "\n")


def logout(data):
    if logstatus == "on":
        write_log(data)


class Kitte888_IPKonflikt(Converter, object):
    def __init__(self, type):
        Converter.__init__(self, type)
        logout("init")
        self.test_ok = 0

    def run_cmd(self, cmd):
        logout("run cmd")
        try:
            return subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return ""

    def get_interface(self):
        logout("get interface")
        out = self.run_cmd("ip route | grep default")
        m = re.search(r"dev (\S+)", out)
        if m:
            return m.group(1)
        return None

    def get_ip(self, iface):
        logout("get ip")
        out = self.run_cmd("ip addr show " + iface)
        m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", out)
        if m:
            return m.group(1)
        return None

    def get_mac(self, iface):
        logout("get mac")
        return self.run_cmd("cat /sys/class/net/" + iface + "/address").strip()

    def arping(self, iface, ip):
        logout("arping")
        return self.run_cmd("arping -c 1 -w 1 -I %s %s" % (iface, ip))


    def extract_macs(self, text):
        logout("extract macs")
        macs = set()
        for line in text.split("\n"):
            m = re.search(r"\[([0-9a-fA-F:]{17})\]", line)
            if m:
                macs.add(m.group(1).lower())
        return macs

    @cached
    def getText(self):
        if self.test_ok == 0:
            logout("get text")
            iface = self.get_interface()
            if not iface:
                return "kein interface"

            ip = self.get_ip(iface)
            mac = self.get_mac(iface)

            if not ip:
                return "keine ip"

            out = self.arping(iface, ip)
            macs = self.extract_macs(out)

            fremd = [m for m in macs if m != mac.lower()]
            logout("iface - ip - mac")
            logout("iface: {} ip: {} mac: {}".format(iface, ip, mac))
            if fremd:
                return "konflikt"
            else:
                self.test_ok = 1
                logout("test ok: {} ".format(self.test_ok))
                return "ok"
        else:
            return "ok"
            
    logout("ende")
    text = property(getText)