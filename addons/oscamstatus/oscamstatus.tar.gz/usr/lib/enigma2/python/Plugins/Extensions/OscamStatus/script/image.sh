#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import logging
import socket
# so in der console testen - /usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/script/ip.sh
# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "image.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Stelle sicher, dass das Verzeichnis existiert
if not os.path.exists(LOGDIR):
    try:
        os.makedirs(LOGDIR)
        print("Verzeichnis '{}' wurde erstellt.".format(LOGDIR))
    except Exception as e:
        print("Fehler beim Erstellen des Verzeichnisses '{}': {}".format(LOGDIR, e))
        sys.exit(1)

# Altes Logfile löschen, wenn vorhanden
if os.path.exists(LOGFILE):
    try:
        os.remove(LOGFILE)
        print("Alte Logdatei '{}' geloescht.".format(LOGFILE))
    except OSError as e:
        print("Fehler beim Loeschen der alten Logdatei: {}".format(e))

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

info = ""
try:
    with open("/etc/issue", "r") as f:
        lines = f.readlines()

    if len(lines) == 0:
        logging.warning("Datei '/etc/issue' ist leer")
    else:
        first_line = lines[0].strip().lower()
        if "welcome" in first_line:
            if len(lines) > 1:
                info = lines[1].strip()
            else:
                logging.warning("Keine gültige Image-Version gefunden (nur 'welcome' in der ersten Zeile)")
        else:
            info = lines[0].strip()

except IOError:
    logging.warning("Datei '/etc/issue' nicht gefunden oder nicht lesbar")

version = info
print("Image-Version:", version)


# info ins Log schreiben
logging.info("Version: {}".format(version))

# Info in Datei schreiben
with open("/tmp/oscamstatus/image_info.txt", "w") as f:
    f.write("{}\n".format(version))
