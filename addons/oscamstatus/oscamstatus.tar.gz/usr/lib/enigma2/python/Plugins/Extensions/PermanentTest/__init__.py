# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/PermanentTest/__init__.py
pass