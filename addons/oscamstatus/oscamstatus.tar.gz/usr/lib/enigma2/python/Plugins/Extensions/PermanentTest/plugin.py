# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/PermanentTest/plugin.py
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo
from Components.Language import language
from Components.MenuList import MenuList
from enigma import getDesktop
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext



# --------------------------- Logfile -------------------------------

from datetime import datetime
from shutil import copyfile
from os import remove
from os.path import isfile
########################### log file loeschen ##################################

myfile="/tmp/permanenttest.log"

## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
############################## File copieren ############################################


###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus

logstatus = "off"

# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return


# ----------------------------- so muss das commando aussehen , um in den file zu schreiben  ------------------------------
logout(data="start")


# ------------------------------------------------------------
# Locale
# ------------------------------------------------------------

def localeInit():
    logout(data="init")
    gettext.bindtextdomain('PermanentTest', '%s%s' % (resolveFilename(SCOPE_PLUGINS), 'Extensions/PermanentTest/locale/'))

localeInit()
language.addCallback(localeInit)



# ------------------------------------------------------------
# Config (nur hidden-Zustand)
# ------------------------------------------------------------

config.plugins.PermanentTest = ConfigSubsection()
config.plugins.PermanentTest.hidden = ConfigYesNo(default=True)

# ------------------------------------------------------------
# SKIN (fixe Position, fixe Farben)
# ------------------------------------------------------------

sz_w = getDesktop(0).size().width()

if sz_w == 3200:


    SKIN = """
        <screen position="0,00" size="3200,60" zPosition="-1" backgroundColor="#00000000" title="%s" flags="wfNoBorder" transparent="0" >
    
       
           
        # ****************** Antennensignal  ****************
        <eLabel backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular; 40" noWrap="1" position="10,14" size="130,60" text="SNR:" zPosition="115" transparent="0" />
        <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular; 40" noWrap="1" position="135,14" render="Label" size="130,60" source="session.FrontendStatus" zPosition="0" transparent="0" >
           <convert type="FrontendInfo">SNR</convert>
        </widget>

        
        # *** Caid *****
        <widget source="session.CurrentService" backgroundColor="#00000000" foregroundColor="#001bade4" render="Label" position="245,14" zPosition="0" size="255,60" font="Regular; 40"  noWrap="1"  transparent="0"  >
           <convert type="Kitte888_CS_Caid">Default</convert>
        </widget>
        
        # *** ECm Zeit *****
            <widget source="session.CurrentService" backgroundColor="#00000000" foregroundColor="#0000ff00"  render="Label" position="660,14" size="1900,60" font="Regular; 40"  noWrap="1" zPosition="1" transparent="0">
               <convert type="Kitte888_CS_EcmTimeReader">Default</convert>
             </widget>

        # ****** CPU Last *****
        <widget source="session.CurrentService" render="Label" position="2780,14" size="230,60" font="Regular; 40" transparent="1" zPosition="11" foregroundColor="#001bade4">
           <convert type="Kitte888_CS_YanCpuUsage">CPU:$0</convert>
        </widget>

        
        
        #  *********** UHR *************
        <widget source="global.CurrentTime" backgroundColor="#00000000" foregroundColor="#00ffffff"  render="Label" position="3000,14" size="120,60" font="Regular;40" zPosition="1" transparent="0">
            <convert type="ClockToText">Default</convert>1
        </widget>

        <eLabel backgroundColor="#00ffffff" font="Regular; 40" halign="center" position="3110,20" size="15,36" text=":" transparent="1" valign="center" zPosition="2" foregroundColor="#00ffffff" />

		<widget source="global.CurrentTime" backgroundColor="#00000000" foregroundColor="#00ffffff"  render="Label" position="3130,20" size="50,60" font="Regular;40" zPosition="1" transparent="0">
            <convert type="ClockToText">Format:%S</convert>1
        </widget>
		

		

    </screen>"""
else:
    if sz_w == 1920:
        SKIN = """
            <screen position="0,00" size="1920,50" zPosition="-1" backgroundColor="#00000000" title="%s" flags="wfNoBorder" transparent="0" >
        
            # ****************** Antennensignal  ****************
            <eLabel backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular; 24" noWrap="1" position="1,14" size="74,60" text="SNR:" zPosition="115" transparent="0" />
            <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular; 24" noWrap="1" position="78,14" render="Label" size="79,60" source="session.FrontendStatus" zPosition="0" transparent="0" >
               <convert type="FrontendInfo">SNR</convert>
            </widget>

            
            # *** Caid *****
            <widget source="session.CurrentService" backgroundColor="#00000000" foregroundColor="#00fff000" render="Label" position="150,14" zPosition="0" size="150,60" font="Regular; 24"  noWrap="1"  transparent="0"  >
               <convert type="Kitte888_CS_Caid">Default</convert>
            </widget>

           
            # *** ECm Zeit *****
            <widget source="session.CurrentService" backgroundColor="#00000000" foregroundColor="#0000ff00"  render="Label" position="500,14" size="1390,60" font="Regular; 24"  noWrap="1" zPosition="1" transparent="0">
               <convert type="Kitte888_CS_EcmTimeReader">Default</convert>
             </widget>

            # ****** CPU Last *****
            <widget source="session.CurrentService" render="Label" position="1670,14" size="120,46" font="Regular; 24" transparent="1" zPosition="11" foregroundColor="#001bade4">
               <convert type="Kitte888_CS_YanCpuUsage">CPU:$0</convert>
            </widget>

            
            
            #  *********** UHR *************
            <widget source="global.CurrentTime" backgroundColor="#00000000" foregroundColor="#00ffffff"  render="Label" position="1790,14" size="80,25" font="Regular;24" zPosition="1" transparent="0">
                <convert type="ClockToText">Default</convert>1
            </widget>
			<widget  source="global.CurrentTime" font="Regular; 24" backgroundColor="#00000000" foregroundColor="#00ffffff"  position="1860,14" render="Label" size="60,25"  transparent="0"  zPosition="2" >
                <convert type="ClockToText">Format:%S</convert>
			</widget>

        </screen>"""


    else:
        SKIN = """
            <screen position="0,00" size="1280,45" zPosition="-1" backgroundColor="#0" title="%s" flags="wfNoBorder" transparent="0">
        
            # ****************** Antennensignal  ****************
            <eLabel backgroundColor="#0" foregroundColor="#ffffff" font="Regular; 20" noWrap="1" position="1,10" size="60,25" text="SNR:" zPosition="115" transparent="0" /><widget backgroundColor="#0" foregroundColor="#ffffff" font="Regular; 20" noWrap="1" position="60,10" render="Label" size="80,25" source="session.FrontendStatus" zPosition="0" transparent="0"><convert type="FrontendInfo">SNR</convert></widget>
        
            
            # *** Caid *****
            <widget source="session.CurrentService" backgroundColor="#0" foregroundColor="#1bade4" render="Label" position="145,10" zPosition="0" size="135,25" font="Regular; 20" noWrap="1" transparent="0"><convert type="Kitte888_CS_Caid">Default</convert></widget>
            
            
        
            # *** ECm Zeit *****
            <widget source="session.CurrentService" backgroundColor="#0" foregroundColor="#ff00" render="Label" position="280,10" size="780,30" font="Regular; 23" noWrap="1" zPosition="1" transparent="0"><convert type="Kitte888_CS_EcmTimeReader">Default</convert></widget>
        
            # ****** CPU Last *****
            <widget source="session.CurrentService" render="Label" position="1062,11" size="120,25" font="Regular; 20" transparent="1" zPosition="11" foregroundColor="#1bade4"><convert type="Kitte888_CS_YanCpuUsage">CPU:$0</convert></widget>
        
            
            
            #  *********** UHR *************
            <widget source="global.CurrentTime" backgroundColor="#0" foregroundColor="#ffffff" render="Label" position="1180,10" size="60,25" font="Regular;20" zPosition="1" transparent="0"><convert type="ClockToText">Default</convert>1
            </widget><widget source="global.CurrentTime" font="Regular; 20" backgroundColor="#0" foregroundColor="#ffffff" position="1240,10" render="Label" size="40,25" transparent="0" zPosition="2"><convert type="ClockToText">Format:%S</convert></widget>
        <eLabel backgroundColor="#0" foregroundColor="#ffffff" font="Regular; 20" noWrap="1" position="1235,10" size="5,25" text=":" zPosition="115" transparent="0" />	
        
        </screen>"""

# ------------------------------------------------------------
# Screen
# ------------------------------------------------------------

class PermanentTestScreen(Screen):
    logout(data="class permanent testscreen")
    skin = SKIN

    def __init__(self, session):
        Screen.__init__(self, session)

# ------------------------------------------------------------
# Controller (show / hide mit Config)
# ------------------------------------------------------------

class PermanentTest:
    logout(data="class permanent test")
    def __init__(self):
        logout(data="permanent test init")
        self.dialog = None
        self.visible = not config.plugins.PermanentTest.hidden.value

    def gotSession(self, session):
        logout(data="gotsession")
        if not self.dialog:
            self.dialog = session.instantiateDialog(PermanentTestScreen)
        self.update()

    def toggle(self):
        logout(data="toggel")
        self.visible = not self.visible
        config.plugins.PermanentTest.hidden.value = not self.visible
        config.plugins.PermanentTest.hidden.save()
        self.update()

    def update(self):
        logout(data="update")
        if not self.dialog:
            logout(data="if not")
            return
        if self.visible:
            logout(data="dialog show")
            self.dialog.show()
        else:
            logout(data="dialog hide")
            self.dialog.hide()

pClock = PermanentTest()

# ------------------------------------------------------------
# Menu (nur Show / Hide)
# ------------------------------------------------------------

class PermanentTestMenu(Screen):
    logout(data="class permanent test menu")
    skin = '<screen position="center,center" size="420,145" title="Permanent Test"><widget name="list" position="10,10" size="400,135" /></screen>'

    def __init__(self, session):
        logout(data="test menu init")
        Screen.__init__(self, session)
        self.session = session
        self['list'] = MenuList([])
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.okClicked, 'cancel': self.close}, -1)
        self.onLayoutFinish.append(self.showMenu)

    def showMenu(self):
        logout(data="show menu")
        if pClock.visible:
            self['list'].setList([_('Deactivate screen')])
        else:
            self['list'].setList([_('Activate screen')])

    def okClicked(self):
        logout(data="ok clicked")
        pClock.toggle()
        self.showMenu()

# ------------------------------------------------------------
# Plugin hooks
# ------------------------------------------------------------

def sessionstart(reason, **kwargs):
    logout(data="sessionstart")
    if reason == 0:
        session = kwargs.get('session')
        if session:
            pClock.gotSession(session)


def startConfig(session, **kwargs):
    logout(data="start config")
    session.open(PermanentTestMenu)


def main(menuid):
    logout(data="main")
    if menuid != 'system':
        return []
    return [(_('Permanent Test'), startConfig, 'permanent_test', None)]


def Plugins(**kwargs):
    logout(data="plugins")
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
        PluginDescriptor(name=_('Permanent Test'), description=_('Shows the ECM permanent on the screen'), where=PluginDescriptor.WHERE_MENU, fnc=main)
    ]
