#!/usr/bin/python
# -*- coding: utf-8 -*-
# so in der console testen - /usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/script/oscam_info.sh
import os
import subprocess
import logging
import shutil
# Konfiguration
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "oscam_info.log")
# Stelle sicher, dass das Verzeichnis existiert
if not os.path.exists(LOGDIR):
    try:
        os.makedirs(LOGDIR)
        print("Verzeichnis '{}' wurde erstellt.".format(LOGDIR))
    except Exception as e:
        print("Fehler beim Erstellen des Verzeichnisses '{}': {}".format(LOGDIR, e))


if os.path.exists(LOGFILE):
    try:
        os.remove(LOGFILE)
        print("Old log file '{}' deleted.".format(LOGFILE))
    except OSError as e:
        print("Error deleting old log file: {}".format(e))

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START oscam_info *******************************")


try:
    import subprocess
    get_output = subprocess.getoutput  # Python 3.x
except AttributeError:
    import commands
    get_output = commands.getoutput  # Python 2.x fallback

# Quelle und Ziel
oscam_version_path = "/tmp/.oscam/oscam.version"
oscam_copy_path = "/tmp/oscam.version"

oscam_version = ""
version_count = 0

if os.path.exists(oscam_version_path):
    shutil.copy(oscam_version_path, oscam_copy_path)
    logging.info("oscam.version wurde nach /tmp kopiert.")

    with open(oscam_copy_path, "r") as f:
        for line in f:
            if line.startswith("Version:"):
                version_count += 1
                value = line.strip().split(":", 1)[1].strip()

                # Erste Zeile: nur bis zum '@' nehmen
                if version_count == 1:
                    value = value.split("@")[0].strip()
                    oscam_version = value
                # Zweite Zeile: anhängen
                elif version_count == 2:
                    oscam_version += " | " + value

            elif line.startswith("WebifPort:"):
                oscam_webif_port = line.strip().split(":", 1)[1].strip()
                logging.info("Webinterface-Port gefunden: {}".format(oscam_webif_port))

    logging.info("OSCam Version(en): {}".format(oscam_version))
else:
    logging.warning("oscam.version wurde nicht gefunden.")


# Pfade für Ausgaben
out_oscam = "/tmp/oscamstatus/oscam"
out_oscam_start = "/tmp/oscamstatus/oscam_start"
out_oscam_path = "/tmp/oscamstatus/oscam_path"

binary_path = ""
configfiles_path = ""

# Kommandos definieren
commands = [
    {
        "desc": "Hole oscam Binary",
        "cmd": "ps xuww | grep -i oscam | grep -vE 'grep|tail' | awk '{print $11}' | uniq",
        "outfile": out_oscam
    },
    {
        "desc": "Hole oscam Startkommando (mit Argumenten)",
        "cmd": "ps xuww | grep -i oscam | grep -vE 'grep|tail' | awk '{for (i=11; i<=26; i++) printf \"%s%s\", $i, (i<26 ? OFS : ORS)}' | uniq",
        "outfile": out_oscam_start
    },
    {
        "desc": "Hole oscam Pfad",
        "cmd": "ps xuww | grep -i oscam | grep -vE 'grep|tail' | awk '{print $11}' | uniq | awk -F/ 'BEGIN {OFS=\"/\"} {NF--; print}'",
        "outfile": out_oscam_path
    }
]



# Kommandos ausführen
for c in commands:
    try:
        logging.info("Starte: {}".format(c['desc']))
        result = get_output(c["cmd"])

        #Ergebnis des Shell-Befehls ins Log schreiben:
        logging.info("Output von '{}':\n{}".format(c['desc'], result.strip()))

        with open(c["outfile"], "w") as f:
            f.write(result + "\n")
        logging.info("Erfolg: {} geschrieben.".format(c['outfile']))

        # Spezieller Teil: Wenn es um das Startkommando geht
        if c["outfile"] == out_oscam_start:
            with open(out_oscam_start, "r") as f:
                lines = f.readlines()
            # /usr/bin/oscamicamnew -r2 -b --config-dir /etc/tuxbox/config/oscamicamnew --pidfile /tmp/oscamicamnew.pid
            # Nur Zeilen nehmen, die mit / beginnen (also echte Pfade)
            valid_lines = [l.strip() for l in lines if l.strip().startswith("/")]
            logging.info("valid line: {}".format(valid_lines))
            if valid_lines:
                line = valid_lines[0]  # Nur die erste relevante Zeile nehmen
                logging.info("line 0 : {}".format(line))
                parts = line.split()
                logging.info("parts: {}".format(parts))
                if parts:
                    binary_path = parts[0]
                    logging.info("Binary Path: {}".format(binary_path))
                    if "-c" in parts or "--config-dir" in parts:
                        logging.info("Ist drin in parts: {}".format(parts))

                        # Überprüfen für '-c'
                        if "-c" in parts:
                            index = parts.index("-c")
                            if index + 1 < len(parts):
                                configfiles_path = parts[index + 1]
                                logging.info("Config Path von -c: {}".format(configfiles_path))

                        # Überprüfen für '--config-dir'
                        if "--config-dir" in parts:
                            index = parts.index("--config-dir")
                            if index + 1 < len(parts):
                                configfiles_path = parts[index + 1]
                                logging.info("Config Path von --config-dir: {}".format(configfiles_path))
                    else:
                        logging.warning("-c nicht gefunden im Startkommando.")
                else:
                    logging.warning("Startzeile leer oder ungültig.")
            else:
                logging.warning("Keine gültige Startzeile gefunden (z.B. oscam-Binary).")


    except Exception as e:
        logging.error("Fehler bei {desc}: {error}".format(desc=c['desc'], error=str(e)))

with open("/tmp/oscamstatus/oscam_info.txt", "w") as f:
    f.write("version={}\n".format(oscam_version))
    f.write("webifport={}\n".format(oscam_webif_port))
    f.write("binarypath={}\n".format(binary_path))
    f.write("configpath={}\n".format(configfiles_path))
logging.info("**************************** ENDE oscam_info *******************************")
