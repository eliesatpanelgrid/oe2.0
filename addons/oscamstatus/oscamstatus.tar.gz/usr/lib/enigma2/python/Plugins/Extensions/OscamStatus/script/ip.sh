#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import logging
import socket
# so in der console testen - /usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/script/ip.sh
# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "ip.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Stelle sicher, dass das Verzeichnis existiert
if not os.path.exists(LOGDIR):
    try:
        os.makedirs(LOGDIR)
        print("Verzeichnis '{}' wurde erstellt.".format(LOGDIR))
    except Exception as e:
        print("Fehler beim Erstellen des Verzeichnisses '{}': {}".format(LOGDIR, e))
        sys.exit(1)

# Altes Logfile löschen, wenn vorhanden
if os.path.exists(LOGFILE):
    try:
        os.remove(LOGFILE)
        print("Alte Logdatei '{}' gelöscht.".format(LOGFILE))
    except OSError as e:
        print("Fehler beim Löschen der alten Logdatei: {}".format(e))

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

# IP-Adresse ermitteln
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(0)
try:
    s.connect(('10.254.254.254', 1))
    ip_address = s.getsockname()[0]
except Exception as e:
    print("Fehler beim Abrufen der IP-Adresse: {}".format(e))
    ip_address = None
finally:
    s.close()

logging.info("Lokale IP-Adresse: {}".format(ip_address))
print(ip_address)

# IP-Info-Datei schreiben
try:
    with open(os.path.join(LOGDIR, "ip_info.txt"), "w") as f:
        f.write("ip={}\n".format(ip_address))
except Exception as e:
    print("Fehler beim Schreiben der IP-Info-Datei: {}".format(e))
