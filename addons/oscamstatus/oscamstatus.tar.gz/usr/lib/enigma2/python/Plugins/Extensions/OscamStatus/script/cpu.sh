#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import shutil
import time
import logging

# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "kitte888_cpu.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"
OSCAM_INFO_FILE = "/tmp/.oscam/oscam.version"  # Beispielpfad
TMP_FILE = "/tmp/oscam.version"
#  python /etc/tuxbox/config/oscamicamall/scripte/cpu.sh
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

# Datei in /tmp kopieren
try:
    shutil.copy2(OSCAM_INFO_FILE, TMP_FILE)
    logging.info("Datei kopiert: %s -> %s", OSCAM_INFO_FILE, TMP_FILE)
except Exception as e:
    logging.error("Fehler beim Kopieren: %s", str(e))
    sys.exit(1)

# Prüfen, ob Datei existiert
if os.path.exists(TMP_FILE):
    cpuversion = ""
    with open(TMP_FILE, "r") as f:
        for zeile in f:
            if "Compiler" in zeile:
                logging.info("CPU-Version gefunden")
                cpuversion = zeile.split(":", 1)[1].strip()
                break

    if cpuversion:
        logging.info("CPU-Version Ausgabe: %s", cpuversion)
        cputyp = cpuversion.split("-")[0]
        with open("/tmp/oscamstatus/cpu_info.txt", "w") as f:
            f.write(cputyp + "\n")
        print(cputyp)
    else:
        logging.info("CPU-Version nicht gefunden")
else:
    logging.error("TMP-Datei nicht vorhanden: %s", TMP_FILE)


