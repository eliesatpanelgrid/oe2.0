#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import logging
import socket
# so in der console testen - /usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/script/ip.sh
# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "modell.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Stelle sicher, dass das Verzeichnis existiert
if not os.path.exists(LOGDIR):
    try:
        os.makedirs(LOGDIR)
        print("Verzeichnis '{}' wurde erstellt.".format(LOGDIR))
    except Exception as e:
        print("Fehler beim Erstellen des Verzeichnisses '{}': {}".format(LOGDIR, e))
        sys.exit(1)

# Altes Logfile löschen, wenn vorhanden
if os.path.exists(LOGFILE):
    try:
        os.remove(LOGFILE)
        print("Alte Logdatei '{}' geloescht.".format(LOGFILE))
    except OSError as e:
        print("Fehler beim Loeschen der alten Logdatei: {}".format(e))

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

modell = ""
try:
    if os.path.exists("/proc/stb/info/vumodel"):
        with open("/proc/stb/info/vumodel", "r") as f:
            modell = f.read().strip()
    elif os.path.exists("/proc/stb/info/model"):
        with open("/proc/stb/info/model", "r") as f:
            modell = f.read().strip()
    else:
        modell = "Unbekanntes Modell"
except Exception as e:
    modell = "Fehler beim Lesen des Modells: %s" % str(e)

version = modell
print("Image-Version:", version)


# info ins Log schreiben
logging.info("Version: {}".format(version))

# Info in Datei schreiben
with open("/tmp/oscamstatus/modell_info.txt", "w") as f:
    f.write("{}\n".format(version))
