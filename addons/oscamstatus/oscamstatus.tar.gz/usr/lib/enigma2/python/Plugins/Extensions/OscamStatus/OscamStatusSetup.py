# -*- coding: utf-8 -*-
# ===============================================================================
# V0.29
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#
# geht auch in Python 2
# ===============================================================================

#
#
# from __init__ import _
# oben alte python2 unte so in Python3 , kein modul init
from . import _

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Button import Button
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Components.config import (
    config,
    NoSave,
    ConfigIP,
    ConfigText,
    ConfigYesNo,
    ConfigInteger,
    ConfigPassword,
    ConfigSubsection,
    getConfigListEntry,
)
from enigma import (
    eListboxPythonMultiContent,
    gFont,
    RT_HALIGN_LEFT,
    RT_VALIGN_CENTER,
    getDesktop,
)
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import (
    resolveFilename,
    SCOPE_CURRENT_PLUGIN,
    SCOPE_SKIN,
)
import re
import os
from os import remove
from Plugins.Extensions.PermanentTest.plugin import pClock
# --------------------------- Logfile -------------------------------
from datetime import datetime
from os.path import isfile
path = "/tmp/oscamstatus/"
if not os.path.exists(path):
    os.makedirs(path)
    print("Verzeichnis {} wurde angelegt".format(path))
else:
    print("Verzeichnis {} existiert bereits".format(path))

# log file loeschen

myfile = "/tmp/oscamstatus/oscamstatus_setup.log"

# If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
# File copieren

# log file anlegen
# kitte888 logfile anlegen die eingabe in logstatus

logstatus = "on"

# ________________________________________________________________________________


def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:
            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return


# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return


# so muss das commando aussehen , um in den file zu schreiben
logout(data="start")



config.plugins.OscamStatus = ConfigSubsection()
config.plugins.OscamStatus.lastServer = ConfigInteger(default=0)
config.plugins.OscamStatus.extMenu = ConfigYesNo(default=True)
config.plugins.OscamStatus.logOffset = ConfigInteger(default=0, limits=(0, 30))
config.plugins.OscamStatus.xOffset = ConfigInteger(default=0, limits=(0, 0))
config.plugins.OscamStatus.useECM = ConfigYesNo(default=False)
config.plugins.OscamStatus.useIP = ConfigYesNo(default=True)
config.plugins.OscamStatus.usePicons = ConfigYesNo(default=False)
# Kitte888 --------------------------------------- logfile auf default aus ---------------------------
config.plugins.OscamStatus.useLOGFILE = ConfigYesNo(default=False)
# config.plugins.OscamStatus.PiconPath = ConfigText(default = resolveFilename(SCOPE_SKIN,"picon_50x30"), fixed_size = False, visible_width=40)
config.plugins.OscamStatus.useECMCHECK = ConfigYesNo(default=False)

# export Variables...
LASTSERVER = config.plugins.OscamStatus.lastServer
EXTMENU = config.plugins.OscamStatus.extMenu

XOFFSET = config.plugins.OscamStatus.xOffset
USEECM = config.plugins.OscamStatus.useECM
# Kitte888 --------------------------------------- logfile auslesen und in USELOGFILE rein ---------------------------
USEPICONS = config.plugins.OscamStatus.usePicons
USELOGFILE = config.plugins.OscamStatus.useLOGFILE
USEECMTEST = config.plugins.OscamStatus.useECMCHECK


global logOffset

logfileschrift = config.plugins.OscamStatus.logOffset.value
logout(data="LOGFILESchrift")
logout(data=str(logfileschrift))
logfileschrift_str = str(logfileschrift)
logout(data="LOGFILESchrift")
logout(data=logfileschrift_str)

if config.plugins.PermanentTest.hidden.value:
    #config.plugins.OscamStatus.useECMCHECK.value = False
    #config.plugins.OscamStatus.useECMCHECK.save()
    logout(data="PermanentTest: AUS ECMCHECK AUS")
else:
    #config.plugins.OscamStatus.useECMCHECK.value = True
    #config.plugins.OscamStatus.useECMCHECK.save()
    logout(data="PermanentTest: EIN ECMCHECK EIN")

if USELOGFILE.value:
    logout(data="LOGFILE_On")
    logstatus = "on"
    logstatusin = "on"

else:
    logout(data="LOGFILE_Off")
    logstatus = "off"
    logstatusin = "off"

def togglePermanentTestFromOscam():
    logout(data="----------------------------------- toggel")
    config.plugins.PermanentTest.hidden.value = not config.plugins.PermanentTest.hidden.value
    config.plugins.PermanentTest.hidden.save()
    pClock.toggle()  # zeigt/versteckt den Screen direkt


def ecm_an_aus():
    logout(data="----------------------------------- Ecm an aus")
    if USEECMTEST.value:
        logout(data="------------------------------- Status_On")
        if config.plugins.PermanentTest.hidden.value:
            logout(data="PermanentTest: AUS (hidden=True)")
            togglePermanentTestFromOscam()
        else:
            logout(data="PermanentTest: EIN (hidden=False)")



    else:
        logout(data="-------------------------------- Status_Off")
        if config.plugins.PermanentTest.hidden.value:
            logout(data="PermanentTest: AUS (hidden=True)")

        else:
            logout(data="PermanentTest: EIN (hidden=False)")
            togglePermanentTestFromOscam()



# PICONPATH = config.plugins.OscamStatus.PiconPath


oscam_regex = {
    'ConfigDir': re.compile(r'ConfigDir:\s*(?P<ConfigDir>.*)\n'),

    'httpport': re.compile(r'httpport\s*=\s*(?P<httpport>[\+]?\d+)\n'),
    'httpuser': re.compile(r'httpuser\s*=\s*(?P<httpuser>.*)\n'),
    'httppwd': re.compile(r'httppwd\s*=\s*(?P<httppwd>.*)\n'),
}


def _parse_line(line):
    #logout(data="parseline")
    #logout(data=str(line))
    for key, rx in list(oscam_regex.items()):
        match = rx.search(line)
        if match:
            return key, match
    # if no matches
    return None, None


def parse_oscam_version_file(filepath, data):
    logout(data="***********  parse_oscam_version_file  *****************")
    logout(data=str(filepath))
    logout(data=str(data))
    # open the file and read through it line by line
    if isfile(filepath):
        logout(data="ist drin im tmp was im filepath steht")
        with open(filepath, 'r') as file_object:
            line = file_object.readline()
            logout(data="-----line oeffnen version und suchen pfad vom installieren ----")
            logout(data=str(line))
            while line:
                #logout(data="inline")
                key, match = _parse_line(line)
                if key == 'ConfigDir':
                    logout(data="key_configdir")
                    data.ConfigDir = match.group('ConfigDir')
                    logout(data=str(data.ConfigDir))
                line = file_object.readline()
        logout(data="---------------return1---------------")
        return 1
    logout(data="------------return0---------------")
    return 0


def parse_oscam_conf_file(filepath, data):
    logout(data="******  parse_oscam_conf_file  ****************")
    # open the file and read through it line by line
    if isfile(filepath):
        with open(filepath, 'r') as file_object:
            line = file_object.readline()
            while line:
                # at each line check for a match with a regex
                key, match = _parse_line(line)

                if key == 'httpport':
                    port = match.group('httpport')
                    logout(data="*************** port ***********************")
                    logout(data=port)

                    data.serverName = "Autodetected"
                    if port[0] == '+':
                        data.useSSL = True
                        data.serverPort = port[1:]

                    else:
                        data.serverPort = port

                if key == 'httpuser':
                    data.username = match.group('httpuser')
                    logout(data="username")
                    logout(data=str(data.username))

                if key == 'httpuser':
                    data.username = match.group('httpuser')
                    logout(data="username")
                    logout(data=str(data.username))

                if key == 'httppwd':
                    data.password = match.group('httppwd')

                line = file_object.readline()


def dlg_xh(w):
    logout(data="desktop X H")
    x = getDesktop(0).size().width() - w - XOFFSET.value
    logout(data=str(x))
    logout(data=str(w))
    logout(data=str(XOFFSET.value))
    if x < 0:
        x = 0
    h = getDesktop(0).size().height()
    logout(data=str(h))
    return x, h


# --------------------------------------------------------------------  Menu Screen Setup  --------------------------------------------------------------
class globalsConfigScreen(Screen, ConfigListScreen):
    w = getDesktop(0).size().width()
    logout("configlistscreen")
    if w >= 1920:
        logout("configlistscreen 1920")
        skin = """
            <screen name="globalsConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" transparent="0" flags="wfNoBorder" title="ConfigScreen">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00ffffff" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="12" name="nummer" position="1210,655" size="60,40" foregroundColor="#3a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <!-- buttons led -->
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>

                <!-- buttons text -->
                <widget name="ButtonRedtext" position="50,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular;25" backgroundColor="#00ffffff"   />
                <widget name= "ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" backgroundColor="#00ffffff"  />
                <!-- =====================================================================  -->
                <widget name="config" position="100,110" size="600,480" transparent="1" foregroundColor="white" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" scrollbarMode="showOnDemand" zPosition="2" itemHeight="60" />

        </screen>"""
    else:
        logout("configlistscreen 1280")
        skin = """
             <screen name="globalsConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" transparent="0" flags="wfNoBorder" title="ConfigScreen">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00ffffff" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="12" name="nummer" position="1210,655" size="60,40" foregroundColor="#3a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />

                
                <!-- buttons led -->
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>

                <!-- buttons text -->
                <widget name="ButtonRedtext" position="50,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular;25" backgroundColor="#00ffffff"   />
                <widget name= "ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" backgroundColor="#00ffffff"  />
                <!-- =====================================================================  -->
                <widget name="config" position="100,110" size="600,480" transparent="1" foregroundColor="white" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" scrollbarMode="showOnDemand" zPosition="2" itemHeight="60" />

        </screen>"""

    def __init__(self, session):
        logout(data="init screen configs")
        self.skin = globalsConfigScreen.skin
        self.session = session
        Screen.__init__(self, session)

        if config.plugins.PermanentTest.hidden.value:
            config.plugins.OscamStatus.useECMCHECK.value = False
            config.plugins.OscamStatus.useECMCHECK.save()
            logout(data="PermanentTest: AUS ECMCHECK AUS")
        else:
            config.plugins.OscamStatus.useECMCHECK.value = True
            config.plugins.OscamStatus.useECMCHECK.save()
            logout(data="PermanentTest: EIN ECMCHECK EIN")

        # -------------------------------------   hier einen eintrag dazu machen fuer den Logfile ein/aus   --------------------------------------------------
        list = []
        list.append(getConfigListEntry(_("Show Plugin in Extensions Menu"), config.plugins.OscamStatus.extMenu))
        # list.append(getConfigListEntry(_("X-Offset (move left)"), config.plugins.OscamStatus.xOffset))
        list.append(getConfigListEntry(_("ECM Time in \"connected\" Dialog"), config.plugins.OscamStatus.useECM))
        list.append(getConfigListEntry(_("Server address always in IP Format"), config.plugins.OscamStatus.useIP))
        # list.append(getConfigListEntry(_("Use Picons"), config.plugins.OscamStatus.usePicons))
        # list.append(getConfigListEntry(_("Picons Path"), config.plugins.OscamStatus.PiconPath))
        # Kitte888 --------------------------------------- logfile Teile im screen list anlegen ---------------------------
        list.append(getConfigListEntry(_("Logfile On/Off"), config.plugins.OscamStatus.useLOGFILE))
        list.append(getConfigListEntry(_("Logfile Text Offset "), config.plugins.OscamStatus.logOffset))
        list.append(getConfigListEntry(_("EcmCheck On/Off"), config.plugins.OscamStatus.useECMCHECK))
        ConfigListScreen.__init__(self, list, session=session)
        self["title"] = StaticText(_("Oscam Status globals Setup"))

        #self["ButtonRedtext"] = StaticText(_("return"))
        #self["ButtonGreentext"] = StaticText(_("save"))

        #self["ButtonGreen"] = Pixmap()
        self["ButtonGreentext"] = Button(_("save"))
        self["ButtonRedtext"] = Button(_("return"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {"red": self.Exit,
                                     "green": self.Save,
                                     "cancel": self.Exit}, -1)
        logout(data="LayoutFinish")
        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):

        pass

    def Save(self):
        logout(data="-------------------------------- save")
        logfileschrift = config.plugins.OscamStatus.logOffset.value
        # Hier wird der Wert von logOffset aus dem Setup übernommen.
        # Angenommen, logOffset ist eine Variable, die den Wert aus dem Setup enthält.
        # logfileschrift = logOffset

        # Jetzt können Sie den Wert von logfileschrift in das Logfile schreiben.
        logout(data="LOGFILESchrift")
        logout(data=str(logfileschrift))
        self.logschrift = logfileschrift
        for x in self["config"].list:
            x[1].save()
        ecm_an_aus()
        self.close()

    def Exit(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()



class oscamServer:
    serverName = "NewServer"
    serverIP = "127.0.0.1"
    serverPort = "8888"
    username = "username"
    password = "password"
    useSSL = False


# -------------------------------------------- pfad fuer cfg file  ------------------------------------------------------
CFG = resolveFilename(SCOPE_CURRENT_PLUGIN, "/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/oscamstatus.cfg")


def readCFG():
    logout(data="******* readCFG ********")
    cfg = None
    oscamServers = []
    logout(data="oscamServer")
    logout(data=str(oscamServer))
    try:
        with open(CFG, "r") as cfg:
            logout(data="[OscamStatus] reading config file...")
            d = cfg.read()
            for line in d.splitlines():
                v = line.strip().split(' ')
                if len(v) == 6:
                    tmp = oscamServer()
                    tmp.username = v[0]
                    tmp.password = v[1]
                    tmp.serverIP = v[2]
                    tmp.serverPort = v[3]
                    tmp.serverName = v[4]
                    tmp.useSSL = bool(int(v[5]))
                    if tmp.serverName != 'Autodetected':
                        oscamServers.append(tmp)
    except Exception as e:
        logout(data="[OscamStatus] no config file found %s".format( e))

    if len(oscamServers) == 0:
        logout(data="oscamServer_0")
        logout(data="[OscamStatus] no config file found")
    tmp = oscamServer()
    logout(data="in_tmp_drin")
    logout(data=str(tmp))

    if parse_oscam_version_file('/tmp/.oscam/oscam.version', tmp):
        logout(data="ist_oscam")
        parse_oscam_conf_file(tmp.ConfigDir + "/oscam.conf", tmp)

    if parse_oscam_version_file('/tmp/.ncam/ncam.version', tmp):
        logout(data="ist_ncam")
        parse_oscam_conf_file(tmp.ConfigDir + "/ncam.conf", tmp)

    oscamServers.append(tmp)
    logout(data="returnoscamServer")
    return oscamServers


def writeCFG(oscamServers):
    logout(data="writeCFG - CFG Path ist")
    logout(data=str(CFG))
    # cfg = file(CFG, "w")
    if os.path.exists(CFG):
        logout(data="writeCFG - CFG Path File ist da")
        with open(CFG, "w") as cfg:
            savedconfig = 0
            logout(data="[OscamStatus] writing datfile...")
            for line in oscamServers:
                if line.serverName != 'Autodetected':
                    cfg.write(line.username + ' ')
                    cfg.write(line.password + ' ')
                    cfg.write(line.serverIP + ' ')
                    cfg.write(line.serverPort + ' ')
                    cfg.write(line.serverName + ' ')
                    cfg.write(str(int(line.useSSL)) + '\n')
                    savedconfig = 1

        if not savedconfig:
            logout(data="writeCFG - ------------------------------- delete oscamstatus.cfg")
            # os.remove(CFG)
    else:
        logout(data="writeCFG - kein config file vorhanden")


class OscamServerEntryList(MenuList):
    def __init__(self, list, enableWrapAround=True):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        
        w = getDesktop(0).size().width()
        # braucht man im screen name=list
        if w >= 1920:
            self.l.setFont(0, gFont("Regular", 30))
            self.l.setFont(1, gFont("Regular", 27))
        else:
            self.l.setFont(0, gFont("Regular", 30))
            self.l.setFont(1, gFont("Regular", 28))



        self.pic0 = LoadPixmap(cached=True, path=resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_off.png"))
        self.pic1 = LoadPixmap(cached=True, path=resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_on.png"))

    def postWidgetCreate(self, instance):
        MenuList.postWidgetCreate(self, instance)
        instance.setItemHeight(40)

    def makeList(self, index):
        self.list = []
        oscamServers = readCFG()
        for cnt, i in enumerate(oscamServers):
            res = [i]
            if cnt == index:
                if self.pic1:
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 15, 13, 25, 24, self.pic1))
                else:
                    res.append((eListboxPythonMultiContent.TYPE_TEXT, 15, 13, 25, 24, 1,
                                RT_HALIGN_LEFT | RT_VALIGN_CENTER, 'x'))
            else:
                if self.pic0:
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 15, 13, 25, 24, self.pic0))
                else:
                    res.append((eListboxPythonMultiContent.TYPE_TEXT, 15, 13, 25, 24, 1,
                                RT_HALIGN_LEFT | RT_VALIGN_CENTER, ' '))
            res.append((eListboxPythonMultiContent.TYPE_TEXT, 120, 0, 120, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                        i.serverName))
            w = getDesktop(0).size().width()
            if w >= 1920:
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 120, 0, 200, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverName))
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 365, 0, 200, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverIP))
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 610, 0, 85, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverPort))
            else:
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 120, 0, 200, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverName))
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 365, 0, 200, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverIP))
                res.append((eListboxPythonMultiContent.TYPE_TEXT, 610, 0, 85, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                            i.serverPort))
            if i.useSSL:
                tx = "SSL"
            else:
                tx = ""
            if w >= 1920:
                res.append(
                    (eListboxPythonMultiContent.TYPE_TEXT, 545, 0, 50, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER, tx))
            else:
                res.append(
                    (eListboxPythonMultiContent.TYPE_TEXT, 370, 0, 30, 50, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER, tx))
            self.list.append(res)
        self.l.setList(self.list)
        self.moveToIndex(index)


# OscamServerEntriesListConfigScreen...  ---------------------- Setup Screen ---------------------------------------------------
class OscamServerEntriesListConfigScreen(Screen):
    w = getDesktop(0).size().width()
    logout("OscamServerEntriesListConfigScreen")
    if w >= 1920:
        logout("OscamServerEntriesListConfigScreen 1920")
        skin = """
            <screen name="OscamServerEntriesListConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" transparent="0" flags="wfNoBorder" title="Server Setup">
                 <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50" valign="center" zPosition="2" transparent="0" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="13" name="nummer" position="1210,655" size="60,40" foregroundColor="#003a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25" halign="center" />
                <!-- buttons led -->
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <!-- buttons text -->
                <widget name="ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonYellowtext" position="650,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonBluetext" position="950,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <!-- =====================================================================  -->
                <widget name="list" position="100,110" size="880,400" scrollbarMode="showOnDemand" font="Regular; 25" itemHeight="50" foregroundColor="#00ffffff" backgroundColor="#00000000" backgroundColorSelected="#001e53ff" foregroundColorSelected="#00ffffff" transparent="1" />


                
            </screen>"""
    else:
        logout("OscamServerEntriesListConfigScreen 1280")
        skin = """
            <screen name="OscamServerEntriesListConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" transparent="0" flags="wfNoBorder" title="Server Setup">
                 <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50" valign="center" zPosition="2" transparent="0" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="13" name="nummer" position="1210,655" size="60,40" foregroundColor="#003a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25" halign="center" />
                <!-- buttons led -->
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <!-- buttons text -->
                <widget name="ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonYellowtext" position="650,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonBluetext" position="950,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <!-- =====================================================================  -->
                <widget name="list" position="100,110" size="880,400" scrollbarMode="showOnDemand" font="Regular; 25" itemHeight="50" foregroundColor="#00ffffff" backgroundColor="#00000000" backgroundColorSelected="#001e53ff" foregroundColorSelected="#00ffffff" transparent="1" />


                
                
            </screen>"""

    def __init__(self, session):
        self.skin = OscamServerEntriesListConfigScreen.skin
        self.session = session
        Screen.__init__(self, session)

        self["list"] = OscamServerEntryList([])
        self["list"].makeList(config.plugins.OscamStatus.lastServer.value)

        self["title"] = StaticText(_("Oscam Servers"))
        self["ButtonGreentext"] = Button(_("new"))
        self["ButtonYellowtext"] = Button(_("edit"))
        self["ButtonBluetext"] = Button(_("delete"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {"green": self.keyNew,
                                     "yellow": self.keyEdit,
                                     "blue": self.keyDelete,
                                     "ok": self.keyOk,
                                     "cancel": self.keyClose}, -1)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass

    def updateEntrys(self):
        self["list"].makeList(config.plugins.OscamStatus.lastServer.value)

    def keyNew(self):
        self.session.openWithCallback(self.updateEntrys, OscamServerEntryConfigScreen, None, -1)

    def keyEdit(self):
        try:
            entry = self["list"].l.getCurrentSelection()[0]
        except:
            entry = None
        if entry:
            self.session.openWithCallback(self.updateEntrys, OscamServerEntryConfigScreen, entry,
                                          self["list"].getSelectionIndex())

    def keyDelete(self):
        try:
            self.index = self["list"].getSelectionIndex()
        except:
            self.index = -1
        if self.index > -1:
            if self.index == config.plugins.OscamStatus.lastServer.value:
                logout(data="[OscamStatus] you can not delete the active entry...")
                return
        message = _("Do you really want to delete this entry?")
        msg = self.session.openWithCallback(self.Confirmed, MessageBox, message)
        msg.setTitle("Oscam Status")

    def Confirmed(self, confirmed):
        if not confirmed:
            return
        oscamServers = readCFG()
        del oscamServers[self.index]
        writeCFG(oscamServers)
        if self.index < config.plugins.OscamStatus.lastServer.value:
            config.plugins.OscamStatus.lastServer.value -= 1
        self.updateEntrys()

    def keyOk(self):
        try:
            entry = self["list"].l.getCurrentSelection()[0]
        except:
            entry = None
        if entry:
            config.plugins.OscamStatus.lastServer.value = self["list"].getSelectionIndex()
            config.plugins.OscamStatus.lastServer.save()
            self.close(entry)

    def keyClose(self):
        self.close(False)


# OscamServerEntryConfigScreen...
class OscamServerEntryConfigScreen(Screen, ConfigListScreen):
    w = getDesktop(0).size().width()
    if w >= 1920:
        skin = """
            <screen name="OscamServerEntryConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50" valign="center" zPosition="2" transparent="0" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="14" name="nummer" position="1210,655" size="60,40" foregroundColor="#003a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25" halign="center" />
                <!-- buttons led -->
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />

                <!-- buttons text -->
                <widget name="ButtonRedtext" position="50,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular;25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <!-- =====================================================================  -->
                <widget name="config" position="100,130" size="700,400" backgroundColor="#000f1b2f" foregroundColor="#00ffffff" backgroundColorSelected="#001e53ff" foregroundColorSelected="#00ffffff" scrollbarMode="showOnDemand" font="Regular; 25" itemHeight="50" />
            
            </screen>"""

    else:
        skin = """
            <screen name="OscamServerEntryConfigScreen" position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50" valign="center" zPosition="2" transparent="0" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="14" name="nummer" position="1210,655" size="60,40" foregroundColor="#003a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25" halign="center" />
                <!-- buttons led -->
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on" />

                <!-- buttons text -->
                <widget name="ButtonRedtext" position="50,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular;25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <widget name="ButtonGreentext" position="350,650" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" font="Regular; 25" foregroundColor="#00ffffff" backgroundColor="#00ffffff" />
                <!-- =====================================================================  -->
                <widget name="config" position="100,130" size="700,400" backgroundColor="#000f1b2f" foregroundColor="#00ffffff" backgroundColorSelected="#001e53ff" foregroundColorSelected="#00ffffff" scrollbarMode="showOnDemand" font="Regular; 25" itemHeight="50" />
            
            </screen>"""

    def __init__(self, session, entry, index):
        self.skin = OscamServerEntryConfigScreen.skin
        self.session = session
        Screen.__init__(self, session)

        if entry is None:
            entry = oscamServer()
        self.index = index

        # Server address IP format or TextFormat?
        serverIP = self.isIPaddress(entry.serverIP)
        if serverIP and config.plugins.OscamStatus.useIP.value:
            self.isIP = True
        else:
            self.isIP = False

        serverPort = int(entry.serverPort)

        self.serverNameConfigEntry = NoSave(ConfigText(default=entry.serverName, fixed_size=False, visible_width=20))
        if self.isIP:
            self.serverIPConfigEntry = NoSave(ConfigIP(default=serverIP, auto_jump=True))
        else:
            self.serverIPConfigEntry = NoSave(ConfigText(default=entry.serverIP, fixed_size=False, visible_width=20))
            self.serverIPConfigEntry.setUseableChars(
                '1234567890aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ.-_')
        self.portConfigEntry = NoSave(ConfigInteger(default=serverPort, limits=(0, 65536)))
        self.usernameConfigEntry = NoSave(ConfigText(default=entry.username, fixed_size=False, visible_width=20))
        self.passwordConfigEntry = NoSave(ConfigPassword(default=entry.password, fixed_size=False))
        self.useSSLConfigEntry = NoSave(ConfigYesNo(entry.useSSL))

        ConfigListScreen.__init__(self, [], session=session)
        self.createSetup()

        self["title"] = StaticText(_("Oscam Server Setup"))
        self["ButtonRedtext"] = Button(_("return"))
        self["ButtonGreentext"] = Button(_("save"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {"red": self.Close,
                                     "green": self.Save,
                                     "cancel": self.Close}, -1)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass

    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Oscam Server Name"), self.serverNameConfigEntry))
        self.list.append(getConfigListEntry(_("Oscam Server Address"), self.serverIPConfigEntry))
        self.list.append(getConfigListEntry(_("Port"), self.portConfigEntry))
        self.list.append(getConfigListEntry(_("Username (httpuser)"), self.usernameConfigEntry))
        self.list.append(getConfigListEntry(_("Password (httppwd)"), self.passwordConfigEntry))
        self.list.append(getConfigListEntry(_("use SSL"), self.useSSLConfigEntry))
        self["config"].setList(self.list)

    def isIPaddress(self, txt):
        theIP = txt.split('.')
        if len(theIP) != 4:
            return False
        serverIP = []
        for x in theIP:
            try:
                serverIP.append(int(x))
            except:
                return False
        return serverIP

    def Close(self):
        self.close()

    def Save(self):
        entry = oscamServer()
        entry.username = self.usernameConfigEntry.value
        entry.password = self.passwordConfigEntry.value
        entry.serverName = self.serverNameConfigEntry.value
        if self.isIP:
            entry.serverIP = "%d.%d.%d.%d" % tuple(self.serverIPConfigEntry.value)
        else:
            entry.serverIP = self.serverIPConfigEntry.value
        entry.serverPort = str(self.portConfigEntry.value)
        entry.useSSL = self.useSSLConfigEntry.value
        oscamServers = readCFG()
        if self.index == -1:
            oscamServers.append(entry)
        else:
            oscamServers[self.index] = entry
        writeCFG(oscamServers)
        self.close()
