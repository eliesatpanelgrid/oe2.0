#!/usr/bin/env python
# -*- coding: utf-8 -*-
# so in der console testen - /usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/script/python.sh
import os
import sys
import time
import logging


# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp/oscamstatus"
LOGFILE = os.path.join(LOGDIR, "python.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Stelle sicher, dass das Verzeichnis existiert
if not os.path.exists(LOGDIR):
    try:
        os.makedirs(LOGDIR)
        print("Verzeichnis '{}' wurde erstellt.".format(LOGDIR))
    except Exception as e:
        print("Fehler beim Erstellen des Verzeichnisses '{}': {}".format(LOGDIR, e))


if os.path.exists(LOGFILE):
    try:
        os.remove(LOGFILE)
        print("Old log file '{}' deleted.".format(LOGFILE))
    except OSError as e:
        print("Error deleting old log file: {}".format(e))
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")


python_version = sys.version
logging.info("python version".format(python_version))
# Extrahiere nur die Hauptversion und Subversion (z.B. 3.12.8)
version = python_version.split()[0]

logging.info("python version".format(version))
print(version)
with open("/tmp/oscamstatus/python_info.txt", "w") as f:
    f.write("python={}\n".format(version))