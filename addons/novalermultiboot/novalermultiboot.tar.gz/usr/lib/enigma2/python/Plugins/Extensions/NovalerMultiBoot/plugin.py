import os
import stat
import subprocess
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Console import Console
from Screens.ChoiceBox import ChoiceBox

ENGINE_SCRIPT_PATH = "/usr/bin/e2multiboot_engine.sh"
SLOTS_CONF_PATH = "/etc/novaler_slots.conf"

ENGINE_SCRIPT_CONTENT = """#!/bin/sh

ACTION="$1"
PARAM1="$2"
PARAM2="$3"

CONF_FILE="/etc/novaler_slots.conf"

init_conf() {
    if [ ! -f "$CONF_FILE" ]; then
        i=6
        while [ "$i" -le 15 ]; do
            echo "Slot_${i}=Empty" >> "$CONF_FILE"
            i=$((i + 1))
        done
    fi
}

update_slot_info() {
    SLOT_NUM="$1"
    SLOT_NAME="$2"
    init_conf
    sed -i "/^Slot_${SLOT_NUM}=/d" "$CONF_FILE"
    echo "Slot_${SLOT_NUM}=${SLOT_NAME}" >> "$CONF_FILE"
}

force_umount_part() {
    TARGET_DEV="$1"
    if [ -n "$TARGET_DEV" ]; then
        fuser -k -9 "$TARGET_DEV" 2>/dev/null
        umount -f "$TARGET_DEV" 2>/dev/null
        umount -l "$TARGET_DEV" 2>/dev/null
    fi
}

generate_startup_files() {
    mount -o remount,rw /boot 2>/dev/null

    # تنظيف مجلد /boot من ملفات STARTUP الخارجية لمنع تضخم وتشوه شاشة البوت (Bootmenu)
    rm -f /boot/STARTUP_LINUX_6 /boot/STARTUP_LINUX_7 /boot/STARTUP_LINUX_8 \
          /boot/STARTUP_LINUX_9 /boot/STARTUP_LINUX_10 /boot/STARTUP_LINUX_11 \
          /boot/STARTUP_LINUX_12 /boot/STARTUP_LINUX_13 /boot/STARTUP_LINUX_14 \
          /boot/STARTUP_LINUX_15 2>/dev/null

    rm -f /boot/*.bak /boot/*.tmp /boot/*~ 2>/dev/null
    sync
}

inject_plugin_to_slot() {
    SLOT_NUM="$1"
    PART_INDEX=$((SLOT_NUM - 5))
    DEV_PART="/dev/mmcblk1p${PART_INDEX}"
    MOUNT_DIR="/mnt/sdcard_inject_${SLOT_NUM}"

    if [ -b "${DEV_PART}" ]; then
        force_umount_part "${DEV_PART}"
        force_umount_part "${MOUNT_DIR}"
        mkdir -p "${MOUNT_DIR}"
        mount "${DEV_PART}" "${MOUNT_DIR}" 2>/dev/null
        if [ $? -eq 0 ]; then
            TARGET_DIR="${MOUNT_DIR}/usr/lib/enigma2/python/Plugins/Extensions/NovalerMultiBoot"
            mkdir -p "${TARGET_DIR}"
            cp -rf /usr/lib/enigma2/python/Plugins/Extensions/NovalerMultiBoot/* "${TARGET_DIR}/" 2>/dev/null
            cp -f /usr/bin/e2multiboot_engine.sh "${MOUNT_DIR}/usr/bin/" 2>/dev/null
            cp -f /etc/novaler_slots.conf "${MOUNT_DIR}/etc/novaler_slots.conf" 2>/dev/null
            chmod 755 "${MOUNT_DIR}/usr/bin/e2multiboot_engine.sh" 2>/dev/null
            force_umount_part "${MOUNT_DIR}"
        fi
        rm -rf "${MOUNT_DIR}"
    fi
}

case "$ACTION" in
    "format_sd")
        DEV_CARD="/dev/mmcblk1"
        if [ ! -b "$DEV_CARD" ]; then
            echo "ERROR: MicroSD Card ($DEV_CARD) not found!"
            exit 1
        fi

        if [ -f "/sys/class/block/mmcblk1/size" ]; then
            SECTORS=$(cat /sys/class/block/mmcblk1/size)
            TOTAL_MB=$(( SECTORS * 512 / 1024 / 1024 ))
        else
            TOTAL_KB=$(blockdev --getsz "$DEV_CARD" 2>/dev/null)
            TOTAL_MB=$(( TOTAL_KB * 512 / 1024 / 1024 ))
        fi

        if [ "$TOTAL_MB" -lt 7500 ]; then
            echo "ERROR: SD Card size is too small (${TOTAL_MB} MB)!"
            exit 1
        fi

        USABLE_MB=$(( TOTAL_MB - 20 ))
        SLOT_SIZE_MB=$(( USABLE_MB / 10 ))

        i=1
        while [ "$i" -le 16 ]; do
            force_umount_part "/dev/mmcblk1p${i}"
            force_umount_part "/mnt/sdcard${i}"
            i=$((i + 1))
        done
        force_umount_part "/dev/mmcblk1"

        parted -s /dev/mmcblk1 mklabel gpt

        i=1
        while [ "$i" -le 10 ]; do
            if [ "$i" -eq 1 ]; then
                START_SIZE="2048s"
            else
                START_SIZE="$(( (i - 1) * SLOT_SIZE_MB ))MiB"
            fi
            END_SIZE="$(( i * SLOT_SIZE_MB ))MiB"
            parted -s /dev/mmcblk1 mkpart primary ext4 ${START_SIZE} ${END_SIZE}
            i=$((i + 1))
        done

        partprobe /dev/mmcblk1
        sleep 3

        i=1
        while [ "$i" -le 10 ]; do
            SLOT_NUM=$((5 + i))
            DEV_PART="/dev/mmcblk1p${i}"
            force_umount_part "${DEV_PART}"
            mkfs.ext4 -F -O ^has_journal -E lazy_itable_init=1 -L "linux${SLOT_NUM}" "${DEV_PART}"
            i=$((i + 1))
        done

        rm -f "$CONF_FILE"
        init_conf
        generate_startup_files
        echo "SUCCESS: Formatted 10 slots successfully!"
        sleep 3
        reboot
        ;;

    "install_image")
        SLOT_NUM="$PARAM1"
        ZIP_PATH="$PARAM2"
        PART_INDEX=$((SLOT_NUM - 5))
        DEV_PART="/dev/mmcblk1p${PART_INDEX}"
        MOUNT_DIR="/mnt/sdcard${SLOT_NUM}"

        ZIP_NAME=$(basename "$ZIP_PATH" .zip)

        echo "[1/5] Force unmounting partition..."
        force_umount_part "${DEV_PART}"
        force_umount_part "${MOUNT_DIR}"
        sleep 1

        echo "[2/5] Formatting partition (${DEV_PART})..."
        mkfs.ext4 -F -O ^has_journal -E lazy_itable_init=1 -L "linux${SLOT_NUM}" "${DEV_PART}"

        mkdir -p "${MOUNT_DIR}"
        mount "${DEV_PART}" "${MOUNT_DIR}"
        
        TMP_HDD="/media/hdd/tmp_e2install"
        rm -rf "$TMP_HDD"
        mkdir -p "$TMP_HDD"
        
        echo "[3/5] Extracting rootfs archive from Zip..."
        unzip -q -j "$ZIP_PATH" "*/rootfs.tar.bz2" -d "$TMP_HDD/"
        if [ -f "$TMP_HDD/rootfs.tar.bz2" ]; then
            echo "[3/5] Extracting image contents to Slot ${SLOT_NUM}..."
            tar -xjf "$TMP_HDD/rootfs.tar.bz2" -C "${MOUNT_DIR}/"
            rm -rf "$TMP_HDD"
            sync
        else
            echo "ERROR: rootfs.tar.bz2 not found inside zip!"
            force_umount_part "${MOUNT_DIR}"
            exit 1
        fi

        echo "[4/5] Detecting Image Identity & Updating Registry..."
        IMG_DETECTED=""
        if [ -f "${MOUNT_DIR}/etc/issue" ]; then
            IMG_DETECTED=$(grep -E -i "openatv|egami|openbh|openpli|pure2|openspa|openvix|corvoboys" "${MOUNT_DIR}/etc/issue" | head -n 1 | sed -e 's/\\n//g' -e 's/\\l//g' | xargs)
        fi
        
        if [ -z "$IMG_DETECTED" ]; then
            IMG_DETECTED="$ZIP_NAME"
        fi

        update_slot_info "$SLOT_NUM" "$IMG_DETECTED"

        echo "[5/5] Injecting Novaler MultiBoot Plugin & Config into Slot ${SLOT_NUM}..."
        TARGET_DIR="${MOUNT_DIR}/usr/lib/enigma2/python/Plugins/Extensions/NovalerMultiBoot"
        mkdir -p "${TARGET_DIR}"
        cp -rf /usr/lib/enigma2/python/Plugins/Extensions/NovalerMultiBoot/* "${TARGET_DIR}/" 2>/dev/null
        cp -f /usr/bin/e2multiboot_engine.sh "${MOUNT_DIR}/usr/bin/" 2>/dev/null
        cp -f "$CONF_FILE" "${MOUNT_DIR}/etc/novaler_slots.conf" 2>/dev/null
        chmod 755 "${MOUNT_DIR}/usr/bin/e2multiboot_engine.sh" 2>/dev/null

        force_umount_part "${MOUNT_DIR}"
        sync
        generate_startup_files
        echo "=========================================="
        echo "SUCCESS: Installed ${IMG_DETECTED} on Slot ${SLOT_NUM}!"
        echo "=========================================="
        ;;

    "inject_all")
        init_conf
        i=1
        while [ "$i" -le 10 ]; do
            slot=$((5 + i))
            echo "[*] Injecting plugin to Slot ${slot}..."
            inject_plugin_to_slot "$slot"
            i=$((i + 1))
        done
        echo "SUCCESS: Plugin injected to all available slots!"
        ;;

    "wipe_slot")
        SLOT_NUM="$PARAM1"
        PART_INDEX=$((SLOT_NUM - 5))
        DEV_PART="/dev/mmcblk1p${PART_INDEX}"

        force_umount_part "${DEV_PART}"
        mkfs.ext4 -F -O ^has_journal -E lazy_itable_init=1 -L "linux${SLOT_NUM}" "${DEV_PART}"
        sync
        update_slot_info "$SLOT_NUM" "Empty"
        echo "SUCCESS: Slot ${SLOT_NUM} wiped!"
        ;;

    "reboot_slot")
        SLOT_NUM="$PARAM1"
        PART_INDEX=$((SLOT_NUM - 5))
        DEV_PART="/dev/mmcblk1p${PART_INDEX}"

        mount -o remount,rw /boot 2>/dev/null
        generate_startup_files

        printf "bootcmd=setenv bootargs \$(bootargs) \$(bootargs_common); mmc read 0 0x1000000 0x3D5000 0x8000; bootm 0x1000000; run bootcmd_fallback\\nbootargs=root=%s rootfstype=ext4 rw rootwait console=ttyAMA0,115200 kernel=/dev/mmcblk0p22\\n" "${DEV_PART}" > /boot/STARTUP
        sync
        reboot
        ;;
esac
"""

def setup_engine_script():
    try:
        with open(ENGINE_SCRIPT_PATH, "w") as f:
            f.write(ENGINE_SCRIPT_CONTENT)
        os.chmod(ENGINE_SCRIPT_PATH, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
    except Exception as e:
        print(f"[NovalerMultiBoot] Error setting engine script: {e}")

    if not os.path.exists(SLOTS_CONF_PATH):
        try:
            with open(SLOTS_CONF_PATH, "w") as f:
                for i in range(6, 16):
                    f.write(f"Slot_{i}=Empty\n")
        except Exception:
            pass

def get_slot_image_name(slot_num):
    if os.path.exists(SLOTS_CONF_PATH):
        try:
            with open(SLOTS_CONF_PATH, "r") as f:
                for line in f:
                    if line.startswith(f"Slot_{slot_num}="):
                        val = line.split("=")[1].strip()
                        return val if val else "Empty"
        except Exception:
            pass
    return "Empty"

class NovalerMultiBootMain(Screen):
    skin = """
    <screen name="NovalerMultiBootMain" position="center,center" size="1280,720" title="Novaler MultiBoot Manager (by khaled ali)">
        <widget name="logo" position="30,20" size="150,150" alphatest="on" />
        <widget name="title_label" position="200,40" size="1040,60" font="Regular;32" halign="left" valign="center" />
        <widget name="menu" position="30,190" size="1220,440" itemHeight="45" font="Regular;26" scrollbarMode="showOnDemand" />
        <widget name="status" position="30,645" size="1220,55" font="Regular;22" halign="center" valign="center" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        setup_engine_script()
        
        self["logo"] = Pixmap()
        self["title_label"] = Label("Novaler MultiBoot Manager (by khaled ali)")
        
        main_menu_items = [
            ("1. 🛠️  Format & Partition SD Card (10 Slots)", "menu_format"),
            ("2. 📥  Install Image to Slot...", "menu_install"),
            ("3. ⚡  Reboot / Switch to Slot...", "menu_reboot"),
            ("4. 🧹  Wipe / Clear Slot...", "menu_wipe"),
            ("5. 🔄  Inject Plugin into All Installed Images", "menu_inject")
        ]
        
        self["menu"] = MenuList(main_menu_items)
        self["status"] = Label("اختر الخيار واضغط OK")
        
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.run_main_menu,
            "cancel": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.load_logo)

    def load_logo(self):
        plugin_path = os.path.dirname(__file__)
        logo_path = os.path.join(plugin_path, "logo.png")
        if not os.path.exists(logo_path):
            logo_path = os.path.join(plugin_path, "plugin.png")
            
        if os.path.exists(logo_path) and self["logo"].instance:
            from Tools.LoadPixmap import LoadPixmap
            pm = LoadPixmap(logo_path)
            if pm:
                self["logo"].instance.setPixmap(pm)

    def run_main_menu(self):
        selected = self["menu"].getCurrent()
        if not selected:
            return
        
        action_key = selected[1]
        
        if action_key == "menu_format":
            cmd = f"{ENGINE_SCRIPT_PATH} format_sd"
            self.session.open(Console, title="Formatting SD Card...", cmdlist=[cmd])

        elif action_key == "menu_install":
            self.show_slot_selection("اختر السلوت المراد تثبيت الصورة عليه:", self.on_slot_selected_for_install)

        elif action_key == "menu_reboot":
            self.show_slot_selection("اختر السلوت المراد الإقلاع إليه:", self.on_slot_selected_for_reboot)

        elif action_key == "menu_wipe":
            self.show_slot_selection("اختر السلوت المراد مسحه وتفريغه:", self.on_slot_selected_for_wipe)

        elif action_key == "menu_inject":
            cmd = f"{ENGINE_SCRIPT_PATH} inject_all"
            self.session.open(Console, title="Injecting Plugin to all images...", cmdlist=[cmd])

    def show_slot_selection(self, title_text, callback_fn):
        slots_list = []
        for s in range(6, 16):
            img_info = get_slot_image_name(s)
            slots_list.append((f"Slot '{s}': {img_info}", str(s)))

        self["status"].setText("اختر السلوت المفضل")
        self.session.openWithCallback(
            callback_fn,
            ChoiceBox,
            title=title_text,
            list=slots_list
        )

    def on_slot_selected_for_install(self, choice):
        if choice:
            slot = choice[1]
            self.select_zip_file(slot)

    def on_slot_selected_for_reboot(self, choice):
        if choice:
            slot = choice[1]
            cmd = f"{ENGINE_SCRIPT_PATH} reboot_slot {slot}"
            self.session.open(Console, title=f"Rebooting to Slot {slot}...", cmdlist=[cmd])

    def on_slot_selected_for_wipe(self, choice):
        if choice:
            slot = choice[1]
            cmd = f"{ENGINE_SCRIPT_PATH} wipe_slot {slot}"
            self.session.open(Console, title=f"Wiping Slot {slot}...", cmdlist=[cmd])

    def select_zip_file(self, slot):
        search_paths = ["/media/hdd/images", "/media/hdd", "/tmp"]
        zip_files = []
        
        for path in search_paths:
            if os.path.exists(path):
                for f in os.listdir(path):
                    if f.endswith(".zip"):
                        full_path = os.path.join(path, f)
                        zip_files.append((f"{f} ({path})", full_path))
        
        if not zip_files:
            self["status"].setText("خطأ: لم يتم العثور على أي ملف zip في /media/hdd/images")
            return

        self.session.openWithCallback(
            lambda choice: self.start_install(slot, choice[1]) if choice else None,
            ChoiceBox,
            title=f"اختر ملف الصورة (.zip) للتثبيت على Slot {slot}:",
            list=zip_files
        )

    def start_install(self, slot, zip_path):
        if zip_path and os.path.isfile(zip_path):
            cmd = f"{ENGINE_SCRIPT_PATH} install_image {slot} '{zip_path}'"
            self.session.open(Console, title=f"Installing Image to Slot {slot}...", cmdlist=[cmd])

def main(session, **kwargs):
    session.open(NovalerMultiBootMain)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Novaler MultiBoot\n(by khaled ali)",
            description="(by khaled ali)",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]

