import os
import stat
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Console import Console
from Screens.ChoiceBox import ChoiceBox

ENGINE_SCRIPT_PATH = "/usr/bin/e2multiboot_engine.sh"

ENGINE_SCRIPT_CONTENT = """#!/bin/sh

ACTION="$1"
PARAM1="$2"
PARAM2="$3"

echo "================================================="
echo "       Novaler 4K Pro - MultiBoot Engine         "
echo "================================================="

# دالة إعادة إنشاء ملفات الإقلاع الأربعة بحجم متناهي الصغر لضمان ظهورها في القائمة بدون امتلاء /boot
generate_startup_files() {
    mount -o remount,rw /boot 2>/dev/null
    rm -f /boot/*.bak /boot/*.tmp /boot/*~ 2>/dev/null

    for slot in 6 7 8 9; do
        part_idx=$((slot - 5))
        dev_part="/dev/mmcblk1p${part_idx}"
        startup_file="/boot/STARTUP_LINUX_${slot}"
        
        # كتابة سطر كود خفيف جداً لتوفير المساحة وفي نفس الوقت إظهار السلوت للنظام
        echo "bootargs=root=${dev_part} rootfstype=ext4 rw rootwait console=ttyAMA0,115200 kernel=/dev/mmcblk0p22" > "${startup_file}"
    done
    sync
}

case "$ACTION" in
    "format_sd")
        SLOTS_COUNT="$PARAM1"
        [ -z "$SLOTS_COUNT" ] && SLOTS_COUNT=4

        echo "[1/5] Unmounting SD Card partitions..."
        umount -f /dev/mmcblk1* 2>/dev/null

        echo "[2/5] Creating GPT Table on /dev/mmcblk1..."
        parted -s /dev/mmcblk1 mklabel gpt

        i=1
        while [ "$i" -le "$SLOTS_COUNT" ]; do
            SLOT_NUM=$((5 + i))
            START_SIZE="$(( (i - 1) * 3000 + 1 ))MiB"
            [ "$i" -eq 1 ] && START_SIZE="2048s"
            END_SIZE="$(( i * 3000 ))MiB"

            echo "[3/5] Creating Partition for Slot ${SLOT_NUM}..."
            parted -s /dev/mmcblk1 mkpart primary ext4 ${START_SIZE} ${END_SIZE}
            i=$((i + 1))
        done

        echo "[4/5] Informing Kernel of partition changes..."
        partprobe /dev/mmcblk1
        sleep 3

        i=1
        while [ "$i" -le "$SLOTS_COUNT" ]; do
            SLOT_NUM=$((5 + i))
            DEV_PART="/dev/mmcblk1p${i}"
            echo "[5/5] Formatting ${DEV_PART} with expanded Inodes..."
            mkfs.ext4 -F -O ^has_journal -N 250000 -E lazy_itable_init=1 -L "linux${SLOT_NUM}" "${DEV_PART}"
            i=$((i + 1))
        done

        echo "[*] Restoring startup files in /boot for Recovery menu visibility..."
        generate_startup_files

        echo "================================================="
        echo " SUCCESS: Formatted ${SLOTS_COUNT} slots successfully!"
        echo " System will reboot in 5 seconds..."
        echo "================================================="
        sleep 5
        reboot
        ;;

    "install_image")
        SLOT_NUM="$PARAM1"
        ZIP_PATH="$PARAM2"
        
        if [ -z "$SLOT_NUM" ] || [ -z "$ZIP_PATH" ]; then
            echo "ERROR: Missing Slot Number or ZIP Path!"
            exit 1
        fi

        PART_INDEX=$((SLOT_NUM - 5))
        DEV_PART="/dev/mmcblk1p${PART_INDEX}"
        MOUNT_DIR="/mnt/sdcard${SLOT_NUM}"

        if [ ! -f "$ZIP_PATH" ]; then
            echo "ERROR: Image ZIP not found at: $ZIP_PATH"
            exit 1
        fi

        echo "[1/4] Unmounting target partition if busy..."
        umount -f "${DEV_PART}" 2>/dev/null
        umount -f "${MOUNT_DIR}" 2>/dev/null

        echo "[2/4] Fast formatting Slot ${SLOT_NUM} (${DEV_PART})..."
        mkfs.ext4 -F -O ^has_journal -N 250000 -E lazy_itable_init=1 -L "linux${SLOT_NUM}" "${DEV_PART}"

        echo "[3/4] Mounting Partition ${DEV_PART} to ${MOUNT_DIR}..."
        mkdir -p "${MOUNT_DIR}"
        mount "${DEV_PART}" "${MOUNT_DIR}"
        
        if [ $? -ne 0 ]; then
            echo "ERROR: Failed to mount partition ${DEV_PART}!"
            exit 1
        fi

        echo "[4/4] Unpacking Image directly to Slot ${SLOT_NUM}..."
        TMP_HDD="/media/hdd/tmp_e2install"
        rm -rf "$TMP_HDD"
        mkdir -p "$TMP_HDD"
        
        unzip -q -j "$ZIP_PATH" "*/rootfs.tar.bz2" -d "$TMP_HDD/"
        
        if [ -f "$TMP_HDD/rootfs.tar.bz2" ]; then
            tar -xjf "$TMP_HDD/rootfs.tar.bz2" -C "${MOUNT_DIR}/"
            TAR_STATUS=$?
            rm -rf "$TMP_HDD"
            sync

            if [ $TAR_STATUS -ne 0 ]; then
                echo "ERROR: Failed to unpack rootfs archive!"
                umount "${MOUNT_DIR}"
                exit 1
            fi
        else
            echo "ERROR: rootfs.tar.bz2 missing inside ZIP archive!"
            rm -rf "$TMP_HDD"
            umount "${MOUNT_DIR}"
            exit 1
        fi

        umount "${MOUNT_DIR}"
        sync

        # التأكد من وجود الملفات الخاصة بكل السلوتات في /boot
        generate_startup_files

        echo "================================================="
        echo " SUCCESS: Image successfully installed to Slot ${SLOT_NUM}!"
        echo "================================================="
        ;;

    "reboot_slot")
        SLOT_NUM="$PARAM1"
        PART_INDEX=$((SLOT_NUM - 5))
        DEV_PART="/dev/mmcblk1p${PART_INDEX}"

        echo "Preparing Boot parameters for Slot ${SLOT_NUM}..."
        mount -o remount,rw /boot 2>/dev/null

        # تأكيد وجود كافة ملفات السلوتات لتظل ظاهرة في القائمة دائماً
        generate_startup_files

        # نسخ أمر الإقلاع الخاص بالسلوت المختار إلى STARTUP المباشر
        printf "bootcmd=setenv bootargs \$(bootargs) \$(bootargs_common); mmc read 0 0x1000000 0x3D5000 0x8000; bootm 0x1000000; run bootcmd_fallback\\nbootargs=root=%s rootfstype=ext4 rw rootwait console=ttyAMA0,115200 kernel=/dev/mmcblk0p22\\n" "${DEV_PART}" > /boot/STARTUP
        sync

        echo "Rebooting to Slot ${SLOT_NUM}..."
        sleep 1
        reboot
        ;;
esac
"""

def setup_engine_script():
    try:
        with open(ENGINE_SCRIPT_PATH, "w") as f:
            f.write(ENGINE_SCRIPT_CONTENT)
        os.chmod(ENGINE_SCRIPT_PATH, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
    except Exception as e:
        print(f"[NovalerMultiBoot] Error writing engine script: {e}")

class NovalerMultiBootMain(Screen):
    skin = """
    <screen name="NovalerMultiBootMain" position="center,center" size="1280,720" title="Novaler External MultiBoot Manager">
        <widget name="logo" position="30,20" size="150,150" alphatest="on" />
        <widget name="title_label" position="200,40" size="1040,60" font="Regular;34" halign="left" valign="center" />
        <widget name="menu" position="30,190" size="1220,440" itemHeight="42" font="Regular;26" scrollbarMode="showOnDemand" />
        <widget name="status" position="30,645" size="1220,55" font="Regular;24" halign="center" valign="center" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        setup_engine_script()
        
        self["logo"] = Pixmap()
        self["title_label"] = Label("Novaler External MultiBoot Manager")
        
        list_items = [
            ("1. Format SD Card for Slots 6 to 9 (4 Slots - GPT)", "format_4"),
            ("2. Format SD Card for Slots 6 & 7 (2 Slots - GPT)", "format_2"),
            ("3. Install Image to Slot 6", "install_6"),
            ("4. Install Image to Slot 7", "install_7"),
            ("5. Install Image to Slot 8", "install_8"),
            ("6. Install Image to Slot 9", "install_9"),
            ("7. Reboot to Slot 6", "reboot_6"),
            ("8. Reboot to Slot 7", "reboot_7"),
            ("9. Reboot to Slot 8", "reboot_8"),
            ("10. Reboot to Slot 9", "reboot_9")
        ]
        
        self["menu"] = MenuList(list_items)
        self["status"] = Label("اختر العملية واضغط OK للتنفيذ")
        
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.run_option,
            "cancel": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.load_logo)

    def load_logo(self):
        plugin_path = os.path.dirname(__file__)
        logo_path = os.path.join(plugin_path, "logo.png")
        if not os.path.exists(logo_path):
            logo_path = os.path.join(plugin_path, "plugin.png")
            
        if os.path.exists(logo_path) and self["logo"].instance:
            from Tools.LoadPixmap import LoadPixmap
            pm = LoadPixmap(logo_path)
            if pm:
                self["logo"].instance.setPixmap(pm)

    def run_option(self):
        selected = self["menu"].getCurrent()
        if not selected:
            return
        
        action_key = selected[1]
        
        if action_key.startswith("format_"):
            slots = action_key.split("_")[1]
            cmd = f"{ENGINE_SCRIPT_PATH} format_sd {slots}"
            self.session.open(Console, title="Formatting SD Card...", cmdlist=[cmd])

        elif action_key.startswith("install_"):
            slot = action_key.split("_")[1]
            self.select_zip_file(slot)

        elif action_key.startswith("reboot_"):
            slot = action_key.split("_")[1]
            cmd = f"{ENGINE_SCRIPT_PATH} reboot_slot {slot}"
            self.session.open(Console, title=f"Rebooting to Slot {slot}...", cmdlist=[cmd])

    def select_zip_file(self, slot):
        search_paths = ["/media/hdd/images", "/media/hdd", "/tmp"]
        zip_files = []
        
        for path in search_paths:
            if os.path.exists(path):
                for f in os.listdir(path):
                    if f.endswith(".zip"):
                        full_path = os.path.join(path, f)
                        zip_files.append((f"{f} ({path})", full_path))
        
        if not zip_files:
            self["status"].setText("خطأ: لم يتم العثور على أي ملف zip في /media/hdd/images أو /media/hdd")
            return

        self.session.openWithCallback(
            lambda choice: self.start_install(slot, choice[1]) if choice else None,
            ChoiceBox,
            title="اختر ملف الصورة (.zip) المراد تثبيتها:",
            list=zip_files
        )

    def start_install(self, slot, zip_path):
        if zip_path and os.path.isfile(zip_path):
            cmd = f"{ENGINE_SCRIPT_PATH} install_image {slot} '{zip_path}'"
            self.session.open(Console, title=f"Installing Image to Slot {slot}...", cmdlist=[cmd])

def main(session, **kwargs):
    session.open(NovalerMultiBootMain)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Novaler MultiBoot",
            description="External MultiBoot Manager for Slots 6-9",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]

