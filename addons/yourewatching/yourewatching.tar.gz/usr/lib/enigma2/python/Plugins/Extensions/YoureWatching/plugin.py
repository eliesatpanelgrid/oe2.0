# Internal filename: '/usr/lib/enigma2/python/Plugins/Extensions/YoureWatching/plugin.py'

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigInteger, ConfigYesNo, ConfigText, ConfigSelection, ConfigDirectory, getConfigListEntry
from enigma import eTimer, ePicLoad, iPlayableService
import os
import re
import io
import ssl
import json
import time
import sys
import threading
import gettext

# --- Python 2 & 3 Compatibility Layer ---
PY3 = sys.version_info[0] == 3

if PY3:
    import html
    def safe_unescape(text):
        if not text:
            return ""
        return html.unescape(text)
    from urllib.request import urlopen, Request
    from urllib.parse import quote, quote_plus
    def safe_str(val):
        if val is None:
            return ""
        return str(val)
else:
    try:
        from HTMLParser import HTMLParser
        hp = HTMLParser()
        def safe_unescape(text):
            if not text:
                return ""
            if isinstance(text, str):
                text = text.decode('utf-8', 'ignore')
            return hp.unescape(text)
    except Exception:
        import xml.sax.saxutils as saxutils
        def safe_unescape(text):
            if not text:
                return ""
            if isinstance(text, str):
                text = text.decode('utf-8', 'ignore')
            return saxutils.unescape(text, {"&quot;": '"', "&apos;": "'", "&#39;": "'"})
    from urllib2 import urlopen, Request
    from urllib import quote, quote_plus
    def safe_str(val):
        if val is None:
            return ""
        if isinstance(val, unicode):
            return val.encode('utf-8')
        return str(val)

PLUGIN_PATH = os.path.dirname(__file__)

def init_translations():
    try:
        gettext.bindtextdomain('yourewatching', os.path.join(PLUGIN_PATH, 'locale'))
        gettext.textdomain('yourewatching')
    except Exception:
        return None

def _(txt):
    try:
        t = gettext.dgettext('yourewatching', txt)
        if t == txt:
            t = gettext.gettext(txt)
        return t
    except Exception:
        return txt

init_translations()

try:
    from twisted.internet import reactor
except ImportError:
    reactor = None

AG_BACKDROP_AVAILABLE = False
BACKDROP_FOLDER = '/tmp/yourewatching/posters/'
get_search_title = None
checkBackdropExistence = None
AgbDB = None

try:
    from Components.Renderer.AglareBackdropX import BACKDROP_FOLDER as AG_BACKDROP_FOLDER, checkBackdropExistence as ag_check, get_search_title as ag_get_search_title, AgbDB as ag_db
    BACKDROP_FOLDER = AG_BACKDROP_FOLDER
    checkBackdropExistence = ag_check
    get_search_title = ag_get_search_title
    AgbDB = ag_db
    AG_BACKDROP_AVAILABLE = True
except ImportError:
    checkBackdropExistence = lambda x: os.path.exists(x) and os.path.getsize(x) > 10
    def get_search_title(title, shortdesc='', fulldesc=''):
        clean = re.sub(r'[^\w\s]', '', title)
        clean = re.sub(r'\s+', ' ', clean)
        return clean.strip()

if checkBackdropExistence is None:
    checkBackdropExistence = lambda x: os.path.exists(x) and os.path.getsize(x) > 10

USER_AGENT = 'Mozilla/5.0 (YoureWatching Enigma2)'
ssl_context = ssl._create_unverified_context()

_plugin_instance = None
_last_title = None
_last_time = 0

config.plugins.youreWatching = ConfigSubsection()
config.plugins.youreWatching.enabled = ConfigYesNo(default=True)
config.plugins.youreWatching.language = ConfigSelection(default='ar-SA', choices=[('ar-SA', _('Arabic')), ('en-US', _('English'))])
config.plugins.youreWatching.poster_path = ConfigDirectory(default=BACKDROP_FOLDER)
config.plugins.youreWatching.tmdb_key = ConfigText(default='911d7d0ade352ba2bd98c45c96a24cca', fixed_size=False)
config.plugins.youreWatching.popup_width = ConfigInteger(default=900, limits=(600, 1920))
config.plugins.youreWatching.popup_height = ConfigInteger(default=520, limits=(300, 1080))
config.plugins.youreWatching.popup_x = ConfigInteger(default=510, limits=(0, 1920))
config.plugins.youreWatching.popup_y = ConfigInteger(default=280, limits=(0, 1080))
config.plugins.youreWatching.popup_alpha = ConfigSelection(default='00', choices=[('00', _('100% Solid Black')), ('20', _('90%')), ('40', _('75%')), ('80', _('50%'))])
config.plugins.youreWatching.cache_days = ConfigSelection(default='7', choices=[('1', _('1 Day')), ('7', _('7 Days')), ('30', _('30 Days')), ('90', _('90 Days'))])
config.plugins.youreWatching.poster_quality = ConfigSelection(default='w500', choices=[('w300', _('Small')), ('w500', _('Medium')), ('original', _('4K Original'))])
config.plugins.youreWatching.title_font = ConfigInteger(default=38, limits=(20, 80))
config.plugins.youreWatching.plot_font = ConfigInteger(default=26, limits=(18, 60))

CACHE_DIR = '/tmp/yourewatching/cache/'
POSTER_DIR = None

def create_paths():
    global POSTER_DIR
    POSTER_DIR = config.plugins.youreWatching.poster_path.value
    if not os.path.exists(POSTER_DIR):
        os.makedirs(POSTER_DIR)
    if not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)

create_paths()

def clean_title(title):
    title = safe_unescape(title)
    patterns = [
        r'\b1080p\b', r'\b720p\b', r'\b2160p\b', r'\bx264\b', r'\bBluRay\b',
        r'\bWEBRip\b', r'\bWEB-DL\b', r'\bAAC\b', r'\bHDRip\b', r'\b\d{3,4}p\b',
        r'\[.*?\]', r'\(.*?\)'
    ]
    for p in patterns:
        title = re.sub(p, '', title, flags=re.I)
    title = re.sub(r'\s+', ' ', title)
    return title.strip()

def get_cache_path(title):
    return os.path.join(CACHE_DIR, '%s.json' % abs(hash(title)))

def load_from_cache(title):
    cache_file = get_cache_path(title)
    if not os.path.exists(cache_file):
        return None
    cache_expiry = int(config.plugins.youreWatching.cache_days.value) * 86400
    if time.time() - os.path.getmtime(cache_file) > cache_expiry:
        return None
    try:
        with io.open(cache_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def save_to_cache(title, data):
    cache_file = get_cache_path(title)
    try:
        with io.open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def translate_text(text, target_lang='ar'):
    if not text or len(text.strip()) < 5:
        return safe_unescape(text) if text else text
    try:
        text = safe_unescape(text)
        if not PY3 and isinstance(text, unicode):
            encoded_text = text.encode('utf-8')
        else:
            encoded_text = str(text)

        encoded = quote_plus(encoded_text.replace('\n', ' ').replace('&', ' and ')[:1800])
        url = 'https://translate.google.com/m?hl=%s&sl=auto&q=%s' % (target_lang, encoded)
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urlopen(req, context=ssl_context, timeout=8)
        data = response.read().decode('utf-8', errors='ignore')
        start = data.find('class="result-container">')
        if start == -1:
            return safe_unescape(text)
        start += len('class="result-container">')
        end = data.find('</div>', start)
        translated = data[start:end].strip()
        translated = translated.replace('&amp;', '&')
        return safe_unescape(translated)
    except Exception:
        return safe_unescape(text)

class YoureWatchingScreen(Screen):
    def __init__(self, session):
        self.session = session
        w = config.plugins.youreWatching.popup_width.value
        h = config.plugins.youreWatching.popup_height.value
        x = config.plugins.youreWatching.popup_x.value
        y = config.plugins.youreWatching.popup_y.value
        alpha = config.plugins.youreWatching.popup_alpha.value
        title_font = config.plugins.youreWatching.title_font.value
        plot_font = config.plugins.youreWatching.plot_font.value
        self.plot_x = 305
        self.plot_y = 215
        self.plot_w = 565
        self.plot_h = 220
        self.skin = '''
        <screen position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#%s000000" zPosition="10">
            <widget name="shadow_bg" position="0,0" size="%d,%d" backgroundColor="#%s000000" zPosition="-10" />
            <widget name="bg" position="0,0" size="%d,%d" backgroundColor="#%s000000" zPosition="-9" />
            <widget name="poster" position="25,25" size="250,415" alphatest="blend" zPosition="2" />
            <widget name="title" position="305,25" size="565,65" font="Regular;%d" foregroundColor="#ffffff" transparent="1" zPosition="2" />
            <widget name="rating" position="305,100" size="250,35" font="Regular;26" foregroundColor="#ffcc00" transparent="1" zPosition="2" />
            <widget name="classification" position="560,100" size="310,35" font="Regular;24" foregroundColor="#ffffff" halign="right" transparent="1" zPosition="2" />
            <widget source="session.Event_Now" render="Progress" position="305,145" size="565,10" borderWidth="0" foregroundColor="#00ff66" backgroundColor="#232936" transparent="0" zPosition="2">
                <convert type="EventTime">Progress</convert>
            </widget>
            <widget source="session.Event_Now" render="Label" position="305,168" size="280,30" font="Regular;20" foregroundColor="#949cb0" halign="left" transparent="1" zPosition="2">
                <convert type="EventTime">Remaining</convert>
                <convert type="RemainingToText">Detailed</convert>
            </widget>
            <widget source="session.Event_Now" render="Label" position="590,168" size="280,30" font="Regular;20" foregroundColor="#ffcc00" halign="right" transparent="1" zPosition="2">
                <convert type="EventTime">Remaining</convert>
                <convert type="RemainingToText">InMinutes</convert>
            </widget>
            <widget name="plot" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#d2d6e0" transparent="1" zPosition="2" />
            <widget name="developer" position="305,455" size="565,25" font="Regular;16" foregroundColor="#558a94a6" halign="right" transparent="1" zPosition="3" />
        </screen>
        ''' % (x, y, w, h, alpha, w, h, alpha, w, h, alpha, title_font, self.plot_x, self.plot_y, self.plot_w, self.plot_h, plot_font)

        Screen.__init__(self, session)
        self['shadow_bg'] = Label('')
        self['bg'] = Label('')
        self['poster'] = Pixmap()
        self['title'] = Label('')
        self['rating'] = Label('')
        self['classification'] = Label('')
        self['plot'] = Label('')
        self['developer'] = Label('Developed by: Ahmed Ibrahim & Shabah Net')

        self.poster_path = None
        self.full_plot = ''
        self.lines = []
        self.line_index = 0
        self.visible_lines_count = 0
        
        self.picload = ePicLoad()
        self.picload.PictureData.get().append(self.decodeFinished)
        
        self.scrollTimer = eTimer()
        try:
            self.scrollTimer.callback.append(self.scrollLinesLoop)
        except AttributeError:
            self.scrollTimer_conn = self.scrollTimer.timeout.connect(self.scrollLinesLoop)

    def updateContent(self, title, poster, rating, classification, class_color, plot):
        self['title'].setText(safe_unescape(title))
        if rating and 'N/A' not in rating:
            self['rating'].setText('Rating: ' + rating)
        else:
            self['rating'].setText('Rating: -')
            
        self['classification'].setText(classification)
        self.full_plot = safe_unescape(plot) if plot else 'No description available'
        self['plot'].setText(self.full_plot)

        self.poster_path = poster
        if self.poster_path and checkBackdropExistence(self.poster_path):
            self.loadPoster(self.poster_path)
        else:
            self['poster'].hide()
            
        self.initLineScrollEngine()

    def initLineScrollEngine(self):
        try:
            self.scrollTimer.stop()
        except Exception:
            pass

        words = self.full_plot.split()
        self.lines = []
        current_line = ''
        max_chars = int(self.plot_w / (config.plugins.youreWatching.plot_font.value * 0.55))
        for word in words:
            if len(current_line) + len(word) + 1 < max_chars:
                current_line += word + ' '
            else:
                self.lines.append(current_line.strip())
                current_line = word + ' '
        if current_line:
            self.lines.append(current_line.strip())
        self.line_index = 0
        self.visible_lines_count = int(self.plot_h / (config.plugins.youreWatching.plot_font.value + 6))
        if len(self.lines) > self.visible_lines_count:
            self.scrollTimer.start(3500, True)

    def scrollLinesLoop(self):
        if len(self.lines) <= self.visible_lines_count:
            return
        self.line_index += 1
        if self.line_index > len(self.lines) - self.visible_lines_count:
            self.line_index = 0
        current_view = self.lines[self.line_index:self.line_index + self.visible_lines_count]
        self['plot'].setText('\n'.join(current_view))
        self.scrollTimer.start(3500, True)

    def loadPoster(self, poster_path):
        if poster_path and os.path.exists(poster_path):
            try:
                size = self['poster'].instance.size()
                self.picload.setPara([size.width(), size.height(), 1, 1, False, 1, '#00000000'])
                self.picload.startDecode(poster_path)
            except Exception:
                pass

    def decodeFinished(self, picInfo=None):
        try:
            ptr = self.picload.getData()
            if ptr:
                self['poster'].instance.setPixmap(ptr)
                self['poster'].show()
        except Exception:
            pass

    def hideScreen(self):
        try:
            self.scrollTimer.stop()
        except Exception:
            pass
        self.hide()

class YoureWatchingController:
    def __init__(self, session):
        self.session = session
        self.dialog = None
        self.session.nav.event.append(self.event)
        
        self.check_infobar_timer = eTimer()
        try:
            self.check_infobar_timer.callback.append(self.attachInfoBarHooks)
        except AttributeError:
            self.check_infobar_timer_conn = self.check_infobar_timer.timeout.connect(self.attachInfoBarHooks)
        self.check_infobar_timer.start(500, False)

    def attachInfoBarHooks(self):
        from Screens.InfoBar import InfoBar
        if InfoBar.instance:
            self.check_infobar_timer.stop()
            if self.onInfoBarShow not in InfoBar.instance.onShow:
                InfoBar.instance.onShow.append(self.onInfoBarShow)
            if self.onInfoBarHide not in InfoBar.instance.onHide:
                InfoBar.instance.onHide.append(self.onInfoBarHide)

    def getDialog(self):
        if self.dialog is None:
            self.dialog = self.session.instantiateDialog(YoureWatchingScreen)
        return self.dialog

    def onInfoBarShow(self):
        if config.plugins.youreWatching.enabled.value:
            self.triggerFetch(force=True)

    def onInfoBarHide(self):
        if self.dialog:
            self.dialog.hideScreen()

    def event(self, ev):
        if not config.plugins.youreWatching.enabled.value:
            return
        
        from Screens.InfoBar import InfoBar
        if not InfoBar.instance or not getattr(InfoBar.instance, 'shown', False):
            self.onInfoBarHide()
            return

        if ev in (iPlayableService.evStart, iPlayableService.evUpdatedInfo):
            self.triggerFetch()

    def triggerFetch(self, force=False):
        global _last_time
        global _last_title
        
        from Screens.InfoBar import InfoBar
        if not InfoBar.instance or not getattr(InfoBar.instance, 'shown', False):
            self.onInfoBarHide()
            return

        service = self.session.nav.getCurrentService()
        if not service:
            return
        info = service.info()
        if not info:
            return
        event = info.getEvent(0)
        if not event:
            return
        raw_name = event.getEventName()
        title = safe_unescape(safe_str(raw_name)).strip()
        if len(title) < 2:
            return
        service_name = safe_unescape(safe_str(info.getName()).replace('Â\x86', '').replace('Â\x87', ''))
        short = safe_unescape(safe_str(event.getShortDescription() or ''))
        extended = safe_unescape(safe_str(event.getExtendedDescription() or ''))
        now = time.time()
        if not force and title == _last_title and (now - _last_time < 5):
            return
        _last_title = title
        _last_time = now
        threading.Thread(target=self.fetch, args=(title, service_name, short, extended)).start()

    def download_poster(self, poster_path, cache_key):
        quality = config.plugins.youreWatching.poster_quality.value
        img_url = 'https://image.tmdb.org/t/p/%s%s' % (quality, poster_path)
        poster_name = '%s.jpg' % abs(hash(cache_key))
        poster_full = os.path.join(POSTER_DIR, poster_name)
        if not os.path.exists(poster_full):
            try:
                r = urlopen(Request(img_url, headers={'User-Agent': USER_AGENT}), context=ssl_context, timeout=12)
                with open(poster_full, 'wb') as f:
                    f.write(r.read())
            except Exception:
                return
        
        from Screens.InfoBar import InfoBar
        if self.dialog and checkBackdropExistence(poster_full) and InfoBar.instance and getattr(InfoBar.instance, 'shown', False):
            self.dialog.poster_path = poster_full
            if reactor:
                reactor.callFromThread(self.dialog.loadPoster, poster_full)

    def fetch(self, title, channel, shortdesc, fulldesc):
        create_paths()
        lang = config.plugins.youreWatching.language.value
        chn_lower = channel.lower()
        adult_keywords = ['18', 'xxx', 'adult', 'pink', 'hustler', 'redlight', 'dorcel', 'private']
        if any(x in chn_lower for x in adult_keywords):
            if reactor:
                reactor.callFromThread(self.show, title, None, 'N/A', 'Adults Only (18+)', '#ff3333', translate_text(fulldesc or shortdesc or 'Adult content channel'))
            return

        search_title = get_search_title(title, shortdesc, fulldesc)
        if not search_title:
            search_title = clean_title(title)
        cache_key = search_title + channel
        desc = (shortdesc + ' ' + fulldesc).strip()
        poster_name = '%s.jpg' % abs(hash(cache_key))
        poster_file = os.path.join(POSTER_DIR, poster_name)
        poster = poster_file if checkBackdropExistence(poster_file) else None
        cached = load_from_cache(cache_key)

        try:
            if cached:
                item = cached
            else:
                if not PY3 and isinstance(search_title, unicode):
                    q_title = quote(search_title.encode('utf-8'))
                else:
                    q_title = quote(search_title)
                url = 'https://api.themoviedb.org/3/search/multi?api_key=%s&query=%s&language=%s' % (config.plugins.youreWatching.tmdb_key.value, q_title, lang)
                req = Request(url, headers={'User-Agent': USER_AGENT})
                response = urlopen(req, context=ssl_context, timeout=10)
                data = json.loads(response.read().decode('utf-8', errors='ignore'))
                if not data.get('results'):
                    if reactor:
                        reactor.callFromThread(self.show, title, None, 'N/A', 'General', '#00ff66', translate_text(desc or 'No description'))
                    return
                item = data['results'][0]
                save_to_cache(cache_key, item)

            display_title = safe_unescape(item.get('title') or item.get('name') or title)
            plot = safe_unescape(item.get('overview') or desc or 'No description available')
            rating_value = item.get('vote_average')
            rating = '%.1f/10' % rating_value if rating_value and rating_value > 0 else 'N/A'
            is_adult = item.get('adult', False)
            genre_ids = item.get('genre_ids', [])
            classification_text = 'Family'
            classification_color = '#00ff66'

            if is_adult or 10749 in genre_ids:
                classification_text = 'Adults Only (18+)'
                classification_color = '#ff3333'
            else:
                plot_lower = plot.lower()
                if any(word in plot_lower for word in ['horror', 'thriller', 'crime', 'violence', 'kill', 'murder', 'blood']):
                    classification_text = 'Parental Guidance'
                    classification_color = '#ffcc00'

            translated_plot = translate_text(plot)
            if reactor:
                reactor.callFromThread(self.show, display_title, poster, rating, classification_text, classification_color, translated_plot)

            if item.get('poster_path') and not poster:
                threading.Thread(target=self.download_poster, args=(item['poster_path'], cache_key)).start()

        except Exception:
            if reactor:
                reactor.callFromThread(self.show, title, None, 'N/A', 'General', '#00ff66', translate_text(desc or 'No description'))

    def show(self, title, poster, rating, classification, class_color, plot):
        from Screens.InfoBar import InfoBar
        if not InfoBar.instance or not getattr(InfoBar.instance, 'shown', False):
            self.onInfoBarHide()
            return
        
        try:
            dlg = self.getDialog()
            dlg.updateContent(title, poster, rating, classification, class_color, plot)
            dlg.show()
        except Exception:
            return None

    def stop(self):
        try:
            self.check_infobar_timer.stop()
            from Screens.InfoBar import InfoBar
            if InfoBar.instance:
                if self.onInfoBarShow in InfoBar.instance.onShow:
                    InfoBar.instance.onShow.remove(self.onInfoBarShow)
                if self.onInfoBarHide in InfoBar.instance.onHide:
                    InfoBar.instance.onHide.remove(self.onInfoBarHide)
            self.session.nav.event.remove(self.event)
            if self.dialog:
                self.dialog.hideScreen()
                self.dialog = None
        except Exception:
            return None

class YoureWatchingSetup(Screen, ConfigListScreen):
    skin = '''
    <screen position="center,center" size="840,680" title="You're Watching Settings" backgroundColor="#00101214" flags="wfNoBorder">
        <eLabel position="0,0" size="840,680" backgroundColor="#00101214" zPosition="-10" />
        <eLabel position="0,0" size="840,65" backgroundColor="#001c2024" zPosition="-1" />
        <widget name="title" position="20,15" size="500,40" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#001c2024" transparent="1" />
        <widget name="config" position="20,85" size="800,490" itemHeight="35" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="1" />
        <eLabel position="20,590" size="800,2" backgroundColor="#002c3238" />
        <eLabel position="40,612" size="180,35" backgroundColor="#009f2222" cornerRadius="6" zPosition="1" />
        <widget name="key_red" position="40,612" size="180,35" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#009f2222" transparent="1" zPosition="2" />
        <eLabel position="250,612" size="180,35" backgroundColor="#00229f43" cornerRadius="6" zPosition="1" />
        <widget name="key_green" position="250,612" size="180,35" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#00229f43" transparent="1" zPosition="2" />
    </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Save'))
        self['title'] = Label(_("You're Watching - Settings"))
        self.list = [
            getConfigListEntry(_('Enable Plugin'), config.plugins.youreWatching.enabled),
            getConfigListEntry(_('Language'), config.plugins.youreWatching.language),
            getConfigListEntry(_('Poster Path'), config.plugins.youreWatching.poster_path),
            getConfigListEntry(_('Cache Days'), config.plugins.youreWatching.cache_days),
            getConfigListEntry(_('Poster Quality'), config.plugins.youreWatching.poster_quality),
            getConfigListEntry(_('Popup Width'), config.plugins.youreWatching.popup_width),
            getConfigListEntry(_('Popup Height'), config.plugins.youreWatching.popup_height),
            getConfigListEntry(_('Popup X'), config.plugins.youreWatching.popup_x),
            getConfigListEntry(_('Popup Y'), config.plugins.youreWatching.popup_y),
            getConfigListEntry(_('Popup Transparency'), config.plugins.youreWatching.popup_alpha),
            getConfigListEntry(_('Title Font Size'), config.plugins.youreWatching.title_font),
            getConfigListEntry(_('Plot Font Size'), config.plugins.youreWatching.plot_font)
        ]
        ConfigListScreen.__init__(self, self.list)
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'cancel': self.close, 'red': self.close, 'save': self.saveConfig, 'green': self.saveConfig}, -1)

    def saveConfig(self):
        create_paths()
        for x in self['config'].list:
            if x[1] is not None:
                x[1].save()
        self.close()

def main(session, **kwargs):
    session.open(YoureWatchingSetup)

def autostart(reason, **kwargs):
    global _plugin_instance
    if reason == 0 and 'session' in kwargs:
        _plugin_instance = YoureWatchingController(kwargs['session'])
    elif reason == 1 and _plugin_instance:
        _plugin_instance.stop()
        _plugin_instance = None

def Plugins(**kwargs):
    return [
        PluginDescriptor(name="You're Watching", where=PluginDescriptor.WHERE_SESSIONSTART, fnc=autostart),
        PluginDescriptor(name="You're Watching Setup", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='plugin.png')
    ]