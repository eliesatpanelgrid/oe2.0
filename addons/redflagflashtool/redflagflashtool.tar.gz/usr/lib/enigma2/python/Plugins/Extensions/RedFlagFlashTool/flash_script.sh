#!/bin/sh
# RedFlag Online Flash Tool - Destek Scripti v2.1 (Gelişmiş İndirme Destekli)
# Parametreler: 1:SLOT, 2:DL_PATH, 3:URL_OR_PATH, 4:IMG_NAME, 5:USER_LANG

SLOT=$1
DL_PATH=$2
URL_OR_PATH=$3
IMG_NAME=$4
USER_LANG=$5

UA_STRING="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
CLEAN_IMG_NAME=$(echo "$IMG_NAME" | sed 's/_/ /g')

# --- ÇOKLU DİL MESAJLARI (Tüm diller senkronize edildi) ---
case $USER_LANG in
    "ar")
        M1="جاري تحضير الملفات..."
        M2="بدأت عملية التفليش. يرجى الانتظار..."
        M3="تمت العملية بنجاح."
        M4="الصورة المثبتة: $CLEAN_IMG_NAME"
        M5="فتحة التثبيت (Slot): Slot $SLOT"
        M6="يمكنك الآن الخروج بالضغط على زر EXIT وإعادة تشغيل الجهاز."
        M7="تم اكتشاف ملف zip كمصدر محلي."
        M8="فشل wget! جاري المحاولة باستخدام cURL كخيار بديل..."
        M9="تم اكتشاف رابط Dropbox، جاري تحويله لرابط مباشر..."
        E1="خطأ: لم يتم العثور على ملف imaj مضغوط!"
        E2="خطأ: لم يتم العثور على ملفات تثبيت صالحة داخل الملف المضغوط!"
        E3="خطأ: فشلت عملية تفليش وكتابة الصورة بواسطة ofgwrite!" ;;
    "fa")
        M1="در حال آماده‌سازی فایل‌ها..."
        M2="عملیات فلش آغاز شد. لطفاً منتظر بمانید..."
        M3="عملیات با موفقیت انجام شد."
        M4="ایمیج نصب شده: $CLEAN_IMG_NAME"
        M5="محل نصب (Slot): Slot $SLOT"
        M6="اکنون می‌توانید با دکمه EXIT خارج شده و دستگاه را راه‌اندازی مجدد کنید."
        M7="فایل zip منبع محلی شناسایی شد."
        M8="خطا در wget! تلاش مجدد با دستور cURL به عنوان پشتیبان..."
        M9="لینک Dropbox شناسایی شد، تبدیل به لینک دانلود مستقیم..."
        E1="خطا: فایل فشرده ایمیج یافت نشد!"
        E2="خطا: هیچ فایل ایمیج معتبری در فایل فشرده یافت نشد!"
        E3="خطا: عملیات نوشتن و فلش ایمیج توسط ofgwrite با شکست مواجه شد!" ;;
    "fr")
        M1="PRÉPARATION DES FICHIERS..."
        M2="FLASH EN COURS. VEUILLEZ PATIENTER..."
        M3="Opération terminée avec succès."
        M4="Image Installée: $CLEAN_IMG_NAME"
        M5="Emplacement du Slot: Slot $SLOT"
        M6="Vous pouvez maintenant quitter avec le bouton EXIT et redémarrer."
        M7="Fichier zip source locale détecté."
        M8="Échec de wget! Tentative avec cURL (Ligne de secours)..."
        M9="Lien Dropbox détecté, conversion en téléchargement direct..."
        E1="ERREUR: FICHIER ARCHIVE NON TROUVÉ!"
        E2="ERREUR: Aucune image valide trouvée dans le zip!"
        E3="ERREUR: L'écriture de l'image avec ofgwrite a échoué!" ;;
    "de")
        M1="DATEIEN WERDEN VORBEREITET..."
        M2="FLASH-VORGANG STARTET. BITTE WARTEN..."
        M3="Vorgang erfolgreich abgeschlossen."
        M4="Installiertes Image: $CLEAN_IMG_NAME"
        M5="Installiert auf Slot: Slot $SLOT"
        M6="Sie können nun mit der EXIT-Taste beenden und neu starten."
        M7="Lokale Quell-Zip-Datei erkannt."
        M8="wget fehlgeschlagen! Versuche es mit cURL als Backup..."
        M9="Dropbox-Link erkannt, konvertiere in Direkt-Download..."
        E1="FEHLER: IMAGE ZIP DATEI NICHT GEFUNDEN!"
        E2="FEHLER: Keine gültigen Image-Dateien im Zip gefunden!"
        E3="FEHLER: ofgwrite Flash-Vorgang ist fehlgeschlagen!" ;;
    "it")
        M1="PREPARAZIONE FILE IN CORSO..."
        M2="PROCESSO DI FLASH AVVIATO. ATTENDERE..."
        M3="Processo completato con successo."
        M4="Immagine Installata: $CLEAN_IMG_NAME"
        M5="Slot di Destinazione: Slot $SLOT"
        M6="Ora puoi uscire con il tasto EXIT e riavviare il dispositivo."
        M7="File zip sorgente locale rilevato."
        M8="wget fallito! Tentativo con cURL come linea di riserva..."
        M9="Link Dropbox rilevato, conversione in download diretto..."
        E1="ERRORE: FILE ZIP NON TROVATO!"
        E2="ERRORE: Nessun file immagine valido trovato nel file zip!"
        E3="ERRORE: Scrittura dell'immagine con ofgwrite fallita!" ;;
    "es")
        M1="PREPARANDO ARCHIVOS..."
        M2="PROCESO DE FLASH INICIADO. POR FAVOR ESPERE..."
        M3="Proceso finalizado con éxito."
        M4="Imagen Identificada: $CLEAN_IMG_NAME"
        M5="Ranura de Destino: Slot $SLOT"
        M6="Ahora puede salir con el botón EXIT y reiniciar el dispositivo."
        M7="Archivo zip de origen local detectado."
        M8="¡wget falló! Intentando con cURL como ruta de respaldo..."
        M9="Enlace de Dropbox detectado, convirtiendo a descarga directa..."
        E1="ERROR: ¡ARCHIVO ZIP NO ENCONTRADO!"
        E2="ERROR: ¡No se encontraron archivos de iamgen válidos en el zip!"
        E3="¡ERROR: El proceso de escritura con ofgwrite ha fallado!" ;;
    "en")
        M1="PREPARING FILES..."
        M2="FLASHING STARTED. PLEASE WAIT..."
        M3="Process finished successfully."
        M4="Installed Image: $CLEAN_IMG_NAME"
        M5="Flashing Target Slot: Slot $SLOT"
        M6="Now you can exit with the EXIT button and restart the device."
        M7="Local source zip file detected."
        M8="wget failed! Trying with cURL as a fallback line..."
        M9="Dropbox link detected, converting to direct download..."
        E1="ERROR: ZIP FILE NOT FOUND!"
        E2="ERROR: No valid image files found in zip!"
        E3="ERROR: ofgwrite flashing process failed!" ;;
    *) # Varsayılan Türkçe (tr)
        M1="DOSYALAR HAZIRLANIYOR..."
        M2="YAZMA ISLEMI BASLADI. LUTFEN BEKLEYIN..."
        M3="Islem basariyla bitti."
        M4="Kurulan İmaj: $CLEAN_IMG_NAME"
        M5="İmajin kurulduğu alan: Slot $SLOT"
        M6="Simdi EXIT tusu ile cikis yapabilir ve cihazi yeniden baslatabilirsiniz."
        M7="Yerel kaynak zip dosyasi algilandi."
        M8="wget basarisiz oldu! Yedek hat olarak cURL ile deneniyor..."
        M9="Dropbox linki algilandi, dogrudan indirme linkine donusturuluyor..."
        E1="HATA: İMAJ DOSYASI BULUNAMADI!"
        E2="HATA: Zip icinde gecerli imaj dosyalari bulunamadi!"
        E3="HATA: ofgwrite yazma islemi basarisiz oldu!" ;;
esac

TMP_EXTRACT="$DL_PATH/rf_temp"
rm -rf "$TMP_EXTRACT" > /dev/null 2>&1
mkdir -p "$TMP_EXTRACT"

URL_OR_PATH=$(echo "$URL_OR_PATH" | tr -d '"' | tr -d "'")

# Dropbox Link Optimizasyonu (?dl=0 -> ?dl=1)
if echo "$URL_OR_PATH" | grep -q "dropbox.com"; then
    if echo "$URL_OR_PATH" | grep -q "dl=0"; then
        echo "$M9"
        URL_OR_PATH=$(echo "$URL_OR_PATH" | sed 's/dl=0/dl=1/g')
    fi
fi

echo "======================================================="
echo "           REDFLAG ONLINE FLASH TOOL v2.1              "
echo "======================================================="
echo "IMAGE : $CLEAN_IMG_NAME"
echo "SLOT  : $SLOT"
echo "PATH  : $DL_PATH"
echo "-------------------------------------------------------"

echo "$M1"

# Giriş kaynağı doğrulaması
if [ -f "$URL_OR_PATH" ] && echo "$URL_OR_PATH" | grep -q "\.zip$"; then
    echo "$M7"
    ZIP_TO_USE="$URL_OR_PATH"
else
    ZIP_TO_USE="$DL_PATH/image.zip"
    if [ ! -f "$ZIP_TO_USE" ] || [ ! -s "$ZIP_TO_USE" ]; then
        if echo "$URL_OR_PATH" | grep -q "drive.google.com"; then
            FILE_ID=$(echo "$URL_OR_PATH" | sed -e 's/.*\/\(d\|file\/d\)\/\([^\/]*\).*/\2/' -e 's/[?&].*//')
            COOKIE_FILE="/tmp/cookies.txt"
            CONFIRM=$(wget --quiet --save-cookies $COOKIE_FILE --keep-session-cookies --no-check-certificate "https://docs.google.com/uc?export=download&id=$FILE_ID" -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')
            
            # Google Drive için wget denemesi
            wget --load-cookies $COOKIE_FILE --trust-server-names --user-agent="$UA_STRING" "https://docs.google.com/uc?export=download&confirm=$CONFIRM&id=$FILE_ID" -O "$ZIP_TO_USE"
            WGET_RES=$?
            rm -f $COOKIE_FILE
            
            # Google Drive'da wget başarısız olursa curl yedek devrede
            if [ $WGET_RES -ne 0 ] || [ ! -s "$ZIP_TO_USE" ]; then
                echo "$M8"
                curl -L -k -A "$UA_STRING" "https://docs.google.com/uc?export=download&confirm=$CONFIRM&id=$FILE_ID" -o "$ZIP_TO_USE"
            fi
        else
            # Standart sunucular için ana indirme (wget)
            wget --no-check-certificate --trust-server-names --user-agent="$UA_STRING" "$URL_OR_PATH" -O "$ZIP_TO_USE"
            WGET_RES=$?
            
            # BAŞARISIZLIK DURUMU: wget hata verdi veya dosya 0 byte indiyse cURL tetiklenir
            if [ $WGET_RES -ne 0 ] || [ ! -s "$ZIP_TO_USE" ]; then
                echo "$M8"
                rm -f "$ZIP_TO_USE" > /dev/null 2>&1
                curl -L -k -A "$UA_STRING" "$URL_OR_PATH" -o "$ZIP_TO_USE"
            fi
        fi
    fi
fi

# Decompress ve Flashing
if [ -f "$ZIP_TO_USE" ] && [ -s "$ZIP_TO_USE" ]; then
    echo "Unzipping..."
    unzip -o "$ZIP_TO_USE" -d "$TMP_EXTRACT" > /dev/null 2>&1
    
    PATH_REAL=$(find "$TMP_EXTRACT" -name "kernel.bin" -exec dirname {} \; | head -n 1)
    [ -z "$PATH_REAL" ] && PATH_REAL=$(find "$TMP_EXTRACT" -name "rootfs.tar.bz2" -exec dirname {} \; | head -n 1)

    if [ -d "$PATH_REAL" ]; then
        echo "$M2"
        ofgwrite -r -k -m$SLOT "$PATH_REAL/" 2>/dev/null
        FLASH_RESULT=$?
        
        if [ $FLASH_RESULT -eq 0 ]; then
            echo "-------------------------------------------------------"
            echo "$M3"
            echo "$M4"
            echo "$M5"
            echo "-------------------------------------------------------"
            echo "$M6"
        else
            echo "$E3"
            rm -rf "$TMP_EXTRACT" > /dev/null 2>&1
            exit 1
        fi
    else
        echo "$E2"
        rm -rf "$TMP_EXTRACT" > /dev/null 2>&1
        exit 1
    fi
else
    echo "$E1"
    rm -rf "$TMP_EXTRACT" > /dev/null 2>&1
    exit 1
fi

rm -rf "$TMP_EXTRACT" > /dev/null 2>&1
exit 0
