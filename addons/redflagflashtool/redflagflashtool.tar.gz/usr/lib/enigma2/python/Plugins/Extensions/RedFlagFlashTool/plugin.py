# -*- coding: utf-8 -*-
import os
import requests
import time
import sys
import json
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, RT_HALIGN_CENTER
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Language import language
from Components.ScrollLabel import ScrollLabel
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.SystemInfo import BoxInfo

PY3 = sys.version_info.major >= 3
ICON_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/RedFlagFlashTool/icons/"
ICON_CACHE = {}

KNOWN_MODELS = ["vuzero", "vuzero4k", "vusolo", "vusolo2", "vusolose", "vusolo4k", "vuduo", "vuduo2", "vuduo4k", "vuduo4kse", "vuuno", "vuuno4k", "vuuno4kse", "vuultimo", "vuultimo4k", "qviartlunix", "qviartlunix3", "qviartlunix4k", "qviartdual", "sf8008", "sf8008m", "sf4008", "sf3038", "sx88", "gbquad4k", "gbue4k", "gbtrio4k", "gbtrio4kpro", "gbquad", "gbultraue", "h7", "h9combo", "h9twin", "h9s", "h11s", "h10", "h8k", "hd51", "osmini", "osmio4k", "osmio4kplus", "multibox", "multiboxpro", "ustym4kpro", "pulse4k", "pulse4kmini", "novaler4k", "novaler4kpro", "viper4k", "zgemma"]

FIRMWARE_SERVERS = [
    ("OpenPLi", "http://downloads.openpli.org/json/", True),
    ("OpenATV", "https://images.mynonpublic.com/openatv/json/", True),
    ("OpenViX", "https://www.openvix.co.uk/json/", True),
    ("OpenBH", "https://images.openbh.net/json/", True),
    ("OpenSPA", "https://openspa.webhop.info/online/json.php?box=", True),    
    ("OpenHDF", "https://flash.hdfreaks.cc/openhdf/json/", True),
    ("PurE2", "https://www.pur-e2.club/OU/images/json/", True),    
    ("OpenVision","https://images.openvision.dedyn.io/json/", True),
]

UA_STRING = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def get_language():
    return language.getLanguage()[:2]

currL = get_language()

LANG_DICT = {
    "tr": {
        "p_name": "RedFlag Flaş Aracı", "p_desc": "Akıllı İmaj Kurulum Aracı", "title": "RedFlag Flaş Aracı v3.0",
        "m_servers": "Popüler İmajlar (Ekip seçerek)", "m_other_sources": "Genişletilmiş Tarama (İmaj arama)", 
        "m1": "Lokal Liste (Images dosyanızdan)", "m_rf_repo": "RedFlag Arşivi (Github Deposundan)",  
        "m_search": "Yazarak Arama", "search_title": "Model adını yazın:", 
        "m2": "Otomatik Cihaz Saptamayla", "m3": "Cihaz Modeli Seçerek", 
        "m5": "Yerel Dosyalar (Cihazdaki imajlar)", "m4": "Hakkında / Bilgi",
        "m_back_btn": "■ Geri Dön (Mavi Tuş)",
        "src": "Bir dosya kaynağı seçin veya bilgi alın", "loading": "Tüm sunucular ve web siteleri taranıyor...",
        "slot_q": "İmajın kurulacağı slotu seçin", "done": "Kurulum tamamlandı. İndirilen zip dosyası silinsin mi?",
        "info": "Yöntem: %s | Model: %s | İmaj: %d adet\nDizin: %s", "mod_sel": "Cihaz seçiniz",
        "err_gh": "HATA: Model listesi alınamadı!", "err_no_mod": "HATA: Bu model için sunucularda imaj bulunamadı!",
        "err_corrupted": "HATA: Dosya geçersiz veya çok küçük!", "help_title": "RedFlag Yardım Bilgileri",
        "settings": "Ayarlar", "console_done": "IMAJ DOSYASI INDIRILDI\\nKURULUM SECIMI ICIN OK TUSU ILE CIKIN.",
        "msg_decision": "İndirme işlemi tamamlandı.\nİmaj kurulumuna devam etmek istiyor musunuz?",
        "err_no_txt": "Dosya /home/Images.txt bulunamadı!", "h_hdd": "HDD İÇİNDEKİLER", "h_images": "IMAGES İÇİNDEKİLER",
        "err_no_zip": "Uyumlu .zip imajı bulunamadı!", "err_server": "SUNUCU HATASI: Kod %s", "err_conn": "BAĞLANTI HATASI!",
        "st_show_main": "Ana Menüde Göster", "st_save_info": "Kaydetmek için OK, çıkmak için CANCEL",
        "msg_saved": "İmaj dosyası başarıyla kaydedildi:", "err_read_txt": "HATA: Read.txt bulunamadı!",
        "w_fallback": "UYARI: wget basarisiz oldu, cURL devralacak!",
        "st_search_mode": "Arama Kaynağı:", "st_mode_teams": "Popüler İmajlar",
        "st_mode_other": "Çoklu Kaynaklar", "st_mode_all": "Tüm Kaynaklar",
        "t_servers": "Popüler İmajlar", "t_other_sources": "İmaj Arama", "t_local": "Lokal Liste", "t_rf_repo": "Arşiv", "t_mod_sel": "Cihaz Seçimi", "t_help": "Yardım", "t_settings": "Ayarlar", "t_main": "İmaj Listesi", "t_slot": "Slot Seçimi",
        "t_local_zips": "Yerel Dosyalar", "t_auto": "Otomatik Saptama", "t_manual": "Manuel Seçim"
    },
    "en": {
        "p_name": "RedFlag Flash Tool", "p_desc": "Smart Image Installer Tool", "title": "RedFlag Flash Tool v3.0",
        "m_servers": "Popular Images (By Team)", "m_other_sources": "Extended Scan (Image search)",
        "m1": "Local List (From Images file)", "m_rf_repo": "RedFlag Archive (From Github Repo)", 
        "m_search": "Search by Typing", "search_title": "Enter model name:", 
        "m2": "Auto Device Detection", "m3": "Manual Model Selection", 
        "m5": "Local Files (Zips on device)", "m4": "About / Info",
        "m_back_btn": "■ Back (Blue Key)",
        "src": "Select a source or get info", "loading": "Scanning all servers and websites...",
        "slot_q": "Select the slot to flash the image", "done": "Flashing completed. Delete downloaded zip?",
        "info": "Mode: %s | Model: %s | Images: %d\nPath: %s", "mod_sel": "Select Device",
        "err_gh": "ERROR: Could not fetch model list!", "err_no_mod": "ERROR: No images found on servers!",
        "err_corrupted": "ERROR: File is invalid or too small!", "help_title": "RedFlag Help Info",
        "settings": "Settings", "console_done": "IMAGE FILE DOWNLOADED\\nEXIT WITH OK TO CHOOSE INSTALLATION.",
        "msg_decision": "Download completed.\nDo you want to continue with flashing?",
        "err_no_txt": "File /home/Images.txt not found!", "h_hdd": "HDD CONTENTS", "h_images": "IMAGES CONTENTS",
        "err_no_zip": "No compatible .zip image found!", "err_server": "SERVER ERROR: Code %s", "err_conn": "CONNECTION ERROR!",
        "st_show_main": "Show in Main Menu", "st_save_info": "Press OK to save, CANCEL to exit",
        "msg_saved": "Image file saved successfully:", "err_read_txt": "ERROR: Read.txt not found!",
        "w_fallback": "WARNING: wget failed, cURL will take over!",
        "st_search_mode": "Search Source:", "st_mode_teams": "Popular Images",
        "st_mode_other": "Multi-source", "st_mode_all": "All Sources",
        "t_servers": "Popular Images", "t_other_sources": "Image Search", "t_local": "Local List", "t_rf_repo": "Archive", "t_mod_sel": "Device Selection", "t_help": "Help", "t_settings": "Settings", "t_main": "Image List", "t_slot": "Slot Selection",
        "t_local_zips": "Local Files", "t_auto": "Auto Detection", "t_manual": "Manual Selection"
    },
    "ar": {
        "p_name": "أداة RedFlag", "p_desc": "أداة ذكية لتثبيت الصور", "title": "أداة RedFlag v3.0",
        "m_servers": "صور شهيرة (حسب الفريق)", "m_other_sources": "فحص موسع (بحث عن صور)",
        "m1": "قائمة محلية (من ملف الصور)", "m_rf_repo": "أرشيف RedFlag (من مستودع Github)", 
        "m_search": "بحث بالكتابة", "search_title": "اكتب الموديل:", 
        "m2": "كشف تلقائي للجهاز", "m3": "اختر الموديل يدويّاً", 
        "m5": "ملفات محلية (على الجهاز)", "m4": "معلومات / عن الأداة",
        "m_back_btn": "■ رجوع (الزر الأزرق)",
        "src": "اختر مصدراً أو احصل على معلومات", "loading": "جاري فحص الخوادم والمواقع...",
        "slot_q": "اختر الفتحة (Slot) للتثبيت", "done": "اكتمل التثبيت. هل تريد حذف ملف zip؟",
        "info": "الوضع: %s | الموديل: %s | الصور: %d\nالمسار: %s", "mod_sel": "اختر الجهاز",
        "err_gh": "خطأ: تعذر جلب قائمة الموديلات!", "err_no_mod": "خطأ: لم يتم العثور على صور في الخوادم!",
        "err_corrupted": "خطأ: الملف تالف أو صغير جداً!", "help_title": "معلومات المساعدة",
        "settings": "الإعدادات", "console_done": "تم تحميل الملف\\nاضغط OK للمتابعة.",
        "msg_decision": "اكتمل التحميل.\nهل تريد متابعة التفليش؟",
        "err_no_txt": "الملف /home/Images.txt غير موجود!", "h_hdd": "محتويات HDD", "h_images": "محتويات IMAGES",
        "err_no_zip": "لم يتم العثور على ملف zip!", "err_server": "خطأ في الخادم: %s", "err_conn": "خطأ في الاتصال!",
        "st_show_main": "إظهار في القائمة الرئيسية", "st_save_info": "اضغط OK للحفظ، و CANCEL للخروج",
        "msg_saved": "تم حفظ ملف الصورة بنجاح:", "err_read_txt": "خطأ: لم يتم العثور على ملف Read.txt!",
        "w_fallback": "تحذير: فشل wget، سيتولى cURL المهمة!",
        "st_search_mode": "مصدر البحث:", "st_mode_teams": "صور شهيرة",
        "st_mode_other": "مصادر متعددة", "st_mode_all": "جميع المصادر",
        "t_servers": "صور شهيرة", "t_other_sources": "بحث عن صور", "t_local": "قائمة محلية", "t_rf_repo": "الأرشيف", "t_mod_sel": "اختيار الجهاز", "t_help": "مساعدة", "t_settings": "الإعدادات", "t_main": "قائمة الصور", "t_slot": "اختيار الفتحة",
        "t_local_zips": "ملفات محلية", "t_auto": "كشف تلقائي", "t_manual": "اختيار يدوي"
    },
    "fa": {
        "p_name": "ابزار RedFlag", "p_desc": "ابزار هوشمند نصب ایمیج", "title": "ابزار فلش RedFlag v3.0",
        "m_servers": "ایمیج‌های محبوب (انتخاب تیم)", "m_other_sources": "اسکن گسترده (جستجوی ایمیج)",
        "m1": "لیست محلی (از فایل ایمیج‌ها)", "m_rf_repo": "آرشیو RedFlag (از مخزن Github)", 
        "m_search": "جستجو با تایپ", "search_title": "نام مدل:", 
        "m2": "تشخیص خودکار دستگاه", "m3": "انتخاب دستی مدل", 
        "m5": "فایل‌های محلی (روی دستگاه)", "m4": "اطلاعات / درباره",
        "m_back_btn": "■ بازگشت (کلید آبی)",
        "src": "یک منبع انتخاب کنید یا اطلاعات بگیرید", "loading": "در حال بررسی سرورها و وب‌سایت‌ها...",
        "slot_q": "اسلات نصب را انتخاب کنید", "done": "نصب تمام شد. فایل zip حذف شود؟",
        "info": "حالت: %s | مدل: %s | ایمیج: %d\nمسیر: %s", "mod_sel": "دستگاه را انتخاب کنید",
        "err_gh": "خطا: لیست مدل‌ها دریافت نشد!", "err_no_mod": "خطا: ایمیجی در سرورها یافت نشد!",
        "err_corrupted": "خطا: فایل خراب یا خیلی کوچک است!", "help_title": "راهنمای RedFlag",
        "settings": "تنظیمات", "console_done": "فایل دانلود شد\\nبرای انتخاب نصب OK بزنید.",
        "msg_decision": "دانلود تمام شد.\nادامه به نصب؟",
        "err_no_txt": "فایل /home/Images.txt یافت نشد!", "h_hdd": "محتویات HDD", "h_images": "محتویات IMAGES",
        "err_no_zip": "فایل .zip سازگار یافت نشد!", "err_server": "خطای سرور: %s", "err_conn": "خطای اتصال!",
        "st_show_main": "نمایش در منوی اصلی", "st_save_info": "برای ذخیره OK و برای خروج CANCEL",
        "msg_saved": "فایل ایمیج ذخیره شد:", "err_read_txt": "خطا: فایل Read.txt یافت نشد!",
        "w_fallback": "هشدار: wget ناموفق بود، cURL تحویل گرفت!",
        "st_search_mode": "منبع جستجو:", "st_mode_teams": "ایمیج‌های محبوب",
        "st_mode_other": "چند منبعی", "st_mode_all": "تمام منابع",
        "t_servers": "ایمیج‌های محبوب", "t_other_sources": "جستجوی ایمیج", "t_local": "لیست محلی", "t_rf_repo": "آرشیو", "t_mod_sel": "انتخاب دستگاه", "t_help": "راهنما", "t_settings": "تنظیمات", "t_main": "لیست ایمیج‌ها", "t_slot": "انتخاب اسلات",
        "t_local_zips": "فایل‌های محلی", "t_auto": "تشخیص خودکار", "t_manual": "انتخاب دستی"
    },
    "de": {
        "p_name": "RedFlag Flash Tool", "p_desc": "Intelligentes Flash-Tool", "title": "RedFlag Flash Tool v3.0",
        "m_servers": "Beliebte Images (Nach Team)", "m_other_sources": "Erweiterter Scan (Image Suche)",
        "m1": "Lokale Liste (Aus Images-Datei)", "m_rf_repo": "RedFlag Archiv (Von Github Repo)", 
        "m_search": "Suche durch Tippen", "search_title": "Modellname eingeben:", 
        "m2": "Auto-Geräteerkennung", "m3": "Manuelle Modellauswahl", 
        "m5": "Lokale Dateien (Zips auf Gerät)", "m4": "Über / Info",
        "m_back_btn": "■ Zurück (Blaue Taste)",
        "src": "Quelle wählen oder Info abrufen", "loading": "Durchsuche Server und Websites...",
        "slot_q": "Wählen Sie den Slot für das Image", "done": "Flashen beendet. Heruntergeladene Zip löschen?",
        "info": "Modus: %s | Modell: %s | Images: %d\nPfad: %s", "mod_sel": "Gerät wählen",
        "err_gh": "FEHLER: Modellliste konnte nicht geladen werden!", "err_no_mod": "FEHLER: Keine Images auf Servern gefunden!",
        "err_corrupted": "FEHLER: Datei ungültig oder zu klein!", "help_title": "RedFlag Hilfe Info",
        "settings": "Einstellungen", "console_done": "IMAGE HERUNTERGELADEN\\nMIT OK BEENDEN.",
        "msg_decision": "Download abgeschlossen.\nMöchten Sie mit dem Flashen fortfahren?",
        "err_no_txt": "Datei /home/Images.txt nicht gefunden!", "h_hdd": "HDD INHALT", "h_images": "IMAGES INHALT",
        "err_no_zip": "Kein kompatibles .zip Image gefunden!", "err_server": "SERVER FEHLER: Code %s", "err_conn": "VERBINDUNGSFEHLER!",
        "st_show_main": "Im Hauptmenü zeigen", "st_save_info": "OK zum Speichern, CANCEL zum Beenden",
        "msg_saved": "Image erfolgreich gespeichert:", "err_read_txt": "FEHLER: Read.txt nicht gefunden!",
        "w_fallback": "WARNUNG: wget fehlgeschlagen, cURL übernimmt!",
        "st_search_mode": "Suchquelle:", "st_mode_teams": "Beliebte Images",
        "st_mode_other": "Multi-Source", "st_mode_all": "Alle Quellen",
        "t_servers": "Beliebte Images", "t_other_sources": "Image Suche", "t_local": "Lokale Liste", "t_rf_repo": "Archiv", "t_mod_sel": "Geräteauswahl", "t_help": "Hilfe", "t_settings": "Einstellungen", "t_main": "Image-Liste", "t_slot": "Slot-Auswahl",
        "t_local_zips": "Lokale Dateien", "t_auto": "Auto-Erkennung", "t_manual": "Manuelle Auswahl"
    },
    "fr": {
        "p_name": "RedFlag Flash Tool", "p_desc": "Outil d'installation intelligent", "title": "RedFlag Flash Tool v3.0",
        "m_servers": "Images Populaires (Par Équipe)", "m_other_sources": "Scan Étendu (Recherche d'image)",
        "m1": "Liste Locale (Depuis Images.txt)", "m_rf_repo": "Archive RedFlag (Depuis Github)", 
        "m_search": "Recherche par frappe", "search_title": "Nom du modèle:", 
        "m2": "Détection Auto", "m3": "Sélection Manuelle", 
        "m5": "Fichiers Locaux (Zips sur l'appareil)", "m4": "À propos / Info",
        "m_back_btn": "■ Retour (Touche Bleue)",
        "src": "Sélectionnez une source ou des infos", "loading": "Analyse des serveurs et sites Web...",
        "slot_q": "Sélectionnez le slot pour flasher", "done": "Installation terminée. Supprimer le zip ?",
        "info": "Mode: %s | Modèle: %s | Images: %d\nChemin: %s", "mod_sel": "Sélectionnez l'appareil",
        "err_gh": "ERREUR: Impossible de récupérer les modèles!", "err_no_mod": "ERREUR: Aucune image sur les serveurs!",
        "err_corrupted": "ERREUR: Fichier invalide ou trop petit!", "help_title": "Info Aide RedFlag",
        "settings": "Réglages", "console_done": "IMAGE TÉLÉCHARGÉE\\nQUITTER AVEC OK.",
        "msg_decision": "Téléchargement terminé.\nVoulez-vous continuer le flashage?",
        "err_no_txt": "Fichier /home/Images.txt introuvable!", "h_hdd": "CONTENU HDD", "h_images": "CONTENU IMAGES",
        "err_no_zip": "Aucune image .zip compatible trouvée!", "err_server": "ERREUR SERVEUR: Code %s", "err_conn": "ERREUR DE CONNEXION!",
        "st_show_main": "Afficher dans le Menu Principal", "st_save_info": "OK pour sauvegarder, CANCEL pour quitter",
        "msg_saved": "Image sauvegardée avec succès:", "err_read_txt": "ERREUR: Read.txt introuvable!",
        "w_fallback": "ATTENTION: wget a échoué, cURL prend le relais!",
        "st_search_mode": "Source de Recherche:", "st_mode_teams": "Images Populaires",
        "st_mode_other": "Multi-sources", "st_mode_all": "Toutes Sources",
        "t_servers": "Images Populaires", "t_other_sources": "Recherche", "t_local": "Liste Locale", "t_rf_repo": "Archive", "t_mod_sel": "Sélection d'appareil", "t_help": "Aide", "t_settings": "Réglages", "t_main": "Liste des images", "t_slot": "Sélection du slot",
        "t_local_zips": "Fichiers Locaux", "t_auto": "Détection Auto", "t_manual": "Sélection Manuelle"
    },
    "it": {
        "p_name": "RedFlag Flash Tool", "p_desc": "Strumento di flash intelligente", "title": "RedFlag Flash Tool v3.0",
        "m_servers": "Immagini Popolari (Per Team)", "m_other_sources": "Scansione Estesa (Ricerca Immagine)",
        "m1": "Lista Locale (Da file Images)", "m_rf_repo": "Archivio RedFlag (Da Github)", 
        "m_search": "Ricerca digitando", "search_title": "Nome modello:", 
        "m2": "Rilevamento Auto", "m3": "Selezione Manuale", 
        "m5": "File Locali (Zip sul dispositivo)", "m4": "Info / Riguardo",
        "m_back_btn": "■ Indietro (Tasto Blu)",
        "src": "Seleziona una fonte o informazioni", "loading": "Scansione server e siti web...",
        "slot_q": "Seleziona lo slot per il flash", "done": "Installazione completata. Eliminare lo zip?",
        "info": "Modalità: %s | Modello: %s | Immagini: %d\nPercorso: %s", "mod_sel": "Seleziona Dispositivo",
        "err_gh": "ERRORE: Impossibile recuperare i modelli!", "err_no_mod": "ERRORE: Nessuna immagine sui server!",
        "err_corrupted": "ERRORE: File non valido o troppo piccolo!", "help_title": "Info Aiuto RedFlag",
        "settings": "Impostazioni", "console_done": "IMMAGINE SCARICATA\\nUSCIRE CON OK.",
        "msg_decision": "Download completato.\nVuoi procedere con il flash?",
        "err_no_txt": "File /home/Images.txt non trovato!", "h_hdd": "CONTENUTO HDD", "h_images": "CONTENUTO IMAGES",
        "err_no_zip": "Nessuna immagine .zip compatibile!", "err_server": "ERRORE SERVER: Codice %s", "err_conn": "ERRORE DI CONNESSIONE!",
        "st_show_main": "Mostra nel Menu Principale", "st_save_info": "OK per salvare, CANCEL per uscire",
        "msg_saved": "Immagine salvata con successo:", "err_read_txt": "ERRORE: Read.txt non trovato!",
        "w_fallback": "ATTENZIONE: wget fallito, subentra cURL!",
        "st_search_mode": "Fonte Ricerca:", "st_mode_teams": "Immagini Popolari",
        "st_mode_other": "Multi-fonte", "st_mode_all": "Tutte le Fonti",
        "t_servers": "Immagini Popolari", "t_other_sources": "Ricerca", "t_local": "Lista Locale", "t_rf_repo": "Archivio", "t_mod_sel": "Selezione Dispositivo", "t_help": "Aiuto", "t_settings": "Impostazioni", "t_main": "Lista Immagini", "t_slot": "Selezione Slot",
        "t_local_zips": "File Locali", "t_auto": "Rilevamento Auto", "t_manual": "Selezione Manuale"
    },
    "es": {
        "p_name": "RedFlag Flash Tool", "p_desc": "Herramienta de flash inteligente", "title": "RedFlag Flash Tool v3.0",
        "m_servers": "Imágenes Populares (Por Equipo)", "m_other_sources": "Escaneo Extendido (Búsqueda de imagen)",
        "m1": "Lista Local (Desde archivo Images)", "m_rf_repo": "Archivo RedFlag (Desde Github)", 
        "m_search": "Búsqueda por texto", "search_title": "Nombre modelo:", 
        "m2": "Detección Automática", "m3": "Selección Manual", 
        "m5": "Archivos Locales (Zips en dispositivo)", "m4": "Acerca de / Info",
        "m_back_btn": "■ Atrás (Botón Azul)",
        "src": "Seleccione una fuente u obtenga información", "loading": "Escaneando servidores y sitios web...",
        "slot_q": "Seleccione el slot para el flash", "done": "Instalación completada. ¿Borrar el zip?",
        "info": "Modo: %s | Modelo: %s | Imágenes: %d\nRuta: %s", "mod_sel": "Seleccione Dispositivo",
        "err_gh": "ERROR: ¡No se pudo obtener la lista de modelos!", "err_no_mod": "ERROR: ¡No se encontraron imágenes!",
        "err_corrupted": "ERROR: ¡Archivo no válido o demasiado pequeño!", "help_title": "Info Ayuda RedFlag",
        "settings": "Ajustes", "console_done": "IMAGEN DESCARGADA\\nSALIR CON OK.",
        "msg_decision": "Descarga completada.\n¿Desea continuar con el flash?",
        "err_no_txt": "¡Archivo /home/Images.txt no encontrado!", "h_hdd": "CONTENIDO HDD", "h_images": "CONTENIDO IMAGES",
        "err_no_zip": "¡No se encontró ninguna imagen .zip!", "err_server": "ERROR SERVIDOR: Código %s", "err_conn": "¡ERROR DE CONEXIÓN!",
        "st_show_main": "Mostrar en Menú Principal", "st_save_info": "OK para guardar, CANCEL para salir",
        "msg_saved": "Imagen guardada con éxito:", "err_read_txt": "ERROR: ¡Read.txt no encontrado!",
        "w_fallback": "ADVERTENCIA: wget falló, ¡cURL se encargará!",
        "st_search_mode": "Fuente de Búsqueda:", "st_mode_teams": "Imágenes Populares",
        "st_mode_other": "Múltiples Fuentes", "st_mode_all": "Todas las Fuentes",
        "t_servers": "Imágenes Populares", "t_other_sources": "Búsqueda", "t_local": "Lista Local", "t_rf_repo": "Archivo", "t_mod_sel": "Selección de Dispositivo", "t_help": "Ayuda", "t_settings": "Ajustes", "t_main": "Lista de Imágenes", "t_slot": "Selección de Slot",
        "t_local_zips": "Archivos Locales", "t_auto": "Detección Automática", "t_manual": "Selección Manual"
    }
}

L = LANG_DICT.get(currL, LANG_DICT["en"])

config.plugins.redflag = ConfigSubsection()
config.plugins.redflag.show_in_mainmenu = ConfigYesNo(default=True) 
config.plugins.redflag.search_mode = ConfigSelection(
    default="all",
    choices=[
        ("teams", L.get("st_mode_teams")),
        ("other", L.get("st_mode_other")),
        ("all", L.get("st_mode_all"))
    ]
)

def _fetch_json(url):
    try:
        res = requests.get(url, headers={'User-Agent': UA_STRING}, timeout=7, verify=False)
        if res.status_code == 200:
            try: return res.json()
            except: return json.loads(res.text)
    except: pass
    return None

def _normalize_images(raw):
    if raw is None: return {}
    result = {}
    if isinstance(raw, dict):
        all_str_vals = all(isinstance(v, str) for v in raw.values())
        if all_str_vals:
            images = {}
            for k, v in raw.items():
                if str(v).startswith("http"): images[k] = {"link": str(v), "name": str(k)}
            if images: result["Images"] = images
            return result
        for cat, entries in raw.items():
            if not isinstance(entries, dict): continue
            result.setdefault(cat, {})
            for img_key, img_val in entries.items():
                if isinstance(img_val, dict):
                    link = img_val.get("link", img_val.get("url", ""))
                    name = img_val.get("name", img_key)
                    if link: result[cat][img_key] = {"link": str(link), "name": str(name)}
                elif isinstance(img_val, str) and str(img_val).startswith("http"):
                    result[cat][img_key] = {"link": str(img_val), "name": str(img_key)}
        return result
    if isinstance(raw, list):
        images = {}
        for item in raw:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                name = str(item[0]).strip()
                link = str(item[-1]).strip()
                if link.startswith("http"): images[name] = {"link": link, "name": name}
            elif isinstance(item, dict):
                name = item.get("name", item.get("title", item.get("label", "")))
                link = item.get("link", item.get("url", item.get("download", "")))
                if name and link and str(link).startswith("http"):
                    images[str(name).strip()] = {"link": str(link).strip(), "name": str(name).strip()}
        if images: result["Images"] = images
        return result
    return {}

def get_cached_icon(icon_path):
    if icon_path not in ICON_CACHE:
        if icon_path and os.path.exists(icon_path): ICON_CACHE[icon_path] = LoadPixmap(icon_path)
        else: ICON_CACHE[icon_path] = None
    return ICON_CACHE[icon_path]

def safe_str(text):
    if text is None: return ""
    if PY3: return str(text)
    else:
        if isinstance(text, type(u'')): return text.encode('utf-8')
        return str(text)

def normalize_str(text):
    s = safe_str(text)
    return "".join(c for c in s.lower() if c.isalnum())

def is_valid_for_model(model, text_to_check):
    text = safe_str(text_to_check).lower()
    words = "".join(c if c.isalnum() else " " for c in text).split()

    if model in words:
        return True

    forbidden_models = [m for m in KNOWN_MODELS if m != model and model in m]

    for word in words:
        if model in word:
            is_forbidden = False
            for fm in forbidden_models:
                if fm in word:
                    is_forbidden = True
                    break
            if not is_forbidden:
                return True

    return False

def extract_filename(link):
    filename = link.split('/')[-1] if '/' in link else link
    return filename.split('?')[0]

def build_list_item(text, value, icon_path=None):
    text_str = safe_str(text)
    res = [(text, value)]
    png = get_cached_icon(icon_path) if icon_path else None
    if png:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 10, 4, 32, 32, png))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, 55, 0, 680, 40, 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, text_str))
        return res
    res.append((eListboxPythonMultiContent.TYPE_TEXT, 15, 0, 720, 40, 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, text_str))
    return res

class IconList(MenuList):
    def __init__(self, list=None, enableWrapAround=False):
        if list is None: list = []
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", 22))
        self.l.setItemHeight(40)

    def getSelection(self):
        sel = self.l.getCurrentSelection()
        return sel[0] if sel else None

class RedFlagSlotSelector(Screen):
    skin = """<screen position="center,center" size="400,240" title=" ">
                <widget name="custom_title" position="15,10" size="370,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="menu" position="10,50" size="380,150" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="key_blue" position="10,205" size="380,30" font="Regular;20" foregroundColor="#00aaff" transparent="1" halign="left" />
              </screen>"""
    def __init__(self, session, title_text):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(title_text)
        self["menu"] = IconList([])
        self["key_blue"] = Label(self.L["m_back_btn"])
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"ok": self.ok, "cancel": self.close, "blue": self.close}, -1)
        self.onLayoutFinish.append(self.loadSlots)

    def loadSlots(self):
        icon_path = os.path.join(ICON_DIR, "slot.png")
        slots = [
            build_list_item("Slot 1", "1", icon_path),
            build_list_item("Slot 2", "2", icon_path),
            build_list_item("Slot 3", "3", icon_path),
            build_list_item("Slot 4", "4", icon_path)
        ]
        self["menu"].setList(slots)

    def ok(self):
        sel = self["menu"].getSelection()
        if sel: self.close(sel)

class RedFlagStartScreen(Screen):
    skin = """<screen position="center,center" size="550,450" title=" ">
                <widget name="custom_title" position="10,10" size="530,35" font="Regular;28" foregroundColor="#ffa500" halign="center" transparent="1" />
                <widget name="menu" position="30,55" size="490,315" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="status" position="10,390" size="530,30" font="Regular;18" halign="center" />
              </screen>"""

    def __init__(self, session):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["title"])
        
        menu_items = [
            build_list_item(self.L["m5"], "local_zips", os.path.join(ICON_DIR, "device.png")), 
            build_list_item(self.L["m1"], "local", os.path.join(ICON_DIR, "local.png")), 
            build_list_item(self.L["m_servers"], "servers_menu", os.path.join(ICON_DIR, "servers.png")), 
            build_list_item(self.L["m_rf_repo"], "rf_repo", os.path.join(ICON_DIR, "repo.png")),
            build_list_item(self.L["m_other_sources"], "other_sources_menu", os.path.join(ICON_DIR, "online.png")),
            build_list_item(self.L["settings"], "settings", os.path.join(ICON_DIR, "settings.png")),
            build_list_item(self.L["m4"], "help", os.path.join(ICON_DIR, "info.png"))
        ]
        
        self["menu"] = IconList(menu_items)
        self["status"] = Label(self.L.get("src", "Info"))
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.goToList, "cancel": self.close}, -1)

    def goToList(self):
        sel = self["menu"].getSelection()
        if sel:
            menu_id = sel[1]
            if menu_id == "servers_menu":
                self.session.open(RedFlagServerMenu)
            elif menu_id == "other_sources_menu":
                self.session.open(RedFlagOtherSourcesMenu)
            elif menu_id == "help":
                self.showHelpFile()
            elif menu_id == "settings":
                self.session.open(RedFlagSettingsSource)
            else:
                self.session.open(RedFlagMain, menu_id)

    def showHelpFile(self):
        plugin_path = os.path.dirname(__file__)
        help_path = os.path.join(plugin_path, "Read.txt")
        if os.path.exists(help_path):
            try:
                with open(help_path, "r") as f: help_text = f.read()
                self.session.open(RedFlagHelpScreen, help_text)
            except Exception as e:
                self.session.open(MessageBox, "Hata: %s" % str(e), MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, self.L.get("err_read_txt", "Error"), MessageBox.TYPE_ERROR)

class RedFlagOtherSourcesMenu(Screen):
    skin = """<screen position="center,center" size="500,300" title=" ">
                <widget name="custom_title" position="15,10" size="470,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="menu" position="30,50" size="440,190" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="key_blue" position="30,250" size="440,30" font="Regular;20" foregroundColor="#00aaff" transparent="1" halign="left" />
              </screen>"""
    def __init__(self, session):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["t_other_sources"]) 
        menu_items = [
            build_list_item(self.L["m2"], "online_auto", os.path.join(ICON_DIR, "auto.png")),
            build_list_item(self.L["m3"], "online_manual", os.path.join(ICON_DIR, "manual.png")),
            build_list_item(self.L["m_search"], "search_keyboard", os.path.join(ICON_DIR, "search.png"))
        ]
        self["menu"] = IconList(menu_items)
        self["key_blue"] = Label(self.L["m_back_btn"])
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"ok": self.ok, "cancel": self.close, "blue": self.close}, -1)

    def ok(self):
        sel = self["menu"].getSelection()
        if sel:
            menu_id = sel[1]
            if menu_id == "online_manual":
                self.session.open(RedFlagModelSelector) 
            elif menu_id == "search_keyboard":
                self.session.openWithCallback(self.onSearchEntered, VirtualKeyBoard, title=self.L["search_title"], text="")
            elif menu_id == "online_auto":
                self.session.open(RedFlagMain, "online_auto")

    def onSearchEntered(self, text):
        if text:
            clean_model = normalize_str(text)
            if clean_model:
                self.session.open(RedFlagMain, "multi_search", clean_model)

class RedFlagServerMenu(Screen):
    skin = """<screen position="center,center" size="500,450" title=" ">
                <widget name="custom_title" position="15,10" size="470,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="menu" position="30,50" size="440,340" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="key_blue" position="30,405" size="440,30" font="Regular;20" foregroundColor="#00aaff" transparent="1" halign="left" />
              </screen>"""
    def __init__(self, session):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["t_servers"])
        menu_items = []
        icon_path = os.path.join(ICON_DIR, "online.png")
        for idx, server in enumerate(FIRMWARE_SERVERS):
            menu_items.append(build_list_item(server[0], str(idx), icon_path))
        
        self["menu"] = IconList(menu_items)
        self["key_blue"] = Label(self.L["m_back_btn"])
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"ok": self.ok, "cancel": self.close, "blue": self.close}, -1)

    def ok(self):
        sel = self["menu"].getSelection()
        if sel:
            idx = int(sel[1])
            self.session.open(RedFlagMain, "server_specific", None, FIRMWARE_SERVERS[idx])

class RedFlagHelpScreen(Screen):
    skin = """<screen position="center,center" size="700,500" title=" ">
                <widget name="custom_title" position="15,10" size="670,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="text" position="20,50" size="660,430" font="Regular;20" />
              </screen>"""
    def __init__(self, session, content):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["t_help"])
        self["text"] = ScrollLabel(content)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.close, "cancel": self.close,
            "up": self["text"].pageUp, "down": self["text"].pageDown
        }, -1)

class RedFlagModelSelector(Screen):
    skin = """<screen position="center,center" size="400,500" title=" ">
                <widget name="custom_title" position="15,10" size="370,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="menu" position="10,50" size="380,395" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="key_blue" position="10,460" size="380,30" font="Regular;20" foregroundColor="#00aaff" transparent="1" halign="left" />
              </screen>"""
    def __init__(self, session):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["t_mod_sel"])
        self["menu"] = IconList([])
        self["key_blue"] = Label(self.L["m_back_btn"])
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"ok": self.ok, "cancel": self.close, "blue": self.close}, -1)
        self.onLayoutFinish.append(self.getOnlineModels)

    def getOnlineModels(self):
        icon_path = os.path.join(ICON_DIR, "stb.png")
        try:
            url = "https://api.github.com/repos/oe-alliance/bootmenu/contents/"
            res = requests.get(url, headers={'User-Agent': UA_STRING}, timeout=10, verify=False).json()
            if isinstance(res, list):
                models = [item["name"] for item in res if item["type"] == "dir" and not item["name"].startswith(".")]
                models.sort()
                self["menu"].setList([build_list_item(m, m, icon_path) for m in models])
            else: raise Exception("API")
        except:
            fallback = ["multiboxpro", "sf8008", "ustym4kpro", "vuduo4kse", "vuultimo4k", "vuzero4k", "qviartdual", "pulse4k"]
            self["menu"].setList([build_list_item(m, m, icon_path) for m in fallback])

    def ok(self):
        sel = self["menu"].getSelection()
        if sel:
            self.session.open(RedFlagMain, "online_manual", str(sel[1]))

class RedFlagMain(Screen):
    skin = """<screen position="center,center" size="780,560" title=" ">
                <widget name="custom_title" position="15,10" size="750,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="menu" position="15,50" size="750,385" scrollbarMode="showOnDemand" foregroundColor="#ffffff" backgroundColor="#151515" foregroundColorSelected="#ffff00" backgroundColorSelected="#0055ff" />
                <widget name="status" position="15,440" size="750,70" font="Regular;19" halign="center" valign="center" foregroundColor="#00ff00" />
                <widget name="key_blue" position="15,520" size="750,30" font="Regular;20" foregroundColor="#00aaff" transparent="1" halign="left" />
              </screen>"""
    def __init__(self, session, mode, manual_model=None, server_info=None):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self.mode = mode
        self.manual_model = manual_model
        self.server_info = server_info
        
        if self.mode == "local": title_text = self.L.get("t_local", "Local List")
        elif self.mode == "local_zips": title_text = self.L.get("t_local_zips", "Local Files")
        elif self.mode == "rf_repo": title_text = self.L.get("t_rf_repo", "Archive")
        elif self.mode == "server_specific": title_text = self.server_info[0] if self.server_info else self.L.get("t_servers", "Servers")
        elif self.mode == "multi_search": title_text = self.L.get("t_other_sources", "Image Search")
        elif self.mode == "online_auto": title_text = self.L.get("t_auto", "Auto Detection")
        elif self.mode == "online_manual": title_text = self.L.get("t_manual", "Manual Selection")
        else: title_text = self.L.get("t_main", "Image List")
        
        self["custom_title"] = Label(title_text)
        
        self["menu"] = IconList([])
        self["status"] = Label(self.L.get("loading", "Scanning..."))
        self["key_blue"] = Label(self.L["m_back_btn"])
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"ok": self.selectSlot, "cancel": self.close, "blue": self.close}, -1)
        
        # Donanım kimliği tespiti (DM8000/DM800 hatasını önlemek için)
        self.device_model = "multiboxpro"
        try:
            val = BoxInfo.getItem("machinebuild") or BoxInfo.getItem("model")
            if val: self.device_model = str(val).strip().lower()
        except:
            if os.path.exists("/proc/stb/info/model"):
                try:
                    with open("/proc/stb/info/model", "r") as f: self.device_model = f.read().strip().lower()
                except: pass

        self.locked_img_name = ""
        self.locked_img_url = ""
        self.selected_slot = "1"
        
        self.download_path = "/tmp"
        for p in ['/media/hdd', '/media/usb', '/media/mmc', '/media/sdcard']:
            if os.path.ismount(p) and os.access(p, os.W_OK):
                self.download_path = os.path.join(p, "images")
                break
        
        if not os.path.exists(self.download_path):
            try: os.makedirs(self.download_path)
            except: self.download_path = "/tmp"

        self.onLayoutFinish.append(self.loadData)

    def loadData(self):
        final_list = []
        icon_zip = os.path.join(ICON_DIR, "zip.png")
        icon_img = os.path.join(ICON_DIR, "image.png")
        
        if self.manual_model: 
            self.device_model = self.manual_model

        if self.mode == "local":
            path = "/home/Images.txt"
            if os.path.exists(path):
                with open(path, "r") as f:
                    for line in f:
                        try:
                            line = line.strip()
                            if not line: continue
                            if line.startswith(("#", "[", "-", "=")):
                                final_list.append(build_list_item(line, "HEADER"))
                            elif "==" in line:
                                p = line.split('==')
                                final_list.append(build_list_item(p[0].strip(), p[1].strip(), icon_img))
                        except: pass
            else:
                self["status"].setText(self.L.get("err_no_txt", "Error"))
                
        elif self.mode == "local_zips":
            scan_targets = [('/media/hdd', self.L.get("h_hdd", "HDD")), ('/media/hdd/images', self.L.get("h_images", "IMAGES"))]
            found_any = False
            for check_path, header_title in scan_targets:
                if os.path.exists(check_path):
                    files = [f for f in os.listdir(check_path) if f.endswith(".zip") and not f.startswith("image.zip") and os.path.isfile(os.path.join(check_path, f))]
                    if files:
                        found_any = True
                        files.sort() 
                        final_list.append(build_list_item("", "HEADER"))
                        final_list.append(build_list_item(header_title, "HEADER"))
                        final_list.append(build_list_item("----------------------------------", "HEADER"))
                        for f in files: final_list.append(build_list_item(f, os.path.join(check_path, f), icon_zip))
            if not found_any: self["status"].setText(self.L.get("err_no_zip", "Error"))
                
        elif self.mode == "rf_repo":
            try:
                timestamp = str(int(time.time()))
                url = "https://raw.githubusercontent.com/RedFlag-TR/FlashTool/main/images?nocache=" + timestamp
                res = requests.get(url, headers={'User-Agent': UA_STRING}, timeout=10, verify=False)
                if res.status_code == 200:
                    raw_data = res.text.replace('\r', '').replace('"', '')
                    for line in raw_data.split('\n'):
                        try:
                            line = line.strip()
                            if not line: continue
                            if line.startswith(("#", "[", "-", "=")) and "http" not in line:
                                final_list.append(build_list_item(line, "HEADER"))
                            elif "http" in line:
                                if "==" in line:
                                    parts = line.split('==')
                                    final_list.append(build_list_item(parts[0].strip(), parts[1].strip(), icon_img))
                                elif "," in line:
                                    parts = line.split(',')
                                    final_list.append(build_list_item(parts[0].strip(), parts[-1].strip(), icon_img))
                                else:
                                    parts = line.rsplit(None, 1)
                                    if len(parts) == 2:
                                        final_list.append(build_list_item(parts[0].replace("_", " ").strip(), parts[1].strip(), icon_img))
                                    else:
                                        final_list.append(build_list_item(extract_filename(parts[0]), parts[0].strip(), icon_img))
                        except: pass
                else: self["status"].setText(self.L["err_server"] % str(res.status_code))
            except: self["status"].setText(self.L.get("err_conn", "Connection Error!"))

        elif self.mode == "server_specific" and self.server_info:
            s_name, s_base_url, s_append = self.server_info
            s_url = "%s/%s" % (s_base_url.rstrip("/"), self.device_model) if s_append else s_base_url
            raw = _fetch_json(s_url)
            normalized = _normalize_images(raw)
            if normalized:
                for cat in sorted(normalized.keys(), reverse=True):
                    images = normalized[cat]
                    final_list.append(build_list_item("", "HEADER"))
                    final_list.append(build_list_item("[ 🌐 %s: %s ]" % (s_name.upper(), cat), "HEADER"))
                    for img_key in sorted(images.keys(), reverse=True):
                        try:
                            img = images[img_key]
                            final_list.append(build_list_item(img["name"], img["link"], icon_img))
                        except: pass
            
            if len(final_list) == 0:
                self["status"].setText(self.L.get("err_no_mod", "Error"))
                
        elif self.mode in ["multi_search", "online_auto", "online_manual"]:
            search_mode_cfg = config.plugins.redflag.search_mode.value
            timestamp = str(int(time.time()))
            
            if self.mode in ["online_auto", "online_manual"]:
                matched_models = [normalize_str(self.device_model)]
            else:
                search_query = normalize_str(self.device_model)
                exact = [m for m in KNOWN_MODELS if m == search_query]
                if exact:
                    matched_models = exact
                else:
                    matched_models = [m for m in KNOWN_MODELS if search_query in m or m in search_query]
                    matched_models.sort(key=len, reverse=True)
                    if not matched_models: matched_models = [search_query]
            
            redflag_lines = []
            if search_mode_cfg in ("all", "other"):
                try:
                    url_rf = "https://raw.githubusercontent.com/RedFlag-TR/FlashTool/main/images?nocache=" + timestamp
                    res_rf = requests.get(url_rf, headers={'User-Agent': UA_STRING}, timeout=5, verify=False)
                    if res_rf.status_code == 200:
                        redflag_lines = res_rf.text.replace('\r', '').replace('"', '').split('\n')
                except: pass
            
            for model in matched_models[:4]: 
                if search_mode_cfg in ("all", "teams"):
                    try:
                        url_atv = "https://images.opena.tv/%s/" % model
                        r_atv = requests.get(url_atv, headers={'User-Agent': UA_STRING}, timeout=4, verify=False)
                        if r_atv.status_code == 200:
                            final_list.append(build_list_item("", "HEADER"))
                            final_list.append(build_list_item("[ 🌐 OPENATV RESMİ SUNUCU: %s ]" % model.upper(), "HEADER"))
                            parts = r_atv.text.split('href="')
                            for p in parts[1:]:
                                try:
                                    link = p.split('"')[0]
                                    if link.endswith('.zip') and is_valid_for_model(model, link):
                                        full_link = url_atv + link
                                        final_list.append(build_list_item(link, full_link, icon_img))
                                except: pass
                    except: pass

                if search_mode_cfg in ("all", "teams"):
                    try:
                        url_pli = "https://downloads.openpli.org/builds/%s" % model
                        r_pli = requests.get(url_pli, headers={'User-Agent': UA_STRING}, timeout=4, verify=False)
                        if r_pli.status_code == 200:
                            final_list.append(build_list_item("", "HEADER"))
                            final_list.append(build_list_item("[ 🌐 OPENPLI RESMİ SUNUCU: %s ]" % model.upper(), "HEADER"))
                            parts = r_pli.text.split('href="')
                            for p in parts[1:]:
                                try:
                                    link = p.split('"')[0]
                                    if link.endswith('.zip') and is_valid_for_model(model, link):
                                        full_link = "https://downloads.openpli.org" + link if link.startswith('/') else url_pli + "/" + link
                                        final_list.append(build_list_item(link.split('/')[-1], full_link, icon_img))
                                except: pass
                    except: pass

                if search_mode_cfg in ("all", "other"):
                    for branch in ["master", "main"]:
                        try:
                            url_oea = "https://raw.githubusercontent.com/oe-alliance/bootmenu/%s/%s/images?nocache=%s" % (branch, model, timestamp)
                            res_oea = requests.get(url_oea, headers={'User-Agent': UA_STRING}, timeout=4, verify=False)
                            if res_oea.status_code == 200:
                                final_list.append(build_list_item("", "HEADER"))
                                final_list.append(build_list_item("[ 🌐 OE-ALLIANCE: %s ]" % model.upper(), "HEADER"))
                                raw_data = res_oea.text.replace('\r', '').replace('"', '')
                                for line in raw_data.split('\n'):
                                    try:
                                        line = line.strip()
                                        if not line or line.startswith('#'): continue
                                        if "http" in line and is_valid_for_model(model, line):
                                            if "," in line:
                                                parts = line.split(',')
                                                name = parts[0].strip()
                                                link = parts[-1].strip()
                                            else:
                                                parts = line.rsplit(None, 1)
                                                if len(parts) == 2:
                                                    name = parts[0].replace("_", " ").strip()
                                                    link = parts[1].strip()
                                                else:
                                                    name = extract_filename(parts[0])
                                                    link = parts[0].strip()
                                                    
                                            link = link.replace("'", "").strip()
                                            if link.startswith("http"):
                                                final_list.append(build_list_item(name, link, icon_img))
                                    except: pass
                                break 
                        except: pass

                if search_mode_cfg in ("all", "other"):
                    rf_found = False
                    for line in redflag_lines:
                        try:
                            line = line.strip()
                            if not line or line.startswith(("#", "[", "-", "=")): continue
                            if "http" in line.lower() and is_valid_for_model(model, line):
                                if not rf_found:
                                    final_list.append(build_list_item("", "HEADER"))
                                    final_list.append(build_list_item("[ 🚩 REDFLAG DEPOSU: %s ]" % model.upper(), "HEADER"))
                                    rf_found = True
                                
                                if "==" in line:
                                    parts = line.split('==')
                                    name = parts[0].strip()
                                    link = parts[1].strip()
                                elif "," in line:
                                    parts = line.split(',')
                                    name = parts[0].strip()
                                    link = parts[-1].strip()
                                else:
                                    parts = line.rsplit(None, 1)
                                    if len(parts) == 2:
                                        name = parts[0].replace("_", " ").strip()
                                        link = parts[1].strip()
                                    else:
                                        name = extract_filename(parts[0])
                                        link = parts[0].strip()
                                        
                                final_list.append(build_list_item(name, link, icon_img))
                        except: pass

                if search_mode_cfg in ("all", "teams"):
                    for s_name, s_base_url, s_append in FIRMWARE_SERVERS:
                        if s_name in ["OpenATV", "OpenPLi"]: continue 
                        try:
                            s_url = "%s/%s" % (s_base_url.rstrip("/"), model) if s_append else s_base_url
                            raw = _fetch_json(s_url)
                            normalized = _normalize_images(raw)
                            if normalized:
                                final_list.append(build_list_item("", "HEADER"))
                                final_list.append(build_list_item("[ 🌐 %s API: %s ]" % (s_name.upper(), model.upper()), "HEADER"))
                                for cat in sorted(normalized.keys(), reverse=True):
                                    images = normalized[cat]
                                    for img_key in sorted(images.keys(), reverse=True):
                                        try:
                                            img = images[img_key]
                                            combined_text = img["name"] + " " + img["link"]
                                            if is_valid_for_model(model, combined_text):
                                                final_list.append(build_list_item(img["name"], img["link"], icon_img))
                                        except: pass
                        except: pass
                            
            if len(final_list) == 0:
                self["status"].setText(self.L.get("err_no_mod", "Error"))

        self["menu"].setList(final_list)
        count = len([x for x in final_list if x[0][1] != "HEADER"])
        
        if self.mode == "local": mode_text = self.L.get("t_local", "Local List")
        elif self.mode == "local_zips": mode_text = self.L.get("t_local_zips", "Local Files")
        elif self.mode == "rf_repo": mode_text = self.L.get("t_rf_repo", "Archive")
        elif self.mode == "server_specific": mode_text = self.server_info[0] if self.server_info else self.L.get("t_servers", "Servers")
        elif self.mode == "multi_search": mode_text = self.L.get("t_other_sources", "Image Search")
        elif self.mode == "online_auto": mode_text = self.L.get("t_auto", "Auto Detection")
        else: mode_text = self.L.get("t_manual", "Manual Selection")
        
        self["status"].setText(self.L.get("info", "%s %s %d") % (mode_text, self.device_model.upper(), count, self.download_path))

    def selectSlot(self):
        sel = self["menu"].getSelection()
        if sel and sel[1] != "HEADER":
            self.locked_img_name = sel[0].strip()
            self.locked_img_url = sel[1].strip()
            if "dropbox.com" in self.locked_img_url and "dl=0" in self.locked_img_url:
                self.locked_img_url = self.locked_img_url.replace("dl=0", "dl=1")
            
            if self.mode == "local_zips":
                self.session.openWithCallback(self.runFlashScriptDirect, RedFlagSlotSelector, self.L.get("t_slot", "Slot"))
            else:
                self.startDownload()

    def startDownload(self):
        target_zip = os.path.join(self.download_path, "image.zip")
        if os.path.exists(target_zip):
            try: os.remove(target_zip)
            except: pass
        cmd = 'wget --no-check-certificate --trust-server-names --user-agent="{0}" "{1}" -O "{2}" || echo "{4}" && echo -e "\n---------------------------------------------------------------------\n{3}\n---------------------------------------------------------------------"'.format(
            UA_STRING, self.locked_img_url, target_zip, self.L.get("console_done", ""), self.L.get("w_fallback", "")
        )
        self.session.openWithCallback(self.askDecision, Console, title="RedFlag Download", cmdlist=[cmd])

    def askDecision(self, result=None):
        target_zip = os.path.join(self.download_path, "image.zip")
        if not os.path.exists(target_zip) or os.path.getsize(target_zip) < 2097152:
            if os.path.exists(target_zip):
                try: os.remove(target_zip)
                except: pass
            self.session.open(MessageBox, self.L.get("err_corrupted", "Error"), MessageBox.TYPE_ERROR)
            return
        from enigma import eTimer
        self.decision_timer = eTimer()
        try: self.decision_timer.timeout.connect(self.showDecisionBox)
        except: self.decision_timer.callback.append(self.showDecisionBox)
        self.decision_timer.start(500, True)

    def showDecisionBox(self):
        self.session.openWithCallback(self.decisionCallback, MessageBox, self.L.get("msg_decision", "Continue?"), MessageBox.TYPE_YESNO)

    def decisionCallback(self, answer):
        if answer: self.session.openWithCallback(self.runFlashScriptAfterSlot, RedFlagSlotSelector, self.L.get("t_slot", "Slot"))
        else: self.saveFileOnly()

    def runFlashScriptDirect(self, slot_choice):
        if slot_choice:
            self.selected_slot = slot_choice[1]
            script = "/usr/lib/enigma2/python/Plugins/Extensions/RedFlagFlashTool/flash_script.sh"
            clean_name = "byRedFlag-" + self.device_model + "-" + self.locked_img_name.replace(" ", "_")
            cmd = "sed -i 's/\\r$//' {0}; chmod 755 {0}; {0} {1} {2} '{3}' '{4}' {5}".format(
                script, self.selected_slot, self.download_path, self.locked_img_url, clean_name, currL
            )
            self.session.openWithCallback(self.askCleanup, Console, title="RedFlag Local Flashing", cmdlist=[cmd])

    def runFlashScriptAfterSlot(self, slot_choice):
        if slot_choice:
            self.selected_slot = slot_choice[1]
            script = "/usr/lib/enigma2/python/Plugins/Extensions/RedFlagFlashTool/flash_script.sh"
            clean_name = "byRedFlag-" + self.device_model + "-" + self.locked_img_name.replace(" ", "_")
            target_zip = os.path.join(self.download_path, "image.zip")
            cmd = "sed -i 's/\\r$//' {0}; chmod 755 {0}; {0} {1} {2} '{3}' '{4}' {5}".format(
                script, self.selected_slot, self.download_path, target_zip, clean_name, currL
            )
            self.session.openWithCallback(self.askCleanup, Console, title="RedFlag Online Flashing", cmdlist=[cmd])

    def saveFileOnly(self):
        old_path = os.path.join(self.download_path, "image.zip")
        clean_name = "byRedFlag-" + self.device_model + "-" + self.locked_img_name.replace(" ", "_") + ".zip"
        new_path = os.path.join(self.download_path, clean_name)
        try:
            if os.path.exists(old_path):
                os.rename(old_path, new_path)
                self.session.open(MessageBox, self.L.get("msg_saved", "Saved:") + " " + clean_name, MessageBox.TYPE_INFO)
        except: pass

    def askCleanup(self, result=None):
        if self.mode == "local_zips":
            self.doCleanup(False)
            return
        from enigma import eTimer
        self.cleanup_timer = eTimer()
        try: self.cleanup_timer.timeout.connect(self.showCleanupBox)
        except: self.cleanup_timer.callback.append(self.showCleanupBox)
        self.cleanup_timer.start(500, True)

    def showCleanupBox(self):
        self.session.openWithCallback(self.doCleanup, MessageBox, self.L.get("done", "Done"), MessageBox.TYPE_YESNO)

    def doCleanup(self, answer):
        import shutil
        temp_dir = os.path.join(self.download_path, "rf_temp")
        target_zip = os.path.join(self.download_path, "image.zip")
        if answer and self.mode not in ["local_zips"]:
            try:
                if os.path.exists(target_zip): os.remove(target_zip)
            except: pass
        try:
            if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
        except: pass
        from enigma import eTimer
        self.exit_timer = eTimer()
        try: self.exit_timer.timeout.connect(self.close)
        except: self.exit_timer.callback.append(self.close)
        self.exit_timer.start(300, True)

class RedFlagSettingsSource(Screen, ConfigListScreen):
    skin = """<screen position="center,center" size="500,200" title=" ">
                <widget name="custom_title" position="15,10" size="470,30" font="Regular;26" foregroundColor="#ffff00" halign="left" transparent="1" />
                <widget name="config" position="20,45" size="460,95" scrollbarMode="showOnDemand" />
                <widget name="status" position="10,150" size="480,30" font="Regular;18" halign="center" foregroundColor="#00ff00"/>
              </screen>"""
    def __init__(self, session):
        self.L = LANG_DICT.get(get_language(), LANG_DICT["en"])
        Screen.__init__(self, session)
        self.setTitle(" ")
        self["custom_title"] = Label(self.L["t_settings"])
        
        self.list = [
            getConfigListEntry(self.L.get("st_show_main", "Show in Menu"), config.plugins.redflag.show_in_mainmenu),
            getConfigListEntry(self.L.get("st_search_mode", "Search Source"), config.plugins.redflag.search_mode)
        ]
        ConfigListScreen.__init__(self, self.list, session = session)
        self["status"] = Label(self.L.get("st_save_info", "OK to save"))
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.save, "cancel": self.cancel}, -1)

    def save(self):
        for x in self["config"].list: x[1].save()
        self.close()

    def cancel(self):
        for x in self["config"].list: x[1].cancel()
        self.close()

def main(session, **kwargs):
    session.open(RedFlagStartScreen)

def main_menu(menuid, **kwargs):
    L = LANG_DICT.get(get_language(), LANG_DICT["en"])
    if menuid == "mainmenu" and config.plugins.redflag.show_in_mainmenu.value:
        return [(L.get("p_name", "RedFlag"), main, "redflag_main", None)]
    return []

def Plugins(path, **kwargs):
    L = LANG_DICT.get(get_language(), LANG_DICT["en"])
    return [
        PluginDescriptor(name=L.get("p_name", "RedFlag"), description=L.get("p_desc", "RedFlag Flash Tool"), where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
        PluginDescriptor(name=L.get("p_name", "RedFlag"), description=L.get("p_desc", "RedFlag Flash Tool"), where=PluginDescriptor.WHERE_MENU, fnc=main_menu)
    ]
