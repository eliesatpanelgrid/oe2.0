# -*- coding: utf-8 -*-

import copy
import os
import json
import glob
import threading
from queue import Queue
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop

from . import _, __version__

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/dame.json"
_heuristic_cache = {}
SIZE = 8
P_NONE = 0
P_HUMAN = 1
P_AI = 2
P_HUMAN_K = 3
P_AI_K = 4


try:
    from skin import loadSkin
    _desk_w = getDesktop(0).size().width()
    if _desk_w >= 2560:
        loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
    elif _desk_w >= 1920:
        loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
    else:
        loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
    pass


def is_human(p):
    return p in (P_HUMAN, P_HUMAN_K)


def is_ai(p):
    return p in (P_AI, P_AI_K)


def is_king(p):
    return p in (P_HUMAN_K, P_AI_K)


def owner(p):
    if is_human(p):
        return P_HUMAN
    if is_ai(p):
        return P_AI
    return P_NONE


def init_board():
    """Initialize the checkers board."""
    b = [[P_NONE] * SIZE for _ in range(SIZE)]
    # AI pieces (top)
    for r in range(3):
        for c in range(SIZE):
            if (r + c) % 2 == 1:
                b[r][c] = P_AI
    # Human pieces (bottom)
    for r in range(5, SIZE):
        for c in range(SIZE):
            if (r + c) % 2 == 1:
                b[r][c] = P_HUMAN
    return b


def board_to_tuple(board):
    """Convert board to hashable tuple for caching."""
    return tuple(tuple(row) for row in board)


def heuristic(board):
    """Heuristic evaluation of board position."""
    score = 0
    for r in range(SIZE):
        for c in range(SIZE):
            p = board[r][c]
            if p == P_HUMAN:
                score -= 10
            elif p == P_AI:
                score += 10
            elif p == P_HUMAN_K:
                score -= 18
            elif p == P_AI_K:
                score += 18

    # Center control bonus
    for r in range(2, 6):
        for c in range(2, 6):
            p = board[r][c]
            if is_ai(p):
                score += 1
            if is_human(p):
                score -= 1

    return score


def heuristic_cached(board):
    """Cached heuristic evaluation."""
    key = board_to_tuple(board)
    if key in _heuristic_cache:
        return _heuristic_cache[key]
    val = heuristic(board)
    _heuristic_cache[key] = val
    return val


def get_jumps(board, r, c, visited=None):
    """Get all jump sequences for a piece at position."""
    if visited is None:
        visited = set()
    p = board[r][c]
    opp = is_human if is_ai(p) else is_ai
    dirs = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    if not is_king(p):
        if is_human(p):
            dirs = [(-1, -1), (-1, 1)]
        else:
            dirs = [(1, -1), (1, 1)]

    paths = []
    for dr, dc in dirs:
        mr, mc = r + dr, c + dc
        lr, lc = r + 2 * dr, c + 2 * dc
        if not (0 <= lr < SIZE and 0 <= lc < SIZE):
            continue
        if not opp(board[mr][mc]):
            continue
        if board[lr][lc] != P_NONE:
            continue
        key = (mr, mc)
        if key in visited:
            continue

        b2 = [row[:] for row in board]
        b2[lr][lc] = p
        b2[r][c] = P_NONE
        b2[mr][mc] = P_NONE

        crowned = False
        if is_human(p) and lr == 0:
            b2[lr][lc] = P_HUMAN_K
            crowned = True
        if is_ai(p) and lr == SIZE - 1:
            b2[lr][lc] = P_AI_K
            crowned = True

        sub = get_jumps(b2, lr, lc, visited | {key}) if not crowned else []
        if sub:
            for sub_path in sub:
                paths.append([(r, c), (lr, lc)] + sub_path[1:])
        else:
            paths.append([(r, c), (lr, lc)])

    return paths


def apply_path(board, path):
    """Apply a move/jump path to the board."""
    b = [row[:] for row in board]
    p = b[path[0][0]][path[0][1]]
    b[path[0][0]][path[0][1]] = P_NONE

    for i in range(len(path) - 1):
        r1, c1 = path[i]
        r2, c2 = path[i + 1]
        if abs(r2 - r1) == 2:
            mr = (r1 + r2) // 2
            mc = (c1 + c2) // 2
            b[mr][mc] = P_NONE

    b[path[-1][0]][path[-1][1]] = p
    lr, lc = path[-1]

    if is_human(p) and lr == 0:
        b[lr][lc] = P_HUMAN_K
    if is_ai(p) and lr == SIZE - 1:
        b[lr][lc] = P_AI_K
    return b


def get_simple_moves(board, r, c):
    """Get simple (non-jump) moves for a piece."""
    p = board[r][c]
    dirs = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    if not is_king(p):
        if is_human(p):
            dirs = [(-1, -1), (-1, 1)]
        else:
            dirs = [(1, -1), (1, 1)]

    moves = []
    for dr, dc in dirs:
        nr, nc = r + dr, c + dc
        if is_king(p):
            while 0 <= nr < SIZE and 0 <= nc < SIZE and board[nr][nc] == P_NONE:
                moves.append((nr, nc))
                nr += dr
                nc += dc
        else:
            if 0 <= nr < SIZE and 0 <= nc < SIZE and board[nr][nc] == P_NONE:
                moves.append((nr, nc))
    return moves


def all_moves(board, player):
    """Get all moves for a player."""
    jumps = []
    simple = []
    piece_count = 0
    for r in range(SIZE):
        for c in range(SIZE):
            p = board[r][c]
            if (player == P_HUMAN and is_human(p)) or (player == P_AI and is_ai(p)):
                piece_count += 1
                jp = get_jumps(board, r, c)
                if jp:
                    for path in jp:
                        jumps.append((r, c, path))
                else:
                    for nr, nc in get_simple_moves(board, r, c):
                        simple.append((r, c, [(r, c), (nr, nc)]))
    print(f"[all_moves] Player {player}: pieces={piece_count}, jumps={len(jumps)}, simple={len(simple)}")
    return jumps if jumps else simple


def count_pieces(board, player):
    """Count pieces on board for a player."""
    cnt = 0
    for r in range(SIZE):
        for c in range(SIZE):
            p = board[r][c]
            if player == P_HUMAN and is_human(p):
                cnt += 1
            if player == P_AI and is_ai(p):
                cnt += 1
    return cnt


def check_win(board):
    """Check if someone has won."""
    if count_pieces(board, P_HUMAN) == 0 or not all_moves(board, P_HUMAN):
        return P_AI
    if count_pieces(board, P_AI) == 0 or not all_moves(board, P_AI):
        return P_HUMAN
    return P_NONE


def minimax(board, depth, alpha, beta, maximizing):
    """Minimax algorithm with alpha-beta pruning."""
    w = check_win(board)
    if w == P_AI:
        return 10000
    if w == P_HUMAN:
        return -10000
    if depth == 0:
        return heuristic_cached(board)

    player = P_AI if maximizing else P_HUMAN
    moves = all_moves(board, player)

    if not moves:
        return 10000 if maximizing else -10000

    # Sort moves to improve alpha-beta
    moves.sort(key=lambda m: len(m[2]), reverse=True)

    if maximizing:
        best = -99999
        for xs, xa, path in moves:
            b2 = apply_path(board, path)
            val = minimax(b2, depth - 1, alpha, beta, False)
            if val > best:
                best = val
            alpha = max(alpha, best)
            if beta <= alpha:
                break
        return best
    else:
        best = 99999
        for xs, xa, path in moves:
            b2 = apply_path(board, path)
            val = minimax(b2, depth - 1, alpha, beta, True)
            if val < best:
                best = val
            beta = min(beta, best)
            if beta <= alpha:
                break
        return best


def ai_best_move(board):
    """Calculate best AI move."""
    moves = all_moves(board, P_AI)
    print("[AI] Total moves:", len(moves))
    
    if not moves:
        print("[AI] No moves available!")
        return None

    # Count Enigma pieces
    ai_pieces = count_pieces(board, P_AI)
    
    # Reduce depth based on remaining pieces
    if ai_pieces <= 3:
        depth = 1  # Very fast
    elif ai_pieces <= 5:
        depth = 2
    else:
        depth = 2  # Keep 2 for now
    
    print(f"[AI] Depth: {depth}, AI pieces: {ai_pieces}")
    
    # Sort moves: jumps first
    moves.sort(key=lambda m: len(m[2]), reverse=True)

    best_val = -99999
    best_move = None
    alpha = -99999
    beta = 99999
    
    for fr, fc, path in moves:
        b2 = apply_path(board, path)
        val = minimax(b2, depth - 1, alpha, beta, False)
        print(f"[AI] Move from ({fr},{fc}) value: {val}")
        if val > best_val:
            best_val = val
            best_move = (fr, fc, path)
        alpha = max(alpha, best_val)
        if beta <= alpha:
            break

    print("[AI] Best move value:", best_val)
    return best_move


def ai_best_movexxxx(board):
    """Calculate best AI move."""
    moves = all_moves(board, P_AI)
    print("[AI] Total moves:", len(moves))  # Debug
    if not moves:
        print("[AI] No moves available!")
        return None

    # Use depth 2 for speed
    depth = 1
    
    # Sort moves: jumps first
    moves.sort(key=lambda m: len(m[2]), reverse=True)

    # Print moves for debug
    for fr, fc, path in moves:
        print("[AI] Move: from", fr, fc, "path length:", len(path))

    best_val = -99999
    best_move = None
    alpha = -99999
    beta = 99999
    for fr, fc, path in moves:
        b2 = apply_path(board, path)
        val = minimax(b2, depth - 1, alpha, beta, False)
        print("[AI] Move value:", val)
        if val > best_val:
            best_val = val
            best_move = (fr, fc, path)

        alpha = max(alpha, best_val)
        if beta <= alpha:
            break

    print("[AI] Best move value:", best_val)
    return best_move


def draw_board_svg(board, cursor_r, cursor_c, sel_r, sel_c,
                   valid_paths, W, H, filepath):
    """Generate SVG representation of the board."""
    padding = 50
    cs = min(W - (padding * 2), H - (padding * 2)) // SIZE
    bw = cs * SIZE
    bh = cs * SIZE
    ox = (W - bw) // 2
    oy = (H - bh) // 2
    pr = max(4, cs * 40 // 100)

    targets = set()
    for path in valid_paths:
        targets.add(path[-1])

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
        '<defs><filter id="shadow"><feDropShadow dx="1" dy="1" stdDeviation="1" flood-opacity="0.8"/></filter></defs>'
    ]

    # Board squares
    for r in range(SIZE):
        for c in range(SIZE):
            fx = ox + c * cs
            fy = oy + r * cs
            dark = (r + c) % 2 == 1
            col = "#b58863" if dark else "#f0d9b5"
            lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>' % (fx, fy, cs, cs, col))

    # Board border
    lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="#222222" stroke-width="3"/>' % (ox, oy, bw, bh))

    # Column letters (A-H)
    fs = max(14, cs // 3)
    for i in range(SIZE):
        lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="middle" fill="#ffffff" font-weight="bold" filter="url(#shadow)">%s</text>' % (
            ox + i * cs + cs // 2, oy - 15, fs, chr(65 + i)))
        lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="end" fill="#ffffff" font-weight="bold" filter="url(#shadow)">%d</text>' % (
            ox - 15, oy + i * cs + cs // 2 + fs // 3, fs, SIZE - i))

    # Pieces
    for r in range(SIZE):
        for c in range(SIZE):
            p = board[r][c]
            if p == P_NONE:
                continue

            cx = ox + c * cs + cs // 2
            cy = oy + r * cs + cs // 2
            fill_col = "#ffffff" if is_human(p) else "#000000"
            lines.append('<circle cx="%d" cy="%d" r="%d" fill="rgba(0,0,0,0.4)"/>' % (cx + 3, cy + 4, pr))
            lines.append('<circle cx="%d" cy="%d" r="%d" fill="%s" stroke="#444444" stroke-width="2"/>' % (cx, cy, pr, fill_col))

            if is_king(p):
                lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="middle" fill="#f5a623" font-weight="bold">K</text>' % (
                    cx, cy + (pr // 3), pr))

    # Target indicators
    for tr, tc in targets:
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#eeeeee"/>' % (
            ox + tc * cs + cs // 2, oy + tr * cs + cs // 2, cs // 4))
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#000000"/>' % (
            ox + tc * cs + cs // 2, oy + tr * cs + cs // 2, max(2, cs // 12)))

    # Selected piece highlight
    if sel_r >= 0:
        cx = ox + sel_c * cs + cs // 2
        cy = oy + sel_r * cs + cs // 2
        sel_radius = int(cs * 0.45)
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="#44cc88" stroke-width="3"/>' % (cx, cy, sel_radius))

    # Cursor highlight
    if cursor_r >= 0:
        cx = ox + cursor_c * cs + cs // 2
        cy = oy + cursor_r * cs + cs // 2
        cur_radius = int(cs * 0.48)
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="#f5a623" stroke-width="3"/>' % (cx, cy, cur_radius))

    lines.append('</svg>')
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines))


class DameScreen(Screen):
    """Main Checkers game screen."""

    def __init__(self, session, resume=False):
        Screen.__init__(self, session)
        self._sw = 800
        self._sh = 800
        self._discard = False

        self["bg"] = Pixmap()
        self["w_status"] = Label("")
        self["w_h_pieces"] = Label("")
        self["w_a_pieces"] = Label("")
        self["w_moves"] = Label("")
        self["w_hi"] = Label("")
        self["w_h_lbl"] = Label("")
        self["w_a_lbl"] = Label("")
        self["w_moves_lbl"] = Label("")
        self["w_hi_lbl"] = Label("")
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("New game"))
        self["key_yellow"] = Label(_("Deselect"))

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "left": self._left,
                "right": self._right,
                "up": self._up,
                "down": self._down,
                "ok": self._ok,
                "yellow": self._deselect,
                "green": self._new_game,
                "red": self._exit,
                "cancel": self._exit,
            }, -1)

        self._ai_timer = eTimer()
        self._ai_timer.callback.append(self._do_ai_move)
        self._ai_queue = None
        self._ai_thread = None
        self._ai_check_timer = None

        self.onClose.append(self._cleanup)
        self.onLayoutFinish.append(self._on_layout)

        self._hi = 0
        self._load_hi()

        if resume and self._load_state():
            pass
        else:
            self._init_game()

    def _init_game(self):
        """Initialize or reset game state."""
        self._board = init_board()
        self._cursor_r = 5
        self._cursor_c = 0

        # Find first human piece
        for r in range(SIZE - 1, -1, -1):
            for c in range(SIZE):
                if (r + c) % 2 == 1 and self._board[r][c] == P_HUMAN:
                    self._cursor_r = r
                    self._cursor_c = c
                    break
            else:
                continue
            break

        self._sel_r = -1
        self._sel_c = -1
        self._valid_paths = []
        self._turn = P_HUMAN
        self._moves = 0
        self._game_over = False
        self._discard = False
        self["w_status"].setText(_("Your turn! Select a piece."))
        self["key_yellow"].setText(_("Deselect"))

    def _on_layout(self):
        """Called after layout is finished."""
        if not self["bg"].instance:
            return
        sz = self["bg"].instance.size()
        self._sw = sz.width()
        self._sh = sz.height()
        self["w_h_lbl"].setText(_("Player:"))
        self["w_a_lbl"].setText(_("Enigma:"))
        self["w_moves_lbl"].setText(_("Moves:"))
        self["w_hi_lbl"].setText(_("Best:"))
        self._render()

    def _left(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor_c = (self._cursor_c - 1) % SIZE
        self._render()

    def _right(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor_c = (self._cursor_c + 1) % SIZE
        self._render()

    def _up(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor_r = (self._cursor_r - 1) % SIZE
        self._render()

    def _down(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor_r = (self._cursor_r + 1) % SIZE
        self._render()

    def _deselect(self):
        """Deselect current piece."""
        self._sel_r = -1
        self._sel_c = -1
        self._valid_paths = []
        self["w_status"].setText(_("Deselected."))
        self._render()

    def _ok(self):
        """Handle OK button press."""
        if self._game_over:
            self._new_game()
            return
        if self._turn != P_HUMAN:
            return

        r, c = self._cursor_r, self._cursor_c

        # No piece selected yet
        if self._sel_r < 0:
            if is_human(self._board[r][c]):
                all_m = all_moves(self._board, P_HUMAN)
                has_jumps = any(len(path) > 2 for dummy1, dummy2, path in all_m)
                piece_paths = [path for fr, fc, path in all_m if fr == r and fc == c]

                if has_jumps:
                    piece_paths = [p for p in piece_paths if len(p) > 2]

                if piece_paths:
                    self._sel_r = r
                    self._sel_c = c
                    self._valid_paths = piece_paths
                    self["w_status"].setText(_("Piece selected. Choose target."))
                else:
                    if has_jumps:
                        self["w_status"].setText(_("You must capture! Select a piece that can jump."))
                    else:
                        self["w_status"].setText(_("No moves for this piece!"))
            else:
                self["w_status"].setText(_("Select one of your pieces!"))
        else:
            # Piece selected, check if target is valid
            matching = [path for path in self._valid_paths if path[-1] == (r, c)]

            if matching:
                path = matching[0]
                self._board = apply_path(self._board, path)
                self._moves += 1
                self._sel_r = -1
                self._sel_c = -1
                self._valid_paths = []

                w = check_win(self._board)
                if w != P_NONE:
                    self._on_win(w)
                    return

                self._turn = P_AI
                self["w_status"].setText(_("Enigma is thinking..."))
                self._render()
                self._ai_timer.start(100, True)

            elif is_human(self._board[r][c]):
                # Select a different piece
                all_m = all_moves(self._board, P_HUMAN)
                has_jumps = any(len(path) > 2 for dummy1, dummy2, path in all_m)
                piece_paths = [path for fr, fc, path in all_m if fr == r and fc == c]

                if has_jumps:
                    piece_paths = [p for p in piece_paths if len(p) > 2]

                if piece_paths:
                    self._sel_r = r
                    self._sel_c = c
                    self._valid_paths = piece_paths
                    self["w_status"].setText(_("Piece selected. Choose target."))
                else:
                    self["w_status"].setText(_("No moves for this piece!"))
            else:
                self["w_status"].setText(_("Invalid move!"))

        self._render()

    def _do_ai_move(self):
        """Start AI move calculation in background thread."""
        self._ai_timer.stop()

        self["w_status"].setText(_("Enigma is thinking..."))
        self._render()

        self._ai_queue = Queue()
        self._ai_thread = threading.Thread(
            target=self._ai_worker_thread,
            args=(copy.deepcopy(self._board),)
        )
        self._ai_thread.daemon = True
        self._ai_thread.start()

        self._ai_check_timer = eTimer()
        self._ai_check_timer.callback.append(self._check_ai_queue)
        self._ai_check_timer.start(100, True)

    def _ai_worker_thread(self, board):
        """Worker thread for AI calculation."""
        try:
            move = ai_best_move(board)
            self._ai_queue.put(move)
        except Exception as e:
            print("AI worker error:", e)
            self._ai_queue.put(None)

    def _check_ai_queue(self):
        """Check if AI calculation is complete."""
        if self._ai_queue is not None and not self._ai_queue.empty():
            if self._ai_check_timer:
                self._ai_check_timer.stop()
            move = self._ai_queue.get()
            self._on_ai_move_calculated(move)

    def _on_ai_move_calculated(self, move):
        """Process the calculated AI move."""
        if move:
            dummy1, dummy2, path = move
            self._board = apply_path(self._board, path)
            self._moves += 1
            captured = len(path) - 2
            if captured > 0:
                self["w_status"].setText(_("Enigma captured %d piece(s). Your turn.") % captured)
            else:
                self["w_status"].setText(_("Enigma moved. Your turn."))
        else:
            self["w_status"].setText(_("Enigma has no moves!"))

        w = check_win(self._board)
        if w != P_NONE:
            self._on_win(w)
            return

        self._turn = P_HUMAN
        self._update_hud()
        self._render()

    def _on_win(self, winner):
        """Handle win condition."""
        self._game_over = True
        self._ai_timer.stop()
        if self._ai_check_timer:
            self._ai_check_timer.stop()

        if winner == P_HUMAN:
            if self._hi == 0 or self._moves < self._hi:
                self._hi = self._moves
                self._save_hi()
            self["w_status"].setText(_("You win in %d moves! Press OK for new game") % self._moves)
        else:
            self["w_status"].setText(_("Enigma wins! Press OK for new game"))

        self._discard = True
        self._update_hud()
        self._render()

    def _render(self):
        """Render the game board."""
        if not self["bg"].instance:
            return

        draw_board_svg(
            self._board,
            self._cursor_r, self._cursor_c,
            self._sel_r, self._sel_c,
            self._valid_paths,
            self._sw, self._sh,
            "/tmp/dame_board.svg")

        px = LoadPixmap("/tmp/dame_board.svg")
        if px:
            self["bg"].instance.setPixmap(px)

        self._update_hud()

    def _update_hud(self):
        """Update HUD display."""
        self["w_h_pieces"].setText(str(count_pieces(self._board, P_HUMAN)))
        self["w_a_pieces"].setText(str(count_pieces(self._board, P_AI)))
        self["w_moves"].setText(str(self._moves))
        self["w_hi"].setText(str(self._hi) if self._hi else "-")

    def _load_hi(self):
        """Load highscore from save file."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    self._hi = json.load(f).get("hi", 0)
        except Exception:
            pass

    def _save_hi(self):
        """Save highscore to save file."""
        try:
            d = {}
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
            d["hi"] = self._hi
            with open(SAVE_FILE, "w") as f:
                json.dump(d, f)
        except Exception:
            pass

    def _load_state(self):
        """Load saved game state."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                if "state" not in d:
                    return False
                s = d["state"]
                self._board = s["board"]
                self._cursor_r = s.get("cursor_r", 5)
                self._cursor_c = s.get("cursor_c", 0)
                self._sel_r = s.get("sel_r", -1)
                self._sel_c = s.get("sel_c", -1)
                self._valid_paths = [[tuple(p) for p in path] for path in s.get("valid_paths", [])]
                self._turn = s["turn"]
                self._moves = s.get("moves", 0)
                self._game_over = s.get("game_over", False)
                self._hi = d.get("hi", 0)
                if self._turn == P_AI:
                    self._turn = P_HUMAN
                return True
        except Exception:
            pass
        return False

    def _save_state(self):
        """Save current game state."""
        try:
            d = {}
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)

            if not self._discard and not self._game_over:
                d["state"] = {
                    "board": self._board,
                    "cursor_r": self._cursor_r,
                    "cursor_c": self._cursor_c,
                    "sel_r": self._sel_r,
                    "sel_c": self._sel_c,
                    "valid_paths": [list(path) for path in self._valid_paths],
                    "turn": self._turn,
                    "moves": self._moves,
                    "game_over": self._game_over,
                }
            elif "state" in d:
                del d["state"]

            d["hi"] = self._hi
            with open(SAVE_FILE, "w") as f:
                json.dump(d, f)
        except Exception:
            pass

    def _delete_state(self):
        """Delete saved game state."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                d.pop("state", None)
                with open(SAVE_FILE, "w") as f:
                    json.dump(d, f)
        except Exception:
            pass

    def _new_game(self):
        """Start a new game."""
        self._ai_timer.stop()
        if self._ai_check_timer:
            self._ai_check_timer.stop()
        self._delete_state()
        self._init_game()
        self._render()

    def _exit(self):
        """Exit the game."""
        self._ai_timer.stop()
        if self._ai_check_timer:
            self._ai_check_timer.stop()
        self._save_state()
        self.close(False)

    def _cleanup(self):
        """Clean up temporary files and threads."""
        try:
            self._ai_timer.stop()
        except Exception:
            pass

        try:
            if self._ai_check_timer:
                self._ai_check_timer.stop()
        except Exception:
            pass

        try:
            if os.path.exists("/tmp/dame_board.svg"):
                os.remove("/tmp/dame_board.svg")
            for f in glob.glob("/tmp/dame_*.svg"):
                try:
                    os.remove(f)
                except Exception:
                    pass
        except Exception:
            pass


def main(session, **kwargs):
    session.open(DameScreen, resume=True)


def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return PluginDescriptor(
        name=_("Dame"),
        description=_("Dame v.%s") % __version__,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="dame.svg",
        fnc=main
    )
