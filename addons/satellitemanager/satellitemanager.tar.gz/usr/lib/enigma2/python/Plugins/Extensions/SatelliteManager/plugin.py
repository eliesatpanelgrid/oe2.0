# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
    try:
        from .SatManager import SatManagerMain
        session.open(SatManagerMain)
    except Exception as e:
        from Screens.MessageBox import MessageBox
        session.open(MessageBox, _("خطأ في تحميل البلاجن:\n%s") % str(e), MessageBox.TYPE_ERROR)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Satellite Manager",
            description="Manage Your Satellites & Transponders List",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png", 
            fnc=main
        )
    ]