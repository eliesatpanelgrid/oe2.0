#!/usr/bin/env python
# -*- coding: utf-8 -*-
# by digiteng...06.2020, 11.2020, 11.2021, 12.2021, 01.2022
# mod by mnasr...03.2026
from __future__ import absolute_import
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
import Tools.Notifications
import os
import re
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, \
getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger, ConfigSelectionNumber, \
ConfigDirectory, ConfigClock, NoSave
from Components.ConfigList import ConfigListScreen
from enigma import eTimer, eLabel, ePixmap, eSize, ePoint, loadJPG, loadPNG, eEPGCache, \
getDesktop, addFont, eServiceReference, eServiceCenter
from Components.Sources.StaticText import StaticText
from Screens.VirtualKeyBoard import VirtualKeyBoard
from PIL import Image
from Screens.LocationBox import LocationBox
import socket
import requests
import json

from Components.ProgressBar import ProgressBar
from Screens.ChoiceBox import ChoiceBox
import shutil
from .xtraSelectionList import xtraSelectionList, xtraSelectionEntryComponent
from Plugins.Extensions.xtraEvent.skins.xtraSkins import *
from Plugins.Extensions.xtraEvent.xtraTitleHelper import *
from .user_agents import get_random_ua
from threading import Timer
from datetime import datetime
import time
from Components.config import config
# --------------------------- Logfile -------------------------------

from datetime import datetime, timedelta
from shutil import copyfile
from os import remove
from os.path import isfile

########################### log file loeschen ##################################
dir_path = "/tmp/xtraevent"

try:
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print("Directory has been created:", dir_path)
    else:
        print("Directory already exists:", dir_path)
except Exception as e:
    print("Error creating directory:", e)

myfile=dir_path + "/xtra.log"
## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
############################## File copieren ############################################
# fuer py2 die int und str anweisung raus genommen und das Grad zeichen

###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus
logstatus = "on"
# kann man erst nach den config values abschalten 328
# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return
# =================================================================================================================
version = "v7.1"
UPDATE_VERSION_URL = "https://github.com/popking159/xtraeventplugin/raw/refs/heads/main/version.txt"
UPDATE_IPK_URL_TEMPLATE = "https://github.com/popking159/xtraeventplugin/raw/refs/heads/main/enigma2-plugin-extensions-xtraevent_{version}_all.ipk"
API_BACKUP_DIR = "/etc/enigma2/xtraevent"
API_BACKUP_FILE = os.path.join(API_BACKUP_DIR, "api.json")
# ==================================================================================================================
# ----------------------------- This is what the command must look like to write to the file.  ------------------------------

logout(data=str(version))

def get_headers():
    try:
        ua = get_random_ua()
        #logout(data="user-agent selected={}".format(ua))
        return {"User-Agent": ua}
    except Exception as err:
        logout(data="get_headers fallback error={}".format(err))
        return {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

headers = get_headers()
logout(data="user-agent selected={}".format(headers))

def safe_str(value):
    try:
        if value is None:
            return ""
        return str(value).strip()
    except:
        return ""


def clean_movie_filename(name):
    """
    Clean movie filename and keep only the real movie title + optional year.

    Examples:
        Eden.2024.720p.WEBRip.x264.AAC-[YTS.MX].mp4 -> Eden 2024
        The Accountant 2 (2025).mp4 -> The Accountant 2 2025
        M3GAN.2.0.2025.720p...mkv -> M3GAN 2.0 2025
        F1.The.Movie.2025...mp4 -> F1 The Movie 2025
        Crime 101 2026 1080p WEB Line HEVC x265 BONE.mkv -> Crime 101 2026
    """
    try:
        name = safe_str(name)

        # Keep only standalone movie containers
        if not re.search(r'\.(mp4|mkv|avi)$', name, flags=re.IGNORECASE):
            return ""

        # Remove extension
        name = re.sub(r'\.(mp4|mkv|avi)$', '', name, flags=re.IGNORECASE)

        # Skip episodic content
        if re.search(r'\bS\d{1,2}E\d{1,3}\b', name, flags=re.IGNORECASE):
            return ""

        # Normalize separators
        name = name.replace('_', ' ')
        name = name.replace('.', ' ')
        name = re.sub(r'\s{2,}', ' ', name).strip()

        # Remove bracket groups that are mostly release tags
        name = re.sub(r'\[[^\]]+\]', ' ', name)
        name = re.sub(r'\{[^\}]+\}', ' ', name)
        name = re.sub(r'\([^\)]*(YTS|PSA|RARBG|Rapta|NeoNoir|GalaxyRG|BONE)[^\)]*\)', ' ', name, flags=re.IGNORECASE)

        # Remove common release / source / codec / audio tags
        garbage_patterns = [
            r'\b(480p|576p|720p|1080p|2160p)\b',
            r'\b(WEBRip|WEB[\- ]DL|WEB|BluRay|BRRip|BDRip|DVDRip|HDRip|HDTV)\b',
            r'\b(Line|LiNE)\b',
            r'\b(x264|x265|h264|h265|HEVC|AVC)\b',
            r'\b(8bit|10bit|10bits|12bit)\b',
            r'\b(HDR|DV|Dolby Vision)\b',
            r'\b(AAC|AC3|DD|DDP|DTS|Atmos)\b',
            r'\b(2CH|6CH|7CH|Dual Audio)\b',
            r'\b(REPACK|PROPER|INTERNAL|EXTENDED|UNRATED|REMUX)\b',
            r'\b(YTS|YTS MX|YTS BZ|PSA|Rapta|GalaxyRG|NeoNoir|RARBG|BONE)\b',
            r'\b(mp4|mkv|avi)\b',
        ]

        for p in garbage_patterns:
            name = re.sub(p, ' ', name, flags=re.IGNORECASE)

        # Remove audio/channel variants that become split after dot replacement
        split_audio_patterns = [
            r'\bAAC\s*5\s*1\b',
            r'\bDDP\s*5\s*1\b',
            r'\bDD\s*5\s*1\b',
            r'\bAC3\s*5\s*1\b',
            r'\bDTS\s*5\s*1\b',
            r'\bAAC\s*2\s*0\b',
            r'\bDDP\s*2\s*0\b',
            r'\bDD\s*2\s*0\b',
        ]
        for p in split_audio_patterns:
            name = re.sub(p, ' ', name, flags=re.IGNORECASE)

        # Remove leftover release-group style tails
        name = re.sub(r'\b\w+-\w+\b$', ' ', name)
        name = re.sub(r'\b[A-Za-z0-9]+\.(MX|BZ)\b', ' ', name, flags=re.IGNORECASE)

        # Normalize brackets and dashes
        name = name.replace('(', ' ').replace(')', ' ')
        name = re.sub(r'\s*-\s*', ' - ', name)
        name = re.sub(r'\s{2,}', ' ', name).strip()

        # Preserve decimal titles like 2.0
        name = re.sub(
            r'\b(\d+)\s+(\d+)\b',
            lambda m: "{}.{}".format(m.group(1), m.group(2)) if len(m.group(2)) == 1 else m.group(0),
            name
        )

        # Keep one year if present
        years = re.findall(r'\b(19\d{2}|20\d{2})\b', name)
        keep_year = years[0] if years else ""

        # Remove duplicate year occurrences from body, then append once
        if keep_year:
            body = re.sub(r'\b(19\d{2}|20\d{2})\b', ' ', name)
            body = re.sub(r'\s*-\s*', ' ', body)
            body = re.sub(r'\s{2,}', ' ', body).strip()
            name = "{} {}".format(body, keep_year).strip()
        else:
            name = re.sub(r'\s*-\s*', ' ', name)
            name = re.sub(r'\s{2,}', ' ', name).strip()

        # Final cleanup
        name = re.sub(r'\s{2,}', ' ', name).strip()
        name = re.sub(r'\s*-\s*$', '', name).strip()

        return name

    except Exception as err:
        logout(data="clean_movie_filename error={}".format(str(err)))
        return ""

try:
    logout(data="xtra 2")
    import sys
    infoPY = sys.version_info[0]
    if infoPY == 3:
        from builtins import str
        from builtins import range
        from builtins import object
        from configparser import ConfigParser
        from _thread import start_new_thread
    else:
        from ConfigParser import ConfigParser
        from thread import start_new_thread
except:
    pass
try:
    logout(data="xtra 3")
    if config.plugins.xtraEvent.tmdbAPI.value != "":
        tmdb_api = config.plugins.xtraEvent.tmdbAPI.value
    else:
        logout(data="xtra 4")
        tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
    if config.plugins.xtraEvent.tvdbAPI.value != "":
        logout(data="xtra 5")
        tvdb_api = config.plugins.xtraEvent.tvdbAPI.value
    else:
        logout(data="xtra 6")
        tvdb_api = "a99d487bb3426e5f3a60dea6d3d3c7ef"
    if config.plugins.xtraEvent.fanartAPI.value != "":
        logout(data="xtra 7")
        fanart_api = config.plugins.xtraEvent.fanartAPI.value
    else:
        logout(data="xtra 8")
        fanart_api = "6d231536dea4318a88cb2520ce89473b"
except:
    pass

try:
    logout(data="xtra 9")
    from Components.Language import language
    lang = language.getLanguage()
    lang = lang[:2]
except:
    logout(data="xtra 10")
    try:
        logout(data="xtra 11")
        lang = config.osd.language.value[:-3]
    except:
        logout(data="xtra 12")
        lang = "en"

lang_path = r"/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/languages"
try:
    logout(data="xtra 13")
    lng = ConfigParser()
    if infoPY == 3:
        lng.read(lang_path,	 encoding='utf8')
    else:
        lng.read(lang_path)
    lng.get(lang, "0")
except:
    try:
        lang="en"
        lng = ConfigParser()
        if infoPY == 3:
            lng.read(lang_path,	 encoding='utf8')
        else:
            lng.read(lang_path)
    except:
        pass

desktop_size = getDesktop(0).size().width()
epgcache = eEPGCache.getInstance()
logout(data="xtra 14")
#config.plugins.xtraEvent.searchType.value(default ='multi')
config.plugins.xtraEvent = ConfigSubsection()
config.plugins.xtraEvent.onoff = ConfigYesNo(default = True)
config.plugins.xtraEvent.skinSelect = ConfigSelection(default = "skin_1", choices = [("skin_1"), ("skin_2")])
config.plugins.xtraEvent.skinSelectColor = ConfigSelection(default = "#3478c1", choices = [
    ("#3478c1", "Blue"),
    ("#4682B4","Steel Blue"),
    ("#ea5b5b","Red"),
    ("#8B0000","Dark Red"),
    ("#8B4513","Saddle Brown"),
    ("#008080","Teal"),
    ("#4F4F4F","Gray31"),
    ("#4f5b66","Space Gray"),
    ("#008B8B","Dark Cyan"),
    ("#2E8B57","SeaGreen"),
    ])
config.plugins.xtraEvent.loc = ConfigDirectory(default='/tmp/')
config.plugins.xtraEvent.searchMOD = ConfigSelection(default = lng.get(lang, '13'), choices = [(lng.get(lang, '13')), (lng.get(lang, '14')), (lng.get(lang, '14a'))])
config.plugins.xtraEvent.searchNUMBER = ConfigSelectionNumber(0, 999, 1, default=50)
# ------------------------------------------------- hier 50 next events downloaden , ca fuer 1 Tag
# config.plugins.xtraEvent.timerMod = ConfigYesNo(default = False)
config.plugins.xtraEvent.timerMod = ConfigSelection(default="Clock", choices=[
    ("-1", _("Disable")),
    ("Period"),
    ("Clock"),
    ])

logout(data="xtra 16")
config.plugins.xtraEvent.timerHour = ConfigSelectionNumber(1, 168, 1, default=1)
config.plugins.xtraEvent.timerClock = ConfigClock(default=0)
config.plugins.xtraEvent.deletFiles = ConfigYesNo(default = True)
config.plugins.xtraEvent.logFiles = ConfigYesNo(default = False)
config.plugins.xtraEvent.logoFiles = ConfigYesNo(default = False)
config.plugins.xtraEvent.castsFiles = ConfigYesNo(default = False)
config.plugins.xtraEvent.searchMANUELnmbr = ConfigSelectionNumber(0, 999, 1, default=1)
config.plugins.xtraEvent.searchMANUELyear = ConfigInteger(default = 0, limits=(0, 9999))
config.plugins.xtraEvent.imgNmbr = ConfigSelectionNumber(0, 999, 1, default=1)
config.plugins.xtraEvent.searchModManuel = ConfigSelection(default = lng.get(lang, '16'), choices = [(lng.get(lang, '16')), (lng.get(lang, '17'))])
config.plugins.xtraEvent.EMCloc = ConfigDirectory(default='/media/hdd/movie/')
config.plugins.xtraEvent.apis = ConfigYesNo(default = False)
config.plugins.xtraEvent.tmdbAPI = ConfigText(default="", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.tvdbAPI = ConfigText(default="", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.omdbAPI = ConfigText(default="", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.fanartAPI = ConfigText(default="", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.searchMANUEL_EMC = ConfigText(default="movies name", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.searchMANUEL = ConfigText(default="event name", visible_width=100, fixed_size=False)
# config.plugins.xtraEvent.searchLang = ConfigText(default="", visible_width=100, fixed_size=False)
config.plugins.xtraEvent.skipSportEvents = ConfigYesNo(default = True)
config.plugins.xtraEvent.searchLang = ConfigYesNo(default = True)
config.plugins.xtraEvent.translatePlot = ConfigYesNo(default = False)
config.plugins.xtraEvent.translatePlotLang = ConfigSelection(
    default="ar",
    choices=[
        ("ar", "Arabic"),
        ("en", "English"),
        ("de", "German"),
        ("fr", "French"),
        ("es", "Spanish"),
        ("it", "Italian"),
        ("tr", "Turkish"),
        ("ru", "Russian")
    ]
)
config.plugins.xtraEvent.translateEventName = ConfigYesNo(default = False)
config.plugins.xtraEvent.translateEventNameLang = ConfigSelection(
    default="ar",
    choices=[
        ("ar", "Arabic"),
        ("en", "English"),
        ("de", "German"),
        ("fr", "French"),
        ("es", "Spanish"),
        ("it", "Italian"),
        ("tr", "Turkish"),
        ("ru", "Russian")
    ]
)
config.plugins.xtraEvent.tmdb = ConfigYesNo(default = True)
config.plugins.xtraEvent.tmdb_backdrop = ConfigYesNo(default = True)
config.plugins.xtraEvent.tvdb = ConfigYesNo(default = False)
config.plugins.xtraEvent.tvdb_backdrop = ConfigYesNo(default = True)
config.plugins.xtraEvent.tvdb_banner = ConfigYesNo(default = True)
config.plugins.xtraEvent.maze = ConfigYesNo(default = False)
config.plugins.xtraEvent.fanart = ConfigYesNo(default = False)
config.plugins.xtraEvent.fanart_backdrop = ConfigYesNo(default = False)
config.plugins.xtraEvent.fanart_banner = ConfigYesNo(default = False)
config.plugins.xtraEvent.bing = ConfigYesNo(default = False)
config.plugins.xtraEvent.extra = ConfigYesNo(default = True)
config.plugins.xtraEvent.extra2 = ConfigYesNo(default = False)
config.plugins.xtraEvent.extra3 = ConfigYesNo(default = False)
config.plugins.xtraEvent.poster = ConfigYesNo(default = True)
config.plugins.xtraEvent.onDemandPosterDownload = ConfigYesNo(default = False)
config.plugins.xtraEvent.banner = ConfigYesNo(default = False)
config.plugins.xtraEvent.backdrop = ConfigYesNo(default = True)
config.plugins.xtraEvent.onDemandBackdropDownload = ConfigYesNo(default = False)
config.plugins.xtraEvent.logo = ConfigYesNo(default = False)
config.plugins.xtraEvent.onDemandLogoDownload = ConfigYesNo(default = False)
config.plugins.xtraEvent.info = ConfigYesNo(default = True)
config.plugins.xtraEvent.onDemandDownload = ConfigYesNo(default = False)
config.plugins.xtraEvent.infoProvider = ConfigSelection(
    default="omdb",
    choices=[
        ("omdb", "OMDB"),
        ("tmdb", "TMDB")
    ]
)
config.plugins.xtraEvent.opt_Images = ConfigYesNo(default = False)
config.plugins.xtraEvent.cnfg = ConfigYesNo(default = True)
config.plugins.xtraEvent.cnfgSel = ConfigSelection(default = "poster", choices = [("poster"), ("banner"), ("backdrop"), ("EMC")])
config.plugins.xtraEvent.TMDBpostersize = ConfigSelection(default="w185", choices = [
    ("w92", "92x138"),
    ("w154", "154x231"),
    ("w185", "185x278"),
    ("w342", "342x513"),
    ("w500", "500x750"),
    ("w780", "780x1170"),
    ("original", "ORIGINAL")])
config.plugins.xtraEvent.TVDBpostersize = ConfigSelection(default="thumbnail", choices = [
    ("thumbnail", "340x500"),
    ("fileName", "original(680x1000)")])
config.plugins.xtraEvent.TMDBbackdropsize = ConfigSelection(default="w300", choices = [
    ("w300", "300x170"),
    ("w780", "780x440"),
    ("w1280", "1280x720"),
    ("original", "ORIGINAL")])
config.plugins.xtraEvent.TMDBlogosize = ConfigSelection(default="w300", choices = [
    ("w92", "92px"),
    ("w154", "154px"),
    ("w185", "185px"),
    ("w300", "300px"),
    ("w500", "500px"),
    ("original", "ORIGINAL")])
config.plugins.xtraEvent.TVDBbackdropsize = ConfigSelection(default="thumbnail", choices = [
    ("thumbnail", "640x360"),
    ("fileName", "original(1920x1080)")])
config.plugins.xtraEvent.FANART_Poster_Resize = ConfigSelection(default="10", choices = [
    ("10", "100x142"),
    ("5", "200x285"),
    ("3", "333x475"),
    ("2", "500x713"),
    ("1", "1000x1426")])
config.plugins.xtraEvent.FANART_Backdrop_Resize = ConfigSelection(default="2", choices = [
    ("2", "original/2"),
    ("1", "original")])
config.plugins.xtraEvent.imdb_Poster_size = ConfigSelection(default="185", choices = [
    ("185", "185x278"),
    ("344", "344x510"),
    ("500", "500x750")])
config.plugins.xtraEvent.PB = ConfigSelection(default="posters", choices = [
    ("posters", "Poster"),
    ("backdrops", "Backdrop"),
    ("logos", "Logo")])
config.plugins.xtraEvent.srcs = ConfigSelection(default="TMDB", choices = [
    ('TMDB', 'TMDB'),
    ('TVDB', 'TVDB'),
    ('FANART', 'FANART'),
    ('IMDB(poster)', 'IMDB(poster)'),
    ('Bing', 'Bing'),
    ('Google', 'Google')])
config.plugins.xtraEvent.searchType = ConfigSelection(default="tv", choices = [
    ('tv', 'TV'),
    ('movie', 'MOVIE'),
    ('multi', 'MULTI')])
config.plugins.xtraEvent.FanartSearchType = ConfigSelection(default="tv", choices = [
    ('tv', 'TV'),
    ('movies', 'MOVIE')])
config.plugins.xtraEvent.TVDB_Banner_Size = ConfigSelection(default="1", choices = [
    ("1", "758x140"),
    ("2", "379x70"),
    ("4", "190x35")])
config.plugins.xtraEvent.FANART_Banner_Size = ConfigSelection(default="1", choices = [
    ("1", "1000x185"),
    ("2", "500x92"),
    ("4", "250x46"),
    ("8", "125x23")
    ])
logout(data="xtra configs end and logfile off or on, false off, true on")
logout(data=str(config.plugins.xtraEvent.logFiles.value))
if config.plugins.xtraEvent.logFiles.value == True:
    logstatus = "on"
else:
    logstatus = "off"

pathMovie = config.plugins.xtraEvent.EMCloc.value
pathXtra = os.path.join(config.plugins.xtraEvent.loc.value, "xtraEvent")
listdir_path = os.listdir(pathMovie)
movielist_path = os.path.join(pathMovie, "movielist.txt")
# --------------------------------------------- check direktories -----------------------------------------------------

logout("First, check all the paths.")
pathLoc = ""
logout(data="location")
logout(data=str(config.plugins.xtraEvent.loc.value))
pathLoc = "{}xtraEvent/".format(config.plugins.xtraEvent.loc.value)
logout(data="path location")
logout(data=str(pathLoc))

if not os.path.exists(pathLoc):
	logout(data="-----  The path location is no longer available; it will be set to TMP.")
	config.plugins.xtraEvent.loc.value = "/tmp/"
	logout(data=str(config.plugins.xtraEvent.loc.value))
	pathLoc = "{}fallbackxtraEvent/".format(config.plugins.xtraEvent.loc.value)
	logout(data="path location")
	logout(data=str(pathLoc))


logout("Check all paths and create a directory.")
if not os.path.exists("{}poster".format(pathLoc)):
    os.makedirs("{}poster".format(pathLoc))

if not os.path.exists("{}poster/dummy".format(pathLoc)):
    os.makedirs("{}poster/dummy".format(pathLoc))

if not os.path.exists("{}banner".format(pathLoc)):
    os.makedirs("{}banner".format(pathLoc))

if not os.path.exists("{}banner/dummy".format(pathLoc)):
    os.makedirs("{}banner/dummy".format(pathLoc))

if not os.path.exists("{}backdrop".format(pathLoc)):
    os.makedirs("{}backdrop".format(pathLoc))

if not os.path.exists("{}backdrop/dummy".format(pathLoc)):
    os.makedirs("{}backdrop/dummy".format(pathLoc))

if not os.path.exists("{}infos".format(pathLoc)):
    os.makedirs("{}infos".format(pathLoc))

if not os.path.exists("{}logo/dummy".format(pathLoc)):
    os.makedirs("{}logo/dummy".format(pathLoc))

if not os.path.exists("{}logo".format(pathLoc)):
    os.makedirs("{}logo".format(pathLoc))

if not os.path.exists("{}casts".format(pathLoc)):
    os.makedirs("{}casts".format(pathLoc))

if not os.path.exists("{}infosomdb".format(pathLoc)):
    os.makedirs("{}infosomdb".format(pathLoc))

if not os.path.exists("{}infosomdbsterne".format(pathLoc)):
    os.makedirs("{}infosomdbsterne".format(pathLoc))

if not os.path.exists("{}infosomdbrated".format(pathLoc)):
    os.makedirs("{}infosomdbrated".format(pathLoc))

if not os.path.exists("{}infossterne".format(pathLoc)):
    os.makedirs("{}infossterne".format(pathLoc))

if not os.path.exists("{}infostmdbstar".format(pathLoc)):
    os.makedirs("{}infostmdbstar".format(pathLoc))

if not os.path.exists("{}infostmdbrated".format(pathLoc)):
    os.makedirs("{}infostmdbrated".format(pathLoc))

if not os.path.exists("{}infoselcinema".format(pathLoc)):
    os.makedirs("{}infoselcinema".format(pathLoc))

if not os.path.exists("{}infoselcinemastars".format(pathLoc)):
    os.makedirs("{}infoselcinemastars".format(pathLoc))

if not os.path.exists("{}infoselcinemarated".format(pathLoc)):
    os.makedirs("{}infoselcinemarated".format(pathLoc))

if not os.path.exists("{}noinfos".format(pathLoc)):
    os.makedirs("{}noinfos".format(pathLoc))

if not os.path.exists("{}mSearch".format(pathLoc)):
    os.makedirs("{}mSearch".format(pathLoc))

if not os.path.exists("{}EMC".format(pathLoc)):
    os.makedirs("{}EMC".format(pathLoc))

# ------------------------------- check created available -----------------------------------------------------------

if os.path.exists("{}poster".format(pathLoc)):
    logout(data="poster available")

if os.path.exists("{}poster/dummy".format(pathLoc)):
    logout(data="poster/dummy available")

if os.path.exists("{}backdrop".format(pathLoc)):
    logout(data="backdrop available")

if os.path.exists("{}backdrop/dummy".format(pathLoc)):
    logout(data="backdrop/dummy available")

if os.path.exists("{}logo".format(pathLoc)):
    logout(data="logo available")

if os.path.exists("{}casts".format(pathLoc)):
    logout(data="casts available")

if os.path.exists("{}logo/dummy".format(pathLoc)):
    logout(data="logo/dummy available")

if os.path.exists("{}banner".format(pathLoc)):
    logout(data="banner available")

if os.path.exists("{}banner/dummy".format(pathLoc)):
    logout(data="banner/dummy available")

if os.path.exists("{}infos".format(pathLoc)):
    logout(data="infos available")

if os.path.exists("{}infosomdb".format(pathLoc)):
    logout(data="infosomdb available")

if os.path.exists("{}infosomdbsterne".format(pathLoc)):
    logout(data="infosomdbsterne available")

if os.path.exists("{}infosomdbrated".format(pathLoc)):
    logout(data="infosomdbrated available")

if os.path.exists("{}infossterne".format(pathLoc)):
    logout(data="infossterne available")

if os.path.exists("{}infostmdbrated".format(pathLoc)):
    logout(data="infostmdbrated available")

if os.path.exists("{}infostmdbstar".format(pathLoc)):
    logout(data="infostmdbstar available")

if os.path.exists("{}noinfos".format(pathLoc)):
    logout(data="noinfos available")

if os.path.exists("{}mSearch".format(pathLoc)):
    logout(data="mSearch available")

if os.path.exists("{}EMC".format(pathLoc)):
    logout(data="EMC available")

    # ---------------------------------------------------------------------------------------------------------------------


class xtra(Screen, ConfigListScreen):
    logout(data="xtra class screen")
    def __init__(self, session):
        logout(data="init")
        self.session = session
        Screen.__init__(self, session)

        if desktop_size <= 1280:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = xtra_720
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = xtra_720_2
        else:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = xtra_1080
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = xtra_1080_2

        list = []
        ConfigListScreen.__init__(self, list, session=session)

        self['key_red'] = Label(_('exit'))
        self['key_green'] = Label(_(lng.get(lang, '40')))
        self['key_yellow'] = Label(_('Backup/Restore'))
        self['key_blue'] = Label(_(lng.get(lang, '18')))
        self["actions"] = ActionMap(["xtraEventAction"],
        {
            "left": self.keyLeft,
            "down": self.keyDown,
            "up": self.keyUp,
            "right": self.keyRight,
            "red": self.exit,
            "green": self.search,
            "yellow": self.apiBackupRestoreMenu,
            "blue": self.ms,
            "cancel": self.exit,
            "ok": self.keyOK,
            #"info": self.strg,
            "menu": self.menuS
        },-1)

        self.setTitle(_("xtraEvent {}".format(version)))
        self['status'] = Label()
        #self['info'] = Label()
        self['int_statu'] = Label()
        self['help'] = StaticText()

        self.timer = eTimer()
        self.timer.callback.append(self.xtraList)
        self.startupUpdateTimer = eTimer()
        self.startupUpdateTimer.callback.append(self.checkForUpdateOnOpen)
        self.onLayoutFinish.append(self.xtraList)
        self.onLayoutFinish.append(self.startupUpdateCheck)
        self.intCheck()

    def startupUpdateCheck(self):
        logout(data="startupUpdateCheck")
        try:
            self.startupUpdateTimer.start(800, True)
        except Exception as err:
            logout(data="startupUpdateCheck error={}".format(str(err)))

    def versionTuple(self, value):
        try:
            cleaned = str(value or '').strip().lower().replace('version', '').replace('=', '').replace('"', '').replace("'", '')
            cleaned = cleaned.replace('v', '')
            return tuple(int(x) for x in cleaned.split('.') if x.strip().isdigit())
        except Exception:
            return (0,)

    def fetchUpdateInfo(self):
        logout(data="fetchUpdateInfo")
        response = requests.get(UPDATE_VERSION_URL, timeout=10)
        response.raise_for_status()
        content = response.text
        version_match = re.search(r"version\s*=\s*['\"]([^'\"]+)['\"]", content)
        desc_match = re.search(r"description\s*=\s*['\"]([\s\S]*?)['\"]", content)
        if not version_match:
            raise ValueError('version.txt does not contain a valid version entry')
        new_version = version_match.group(1).strip()
        description = ''
        if desc_match:
            description = desc_match.group(1).replace('\n', '\n').strip()
        update_url = UPDATE_IPK_URL_TEMPLATE.format(version=new_version)
        return {
            'version': new_version,
            'description': description,
            'url': update_url
        }

    def checkForUpdateOnOpen(self):
        logout(data="checkForUpdateOnOpen")
        if not self.intCheck():
            return
        try:
            info = self.fetchUpdateInfo()
            if self.versionTuple(info['version']) > self.versionTuple(version):
                msg = "Current version: {}\nNew version: {}\n\n{}\n\nUpdate will start automatically in 10 seconds. Press No to cancel.".format(
                    version,
                    info['version'],
                    info['description'] or 'Update available.'
                )
                self.session.openWithCallback(
                    lambda answer, data=info: self.instalUpdate(answer, data),
                    MessageBox,
                    _(msg),
                    MessageBox.TYPE_YESNO,
                    timeout=10,
                    default=True
                )
            else:
                logout(data="No update available")
        except Exception as err:
            logout(data="checkForUpdateOnOpen error={}".format(str(err)))

    def intCheck(self):
        try:
            socket.setdefaulttimeout(2)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            self['int_statu'].setText("☻")
            return True
        except:
            self['int_statu'].hide()
            self['status'].setText(lng.get(lang, '68'))
            return False

    # def getFolderSizeMB(self, folder_path):
        # try:
            # total_size = 0
            # if os.path.isdir(folder_path):
                # for current_path, folders, files in os.walk(folder_path):
                    # for fname in files:
                        # file_path = os.path.join(current_path, fname)
                        # try:
                            # total_size += os.path.getsize(file_path)
                        # except Exception:
                            # pass
            # return "{:.1f}".format(total_size / (1024.0 * 1024.0))
        # except Exception:
            # return "0.0"

    # def strg(self):
        # if config.plugins.xtraEvent.onoff.value:
            # try:
                # base_path = pathLoc.rstrip('/')
                # folders = [
                    # 'EMC', 'infos', 'infostmdbrated', 'poster',
                    # 'backdrop', 'infosomdb', 'infostmdbstar', 
                    # 'banner', 'infosomdbrated', 'logo', 
                    # 'casts', 'infosomdbsterne', 'mSearch', 'noinfos'
                # ]
                # lines = []
                # for folder_name in folders:
                    # folder_path = os.path.join(base_path, folder_name)
                    # lines.append('{:<16} {} MB'.format(folder_name + ':', self.getFolderSizeMB(folder_path)))
                # self['status'].setText(_(lng.get(lang, '48')))
                # self.session.open(MessageBox, '\n'.join(lines), MessageBox.TYPE_INFO, timeout=0)
            # except Exception as err:
                # with open('/tmp/xtraEvent.log', 'a+') as f:
                    # f.write('xtra-info-strg, %s\n' % (err))
        # else:
            # self.exit()

    def keyOK(self):
        logout(data="key ok")
        if self['config'].getCurrent()[1] is config.plugins.xtraEvent.loc:

            self.session.openWithCallback(self.pathSelected, LocationBox, text=_('Default Folder'), currDir=config.plugins.xtraEvent.loc.getValue(), minFree=100)
        if self['config'].getCurrent()[1] is config.plugins.xtraEvent.cnfgSel:
            self.compressImg()

    def pathSelected(self, res):

        logout(data="path selected 509 ")
        logout(data=str(res))
        import shutil
        if res is not None:
            config.plugins.xtraEvent.loc.value = res
            pathLoc = "{}xtraEvent/".format(config.plugins.xtraEvent.loc.value)
            logout(data="path selected pathLoc ")
            logout(data=str(pathLoc))
            if not os.path.exists(pathLoc):
                logout(data="create directory")
                os.makedirs(pathLoc)
            if not os.path.isdir(pathLoc):
                pathLoc = "/tmp/"

            if not os.path.isdir(pathLoc):
                os.makedirs("{}poster".format(pathLoc))
                os.makedirs("{}poster/dummy".format(pathLoc))
                os.makedirs("{}banner".format(pathLoc))
                os.makedirs("{}banner/dummy".format(pathLoc))
                os.makedirs("{}backdrop".format(pathLoc))
                os.makedirs("{}backdrop/dummy".format(pathLoc))
                os.makedirs("{}infos".format(pathLoc))
                os.makedirs("{}logo".format(pathLoc))
                os.makedirs("{}casts".format(pathLoc))
                os.makedirs("{}logo/dummy".format(pathLoc))
                os.makedirs("{}infosomdb".format(pathLoc))
                os.makedirs("{}infosomdbsterne".format(pathLoc))
                os.makedirs("{}infosomdbrated".format(pathLoc))
                os.makedirs("{}infossterne".format(pathLoc))
                os.makedirs("{}infoselcinema".format(pathLoc))
                os.makedirs("{}infoselcinemastars".format(pathLoc))
                os.makedirs("{}infoselcinemarated".format(pathLoc))
                os.makedirs("{}noinfos".format(pathLoc))
                os.makedirs("{}mSearch".format(pathLoc))
                os.makedirs("{}EMC".format(pathLoc))
                logout(data="path download copy bqts")

            self.updateFinish()
        logout(data="path selected nichts gemacht")
    # ------------------------------------------------ check new folders ---------------------------
    def pathCheck(self):

        if not os.path.isdir(pathLoc):

            logout(data="check neue ordner 523")
            logout(data=str(pathLoc))
            os.makedirs("{}poster".format(pathLoc))
            os.makedirs("{}banner".format(pathLoc))
            os.makedirs("{}backdrop".format(pathLoc))
            os.makedirs("{}infos".format(pathLoc))
            os.makedirs("{}infosomdb".format(pathLoc))
            os.makedirs("{}infosomdbsterne".format(pathLoc))
            os.makedirs("{}infosomdbrated".format(pathLoc))
            os.makedirs("{}infossterne".format(pathLoc))
            os.makedirs("{}infoselcinema".format(pathLoc))
            os.makedirs("{}infoselcinemastars".format(pathLoc))
            os.makedirs("{}infoselcinemarated".format(pathLoc))
            os.makedirs("{}logo".format(pathLoc))
            os.makedirs("{}casts".format(pathLoc))
            os.makedirs("{}logo/dummy".format(pathLoc))
            os.makedirs("{}noinfos".format(pathLoc))
            os.makedirs("{}mSearch".format(pathLoc))
            os.makedirs("{}EMC".format(pathLoc))
            os.makedirs("{}poster/dummy".format(pathLoc))
            os.makedirs("{}banner/dummy".format(pathLoc))
            os.makedirs("{}backdrop/dummy".format(pathLoc))

            logout(data="check neue ordner neu angelegt 536")
        else:
            logout(data="check neue ordner available 538")


    def delay(self):
        logout(data="delay")
        self.timer.start(100, True)

    def xtraList(self):
        logout(data="xtraList")
        for x in self["config"].list:
            if len(x) > 1:
                x[1].save()
        on_color = "\\c0000??00"
        off_color = "\\c00??0000"
        list = []
# CONFIGURATION____________________________________________________________________________________________________________

        if config.plugins.xtraEvent.onoff.value:
            list.append(getConfigListEntry("{}◙ \\c00?????? {}".format(on_color, lng.get(lang, '0')), config.plugins.xtraEvent.onoff, _(lng.get(lang, '0'))))
            list.append(getConfigListEntry("♥   {}".format(lng.get(lang, '1')), config.plugins.xtraEvent.cnfg, _(lng.get(lang, '2'))))
            list.append(getConfigListEntry("Delete Files 3 Day old on", config.plugins.xtraEvent.deletFiles, _(lng.get(lang, '4'))))
            list.append(getConfigListEntry("Logfiles on/off", config.plugins.xtraEvent.logFiles, _(lng.get(lang, '4'))))

            list.append(getConfigListEntry("—"*100))
            if config.plugins.xtraEvent.cnfg.value:
                if config.plugins.xtraEvent.loc.value:
                    list.append(getConfigListEntry("{}".format(lng.get(lang, '3')), config.plugins.xtraEvent.loc, _(lng.get(lang, '4'))))
                else:
                    list.append(getConfigListEntry("{}{}".format(off_color, lng.get(lang, '3')), config.plugins.xtraEvent.loc, _(lng.get(lang, '4'))))
                list.append(getConfigListEntry(lng.get(lang, '5'), config.plugins.xtraEvent.skinSelect, _(lng.get(lang, '19'))))
                if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                    list.append(getConfigListEntry("{}".format(lng.get(lang, '69')), config.plugins.xtraEvent.skinSelectColor, _(lng.get(lang, '19'))))
                list.append(getConfigListEntry(lng.get(lang, '6'), config.plugins.xtraEvent.opt_Images, _(lng.get(lang, '7'))))
                if config.plugins.xtraEvent.opt_Images.value:
                    list.append(getConfigListEntry("\t{}".format(lng.get(lang, '7')), config.plugins.xtraEvent.cnfgSel, _(lng.get(lang, '21'))))
                list.append(getConfigListEntry(lng.get(lang, '22'), config.plugins.xtraEvent.apis, _("...")))
                if config.plugins.xtraEvent.apis.value:
                    list.append(getConfigListEntry("    TMDB API", config.plugins.xtraEvent.tmdbAPI, _(lng.get(lang, '23'))))
                    list.append(getConfigListEntry("    TVDB API", config.plugins.xtraEvent.tvdbAPI, _(lng.get(lang, '23'))))
                    list.append(getConfigListEntry("    OMDB API", config.plugins.xtraEvent.omdbAPI, _(lng.get(lang, '23'))))
                    list.append(getConfigListEntry("    FANART API", config.plugins.xtraEvent.fanartAPI, _(lng.get(lang, '23'))))
                list.append(getConfigListEntry("—"*100))
                list.append(getConfigListEntry(lng.get(lang, '8'), config.plugins.xtraEvent.searchMOD, _(lng.get(lang, '24'))))
                list.append(getConfigListEntry(lng.get(lang, '9'), config.plugins.xtraEvent.searchNUMBER, _(lng.get(lang, '25'))))
                list.append(getConfigListEntry(lng.get(lang, '10'), config.plugins.xtraEvent.searchLang, _(lng.get(lang, '26'))))

                list.append(getConfigListEntry(lng.get(lang, '11'), config.plugins.xtraEvent.timerMod, _(lng.get(lang, '27'))))
                if config.plugins.xtraEvent.timerMod.value:
                    if config.plugins.xtraEvent.timerMod.value == "Period":
                        list.append(getConfigListEntry(lng.get(lang, '46'), config.plugins.xtraEvent.timerHour, _(lng.get(lang, '67'))))
                    elif config.plugins.xtraEvent.timerMod.value == "Clock":
                        list.append(getConfigListEntry(lng.get(lang, '46'), config.plugins.xtraEvent.timerClock, _(lng.get(lang, '67'))))


                list.append(getConfigListEntry("—"*100))
            list.append(getConfigListEntry(" ▀ {}".format(lng.get(lang, '28'))))
            list.append(getConfigListEntry("_"*100))
    # skip words
            list.append(getConfigListEntry("Skip sport/live events", config.plugins.xtraEvent.skipSportEvents, _("Exclude predefined sport/live titles from download and display")))
    # poster__________________________________________________________________________________________________________________
            list.append(getConfigListEntry("POSTER", config.plugins.xtraEvent.poster, _("...")))
            if config.plugins.xtraEvent.poster.value == True:
                list.append(getConfigListEntry("    On-demand poster download", config.plugins.xtraEvent.onDemandPosterDownload, _("Allow xtraPoster to fetch missing posters while rendering")))
                list.append(getConfigListEntry("    TMDB", config.plugins.xtraEvent.tmdb, _(" ")))
                if config.plugins.xtraEvent.tmdb.value:
                    list.append(getConfigListEntry("        Tmdb Poster {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TMDBpostersize, _(" ")))
                    list.append(getConfigListEntry("        {}".format(lng.get(lang, '63')), config.plugins.xtraEvent.searchType, _(" ")))
                list.append(getConfigListEntry("    TVDB", config.plugins.xtraEvent.tvdb, _(lng.get(lang, '29'))))
                if config.plugins.xtraEvent.tvdb.value:
                    list.append(getConfigListEntry("        Tvdb Poster {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TVDBpostersize, _(" ")))
                list.append(getConfigListEntry("    FANART", config.plugins.xtraEvent.fanart, _(lng.get(lang, '29'))))
                if config.plugins.xtraEvent.fanart.value:
                    list.append(getConfigListEntry("        Fanart Poster {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.FANART_Poster_Resize, _(" ")))
                list.append(getConfigListEntry("    MAZE(TV SHOWS)", config.plugins.xtraEvent.maze, _(" ")))
                list.append(getConfigListEntry("_" * 100))

            list.append(getConfigListEntry("BACKDROP", config.plugins.xtraEvent.backdrop, _(" ")))
            if config.plugins.xtraEvent.backdrop.value == True:
                list.append(getConfigListEntry("    On-demand backdrop download", config.plugins.xtraEvent.onDemandBackdropDownload, _("Allow xtraBackdrop to fetch missing backdrops while rendering")))
                list.append(getConfigListEntry("    TMDB", config.plugins.xtraEvent.tmdb_backdrop, _(" ")))
                if config.plugins.xtraEvent.tmdb_backdrop.value:
                    list.append(getConfigListEntry("        Tmdb Backdrop {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TMDBbackdropsize, _(" ")))
                    list.append(getConfigListEntry("        {}".format(lng.get(lang, '63')), config.plugins.xtraEvent.searchType, _(" ")))
                list.append(getConfigListEntry("    TVDB", config.plugins.xtraEvent.tvdb_backdrop, _(" ")))
                if config.plugins.xtraEvent.tvdb_backdrop.value:
                    list.append(getConfigListEntry("        Tvdb Backdrop {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TVDBbackdropsize, _(" ")))
                list.append(getConfigListEntry("    FANART", config.plugins.xtraEvent.fanart_backdrop, _(" ")))
                if config.plugins.xtraEvent.fanart_backdrop.value:
                    list.append(getConfigListEntry("        Fanart Backdrop {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.FANART_Backdrop_Resize, _(" ")))
                list.append(getConfigListEntry("    EXTRA (tvmovie.de)", config.plugins.xtraEvent.extra, _(lng.get(lang, '30'))))
                list.append(getConfigListEntry("    EXTRA-2 (Bing/Google)", config.plugins.xtraEvent.extra2, _(lng.get(lang, '31'))))
                list.append(getConfigListEntry("_" * 100))

            list.append(getConfigListEntry("LOGO", config.plugins.xtraEvent.logoFiles, _(" ")))
            if config.plugins.xtraEvent.logoFiles.value:
                list.append(getConfigListEntry("    On-demand download", config.plugins.xtraEvent.onDemandLogoDownload, _("Allow xtraLogo to fetch missing Logo while rendering")))
                list.append(getConfigListEntry("    Tmdb Logo {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TMDBlogosize, _(" ")))
                list.append(getConfigListEntry("    {}".format(lng.get(lang, '63')), config.plugins.xtraEvent.searchType, _(" ")))
                list.append(getConfigListEntry("_" * 100))

            list.append(getConfigListEntry("BANNER", config.plugins.xtraEvent.banner, _(" ")))
            if config.plugins.xtraEvent.banner.value == True:
                list.append(getConfigListEntry("    TVDB", config.plugins.xtraEvent.tvdb_banner, _(" ")))
                if config.plugins.xtraEvent.tvdb_banner.value:
                    list.append(getConfigListEntry("        Tvdb Banner {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.TVDB_Banner_Size, _(" ")))
                list.append(getConfigListEntry("    FANART", config.plugins.xtraEvent.fanart_banner, _(" ")))
                if config.plugins.xtraEvent.fanart_banner.value:
                    list.append(getConfigListEntry("        Fanart Banner {}".format(lng.get(lang, '49')), config.plugins.xtraEvent.FANART_Banner_Size, _(" ")))
                list.append(getConfigListEntry("_" * 100))

            list.append(getConfigListEntry("CASTS", config.plugins.xtraEvent.castsFiles, _(" ")))
            if config.plugins.xtraEvent.castsFiles.value:
                list.append(getConfigListEntry("_" * 100))

            list.append(getConfigListEntry("INFO", config.plugins.xtraEvent.info, _(lng.get(lang, '32'))))
            if config.plugins.xtraEvent.info.value:
                list.append(getConfigListEntry("    Provider", config.plugins.xtraEvent.infoProvider, _("Select the metadata source for xtraInfo")))
                list.append(getConfigListEntry("    On-demand download", config.plugins.xtraEvent.onDemandDownload, _("Allow xtraInfo to fetch missing metadata while rendering")))
                list.append(getConfigListEntry("    Translate Plot", config.plugins.xtraEvent.translatePlot, _("Translate OMDB plot before saving/showing")))
                if config.plugins.xtraEvent.translatePlot.value:
                    list.append(getConfigListEntry("        Plot Language", config.plugins.xtraEvent.translatePlotLang, _("Target language for translated plot")))
    # elcinema_____________________________________________________________________________________________________________
            list.append(getConfigListEntry("EXTRA-3 (elcinema.com)", config.plugins.xtraEvent.extra3, _(lng.get(lang, '64'))))
            list.append(getConfigListEntry("_"*100))
            list.append(getConfigListEntry("Translate Event Name", config.plugins.xtraEvent.translateEventName, _("Translate Event Name before saving/showing")))
            if config.plugins.xtraEvent.translateEventName.value:
                list.append(getConfigListEntry("    Event Name Language", config.plugins.xtraEvent.translateEventNameLang, _("Target language for translated Event Name")))
            list.append(getConfigListEntry("_"*100))
        else:
            list.append(getConfigListEntry("{}◙ \\c00?????? {}".format(off_color, lng.get(lang, '0')), config.plugins.xtraEvent.onoff, _(lng.get(lang, '0'))))



        # self["config"].l.setItemHeight(50)
        self["config"].list = list
        self["config"].l.setList(list)
        self.help()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.delay()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.delay()

    def keyDown(self):
        self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.delay()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.delay()

    def pageUp(self):
        self["config"].instance.moveSelection(self["config"].instance.pageDown)
        self.delay()

    def pageDown(self):
        self["config"].instance.moveSelection(self["config"].instance.pageUp)
        self.delay()

    def help(self):
        cur = self["config"].getCurrent()
        if cur:
            self["help"].text = cur[2]

    def menuS(self):
        logout(data="------------------ def menuS")
        if config.plugins.xtraEvent.onoff.value:
            list = [(_(lng.get(lang, '50')), self.brokenImageRemove), (_(lng.get(lang, '73')), self.removeImagesAll),\
            (_(lng.get(lang, "75")), self.update), (_(lng.get(lang, '35')), self.exit)]
            self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_('xtraEvent...'), list=list)
        else:
            self.exit()

    def update(self):
        logout(data="------------------ def update")
        try:
            info = self.fetchUpdateInfo()
            if self.versionTuple(info['version']) > self.versionTuple(version):
                msg = "Current version: {}\nNew version: {}\n\n{}\n\nDo you want to update now?".format(
                    version,
                    info['version'],
                    info['description'] or 'Update available.'
                )
                self.session.openWithCallback(
                    lambda answer, data=info: self.instalUpdate(answer, data),
                    MessageBox,
                    _(msg),
                    MessageBox.TYPE_YESNO
                )
            else:
                self.session.open(MessageBox, _('You already have the latest version: {}').format(version), MessageBox.TYPE_INFO, timeout=5)
        except Exception as err:
            self['info'].setText(str(err))
            with open('/tmp/xtraEvent.log', 'a+') as f:
                f.write('update %s\n\n' % err)

    def instalUpdate(self, answer, update_info=None):
        logout(data="------------------ def installUpdate")
        try:
            if answer is not True:
                return

            info = update_info or self.fetchUpdateInfo()
            update_url = info['url']
            up_name = os.path.basename(update_url)
            up_tmp = '/tmp/{}'.format(up_name)

            response = requests.get(update_url, stream=True, allow_redirects=True, timeout=60)
            response.raise_for_status()
            with open(up_tmp, 'wb') as handle:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        handle.write(chunk)

            if os.path.exists(up_tmp) and os.path.getsize(up_tmp) > 0:
                rc = os.system('opkg install "{}"'.format(up_tmp))
                os.system('sync')
                try:
                    os.remove(up_tmp)
                except Exception:
                    pass
                if rc == 0:
                    self.updateInstalledNotice(info['version'])
                else:
                    raise Exception('opkg install failed with code {}'.format(rc))
            else:
                raise Exception('Downloaded update package is missing or empty')
        except Exception as err:
            self.session.open(MessageBox, _('Update failed: {}').format(str(err)), MessageBox.TYPE_ERROR, timeout=10)
            self['info'].setText(str(err))
            with open('/tmp/xtraEvent.log', 'a+') as f:
                f.write('instalUpdate %s\n\n' % err)

    def updateInstalledNotice(self, installed_version=None):
        logout(data="------------------ def updateInstalledNotice")
        note = _('Update installed successfully.')
        if installed_version:
            note = _('xtraEvent {} installed successfully.').format(installed_version)
        note += '\n' + _('GUI restart is required.')
        self.session.openWithCallback(self.restarte2, MessageBox, note, MessageBox.TYPE_INFO, timeout=10)

    def updateFinish(self):
        logout(data="------------------ def updateFinish")
        for x in self["config"].list:
            if len(x) > 1:
                x[1].save()
        logout(data="------------------ def updateFinish configfile save")
        configfile.save()
        logout(data="------------------ def updateFinish configfile save ende")
        self.session.openWithCallback(self.restarte2Confirm, MessageBox, _(lng.get(lang, '70')), MessageBox.TYPE_YESNO)

    def restarte2Confirm(self, answer):
        logout(data="------------------ def restart2Confirm")
        if answer:
            self.session.open(TryQuitMainloop, 3)

    def restarte2(self, answer=None):
        logout(data="------------------ def restart2")
        self.exit()

    def apiBackupRestoreMenu(self):
        logout(data='apiBackupRestoreMenu')
        choices = [
            (_('Backup API keys'), 'backup'),
            (_('Restore API keys'), 'restore')
        ]
        self.session.openWithCallback(self.apiBackupRestoreMenuCallback, ChoiceBox, title=_('API Backup / Restore'), list=choices)

    def apiBackupRestoreMenuCallback(self, choice=None):
        logout(data='apiBackupRestoreMenuCallback')
        if not choice:
            return
        action = choice[1]
        if action == 'backup':
            self.backupApiKeys()
        elif action == 'restore':
            self.restoreApiKeys()

    def backupApiKeys(self):
        logout(data='backupApiKeys')
        try:
            if not os.path.exists(API_BACKUP_DIR):
                os.makedirs(API_BACKUP_DIR)

            data = {}
            key_map = {
                'tmdb': config.plugins.xtraEvent.tmdbAPI.value,
                'tvdb': config.plugins.xtraEvent.tvdbAPI.value,
                'omdb': config.plugins.xtraEvent.omdbAPI.value,
                'fanart': config.plugins.xtraEvent.fanartAPI.value
            }
            for name, value in key_map.items():
                value = (value or '').strip()
                if value:
                    data[name] = value

            with open(API_BACKUP_FILE, 'w') as handle:
                json.dump(data, handle, indent=2, sort_keys=True)

            if data:
                msg = _('Saved API keys: {}\nFile: {}').format(', '.join(sorted(data.keys())).upper(), API_BACKUP_FILE)
            else:
                msg = _('No API keys were set. Empty backup created at {}').format(API_BACKUP_FILE)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=8)
        except Exception as err:
            self.session.open(MessageBox, _('Backup failed: {}').format(str(err)), MessageBox.TYPE_ERROR, timeout=10)

    def restoreApiKeys(self):
        logout(data='restoreApiKeys')
        try:
            if not os.path.exists(API_BACKUP_FILE):
                self.session.open(MessageBox, _('No saved APIs are present.'), MessageBox.TYPE_INFO, timeout=8)
                return

            with open(API_BACKUP_FILE, 'r') as handle:
                raw = handle.read().strip()

            if not raw:
                self.session.open(MessageBox, _('No saved APIs are present.'), MessageBox.TYPE_INFO, timeout=8)
                return

            data = json.loads(raw)
            if not isinstance(data, dict) or not data:
                self.session.open(MessageBox, _('No saved APIs are present.'), MessageBox.TYPE_INFO, timeout=8)
                return

            restored = []
            mapping = {
                'tmdb': config.plugins.xtraEvent.tmdbAPI,
                'tvdb': config.plugins.xtraEvent.tvdbAPI,
                'omdb': config.plugins.xtraEvent.omdbAPI,
                'fanart': config.plugins.xtraEvent.fanartAPI
            }
            for name, cfg in mapping.items():
                value = data.get(name, '')
                if value:
                    cfg.value = value
                    cfg.save()
                    restored.append(name.upper())

            configfile.save()
            self.xtraList()

            if restored:
                msg = _('Restored API keys: {}').format(', '.join(restored))
            else:
                msg = _('No saved APIs are present.')
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=8)
        except Exception as err:
            self.session.open(MessageBox, _('Restore failed: {}').format(str(err)), MessageBox.TYPE_ERROR, timeout=10)

    def removeImagesAll(self):
        logout(data="------------------ def removeImagesAll")
        self.session.openWithCallback(self.removeImagesAllYes, MessageBox, _(lng.get(lang, '73')), MessageBox.TYPE_YESNO)

    def removeImagesAllYes(self, answer):
        logout(data="------------------ def removeImagesAllYes")
        if answer:
            import shutil
            pathLoc = "{}xtraEvent/".format(config.plugins.xtraEvent.loc.value)
            logout(data="path download")
            if os.path.isdir(pathLoc):
                shutil.rmtree(pathLoc)
            if not os.path.isdir(pathLoc):
                logout(data="path download anlegen")
                os.makedirs("{}poster".format(pathLoc))
                os.makedirs("{}banner".format(pathLoc))
                os.makedirs("{}backdrop".format(pathLoc))
                os.makedirs("{}infos".format(pathLoc))
                os.makedirs("{}infossterne".format(pathLoc))
                os.makedirs("{}infosomdb".format(pathLoc))
                os.makedirs("{}infosomdbsterne".format(pathLoc))
                os.makedirs("{}infosomdbrated".format(pathLoc))
                os.makedirs("{}infostmdbrated".format(pathLoc))
                os.makedirs("{}infostmdbstar".format(pathLoc))
                os.makedirs("{}infoselcinemastars".format(pathLoc))
                os.makedirs("{}infoselcinemarated".format(pathLoc))
                os.makedirs("{}infoselcinema".format(pathLoc))
                os.makedirs("{}mSearch".format(pathLoc))
                os.makedirs("{}EMC".format(pathLoc))
                os.makedirs("{}logo".format(pathLoc))
                os.makedirs("{}casts".format(pathLoc))
            self.updateFinish()

    def compressImg(self):
        logout(data="------------------ def compressImg")
        try:
            filepath = "{}{}".format(pathLoc, config.plugins.xtraEvent.cnfgSel.value)
            folder_size = sum([sum([os.path.getsize(os.path.join(filepath, fname)) for fname in files]) for filepath, folders, files in os.walk(filepath)])
            old_size = "%0.1f" % (folder_size//1024)
            if os.path.exists(filepath):
                lstdr = os.listdir(filepath)
                for j in lstdr:
                    try:
                        filepath = "".join([filepath, "/", j])
                        if os.path.isfile(filepath):
                            im = Image.open(filepath)
                            im.save(filepath, optimize=True, quality=80)
                    except:
                        pass
                folder_size = sum([sum([os.path.getsize(os.path.join(filepath, fname)) for fname in files]) for filepath, folders, files in os.walk(filepath)])
                new_size = "%0.1f" % (folder_size//1024)
                self['info'].setText(_("{} images optimization end...\nGain : {}KB to {}KB".format(len(lstdr), old_size, new_size)))
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("compressImg, %s\n"%(err))
            self['info'].setText(str(err))


    def brokenImageRemove(self):
        logout(data="------------------ def brokenImageRemove")
        b = os.listdir(pathLoc)
        rmvd = 0
        try:
            for i in b:
                bb = "{}{}/".format(pathLoc, i)
                fc = os.path.isdir(bb)
                if fc != False:
                    for f in os.listdir(bb):
                        if f.endswith('.jpg'):
                            try:
                                img = Image.open("{}{}".format(bb, f))
                                img.verify()
                            except:
                                try:
                                    os.remove("{}{}".format(bb, f))
                                    rmvd += 1
                                except:
                                    pass
        except:
            pass
        self['info'].setText(_("Removed Broken Images : {}".format(str(rmvd))))

    def menuCallback(self, ret = None):
        logout(data="------------------ def menuCallback")
        ret and ret[1]()

    def search(self):
        logout(data="------------------ def search")
        if config.plugins.xtraEvent.onoff.value:
            if pathLoc != "":
                from . import download
                if config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '14'):
                    self.session.open(download.downloads)
                if config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '13'):
                    self.session.open(selBouquets)
                elif config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '14a'):
                    self.session.open(selBouquets)
            else:
                self.session.open(MessageBox, _(lng.get(lang, '4')), MessageBox.TYPE_INFO, timeout = 10)
                self.session.open(selBouquets)
        else:
            self.exit()

    def ms(self):
        if config.plugins.xtraEvent.onoff.value:
            if pathLoc != "":
                self.session.open(manuelSearch)
            else:
                self.session.open(MessageBox, _(lng.get(lang, '4')), MessageBox.TYPE_INFO, timeout = 10)
        else:
            self.exit()

    def exit(self):
        logout(data="-------------------  def exit")
        if self['config'].getCurrent()[1] is config.plugins.xtraEvent.skinSelectColor or self['config'].getCurrent()[1] is config.plugins.xtraEvent.skinSelect:
            from Plugins.Extensions.xtraEvent.skins import xtraSkins
            from six.moves import reload_module
            reload_module(xtraSkins)
            for x in self["config"].list:
                if len(x)>1:
                    x[1].save()
                configfile.save()
            self.close()
        for x in self["config"].list:
            if len(x) > 1:
                x[1].save()
        configfile.save()
        try:
            logout(data="def exit clock")
            if config.plugins.xtraEvent.timerMod.value == "Clock":
                logout(data="def exit ist clock")
                tc = config.plugins.xtraEvent.timerClock.value
                logout(data=str(tc))

                dt = datetime.today()
                logout(data="date time")
                logout(data=str(dt))

                #setclk = dt.replace(day=dt.day+1, hour=tc[0], minute=tc[1], second=0, microsecond=0)
                offset = tc[0] * 60 + tc[1]  # Offset in Minuten umrechnen
                setclk = datetime.today() + timedelta(minutes=offset)
                logout(data="set clock")
                logout(data=str(setclk))

                ds = setclk - dt
                logout(data="clock - dt")
                logout(data=str(ds))

                secs = ds.seconds + 1
                logout(data="seconds")
                logout(data=str(secs))

                def startDownload():
                    logout(data="start download")
                    from . import download
                    download.downloads("").save()
                    logout(data="ende download")

                logout(data="timer")
                t = Timer(secs, startDownload)
                logout(data="timer start")
                logout(data=str(t))
                t.start()

            self.close()
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("timer clock, %s\n"%(err))

class manuelSearch(Screen, ConfigListScreen):
    logout(data="---------------- def manuelSearchScreen")
    logout(data=str(version))

    def __init__(self, session):
        logout(data="init")
        Screen.__init__(self, session)
        if desktop_size <= 1280:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = manuel_720
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = manuel_720_2
        else:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = manuel_1080
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = manuel_1080_2

        self.title = ""
        self.raw_title = ""
        self.year = ""
        self.evnt = ""

        list = []
        ConfigListScreen.__init__(self, list, session=session)
        self.setTitle(_(lng.get(lang, '18')))

        self["key_red"] = StaticText(_("Create Movielist"))
        self["key_green"] = StaticText(_(lng.get(lang, '40')))
        self["key_yellow"] = StaticText(_(lng.get(lang, '65')))
        self["key_blue"] = StaticText(_("Keyboard"))
        self["actions"] = ActionMap(["xtraEventAction"],
            {
                "left": self.keyLeft,
                "right": self.keyRight,
                "cancel": self.stop,
                "red": self.check_movielist,
                "ok": self.keyOK,
                "green": self.mnlSrch,
                "yellow": self.append,
                "blue": self.vk
            }, -2)
        self['status'] = Label()
        self['info'] = Label()
        self['Picture'] = Pixmap()
        self['Picture2'] = Pixmap()
        self['int_statu'] = Label()
        self['progress'] = ProgressBar()
        self['progress'].setRange((0, 100))
        self.safeSetProgress(0)

        testver = version
        self.testver = testver
        self["testver"] = Label()
        self.isClosing = False
        self.timer = eTimer()
        self.timer.callback.append(self.msList)
        self.timer.callback.append(self.picShow)
        self.onLayoutFinish.append(self.msList)
        self.onLayoutFinish.append(self.intCheck)

        self.check_movielist()

    def safeSetStatus(self, text):
        try:
            if getattr(self, "isClosing", False):
                return
            if "status" in self:
                self["status"].setText(text)
        except Exception as err:
            logout(data="safeSetStatus error={}".format(str(err)))

    def safeSetInfo(self, text):
        try:
            if getattr(self, "isClosing", False):
                return
            if "info" in self:
                self["info"].setText(text)
        except Exception as err:
            logout(data="safeSetInfo error={}".format(str(err)))

    def safeSetProgress(self, value):
        try:
            if getattr(self, "isClosing", False):
                return
            if "progress" in self:
                self["progress"].setValue(value)
        except Exception as err:
            logout(data="safeSetProgress error={}".format(str(err)))

    def get_manual_search_title(self):
        try:
            base_title = safe_str(self.title)
            cleaned_title = clean_search_title(base_title)
            logout(data="manual search title raw={}".format(base_title))
            logout(data="manual search title cleaned={}".format(cleaned_title))
            return cleaned_title or base_title
        except Exception as err:
            logout(data="get_manual_search_title error={}".format(str(err)))
            return safe_str(self.title)

    def get_manual_display_title(self):
        try:
            cleaned_title = self.get_manual_search_title()
            return cleaned_title
        except Exception as err:
            logout(data="get_manual_display_title error={}".format(str(err)))
            return safe_str(self.title)

    def check_movielist(self):
        logout(data="------------------ def check_movieList")
        try:
            mlst = listdir_path
            #logout(data="existing movie folder files")
            #logout(data=str(mlst))

            if not mlst:
                return

            movieList = [
                x for x in mlst
                if x.lower().endswith(".mp4") or x.lower().endswith(".mkv") or x.lower().endswith(".avi")
            ]
            #logout(data="filtered movie containers")
            #logout(data=str(movieList))

            file_path = movielist_path
            if isfile(file_path):
                remove(file_path)

            seen_titles = set()

            with open(file_path, 'a') as file:
                for movie in movieList:
                    movie_name = clean_movie_filename(movie)
                    logout(data="raw movie filename={}".format(movie))
                    logout(data="cleaned movie title={}".format(movie_name))

                    if not movie_name:
                        continue

                    if movie_name.lower() == "instant record":
                        continue

                    if movie_name in seen_titles:
                        continue
                    seen_titles.add(movie_name)

                    poster_path = os.path.join(pathXtra, "EMC", "{}-poster.jpg".format(movie_name))
                    backdrop_path = os.path.join(pathXtra, "EMC", "{}-backdrop.jpg".format(movie_name))
                    info_path = os.path.join(pathXtra, "EMC", "{}-info.json".format(movie_name))

                    poster_src_path = os.path.join(pathXtra, "poster", "{}.jpg".format(movie_name))
                    backdrop_src_path = os.path.join(pathXtra, "backdrop", "{}.jpg".format(movie_name))
                    info_src_path = os.path.join(pathXtra, "infos", "{}.json".format(movie_name))

                    if not os.path.exists(poster_path):
                        if os.path.exists(poster_src_path):
                            shutil.copy(poster_src_path, poster_path)
                            if os.path.exists(backdrop_src_path):
                                shutil.copy(backdrop_src_path, backdrop_path)
                            if os.path.exists(info_src_path):
                                shutil.copy(info_src_path, info_path)
                        else:
                            file.write(movie_name + '\n')

        except Exception as err:
            logout(data="check_movielist error={}".format(str(err)))
            pass

    def stop(self):
        logout(data="------------------ def stop")
        self.isClosing = True
        time.sleep(1)
        logout(data="Wait for file to close, otherwise it will be write-protected.")
        self.close()

    def intCheck(self):
        logout(data="------------------ def intCheck")
        self["testver"].setText("%s " % (self.testver))
        try:
            socket.setdefaulttimeout(2)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            self['int_statu'].setText("☻")
            return True
        except:
            self['int_statu'].hide()
            self['status'].setText(lng.get(lang, '68'))
            return False

    def keyOK(self):
        logout(data="------------------ def keyOK")
        if self['config'].getCurrent()[1] is config.plugins.xtraEvent.EMCloc:
            self.session.openWithCallback(self.pathSelected, LocationBox, text=_('Default Folder'), currDir=config.plugins.xtraEvent.EMCloc.getValue(), minFree=100)

    def pathSelected(self, res):
        logout(data="------------------ def pathSelected")
        if res is not None:
            config.plugins.xtraEvent.EMCloc.value = res
            pathLoc = config.plugins.xtraEvent.EMCloc.value
        return

    def delay(self):
        logout(data="------------------ def delay")
        self.timer.start(100, True)

    def msList(self):
        logout(data="------------------ def msList")
        self["Picture2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/pic/film2.png")
        self["Picture2"].instance.setScale(1)
        self["Picture2"].show()
        for x in self["config"].list:
            if len(x) > 1:
                x[1].save()
        list = []
        list.append(getConfigListEntry(_(lng.get(lang, '59')), config.plugins.xtraEvent.searchModManuel))
        list.append(getConfigListEntry(_(lng.get(lang, '57')), config.plugins.xtraEvent.searchMANUELnmbr))
        if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '17'):
            list.append(getConfigListEntry(_(lng.get(lang, '60')), config.plugins.xtraEvent.EMCloc))
        list.append(getConfigListEntry(_("Year"), config.plugins.xtraEvent.searchMANUELyear))
        list.append(getConfigListEntry(_(lng.get(lang, '10')), config.plugins.xtraEvent.searchLang))
        list.append(getConfigListEntry(_(lng.get(lang, '61')), config.plugins.xtraEvent.PB))
        list.append(getConfigListEntry(_(lng.get(lang, '62')), config.plugins.xtraEvent.srcs))
        if config.plugins.xtraEvent.srcs.value == "TMDB":
            list.append(getConfigListEntry(_(lng.get(lang, '63')), config.plugins.xtraEvent.searchType))
            if config.plugins.xtraEvent.PB.value == "posters":
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.TMDBpostersize))
            elif config.plugins.xtraEvent.PB.value == "backdrops":
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.TMDBbackdropsize))
            elif config.plugins.xtraEvent.PB.value == "logos":
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.TMDBlogosize))
        if config.plugins.xtraEvent.srcs.value == "TVDB":
            if config.plugins.xtraEvent.PB.value == "posters":
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.TVDBpostersize))
            else:
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.TVDBbackdropsize))
        if config.plugins.xtraEvent.srcs.value == "FANART":
            list.append(getConfigListEntry(_("\tSearch Type"), config.plugins.xtraEvent.FanartSearchType))
            if config.plugins.xtraEvent.PB.value == "posters":
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.FANART_Poster_Resize))
            else:
                list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.FANART_Backdrop_Resize))
        if config.plugins.xtraEvent.srcs.value == "IMDB(poster)":
            list.append(getConfigListEntry(_("\t{}".format(lng.get(lang, '49'))), config.plugins.xtraEvent.imdb_Poster_size))
        list.append(getConfigListEntry("—"*50))
        list.append(getConfigListEntry(_(lng.get(lang, '58')), config.plugins.xtraEvent.imgNmbr))
        list.append(getConfigListEntry("—"*50))
        self["config"].list = list
        self["config"].l.setList(list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        if self['config'].getCurrent()[0] == lng.get(lang, '57'):
            self.curEpg()
        self.delay()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        if self['config'].getCurrent()[0] == lng.get(lang, '57'):
            self.curEpg()
        self.delay()

    def curEpg(self):
        logout(data="------------------ def curEpg")
        if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
            try:
                events = ""
                ref = self.session.nav.getCurrentlyPlayingServiceReference().toString()
                events = epgcache.lookupEvent(['IBDCTSERNX', (ref, 1, -1, -1)])
                if events:
                    n = config.plugins.xtraEvent.searchMANUELnmbr.value
                    self.evnt = events[int(n)][4]
                    self.vkEdit("")
            except:
                pass
        if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '17'):
            self.movieList()

    def movieList(self):
        logout(data="------------------ def movieList")
        try:
            movie_dir = config.plugins.xtraEvent.EMCloc.value
            logout(data="movieList dir={}".format(str(movie_dir)))

            if not movie_dir or not os.path.isdir(movie_dir):
                logout(data="movieList invalid dir")
                return

            mlst = os.listdir(movie_dir)
            logout(data=str(mlst))

            if not mlst:
                return

            movie_files = [
                x for x in mlst
                if x.lower().endswith(".mp4") or x.lower().endswith(".mkv") or x.lower().endswith(".avi")
            ]

            cleaned_movies = []
            seen_titles = set()

            for x in movie_files:
                cleaned = clean_movie_filename(x)
                if cleaned and cleaned not in seen_titles:
                    cleaned_movies.append(cleaned)
                    seen_titles.add(cleaned)

            logout(data="cleaned movielist")
            logout(data=str(cleaned_movies))

            if cleaned_movies:
                n = int(config.plugins.xtraEvent.searchMANUELnmbr.value)
                if 0 <= n < len(cleaned_movies):
                    self.evnt = cleaned_movies[n]
                    self.vkEdit("")
        except Exception as err:
            logout(data="movieList error={}".format(str(err)))
            pass

    def vk(self):
        logout(data="------------------ def vk")
        self.session.openWithCallback(self.vkEdit, VirtualKeyBoard, title=lng.get(lang, '39'), text=self.evnt)

    def vkEdit(self, text=None):
        logout(data="------------------ def vkEdit")
        try:
            if text:
                config.plugins.xtraEvent.searchMANUEL = ConfigText(default="{}".format(text), visible_width=100, fixed_size=False)
                config.plugins.xtraEvent.searchMANUEL_EMC = ConfigText(default="{}".format(text), visible_width=100, fixed_size=False)

                if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
                    raw_title = config.plugins.xtraEvent.searchMANUEL.value
                else:
                    raw_title = config.plugins.xtraEvent.searchMANUEL_EMC.value
                    raw_title = raw_title.split('-')[-1].split(".")[0].strip()
            else:
                config.plugins.xtraEvent.searchMANUEL = ConfigText(default="{}".format(self.evnt), visible_width=100, fixed_size=False)
                config.plugins.xtraEvent.searchMANUEL_EMC = ConfigText(default="{}".format(self.evnt), visible_width=100, fixed_size=False)

                if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
                    raw_title = config.plugins.xtraEvent.searchMANUEL.value
                else:
                    raw_title = config.plugins.xtraEvent.searchMANUEL_EMC.value
                    raw_title = raw_title.split('-')[-1].split(".")[0].strip()

            self.raw_title = safe_str(raw_title)
            self.title = clean_search_title(self.raw_title)

            logout(data="vkEdit raw title={}".format(str(self.raw_title)))
            logout(data="vkEdit cleaned title={}".format(str(self.title)))

            self['status'].setText(_("Search : {}".format(str(self.title))))
        except Exception as err:
            logout(data="vkEdit error={}".format(str(err)))
            self.raw_title = safe_str(text or self.evnt)
            self.title = clean_search_title(self.raw_title)
            self['status'].setText(_("Search : {}".format(str(self.title))))

    def mnlSrch(self):
        logout(data="------------------ def mnlSrch")
        try:
            self.title = self.get_manual_search_title()
            fs = os.listdir("{}mSearch/".format(pathLoc))
            logout(data="def mnlSrch fs")
            logout(data=str(fs))

            for f in fs:
                os.remove("{}mSearch/{}".format(pathLoc, f))
        except:
            logout(data="def mnlSrch return")
            return

        if config.plugins.xtraEvent.PB.value == "posters":
            logout(data="def mnlSrch poster")
            if config.plugins.xtraEvent.srcs.value == "TMDB":
                start_new_thread(self.tmdb, ())
            if config.plugins.xtraEvent.srcs.value == "TVDB":
                start_new_thread(self.tvdb, ())
            if config.plugins.xtraEvent.srcs.value == "FANART":
                start_new_thread(self.fanart, ())
            if config.plugins.xtraEvent.srcs.value == "IMDB(poster)":
                start_new_thread(self.imdb, ())
            if config.plugins.xtraEvent.srcs.value == "Bing":
                start_new_thread(self.bing, ())
            if config.plugins.xtraEvent.srcs.value == "Google":
                start_new_thread(self.google, ())

        elif config.plugins.xtraEvent.PB.value == "backdrops":
            logout(data="def mnlSrch backdrop")
            if config.plugins.xtraEvent.srcs.value == "TMDB":
                start_new_thread(self.tmdb, ())
            if config.plugins.xtraEvent.srcs.value == "TVDB":
                start_new_thread(self.tvdb, ())
            if config.plugins.xtraEvent.srcs.value == "FANART":
                start_new_thread(self.fanart, ())
            if config.plugins.xtraEvent.srcs.value == "Bing":
                start_new_thread(self.bing, ())
            if config.plugins.xtraEvent.srcs.value == "Google":
                start_new_thread(self.google, ())

        elif config.plugins.xtraEvent.PB.value == "logos":
            logout(data="def mnlSrch logo")
            if config.plugins.xtraEvent.srcs.value == "TMDB":
                start_new_thread(self.tmdb_logo, ())
            else:
                self.safeSetStatus(_("Logo manual search supported only with TMDB"))

    def tmdb_logo(self):
        logout(data="------------------ def tmdb_logo")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)

        try:
            self.srch = config.plugins.xtraEvent.searchType.value
            self.year = config.plugins.xtraEvent.searchMANUELyear.value
            search_title = self.get_manual_search_title()

            from requests.utils import quote
            url = "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(self.srch, tmdb_api, quote(search_title))
            logout(data="------------------ def tmdb_logo search url")
            logout(data=str(url))

            if self.year != "0":
                if config.plugins.xtraEvent.searchType.value == "tv":
                    url += "&first_air_date_year={}".format(self.year)
                elif config.plugins.xtraEvent.searchType.value == "movie":
                    url += "&year={}".format(self.year)
                logout(data="------------------ def tmdb_logo search url year")
                logout(data=str(url))

            js = requests.get(url).json()
            results = js.get('results', [])
            if not results:
                self.safeSetStatus("Download Ends : no files found")
                return

            item = results[0]
            tmdb_id = item.get('id')
            media_type = item.get('media_type', self.srch)

            if self.srch in ("movie", "tv"):
                media_type = self.srch
            elif media_type not in ("movie", "tv"):
                if item.get("title", "") or item.get("release_date", ""):
                    media_type = "movie"
                else:
                    media_type = "tv"

            if not tmdb_id:
                self.safeSetStatus("Download Ends : no files found")
                return

            url = "https://api.themoviedb.org/3/{}/{}?api_key={}&append_to_response=images".format(media_type, int(tmdb_id), tmdb_api)
            logout(data="------------------ def tmdb_logo details url")
            logout(data=str(url))

            if config.plugins.xtraEvent.searchLang.value:
                url += "&language={}".format(lang)

            p1 = requests.get(url).json()
            logos = p1.get('images', {}).get('logos', [])
            n = len(logos)

            if n > 0:
                downloaded = 0
                sz = config.plugins.xtraEvent.TMDBlogosize.value

                for i in range(int(n)):
                    logo = logos[i].get('file_path')
                    if logo:
                        url_logo = "https://image.tmdb.org/t/p/{}{}".format(sz, logo)
                        dwnldFile = "{}mSearch/{}-logos-{}.png".format(pathLoc, search_title, i + 1)
                        open(dwnldFile, 'wb').write(requests.get(url_logo, stream=True, allow_redirects=True).content)
                        downloaded += 1
                        self.prgrs(downloaded, n)
            else:
                self.safeSetStatus(_("Download : Logo not found - Language off ?"))

            config.plugins.xtraEvent.imgNmbr.value = 1

        except Exception as err:
            logout(data="------------------ def tmdb_logo except")
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("Manuel Search tmdb_logo, %s, %s\n" % (self.title, err))

    def picShow(self):
        logout(data="------------------ def picShow")
        self["Picture2"].hide()
        try:
            self.iNmbr = config.plugins.xtraEvent.imgNmbr.value
            search_title = self.get_manual_search_title()

            if config.plugins.xtraEvent.PB.value == "logos":
                self.path = "{}mSearch/{}-logos-{}.png".format(pathLoc, search_title, self.iNmbr)
                self["Picture"].instance.setPixmap(loadPNG(self.path))
            else:
                self.path = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, self.iNmbr)
                if config.plugins.xtraEvent.srcs.value == "IMDB(poster)":
                    self.path = "{}mSearch/{}-poster-1.jpg".format(pathLoc, search_title)
                self["Picture"].instance.setPixmap(loadJPG(self.path))

            self["Picture"].instance.setScale(1)
            self["Picture"].show()

            if desktop_size <= 1280:
                if config.plugins.xtraEvent.PB.value == "posters":
                    self["Picture"].instance.resize(eSize(185, 278))
                    self["Picture"].instance.move(ePoint(930, 325))
                elif config.plugins.xtraEvent.PB.value == "backdrops":
                    self["Picture"].instance.resize(eSize(300, 170))
                    self["Picture"].instance.move(ePoint(890, 375))
                else:
                    self["Picture"].instance.resize(eSize(300, 170))
                    self["Picture"].instance.move(ePoint(890, 375))
            else:
                if config.plugins.xtraEvent.PB.value == "posters":
                    self["Picture"].instance.resize(eSize(185, 278))
                    self["Picture"].instance.move(ePoint(1450, 550))
                elif config.plugins.xtraEvent.PB.value == "backdrops":
                    self["Picture"].instance.resize(eSize(300, 170))
                    self["Picture"].instance.move(ePoint(1400, 600))
                else:
                    self["Picture"].instance.resize(eSize(300, 170))
                    self["Picture"].instance.move(ePoint(1400, 600))

            self['Picture'].show()
            self.inf()

        except Exception as err:
            logout(data="picShow error={}".format(str(err)))
            pass

    def inf(self):
        logout(data="------------------ def inf")
        pb_path = ""
        pb_sz = ""
        tot = ""
        cur = ""
        try:
            msLoc = "{}mSearch/".format(pathLoc)
            n = 0
            search_title = self.get_manual_search_title()

            if config.plugins.xtraEvent.PB.value == "logos":
                for file in os.listdir(msLoc):
                    if file.startswith("{}-logos".format(search_title)):
                        n += 1
                pb_path = "{}mSearch/{}-logos-{}.png".format(pathLoc, search_title, self.iNmbr)
            else:
                for file in os.listdir(msLoc):
                    if file.startswith("{}-{}".format(search_title, config.plugins.xtraEvent.PB.value)):
                        n += 1
                pb_path = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, self.iNmbr)

            tot = n
            cur = config.plugins.xtraEvent.imgNmbr.value
            pb_sz = "{} KB".format(os.path.getsize(pb_path) // 1024)
            im = Image.open(pb_path)
            pb_res = im.size
            self['info'].setText(_("{}/{} - {} - {}".format(cur, tot, pb_sz, pb_res)))
        except Exception as err:
            logout(data="inf error={}".format(str(err)))
            pass

    def append(self):
        logout(data="------------------ def append")
        try:
            clean_title = self.get_manual_search_title()
            self.title = clean_title

            logout(data="------------------ def append cleaned title")
            logout(data=str(clean_title))

            target_title = clean_title

            # EMC/manual movie mode:
            # find the best matching movie title from EMCloc instead of using searchMANUELnmbr index
            if config.plugins.xtraEvent.searchModManuel.value != lng.get(lang, '16'):
                try:
                    movie_dir = config.plugins.xtraEvent.EMCloc.value
                    logout(data="append emc movie dir={}".format(str(movie_dir)))

                    search_base = safe_str(clean_title).lower().strip()
                    best_match = ""

                    if movie_dir and os.path.isdir(movie_dir):
                        movie_files = os.listdir(movie_dir)

                        cleaned_movies = []
                        for fname in movie_files:
                            if fname.lower().endswith(".mp4") or fname.lower().endswith(".mkv") or fname.lower().endswith(".avi"):
                                cleaned = clean_movie_filename(fname)
                                if cleaned:
                                    cleaned_movies.append(cleaned)

                        logout(data="append emc cleaned movie candidates={}".format(str(cleaned_movies)))

                        # 1) exact case-insensitive match
                        for candidate in cleaned_movies:
                            if safe_str(candidate).lower() == search_base:
                                best_match = candidate
                                break

                        # 2) startswith match: "Crime 101" -> "Crime 101 2026"
                        if not best_match:
                            for candidate in cleaned_movies:
                                cand_lc = safe_str(candidate).lower()
                                if cand_lc.startswith(search_base + " ") or cand_lc.startswith(search_base + "-"):
                                    best_match = candidate
                                    break

                        # 3) fallback substring match
                        if not best_match:
                            for candidate in cleaned_movies:
                                cand_lc = safe_str(candidate).lower()
                                if search_base in cand_lc:
                                    best_match = candidate
                                    break

                        if best_match:
                            target_title = best_match

                    logout(data="append emc target title={}".format(str(target_title)))

                except Exception as err:
                    logout(data="append emc title detect error={}".format(str(err)))

            if config.plugins.xtraEvent.PB.value == "posters":
                logout(data="------------------ def append poster")
                if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
                    target = "{}poster/{}.jpg".format(pathLoc, target_title)
                else:
                    target = "{}EMC/{}-poster.jpg".format(pathLoc, target_title)

            elif config.plugins.xtraEvent.PB.value == "backdrops":
                logout(data="------------------ def append backdrop")
                if config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
                    target = "{}backdrop/{}.jpg".format(pathLoc, target_title)
                else:
                    target = "{}EMC/{}-backdrop.jpg".format(pathLoc, target_title)

            elif config.plugins.xtraEvent.PB.value == "logos":
                logout(data="------------------ def append logo")
                target = "{}logo/{}.png".format(pathLoc, target_title)

            else:
                return

            import shutil
            logout(data="------------------ def append 10")

            if os.path.exists(self.path):
                logout(data="------------------ def append 11")
                shutil.copyfile(self.path, target)
                logout(data=str(self.path))
                logout(data=str(target))

                if os.path.exists(target):
                    logout(data="------------------ def append 12")

                    if config.plugins.xtraEvent.PB.value == "backdrops":
                        if not config.plugins.xtraEvent.searchModManuel.value == lng.get(lang, '16'):
                            logout(data="------------------ def append 14 resize EMC backdrop")
                            im1 = Image.open(target)
                            im1 = im1.resize((640, 360))
                            im1.save(target)

                        try:
                            im1 = Image.open(target)
                            im2 = Image.open("/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/pic/emc_background.jpg")
                            mask = Image.new("L", im1.size, 80)
                            im = Image.composite(im1, im2, mask)
                        except:
                            pass

                    elif config.plugins.xtraEvent.PB.value == "posters":
                        logout(data="------------------ def append 16 resize poster")
                        im1 = Image.open(target)
                        im1 = im1.resize((185, 272))
                        im1.save(target)

                    elif config.plugins.xtraEvent.PB.value == "logos":
                        logout(data="------------------ def append logo saved")
                        pass

        except Exception as err:
            logout(data="append error={}".format(str(err)))
            return

    def tmdb(self):
        logout(data="------------------ def tmdb")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)
        try:
            self.srch = config.plugins.xtraEvent.searchType.value
            self.year = config.plugins.xtraEvent.searchMANUELyear.value
            search_title = self.get_manual_search_title()

            from requests.utils import quote
            url = "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(self.srch, tmdb_api, quote(search_title))
            logout(data="------------------ def tmdb url 1")
            logout(data=str(url))

            import json
            response = requests.get(url)
            file_path = "{}EMC/{}-info.json".format(pathLoc, search_title)
            with open(file_path, 'w') as file:
                json.dump(response.json(), file)
                logout(data="-----json written----")

            if self.year != "0":
                logout(data="------------------ def tmdb 1")
                if config.plugins.xtraEvent.searchType.value == "tv":
                    logout(data="------------------ def tmdb 2")
                    url += "&first_air_date_year={}".format(self.year)
                    logout(data=str(url))
                elif config.plugins.xtraEvent.searchType.value == "movie":
                    logout(data="------------------ def tmdb 2a")
                    url += "&year={}".format(self.year)
                    logout(data=str(url))

            id = requests.get(url).json()['results'][0]['id']
            logout(data="------------------ def tmdb url 2")

            url = "https://api.themoviedb.org/3/{}/{}?api_key={}&append_to_response=images".format(self.srch, int(id), tmdb_api)
            logout(data="------------------ def tmdb url ist")
            logout(data=str(url))
            if config.plugins.xtraEvent.searchLang.value:
                logout(data="------------------ def tmdb 3")
                url += "&language={}".format(lang)
            logout(data="------------------ def tmdb url 3")
            logout(data=str(url))

            if config.plugins.xtraEvent.PB.value == "posters":
                logout(data="------------------ def tmdb 4")
                sz = config.plugins.xtraEvent.TMDBpostersize.value
                logout(data=str(sz))
            else:
                logout(data="------------------ def tmdb 5")
                sz = config.plugins.xtraEvent.TMDBbackdropsize.value
                logout(data=str(sz))

            logout(data="------------------ def tmdb 6")
            p1 = requests.get(url).json()
            logout(data="------------------ def tmdb 6 p1")
            #logout(data=str(p1))
            pb_no = p1['images'][config.plugins.xtraEvent.PB.value]
            logout(data="------------------ def tmdb 6 pb_no")
            logout(data=str(pb_no))
            n = len(pb_no)
            logout(data="------------------ def tmdb 6 n")
            logout(data=str(n))

            if n > 0:
                logout(data="------------------ def tmdb 7")
                downloaded = 0
                for i in range(int(n)):
                    poster = p1['images'][config.plugins.xtraEvent.PB.value][i]['file_path']
                    if poster:
                        url_poster = "https://image.tmdb.org/t/p/{}{}".format(sz, poster)
                        dwnldFile = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, i + 1)
                        open(dwnldFile, 'wb').write(requests.get(url_poster, stream=True, allow_redirects=True).content)
                        downloaded += 1
                        self.prgrs(downloaded, n)
            else:
                logout(data="------------------ def tmdb else")
                self.safeSetStatus(_("Download :  Poster not found - Language off ?"))
            config.plugins.xtraEvent.imgNmbr.value = 1

        except Exception as err:
            logout(data="------------------ def tmdb except")
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("Manuel Search tmdb , %s, %s\n" % (self.title, err))

    def tvdb(self):
        logout(data="--------------------------- def tvdb")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)
        try:
            logout(data="--------------------------- def tvdb 1")
            self.srch = config.plugins.xtraEvent.searchType.value
            self.year = config.plugins.xtraEvent.searchMANUELyear.value
            search_title = self.get_manual_search_title()

            from requests.utils import quote
            url = "https://thetvdb.com/api/GetSeries.php?seriesname={}".format(quote(search_title))
            logout(data="------------------ def tvdb url 1 ist")
            logout(data=str(url))
            if self.year != 0:
                logout(data="--------------------------- def tvdb 2")
                url += "%20{}".format(self.year)
            url_read = requests.get(url).text
            series_id = re.findall('<seriesid>(.*?)</seriesid>', url_read)[0]
            if config.plugins.xtraEvent.PB.value == "posters":
                logout(data="--------------------------- def tvdb 3")
                keyType = "poster"
            else:
                logout(data="--------------------------- def tvdb 4")
                keyType = "fanart"
            url = 'https://api.thetvdb.com/series/{}/images/query?keyType={}'.format(series_id, keyType)
            logout(data="------------------ def tvdb url 2 ist")
            logout(data=str(url))
            if config.plugins.xtraEvent.searchLang.value:
                logout(data="--------------------------- def tvdb 5")
                u = requests.get(url, headers={"Accept-Language": "{}".format(lang)})
            try:
                logout(data="--------------------------- def tvdb 6")
                pb_no = u.json()["data"]
                n = len(pb_no)
            except:
                logout(data="--------------------------- def tvdb 7")
                self.safeSetStatus(_("Download : No"))
                return
            if n > 0:
                logout(data="--------------------------- def tvdb 8")
                downloaded = 0
                for i in range(int(n)):
                    if config.plugins.xtraEvent.PB.value == "posters":
                        img_pb = u.json()["data"][i]['{}'.format(config.plugins.xtraEvent.TVDBpostersize.value)]
                    else:
                        img_pb = u.json()["data"][i]['{}'.format(config.plugins.xtraEvent.TVDBbackdropsize.value)]
                    url = "https://artworks.thetvdb.com/banners/{}".format(img_pb)
                    logout(data="------------------ def tvdb url 3 ist")
                    logout(data=str(url))
                    dwnldFile = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, i + 1)
                    open(dwnldFile, 'wb').write(requests.get(url, stream=True, allow_redirects=True).content)
                    downloaded += 1
                    self.prgrs(downloaded, n)
            else:
                logout(data="--------------------------- def tvdb 9")
                self.safeSetStatus(_("Download : No"))
            config.plugins.xtraEvent.imgNmbr.value = 1
        except Exception as err:
            logout(data="--------------------------- def tvdb 10")
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("Manuel Search tvdb , %s, %s\n" % (self.title, err))
            return

    def fanart(self):
        logout(data=" -----------------  def fanart")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)
        id = "-"
        from requests.utils import quote
        search_title = self.get_manual_search_title()

        if config.plugins.xtraEvent.FanartSearchType.value == "tv":
            try:
                url_maze = "http://api.tvmaze.com/singlesearch/shows?q={}".format(quote(search_title))
                logout(data="------------------ def fanart url maze")
                logout(data=str(url_maze))
                mj = requests.get(url_maze).json()
                id = (mj['externals']['thetvdb'])
            except Exception as err:
                with open("/tmp/xtraEvent.log", "a+") as f:
                    f.write("fanart maze man.search, %s, %s\n" % (self.title, err))
        else:
            try:
                self.year = config.plugins.xtraEvent.searchMANUELyear.value
                url = "https://api.themoviedb.org/3/search/movie?api_key={}&query={}".format(tmdb_api, quote(search_title))
                logout(data="------------------ def fanart url 1449")
                logout(data=str(url))
                if self.year != 0:
                    url += "&primary_release_year={}&year={}".format(self.year, self.year)
                    logout(data="------------------ def fanart url 1453")
                    logout(data=str(url))
                id = requests.get(url).json()['results'][0]['id']
            except Exception as err:
                self.safeSetStatus("Download Ende : no json info found")
                with open("/tmp/xtraEvent.log", "a+") as f:
                    f.write("fanart tvdb id man.search, %s, %s\n" % (self.title, err))
        try:
            m_type = config.plugins.xtraEvent.FanartSearchType.value
            url_fanart = "https://webservice.fanart.tv/v3/{}/{}?api_key={}".format(m_type, id, fanart_api)
            logout(data="------------------ def fanart url fanart")
            logout(data=str(url_fanart))
            fjs = requests.get(url_fanart, verify=False, timeout=5).json()
            if config.plugins.xtraEvent.PB.value == "posters":
                if config.plugins.xtraEvent.FanartSearchType.value == "tv":
                    pb_no = fjs['tvposter']
                    n = len(pb_no)
                else:
                    pb_no = fjs['movieposter']
                    n = len(pb_no)
            elif config.plugins.xtraEvent.PB.value == "backdrops":
                if config.plugins.xtraEvent.FanartSearchType.value == "tv":
                    pb_no = fjs['showbackground']
                    n = len(pb_no)
                else:
                    pb_no = fjs['moviebackground']
                    n = len(pb_no)
            if n > 0:
                downloaded = 0
                for i in range(int(n)):
                    try:
                        if config.plugins.xtraEvent.PB.value == "posters":
                            if config.plugins.xtraEvent.FanartSearchType.value == "tv":
                                url = (fjs['tvposter'][i]['url'])
                                logout(data="------------------ def fanart url poster")
                                logout(data=str(url))
                            else:
                                url = (fjs['movieposter'][i]['url'])
                                logout(data="------------------ def fanart url movieposter")
                                logout(data=str(url))
                        if config.plugins.xtraEvent.PB.value == "backdrops":
                            if config.plugins.xtraEvent.FanartSearchType.value == "tv":
                                url = (fjs['showbackground'][i]['url'])
                                logout(data="------------------ def fanart url backdrops")
                                logout(data=str(url))
                            else:
                                url = (fjs['moviebackground'][i]['url'])
                                logout(data="------------------ def fanart url moviebackground")
                                logout(data=str(url))
                        open("/tmp/url", "a+").write("%s\n" % url)
                        dwnldFile = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, i + 1)
                        open(dwnldFile, 'wb').write(requests.get(url, verify=False).content)
                        downloaded += 1
                        self.prgrs(downloaded, n)
                        scl = 1
                        im = Image.open(dwnldFile)
                        if config.plugins.xtraEvent.PB.value == "posters":
                            scl = config.plugins.xtraEvent.FANART_Poster_Resize.value
                        if config.plugins.xtraEvent.PB.value == "backdrops":
                            scl = config.plugins.xtraEvent.FANART_Backdrop_Resize.value
                        im1 = im.resize((im.size[0] // int(scl), im.size[1] // int(scl)), Image.ANTIALIAS)
                        im1.save(dwnldFile)
                    except Exception as err:
                        logout(data=" -----------------  def fanart 1479")
                        with open("/tmp/xtraEvent.log", "a+") as f:
                            f.write("fanart man.search save, %s, %s\n" % (self.title, err))
            else:
                self.safeSetStatus(_(lng.get(lang, '56')))
            config.plugins.xtraEvent.imgNmbr.value = 1
        except Exception as err:
            logout(data=" -----------------  def fanart 1487")
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("fanart man.search2, %s, %s\n" % (self.title, err))

    def imdb(self):
        logout(data="-------------------- def imdb")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)

        try:
            if config.plugins.xtraEvent.PB.value != "posters":
                self.safeSetStatus("Download Ends : IMDB supports poster search only")
                return

            search_title = self.get_manual_search_title()
            logout(data="imdb search title={}".format(search_title))

            from requests.utils import quote

            imdb_headers = {
                "User-Agent": headers.get("User-Agent", "Mozilla/5.0"),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://www.imdb.com/",
                "Connection": "keep-alive",
            }

            search_urls = [
                "https://www.imdb.com/find/?q={}&s=tt".format(quote(search_title)),
                "https://www.imdb.com/find/?q={}".format(quote(search_title)),
                "https://m.imdb.com/find/?q={}".format(quote(search_title)),
            ]

            ff = ""
            final_url = ""
            status_code = 0

            for url_find in search_urls:
                try:
                    logout(data="imdb search url={}".format(url_find))
                    response = requests.get(url_find, headers=imdb_headers, timeout=(5, 10), allow_redirects=True)
                    status_code = response.status_code
                    final_url = response.url

                    ff = response.text
                    #logout(data="imdb page text={}".format(ff))
                    if not ff:
                        try:
                            ff = response.content.decode("utf-8", "ignore")
                            #logout(data="imdb page text decoded={}".format(ff))
                        except:
                            ff = ""

                    logout(data="imdb status={}".format(status_code))
                    logout(data="imdb final_url={}".format(final_url))
                    logout(data="imdb text_len={}".format(len(ff)))

                    if status_code == 200 and ff:
                        break
                except Exception as inner_err:
                    logout(data="imdb search request error={}".format(str(inner_err)))
                    continue

            if not ff:
                self.safeSetStatus("Download Ends : no imdb page")
                return

            patterns = [
                r'src="https://(m\.media-amazon\.com/images/[^"]+?)"',
                r'src="https://(.*?)\._V1_QL75_UX\d+_CR0,0,\d+,\d+\.jpg"',
                r'src="https://(.*?)\._V1_UX75_CR0,0,75,109_AL_\.jpg"',
                r'src="https://(.*?)\._V1_.*?\.jpg"',
            ]

            img_url = ""
            for p in patterns:
                found = re.findall(p, ff)
                if found:
                    candidate = found[0]
                    if not candidate.startswith("http"):
                        candidate = "https://" + candidate
                    img_url = candidate
                    break

            if not img_url:
                logout(data="imdb no poster match found")
                self.safeSetStatus("Download Ends : no files found")
                return

            size = config.plugins.xtraEvent.imdb_Poster_size.value

            # Resize only if this is an IMDb-style _V1_ image URL
            if "._V1_" in img_url:
                base = img_url.split("._V1_")[0]
                img_url = "{}._V1_UX{}_AL_.jpg".format(base, size)

            logout(data="imdb poster url={}".format(img_url))

            dwnldFile = "{}mSearch/{}-poster-1.jpg".format(pathLoc, search_title)

            response = requests.get(
                img_url,
                stream=True,
                allow_redirects=True,
                headers=imdb_headers,
                timeout=(5, 10)
            )

            content_type = response.headers.get("Content-Type", "").lower()
            logout(data="imdb image status={}".format(response.status_code))
            logout(data="imdb image content_type={}".format(content_type))

            if response.status_code != 200:
                self.safeSetStatus("Download Ends : no files found")
                return

            if "image" not in content_type and response.content[:2] != b"\xff\xd8" and response.content[:8] != b"\x89PNG\r\n\x1a\n":
                logout(data="imdb non-image response")
                self.safeSetStatus("Download Ends : no files found")
                return

            with open(dwnldFile, "wb") as f:
                f.write(response.content)

            if os.path.exists(dwnldFile) and os.path.getsize(dwnldFile) > 0:
                config.plugins.xtraEvent.imgNmbr.value = 1
                self.prgrs(1, 1)
                logout(data="imdb saved file={}".format(dwnldFile))
            else:
                try:
                    os.remove(dwnldFile)
                except:
                    pass
                self.safeSetStatus("Download Ends : no files found")

        except Exception as err:
            logout(data="imdb error={}".format(str(err)))
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("imdb man.search2, %s, %s\n" % (self.title, err))
            return

    def bing(self):
        logout(data=" -----------------  def bing")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)
        try:
            search_title = self.get_manual_search_title()
            url = "https://www.bing.com/images/search?q={}".format(search_title.replace(" ", "+"))
            if config.plugins.xtraEvent.PB.value == "posters":
                url += "+poster"
            else:
                url += "+backdrop"
            headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
            try:
                ff = requests.get(url, stream=True, headers=headers).text
                p = re.findall(r'ihk="/th\?id=(.*?)&', ff)
            except:
                pass
            n = 9
            downloaded = 0
            for i in range(n):
                try:
                    url = re.findall(',&quot;murl&quot;:&quot;(.*?)&', ff)[i]
                    dwnldFile = "{}mSearch/{}-{}-{}.jpg".format(pathLoc, search_title, config.plugins.xtraEvent.PB.value, i + 1)
                    open(dwnldFile, 'wb').write(requests.get(url, stream=True, allow_redirects=True).content)
                    downloaded += 1
                    self.prgrs(downloaded, n)
                except:
                    self.safeSetStatus("Download Ende")
                    pass
            config.plugins.xtraEvent.imgNmbr.value = 1
        except Exception as err:
            self.safeSetStatus(_(str(err)))
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("bing man.search2, %s, %s\n" % (self.title, err))

    def google(self):
        logout(data="------------------ def google")
        self.safeSetStatus("Download Start")
        self.safeSetProgress(0)

        try:
            search_title = self.get_manual_search_title()
            from requests.utils import quote
            encoded_title = quote(search_title)

            if config.plugins.xtraEvent.PB.value == "posters":
                url = (
                    "https://www.google.com/search?"
                    "as_st=y&"
                    "as_q={}&"
                    "as_epq=&"
                    "as_oq=&"
                    "as_eq=&"
                    "imgsz=m&"
                    "imgar=t%7Cxt&"
                    "imgcolor=&"
                    "imgtype=&"
                    "cr=&"
                    "as_sitesearch=&"
                    "as_filetype=jpg&"
                    "tbs=&"
                    "udm=2"
                ).format(encoded_title)
            else:
                url = (
                    "https://www.google.com/search?"
                    "as_st=y&"
                    "as_q={}&"
                    "as_epq=&"
                    "as_oq=&"
                    "as_eq=&"
                    "imgsz=m&"
                    "imgar=w&"
                    "imgcolor=&"
                    "imgtype=&"
                    "cr=&"
                    "as_sitesearch=&"
                    "as_filetype=jpg&"
                    "tbs=&"
                    "udm=2"
                ).format(encoded_title)

            logout(data="google search url={}".format(url))

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://www.google.com/",
                "Upgrade-Insecure-Requests": "1"
            }

            ff = requests.get(url, stream=True, headers=headers, timeout=(5, 10)).text
            #logout(data="google text={}".format(ff))
            if "/httpservice/retry/enablejs" in ff or "Google Search" in ff and "enablejs" in ff:
                logout(data="google returned enablejs/challenge page")
                self.safeSetStatus("Google blocked or requires JavaScript")
                return

            # collect image urls from Google page
            urls = []

            # common direct https image pattern
            matches = re.findall(r'\],\["https://(.*?)",\d+,\d+\]', ff)
            for item in matches:
                img_url = "https://{}".format(item)
                if img_url not in urls:
                    urls.append(img_url)

            # fallback: generic escaped image urls
            if not urls:
                matches = re.findall(r'"(https://[^"]+\.(?:jpg|jpeg|png|webp))"', ff, flags=re.IGNORECASE)
                for item in matches:
                    img_url = item.replace("\\u003d", "=").replace("\\/", "/")
                    if img_url not in urls:
                        urls.append(img_url)

            if not urls:
                self.safeSetStatus("Download Ends : no files found")
                logout(data="google no image urls found")
                return

            max_results = min(9, len(urls))
            downloaded = 0

            for i in range(max_results):
                try:
                    img_url = urls[i]
                    logout(data="google image url={}".format(img_url))

                    dwnldFile = "{}mSearch/{}-{}-{}.jpg".format(
                        pathLoc,
                        search_title,
                        config.plugins.xtraEvent.PB.value,
                        i + 1
                    )

                    response = requests.get(
                        img_url,
                        stream=True,
                        allow_redirects=True,
                        timeout=(5, 10),
                        headers=headers
                    )

                    content_type = response.headers.get("Content-Type", "").lower()
                    if response.status_code != 200:
                        logout(data="google bad status={} url={}".format(response.status_code, img_url))
                        continue
                    if "image" not in content_type and response.content[:2] != b"\xff\xd8" and response.content[:8] != b"\x89PNG\r\n\x1a\n":
                        logout(data="google skipped non-image url={}".format(img_url))
                        continue

                    with open(dwnldFile, 'wb') as f:
                        f.write(response.content)

                    if os.path.exists(dwnldFile) and os.path.getsize(dwnldFile) > 0:
                        downloaded += 1
                        self.prgrs(downloaded, max_results)
                    else:
                        try:
                            os.remove(dwnldFile)
                        except:
                            pass

                except Exception as inner_err:
                    logout(data="google item error={}".format(str(inner_err)))
                    continue

            if downloaded == 0:
                self.safeSetStatus("Download Ends : no files found")
            else:
                config.plugins.xtraEvent.imgNmbr.value = 1
                self.prgrs(downloaded, downloaded)

        except Exception as err:
            logout(data="google error={}".format(str(err)))
            self.safeSetStatus("Download Ends : no files found")
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("google man.search2, %s, %s\n" % (self.title, err))
            return

    def prgrs(self, downloaded, n):
        self.safeSetStatus("Download : {} / {}".format(downloaded, n))
        try:
            if n > 0:
                self.safeSetProgress(int(100 * downloaded // n))
            else:
                self.safeSetProgress(0)
        except Exception as err:
            logout(data="prgrs error={}".format(str(err)))

class selBouquets(Screen):
    logout(data="selBouquets")
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)

        if desktop_size <= 1280:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = selbuq_720
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = selbuq_720_2
        else:
            if config.plugins.xtraEvent.skinSelect.value == 'skin_1':
                self.skin = selbuq_1080
            if config.plugins.xtraEvent.skinSelect.value == 'skin_2':
                self.skin = selbuq_1080_2

        try:
            if config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '13'):
                sl = self.getBouquetList()
            elif config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '14a'):
                sl = self.getProviderList()
            else:
                pass
            list = []
            for i in sl:
                list.append(xtraSelectionEntryComponent(i[0], 1, 0, 0))
            self["list"] = xtraSelectionList(list)
        except:
            return

        self["list"].l.setItemHeight(70)
        self["actions"] = ActionMap(["xtraEventAction"],
            {
                "cancel": self.cancel,
                "red": self.bqtinchannelsold,
                "green": self.bqtinchannels,
                "yellow": self["list"].toggleSelection,
                "blue": self["list"].toggleAllSelection,
                "ok": self["list"].toggleSelection
            }, -1)
        self["key_red"] = Label(_("Search"))
        self["key_green"] = Label(_("Save"))
        self["key_yellow"] = Label(_(lng.get(lang, '43')))
        self["key_blue"] = Label(_(lng.get(lang, '44')))
        self.setTitle(_(lng.get(lang, '55')))
        self['status'] = Label()
        self['info'] = Label()

        testver = version
        self.testver = testver
        self["testver"] = Label()
        self["testver"].setText("%s " % (self.testver))
# mit rot die alte liste nehmen und suchen

    def getBouquetList(self):
        logout(data="getBouquetList")

        self.statussearchold = "No Bouquet File make New"
        logout(data="statussearchold text ")
        self["statussearchold"] = Label()
        self['statussearchold'].setText(self.statussearchold)
        self['statussearchold'].show()

        logout(data="statussearchold")
        logout(data=str(self.statussearchold))
        if os.path.exists("{}bqts".format(pathLoc)):
            logout(data="statussearchold new")
            self.statussearchold = (_("Press Red for the Old Bouquets search "))
            self['statussearchold'].setText(self.statussearchold)
            self['statussearchold'].show()
            logout(data=str(self.statussearchold))
            logout(data="statussearchold ende")




        try:
            bouquets = []
            service_types_tv = '1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 31) || (type == 134) || (type == 195)'
            serviceHandler = eServiceCenter.getInstance()
            if config.usage.multibouquet.value:
                bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
                list = serviceHandler.list(bouquet_root)
                if list:
                    while True:
                        s = list.getNext()
                        if not s.valid():
                            break
                        if s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible:
                            info = serviceHandler.info(s)
                            if info:
                                bouquets.append((info.getName(s), s))
                    return bouquets
            else:
                bouquet_root = '%s FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'%(service_types_tv)
                info = serviceHandler.info(bouquet_root)
                if info:
                    bouquets.append((info.getName(bouquet_root), bouquet_root))
                return bouquets
            return None
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("getBouquetList, %s\n"%(err))

    def getProviderList(self):
        logout(data="getProviderList")
        try:
            service_types_tv = '1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 31) || (type == 134) || (type == 195)'
            self.root = eServiceReference('%s FROM PROVIDERS ORDER BY name' % (service_types_tv))
            serviceHandler = eServiceCenter.getInstance()
            services = serviceHandler.list(eServiceReference(self.root))
            providers = services and services.getContent("NS", True)

            plists = []
            for provider in providers:
                plists.append(provider)
            return plists

        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("getProviderList, %s\n"%(err))

    def buqChList(self, bqtNm):
        logout(data="buqChList")
        try:
            channels = []
            serviceHandler = eServiceCenter.getInstance()
            chlist = serviceHandler.list(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
            if chlist :
                while True:
                    chh = chlist.getNext()
                    if not chh.valid(): break
                    info = serviceHandler.info(chh)
                    if chh.flags & eServiceReference.isDirectory:
                        info = serviceHandler.info(chh)
                    if info.getName(chh) in bqtNm:
                        chlist = serviceHandler.list(chh)
                        while True:
                            chhh = chlist.getNext()
                            if not chhh.valid(): break
                            channels.append((chhh.toString()))
                # open("/tmp/chList", "w").write(str(channels))
                return channels
            return
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("chList Bouquet, %s\n"%(err))

    def provChList(self, prvNm):
        logout(data="provChList")
        try:
            service_types_tv = '1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 31) || (type == 134) || (type == 195)'
            channels = []
            serviceHandler = eServiceCenter.getInstance()
            chlist = serviceHandler.list(eServiceReference('%s FROM PROVIDERS ORDER BY name' % (service_types_tv)))
            if chlist :
                while True:
                    chh = chlist.getNext()
                    if not chh.valid(): break
                    info = serviceHandler.info(chh)
                    if chh.flags & eServiceReference.isDirectory:
                        info = serviceHandler.info(chh)
                    if info.getName(chh) in prvNm:
                        chlist = serviceHandler.list(chh)
                        while True:
                            chhh = chlist.getNext()
                            if not chhh.valid(): break
                            channels.append((chhh.toString()))
                # open("/tmp/chList", "w").write(str(channels))
                return channels
            return
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("chList Bouquet, %s\n"%(err))

    def bqtinchannelsold(self):
        logout(data="bqtinchannelsold")

        try:
            if os.path.exists("{}bqts".format(pathLoc)):
            #    os.remove("{}bqts".format(pathLoc))

            #bE = "{}bqts".format(pathLoc)
            #blist = []
            #for idx, item in enumerate(self["list"].list):
            #    item = self["list"].list[idx][0]
            #    if item[3]:
            #        blist.append(item[0])
            #for p in blist:

            #    if config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '13'):
            #        refs = self.buqChList(p)
            #        for ref in refs:
            #            open(bE, "a+").write("{}\n".format(ref))

            #    elif config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '14a'):
            #        refs = self.provChList(p)
            #        for ref in refs:
            #            open(bE, "a+").write("{}\n".format(ref))

            #else:
                    list = [(_(lng.get(lang, '53')), self.withPluginDownload), (_(lng.get(lang, '54')), self.withTimerDownload), (_(lng.get(lang, '35')), self.cancel)]
                    self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_('Download ?'), list=list)
            else:
                return
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("bqtinchannels, %s\n" % (err))

    def bqtinchannels(self):
        logout(data="bqtinchannels")
        try:
            if os.path.exists("{}bqts".format(pathLoc)):
                logout(data="bqtinchannels1")
                logout(data=str(pathLoc))
                import stat
                #os.chmod(pathLoc, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
                # achtung wenn die dateien rechte 777 haben geht das loeschen nicht
                os.remove("{}bqts".format(pathLoc))

            bE = "{}bqts".format(pathLoc)
            blist = []
            logout(data="bqtinchannels2")
            for idx,item in enumerate(self["list"].list):
                logout(data="bqtinchannels3")
                item = self["list"].list[idx][0]
                if item[3]:
                    blist.append(item[0])
            for p in blist:

                if config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '13'):
                    logout(data="bqtinchannels3")
                    refs = self.buqChList(p)
                    for ref in refs:
                        open(bE, "a+").write("{}\n".format(ref))

                elif config.plugins.xtraEvent.searchMOD.value == lng.get(lang, '14a'):
                    logout(data="bqtinchannels4")
                    refs = self.provChList(p)
                    for ref in refs:
                        open(bE, "a+").write("{}\n".format(ref))

            else:
                logout(data="bqtinchannels ende")
                list = [(_(lng.get(lang, '53')), self.withPluginDownload), (_(lng.get(lang, '54')), self.withTimerDownload), (_(lng.get(lang, '35')), self.cancel)]
                self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_('Download ?'), list=list)
        except Exception as err:
            with open("/tmp/xtraEvent.log", "a+") as f:
                f.write("bqtinchannels, %s\n"%(err))

    def withPluginDownload(self):
        logout(data="withPluginDownload")
        from . import download
        self.session.open(download.downloads)

    def withTimerDownload(self):
        logout(data="withTimerDownload")
        if config.plugins.xtraEvent.timerMod.value == False:
            self.session.open(MessageBox, _(lng.get(lang, '52')), MessageBox.TYPE_INFO, timeout = 10)
        else:
            self.session.openWithCallback(self.restart, MessageBox, _(lng.get(lang, '47')), MessageBox.TYPE_YESNO, timeout = 20)

    def menuCallback(self, ret = None):
        logout(data="menuCallback")
        ret and ret[1]()

    def restart(self, answer):
        logout(data="restart")
        if answer is True:
            configfile.save()
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def cancel(self):
        logout(data="cancel")
        self.close(self.session, False)

