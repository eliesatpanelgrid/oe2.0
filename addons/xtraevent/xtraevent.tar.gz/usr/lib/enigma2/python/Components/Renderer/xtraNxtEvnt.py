# -*- coding: utf-8 -*-
# by digiteng...05.2020, 07.2020, 11.2021
# mod by mnasr...03.2026
# for channellist,
# <widget source="ServiceEvent" render="xtraNxtEvnt" nxtEvents="4" snglEvent="" font="Regular; 18" position="840,500" size="400,110" zPosition="5" backgroundColor="background" transparent="1" />
# nxtEvents or snglEvent must be empty...
# for event names...

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import eLabel, eEPGCache
from Components.VariableText import VariableText
from time import localtime
from Components.config import config
import os
from Plugins.Extensions.xtraEvent.xtraTitleHelper import *

try:
    import sys
    if sys.version_info[0] == 3:
        from builtins import range
except:
    pass

# --------------------------- Logfile -------------------------------

from datetime import datetime
from os import remove
from os.path import isfile

dir_path = "/tmp/xtraevent"

try:
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print("Directory has been created:", dir_path)
    else:
        print("Directory already exists:", dir_path)
except Exception as e:
    print("Error creating directory:", e)

myfile = dir_path + "/xtraNxtEvnt.log"
if isfile(myfile):
    remove(myfile)

logstatus = "off"
if config.plugins.xtraEvent.logFiles.value == True:
    logstatus = "on"
else:
    logstatus = "off"


def write_log(msg):
    if logstatus == 'on':
        with open(myfile, "a") as log:
            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + str(msg) + "\n")
            return
    return


def logout(data):
    if logstatus == 'on':
        write_log(data)
        return
    return


logout(data="xtraNxtEvnt start")


class xtraNxtEvnt(Renderer, VariableText):

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)

        self.snglEvnt = 0
        self.nxEvnt = 0
        self.epgcache = eEPGCache.getInstance()

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == 'nxtEvents':
                self.nxEvnt = value
                logout(data="nxtEvents={}".format(str(self.nxEvnt)))
            if attrib == 'snglEvent':
                self.snglEvnt = value
                logout(data="snglEvent={}".format(str(self.snglEvnt)))

        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = eLabel

    def changed(self, what):
        self.text = ''
        try:
            ref = self.source.service
            if ref:
                events = self.epgcache.lookupEvent(['IBDCT', (ref.toString(), 0, -1, 1200)])
                logout(data="events={}".format(str(events)))

                if events and self.snglEvnt == "":
                    for i in range(int(self.nxEvnt)):
                        evnts = events[i + 1][4]
                        evnts = get_translated_event_name(evnts)
                        bt = localtime(events[i + 1][1])
                        self.text = "%s %02d:%02d - %s\n" % (self.text, bt[3], bt[4], evnts)

                if events and self.snglEvnt != "":
                    evnts = events[int(self.snglEvnt)][4]
                    evnts = get_translated_event_name(evnts)
                    bt = localtime(events[int(self.snglEvnt)][1])
                    self.text = "%s %02d:%02d - %s\n" % (self.text, bt[3], bt[4], evnts)
                else:
                    return ""
            else:
                return ""
        except Exception as err:
            logout(data="xtraNxtEvnt changed error={}".format(str(err)))
            return ""