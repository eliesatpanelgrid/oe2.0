# -*- coding: utf-8 -*-
# by digiteng...05.2020, 08.2020, 11.2021, 12.2021
# mod by mnasr...03.2026
# for channellist,
# <widget source="ServiceEvent" render="xtraNextEvents" nextEvent="1" usedImage="backdrop" delayPic="200" position="840,420" size="100,60" zPosition="5" />
# <widget source="ServiceEvent" render="xtraNextEvents" nextEvent="2" usedImage="backdrop" delayPic="200" position="940,420" size="100,60" zPosition="5" />
# <widget source="ServiceEvent" render="xtraNextEvents" nextEvent="3" usedImage="backdrop" delayPic="200" position="1040,420" size="100,60" zPosition="5" />
# <widget source="ServiceEvent" render="xtraNextEvents" nextEvent="4" usedImage="backdrop" delayPic="200" position="1140,420" size="100,60" zPosition="5" />
# ...
# usedImage="backdrop", usedImage="poster", usedImage="banner"

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadJPG, eTimer, eEPGCache
from Components.config import config
import os
import inspect
from Plugins.Extensions.xtraEvent.skins.xtraSkins import *
from Plugins.Extensions.xtraEvent.xtraTitleHelper import *

# --------------------------- Logfile -------------------------------

from datetime import datetime
from shutil import copyfile
from os import remove
from os.path import isfile

########################### delete old logfile ##################################
dir_path = "/tmp/xtraevent"

try:
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print("Directory has been created:", dir_path)
    else:
        print("Directory already exists:", dir_path)
except Exception as e:
    print("Error creating directory:", e)

myfile = dir_path + "/NextEvents.log"
## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)

########################### logfile on/off ##################################

logstatus = "off"
if config.plugins.xtraEvent.logFiles.value == True:
    logstatus = "on"
else:
    logstatus = "off"

# ________________________________________________________________________________

def write_log(msg):
    if logstatus == 'on':
        with open(myfile, "a") as log:
            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + str(msg) + "\n")
            return
    return

def logout(data):
    if logstatus == 'on':
        write_log(data)
        return
    return

# -------------------------------------------------------------------------------
logout(data="xtraNextEvents start")

NoImage = "/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/pic/film.jpg"

try:
    pathLoc = config.plugins.xtraEvent.loc.value
except:
    pathLoc = ""

class xtraNextEvents(Renderer):

    GUI_WIDGET = ePixmap

    def __init__(self):
        logout(data="init")
        caller_frame = inspect.currentframe().f_back
        caller_name = inspect.getframeinfo(caller_frame).function
        log_message = "Function getText() was called by {}.".format(caller_name)
        logout(data=str(log_message))

        Renderer.__init__(self)

        self.nxEvnt = 0
        self.nxEvntUsed = ""
        self.delayPicTime = 100
        self.epgcache = eEPGCache.getInstance()
        self.timer = eTimer()
        self.timer.callback.append(self.showPicture)

    def applySkin(self, desktop, parent):
        logout(data="applySkin")
        caller_frame = inspect.currentframe().f_back
        caller_name = inspect.getframeinfo(caller_frame).function
        log_message = "Function getText() was called by {}.".format(caller_name)
        logout(data=str(log_message))

        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == "size":
                self.piconsize = value
            elif attrib == 'nextEvent':
                self.nxEvnt = int(value)
                logout(data="nextEvent")
                logout(data=str(self.nxEvnt))
            elif attrib == 'usedImage':
                self.nxEvntUsed = value
            elif attrib == 'delayPic':
                self.delayPicTime = int(value)

        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def changed(self, what):
        logout(data="changed")
        caller_frame = inspect.currentframe().f_back
        caller_name = inspect.getframeinfo(caller_frame).function
        log_message = "Function getText() was called by {}.".format(caller_name)
        logout(data=str(log_message))

        if not self.instance:
            return
        else:
            if what[0] != self.CHANGED_CLEAR:
                self.instance.hide()
                self.timer.start(self.delayPicTime, True)
            else:
                self.instance.hide()

    def showPicture(self):
        logout(data="showPicture")
        caller_frame = inspect.currentframe().f_back
        caller_name = inspect.getframeinfo(caller_frame).function
        log_message = "Function getText() was called by {}.".format(caller_name)
        logout(data=str(log_message))

        evnt = ''
        pstrNm = ''
        evntNm = ''
        events = ''

        try:
            ref = self.source.service
            if ref:
                events = self.epgcache.lookupEvent(['T', (ref.toString(), 0, -1, 1200)])
                logout(data=str(events))
                if events:
                    logout(data="showPicture2")
                    evnt = events[self.nxEvnt][0]
                    logout(data=str(evnt))

                    evntNm = clean_search_title(evnt)
                    logout(data="cleaned next event title")
                    logout(data=str(evntNm))

                    pstrNm = "{}xtraEvent/{}/{}.jpg".format(pathLoc, self.nxEvntUsed, evntNm)
                    logout(data=str(pstrNm))

                    if os.path.exists(pstrNm):
                        self.instance.setPixmap(loadJPG(pstrNm))
                        self.instance.setScale(1)
                        self.instance.show()
                    else:
                        self.instance.hide()
                else:
                    self.instance.hide()
            else:
                self.instance.hide()
                return
        except Exception as err:
            logout(data="showPicture error={}".format(str(err)))
            return