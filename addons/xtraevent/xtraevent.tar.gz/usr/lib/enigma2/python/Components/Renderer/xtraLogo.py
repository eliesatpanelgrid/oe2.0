# -*- coding: utf-8 -*-
# by digiteng...08.2020 - 11.2021
# mod by mnasr...03.2026
# patched with guarded auto-download + logging
# <widget source="session.Event_Now" render="xtraLogo" position="59,148" size="278,185" zPosition="1" />

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eEPGCache, loadPNG
from Components.config import config

import os
import json
import threading

import requests

# --------------------------- Logfile -------------------------------
from datetime import datetime
from os import remove
from os.path import isfile

from Plugins.Extensions.xtraEvent.skins.xtraSkins import *
from Plugins.Extensions.xtraEvent.xtraTitleHelper import *
from Plugins.Extensions.xtraEvent.user_agents import *

dir_path = "/tmp/xtraevent"

try:
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print("Directory has been created:", dir_path)
    else:
        print("Directory already exists:", dir_path)
except Exception as e:
    print("Error creating directory:", e)

myfile = dir_path + "/logo.log"
if isfile(myfile):
    remove(myfile)

logstatus = "off"
if config.plugins.xtraEvent.logFiles.value == True:
    logstatus = "on"
else:
    logstatus = "off"


def write_log(msg):
    if logstatus == 'on':
        try:
            with open(myfile, "a") as log:
                log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + str(msg) + "\n")
        except:
            pass


def logout(data):
    if logstatus == 'on':
        write_log(data)


logout(data="xtraLogo start")

# --------------------------- APIs -------------------------------
if config.plugins.xtraEvent.tmdbAPI.value != "":
    tmdb_api = config.plugins.xtraEvent.tmdbAPI.value
else:
    tmdb_api = "3c3efcf47c3577558812bb9d64019d65"

# --------------------------- Py2 / Py3 -------------------------------
try:
    import sys
    PY3 = sys.version_info[0]
    if PY3 == 3:
        from builtins import str
        from builtins import range
        from builtins import object
        from configparser import ConfigParser
        from _thread import start_new_thread
        from urllib.parse import quote
    else:
        from ConfigParser import ConfigParser
        from thread import start_new_thread
        from urllib import quote
except:
    pass

def get_headers():
    try:
        ua = get_random_ua()
        #logout(data="user-agent selected={}".format(ua))
        return {"User-Agent": ua}
    except Exception as err:
        logout(data="get_headers fallback error={}".format(err))
        return {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

headers = get_headers()
logout(data="user-agent selected={}".format(headers))

try:
    from Components.Language import language
    lang = language.getLanguage()
    lang = lang[:2]
except:
    try:
        lang = config.osd.language.value[:-3]
    except:
        lang = "en"

lang_path = r"/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/languages"
try:
    lng = ConfigParser()
    if PY3 == 3:
        lng.read(lang_path, encoding='utf8')
    else:
        lng.read(lang_path)
    lng.get(lang, "0")
except:
    try:
        lang = "en"
        lng = ConfigParser()
        if PY3 == 3:
            lng.read(lang_path, encoding='utf8')
        else:
            lng.read(lang_path)
    except:
        pass

epgcache = eEPGCache.getInstance()

try:
    pathLoc = config.plugins.xtraEvent.loc.value
except:
    pathLoc = ""

# --------------------------- global guard -------------------------------
_active_logo_downloads = set()
_active_logo_downloads_lock = threading.Lock()


def build_logo_download_key(title):
    try:
        return safe_str(title).lower()
    except:
        return str(title)


def try_mark_logo_download_active(key):
    try:
        with _active_logo_downloads_lock:
            if key in _active_logo_downloads:
                return False
            _active_logo_downloads.add(key)
            return True
    except Exception as err:
        logout(data="try_mark_logo_download_active error={}".format(err))
        return False


def unmark_logo_download_active(key):
    try:
        with _active_logo_downloads_lock:
            _active_logo_downloads.discard(key)
    except Exception as err:
        logout(data="unmark_logo_download_active error={}".format(err))


class xtraLogo(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.last_name = ""

    # --------------------------- helpers -------------------------------

    def _clean_title(self, evnt):
        try:
            name = evnt.replace('\xc2\x86', '').replace('\xc2\x87', '')
        except:
            name = evnt
        return clean_search_title(name)

    def _logo_dir(self):
        return "{}xtraEvent/logo".format(pathLoc)

    def _logo_path(self, title):
        return "{}/{}.png".format(self._logo_dir(), title)

    def _ensure_dirs(self):
        try:
            if not os.path.exists(self._logo_dir()):
                os.makedirs(self._logo_dir())
        except Exception as err:
            logout(data="mkdir logo dir error: {}".format(err))

    def _show_logo(self, logo_path):
        try:
            if self.instance and os.path.exists(logo_path):
                self.instance.setPixmap(loadPNG(logo_path))
                self.instance.setScale(1)
                self.instance.show()
                logout(data="logo shown: {}".format(logo_path))
                return True
        except Exception as err:
            logout(data="show logo error: {}".format(err))
        return False

    def _is_ondemand_enabled(self):
        try:
            return config.plugins.xtraEvent.onDemandLogoDownload.value
        except:
            return False

    def _download_file(self, url, dest):
        try:
            logout(data="download file url={}".format(url))
            r = requests.get(url, stream=True, allow_redirects=True, timeout=(5, 10), headers=headers)
            if r.status_code != 200:
                logout(data="download file bad status={}".format(r.status_code))
                return False

            with open(dest, 'wb') as f:
                f.write(r.content)

            if os.path.exists(dest) and os.path.getsize(dest) > 0:
                logout(data="download file saved={}".format(dest))
                return True

            logout(data="download file saved empty")
            try:
                os.remove(dest)
            except:
                pass
            return False

        except Exception as err:
            logout(data="download file error: {}".format(err))
            try:
                if os.path.exists(dest):
                    os.remove(dest)
            except:
                pass
            return False

    def _tmdb_logo_download(self, title, dest):
        if not config.plugins.xtraEvent.logoFiles.value:
            logout(data="logoFiles is OFF")
            return False

        try:
            srch = config.plugins.xtraEvent.searchType.value
        except:
            srch = "multi"

        if not srch:
            srch = "multi"

        queries = []

        try:
            if config.plugins.xtraEvent.searchLang.value:
                queries.append(
                    "https://api.themoviedb.org/3/search/{}?api_key={}&query={}&language={}".format(
                        srch, tmdb_api, quote(title), lang
                    )
                )
        except:
            pass

        queries.append(
            "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(
                srch, tmdb_api, quote(title)
            )
        )

        if srch != "multi":
            queries.append(
                "https://api.themoviedb.org/3/search/multi?api_key={}&query={}".format(
                    tmdb_api, quote(title)
                )
            )

        seen = set()
        for url_tmdb in queries:
            if url_tmdb in seen:
                continue
            seen.add(url_tmdb)

            try:
                logout(data="xtraLogo search url={}".format(url_tmdb))
                data = requests.get(url_tmdb, timeout=(5, 10), headers=headers).json()
                results = data.get("results", [])
                if not results:
                    logout(data="xtraLogo no TMDB search results")
                    continue

                item = results[0]
                tmdb_id = item.get("id")
                media_type = item.get("media_type", srch)

                if srch in ("movie", "tv"):
                    media_type = srch
                elif media_type not in ("movie", "tv"):
                    if item.get("title", "") or item.get("release_date", ""):
                        media_type = "movie"
                    else:
                        media_type = "tv"

                if not tmdb_id:
                    logout(data="xtraLogo no tmdb id")
                    continue

                url_images = "https://api.themoviedb.org/3/{}/{}/images?api_key={}".format(
                    media_type, tmdb_id, tmdb_api
                )
                logout(data="xtraLogo images url={}".format(url_images))
                img_json = requests.get(url_images, timeout=(5, 10), headers=headers).json()
                logos = img_json.get("logos", [])
                if not logos:
                    logout(data="xtraLogo no logos found")
                    continue

                selected_logo = None
                for item_logo in logos:
                    if item_logo.get("iso_639_1") == lang:
                        selected_logo = item_logo
                        break
                if selected_logo is None:
                    for item_logo in logos:
                        if item_logo.get("iso_639_1") == "en":
                            selected_logo = item_logo
                            break
                if selected_logo is None:
                    selected_logo = logos[0]

                file_path = selected_logo.get("file_path")
                if not file_path:
                    logout(data="xtraLogo selected logo missing file_path")
                    continue

                logo_size = "w300"
                try:
                    logo_size = config.plugins.xtraEvent.TMDBlogosize.value
                except:
                    pass

                url_logo = "https://image.tmdb.org/t/p/{}{}".format(logo_size, file_path)
                if self._download_file(url_logo, dest):
                    logout(data="xtraLogo success")
                    return True

            except Exception as e:
                logout(data="xtraLogo tmdb loop error={}".format(str(e)))

        return False

    def _download_logo(self, title, dest):
        logout(data="auto download start title={}".format(title))
        logout(data="auto download dest={}".format(dest))

        try:
            if should_skip_event(title):
                logout(data="logo skip event={}".format(title))
                return
        except Exception as err:
            logout(data="logo skip check error={}".format(err))

        self._ensure_dirs()

        if os.path.exists(dest):
            logout(data="logo already exists, skip download")
            return

        ok = False

        try:
            ok = self._tmdb_logo_download(title, dest)
        except Exception as err:
            logout(data="logo outer error={}".format(err))

        if ok:
            logout(data="auto download success for {}".format(title))
        else:
            logout(data="auto download failed for {}".format(title))

    # --------------------------- renderer -------------------------------

    def changed(self, what):
        logout(data="xtraLogo changed")

        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
            return

        try:
            event = self.source.event
            if not event:
                self.instance.hide()
                return

            evnt = event.getEventName()
            logout(data="xtraLogo raw event={}".format(str(evnt)))

            if not evnt:
                self.instance.hide()
                return

            evntNm = self._clean_title(evnt)
            logout(data="xtraLogo clean event={}".format(str(evntNm)))

            if not evntNm:
                self.instance.hide()
                return

            if should_skip_event(evntNm):
                logout(data="xtraLogo skipped event={}".format(evntNm))
                self.instance.hide()
                return

            pstrNm = self._logo_path(evntNm)
            logout(data="xtraLogo expected path={}".format(pstrNm))

            if os.path.exists(pstrNm):
                self.last_name = evntNm
                self._show_logo(pstrNm)
                return

            if not self._is_ondemand_enabled():
                logout(data="xtraLogo on-demand download disabled")
                self.instance.hide()
                return

            key = build_logo_download_key(evntNm)
            if not try_mark_logo_download_active(key):
                logout(data="skip duplicate logo download for key={}".format(key))
                self.instance.hide()
                return

            def run_logo_download():
                try:
                    self._download_logo(evntNm, pstrNm)
                except Exception as e:
                    logout(data="run_logo_download error={}".format(str(e)))
                finally:
                    unmark_logo_download_active(key)
                    logout(data="xtraLogo cleared active download for {}".format(evntNm))

            start_new_thread(run_logo_download, ())
            self.instance.hide()

        except Exception as e:
            logout(data="xtraLogo changed error={}".format(str(e)))
            self.instance.hide()