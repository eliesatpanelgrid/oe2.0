# -*- coding: utf-8 -*-
# by digiteng...07.2020 - 08.2020 - 10.2021
# mod by mnasr...03.2026
# <widget source="Service" render="xtraEmcBackdrop" position="1396,565" size="457,267" zPosition="-10" />

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadJPG
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.CurrentService import CurrentService
from Components.config import config
import os
from Plugins.Extensions.xtraEvent.skins.xtraSkins import *
from Plugins.Extensions.xtraEvent.xtra import clean_movie_filename
# --------------------------- Logfile -------------------------------

from datetime import datetime
from shutil import copyfile
from os import remove
from os.path import isfile

########################### log file loeschen ##################################
dir_path = "/tmp/xtraevent"

try:
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print("Directory has been created:", dir_path)
    else:
        print("Directory already exists:", dir_path)
except Exception as e:
    print("Error creating directory:", e)

myfile=dir_path + "/EmcBackdrop.log"
## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
############################## File copieren ############################################
# fuer py2 die int und str anweisung raus genommen und das Grad zeichen

###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus



logstatus = "off"
if config.plugins.xtraEvent.logFiles.value == True:
    logstatus = "on"
else:
    logstatus = "off"


# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************

def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return

# ----------------------------- so muss das commando aussehen , um in den file zu schreiben  ------------------------------
logout(data="start")

try:
    pathLoc = config.plugins.xtraEvent.loc.value
except:
    pathLoc = ""

class xtraEmcBackdrop(Renderer):

    def __init__(self):
        Renderer.__init__(self)

    GUI_WIDGET = ePixmap
    def changed(self, what):
        if not self.instance:
            return
        else:
            if what[0] != self.CHANGED_CLEAR:
                movieNm = ""
                try:
                    service = self.source.getCurrentService()
                    if service:
                        evnt = service.getPath()
                        raw_name = os.path.basename(evnt)
                        logout(data="raw movie path={}".format(str(evnt)))
                        logout(data="raw movie filename={}".format(str(raw_name)))

                        movieNm = clean_movie_filename(raw_name)
                        logout(data="cleaned movie name={}".format(str(movieNm)))

                        if not movieNm:
                            self.instance.setScale(2)
                            self.instance.setPixmap(loadJPG("/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/pic/noMovie.jpg"))
                            self.instance.show()
                            return

                        pstrNm = "{}xtraEvent/EMC/{}-backdrop.jpg".format(pathLoc, movieNm.strip())
                        logout(data=str(pstrNm))

                        if os.path.exists(pstrNm):
                            self.instance.setScale(2)
                            self.instance.setPixmap(loadJPG(pstrNm))
                            self.instance.show()
                        else:
                            self.instance.setScale(2)
                            self.instance.setPixmap(loadJPG("/usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/pic/noMovie.jpg"))
                            self.instance.show()
                    else:
                        self.instance.hide()
                except Exception as err:
                    logout(data="xtraEmcBackdrop error={}".format(str(err)))
                    self.instance.hide()
            else:
                self.instance.hide()
                return
