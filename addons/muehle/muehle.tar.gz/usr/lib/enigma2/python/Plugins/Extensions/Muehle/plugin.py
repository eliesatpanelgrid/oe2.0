# -*- coding: utf-8 -*-

import os
import json
import random
import glob

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop

from . import _, __version__

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/muehle.json"

P_NONE = 0
P_HUMAN = 1
P_AI = 2

PHASE_PLACE = "place"
PHASE_MOVE = "move"
PHASE_JUMP = "jump"


try:
    from skin import loadSkin
    _desk_w = getDesktop(0).size().width()
    if _desk_w >= 2560:
        loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
    elif _desk_w >= 1920:
        loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
    else:
        loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
    pass

# Board positions (24 points)
POS_COORDS = [
    (0, 0), (3, 0), (6, 0),
    (1, 1), (3, 1), (5, 1),
    (2, 2), (3, 2), (4, 2),
    (0, 3), (1, 3), (2, 3),
    (4, 3), (5, 3), (6, 3),
    (2, 4), (3, 4), (4, 4),
    (1, 5), (3, 5), (5, 5),
    (0, 6), (3, 6), (6, 6),
]

NEIGHBORS = [
    [1, 9],
    [0, 2, 4],
    [1, 14],
    [4, 10],
    [1, 3, 5, 7],
    [4, 13],
    [7, 11],
    [4, 6, 8],
    [7, 12],
    [0, 10, 21],
    [3, 9, 11, 18],
    [6, 10, 15],
    [8, 13, 17],
    [5, 12, 14, 20],
    [2, 13, 23],
    [11, 16],
    [15, 17, 19],
    [12, 16],
    [10, 19],
    [16, 18, 20, 22],
    [13, 19],
    [9, 22],
    [19, 21, 23],
    [14, 22],
]

MILLS = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [9, 10, 11], [12, 13, 14],
    [15, 16, 17], [18, 19, 20], [21, 22, 23],
    [0, 9, 21], [3, 10, 18], [6, 11, 15],
    [1, 4, 7], [16, 19, 22],
    [8, 12, 17], [5, 13, 20], [2, 14, 23],
]


def check_mill(board, pos, player):
    """Check if a move creates a mill."""
    for mill in MILLS:
        if pos in mill and all(board[p] == player for p in mill):
            return True
    return False


def get_mills(board, player):
    """Get all mills for a player."""
    result = []
    for mill in MILLS:
        if all(board[p] == player for p in mill):
            result.append(mill)
    return result


def count_pieces(board, player):
    """Count pieces on board for a player."""
    return sum(1 for p in board if p == player)


def get_moves_for(board, pos, player):
    """Get valid moves for a piece at position."""
    phase = PHASE_JUMP if count_pieces(board, player) == 3 else PHASE_MOVE
    if phase == PHASE_JUMP:
        return [i for i, v in enumerate(board) if v == P_NONE]
    return [n for n in NEIGHBORS[pos] if board[n] == P_NONE]


def removable(board, opponent):
    """Get removable opponent pieces (not in mills if possible)."""
    free = [i for i in range(24) if board[i] == opponent and not check_mill(board, i, opponent)]
    if not free:
        free = [i for i in range(24) if board[i] == opponent]
    return free


def check_win(board, player, hand_opponent):
    """Check if player has won."""
    if hand_opponent > 0:
        return False

    opponent = P_AI if player == P_HUMAN else P_HUMAN

    if count_pieces(board, opponent) < 3:
        return True

    if count_pieces(board, opponent) > 3:
        for pos in range(24):
            if board[pos] == opponent:
                if get_moves_for(board, pos, opponent):
                    return False
        return True

    return False


def score_board(board):
    """Heuristic evaluation of board position."""
    h_count = count_pieces(board, P_HUMAN)
    a_count = count_pieces(board, P_AI)
    h_mills = len(get_mills(board, P_HUMAN))
    a_mills = len(get_mills(board, P_AI))
    h_moves = sum(len(get_moves_for(board, p, P_HUMAN)) for p in range(24) if board[p] == P_HUMAN)
    a_moves = sum(len(get_moves_for(board, p, P_AI)) for p in range(24) if board[p] == P_AI)
    return (a_count - h_count) * 10 + (a_mills - h_mills) * 6 + (a_moves - h_moves) * 1


def ai_place(board, hand_ai):
    """AI move during placement phase."""
    best_s = -9999
    best_p = None
    for pos in range(24):
        if board[pos] != P_NONE:
            continue
        b2 = board[:]
        b2[pos] = P_AI
        s = score_board(b2)
        if check_mill(b2, pos, P_AI):
            s += 20

        b3 = board[:]
        b3[pos] = P_HUMAN
        if check_mill(b3, pos, P_HUMAN):
            s += 15

        if s > best_s:
            best_s = s
            best_p = pos
    return best_p


def ai_move_piece(board):
    """AI move during move/jump phase."""
    best_s = -9999
    best = None
    pieces = [p for p in range(24) if board[p] == P_AI]
    random.shuffle(pieces)

    for pos in pieces:
        for target in get_moves_for(board, pos, P_AI):
            b2 = board[:]
            b2[target] = P_AI
            b2[pos] = P_NONE
            s = score_board(b2)
            if check_mill(b2, target, P_AI):
                s += 25
            if s > best_s:
                best_s = s
                best = (pos, target)
    return best


def ai_remove(board):
    """AI chooses which piece to remove after a mill."""
    best_s = -9999
    best_p = None
    for pos in removable(board, P_HUMAN):
        b2 = board[:]
        b2[pos] = P_NONE
        s = score_board(b2)
        if s > best_s:
            best_s = s
            best_p = pos
    return best_p


def draw_board_svg(board, cursor, selected, valid_moves, mills,
                   hand_h, hand_a, phase, remove_mode, W, H, filepath):
    """Generate SVG representation of the board."""
    pad = min(W, H) // 6.5
    size = min(W - pad * 2, H - pad * 2)
    ox = (W - size) // 2
    oy = (H - size) // 2
    step = size // 6

    def px(col):
        return ox + int(col * step)

    def py(row):
        return oy + int(row * step)

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
        '<rect width="%d" height="%d" fill="#1a472a"/>' % (W, H)
    ]

    mill_positions = set()
    for mill in mills:
        for p in mill:
            mill_positions.add(p)

    lw = max(2, step // 10)
    lc = "#3a5a7a"

    # Outer squares
    for i in range(3):
        s, e = i, 6 - i
        lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="%s" stroke-width="%d"/>' % (
            px(s), py(s), px(e) - px(s), py(e) - py(s), lc, lw))

    # Horizontal and vertical lines
    for col in [0, 3, 6]:
        lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (px(col), py(0), px(col), py(2), lc, lw))
        lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (px(col), py(4), px(col), py(6), lc, lw))
    for row in [0, 3, 6]:
        lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (px(0), py(row), px(2), py(row), lc, lw))
        lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (px(4), py(row), px(6), py(row), lc, lw))

    # Mill connection lines
    for mill in MILLS:
        for i in range(len(mill) - 1):
            p1, p2 = mill[i], mill[i + 1]
            c1, r1 = POS_COORDS[p1]
            c2, r2 = POS_COORDS[p2]
            lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#f5a623" stroke-width="%d" opacity="0.6"/>' % (
                px(c1), py(r1), px(c2), py(r2), int(lw * 1.5)))

    r_stone = max(8, step * 24 // 100)

    # Board positions (empty spots)
    for pos in range(24):
        p = board[pos]
        col, row = POS_COORDS[pos]
        if p == P_NONE:
            if pos not in set(valid_moves):
                lines.append('<circle cx="%d" cy="%d" r="%d" fill="#3a5a7a"/>' % (px(col), py(row), max(3, step // 8)))
            continue

        cx, cy = px(col), py(row)
        color = "#cc1111" if p == P_HUMAN else "#3a7bd5"

        if pos in mill_positions:
            lines.append('<circle cx="%d" cy="%d" r="%d" fill="rgba(245,166,35,0.35)"/>' % (cx, cy, r_stone + 5))
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy, r_stone, color))
        if pos in mill_positions:
            lines.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="#f5a623" stroke-width="2"/>' % (cx, cy, r_stone + 2))

    # Selected piece highlight
    if selected is not None:
        col, row = POS_COORDS[selected]
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="#44cc88" stroke-width="3"/>' % (px(col), py(row), r_stone + 3))

    # Cursor
    if cursor is not None:
        col, row = POS_COORDS[cursor]
        cx, cy = px(col), py(row)
        ec = max(4, r_stone // 2)
        for ex, ey in [(cx - r_stone - 2, cy - r_stone - 2),
                       (cx + r_stone - ec + 2, cy - r_stone - 2),
                       (cx - r_stone - 2, cy + r_stone - ec + 2),
                       (cx + r_stone - ec + 2, cy + r_stone - ec + 2)]:
            lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#f5a623"/>' % (ex, ey, ec, ec))

    hs = max(4, step * 18 // 100)
    gap = max(2, step // 20)

    def get_centered_hx(current_index, total_in_hand):
        stones_per_row = 5
        row_start = (current_index // stones_per_row) * stones_per_row
        row_count = min(stones_per_row, total_in_hand - row_start)
        row_width = (row_count * (hs * 2)) + ((row_count - 1) * gap)
        start_x = ox + (size // 2) - (row_width // 2)
        return start_x + (current_index % stones_per_row) * (hs * 2 + gap) + hs

    # Human pieces in hand
    for i in range(hand_h):
        hx = get_centered_hx(i, hand_h)
        hy = oy + size + step * 0.8 + (i // 5) * (hs * 2 + gap) + hs
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#cc1111"/>' % (hx, hy, hs))

    # AI pieces in hand
    for i in range(hand_a):
        hx = get_centered_hx(i, hand_a)
        hy = oy - step * 0.8 - (i // 5) * (hs * 2 + gap) - hs
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#3a7bd5"/>' % (hx, hy, hs))

    # Graveyard (captured pieces)
    lost_h = 9 - (count_pieces(board, P_HUMAN) + hand_h)
    lost_a = 9 - (count_pieces(board, P_AI) + hand_a)
    fs = hs * 0.8
    dist_graveyard = 80

    for i in range(lost_h):
        fx = ox - dist_graveyard
        fy = oy + i * (fs * 2 + gap) + fs
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#cc1111" opacity="0.4"/>' % (fx, fy, fs))

    for i in range(lost_a):
        fx = ox + size + dist_graveyard
        fy = oy + i * (fs * 2 + gap) + fs
        lines.append('<circle cx="%d" cy="%d" r="%d" fill="#3a7bd5" opacity="0.4"/>' % (fx, fy, fs))

    lines.append('</svg>')
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines))


class MuehleScreen(Screen):
    """Main Mill game screen."""

    def __init__(self, session, resume=False):
        Screen.__init__(self, session)
        self.setTitle(_("Mill"))

        self._sw = 800
        self._sh = 800
        self._discard = False

        self["bg"] = Pixmap()
        self["w_status"] = Label("")
        self["w_moves"] = Label("")
        self["w_moves_lbl"] = Label("")
        self["w_highscore"] = Label("")
        self["w_highscore_lbl"] = Label(_("Highscore:"))
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("New game"))

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "left": self._left,
                "right": self._right,
                "up": self._up,
                "down": self._down,
                "ok": self._ok,
                "green": self._new_game,
                "red": self._exit,
                "cancel": self._exit,
            }, -1)

        self._ai_timer = eTimer()
        self._ai_timer.callback.append(self._do_ai_turn)
        self.onClose.append(self._cleanup)
        self.onLayoutFinish.append(self._on_layout)
        self._highscore = self._load_highscore()

        if resume and self._load_state():
            pass
        else:
            self._init_game()

    def _init_game(self):
        """Initialize or reset game state."""
        self._board = [P_NONE] * 24
        self._hand_h = 9
        self._hand_a = 9
        self._cursor = 0
        self._selected = None
        self._valid_moves = []
        self._turn = P_HUMAN
        self._phase = PHASE_PLACE
        self._remove_mode = False
        self._mills = []
        self._moves = 0
        self._game_over = False
        self._discard = False
        self["w_status"].setText(_("Place your pieces! %d remaining.") % self._hand_h)
        self._update_hud()

    def _on_layout(self):
        """Called after layout is finished."""
        if not self["bg"].instance:
            return
        sz = self["bg"].instance.size()
        self._sw = sz.width()
        self._sh = sz.height()
        self["w_moves_lbl"].setText(_("Moves:"))
        self._render()

    def _left(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor = (self._cursor - 1) % 24
        self._render()

    def _right(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        self._cursor = (self._cursor + 1) % 24
        self._render()

    def _up(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        neighbors = NEIGHBORS[self._cursor]
        if neighbors:
            col0, row0 = POS_COORDS[self._cursor]
            above = [n for n in neighbors if POS_COORDS[n][1] < row0]
            if above:
                self._cursor = min(above, key=lambda n: POS_COORDS[n][1])
            else:
                self._cursor = (self._cursor - 1) % 24
        self._render()

    def _down(self):
        if self._turn != P_HUMAN or self._game_over:
            return
        col0, row0 = POS_COORDS[self._cursor]
        neighbors = NEIGHBORS[self._cursor]
        below = [n for n in neighbors if POS_COORDS[n][1] > row0]
        if below:
            self._cursor = max(below, key=lambda n: POS_COORDS[n][1])
        else:
            self._cursor = (self._cursor + 1) % 24
        self._render()

    def _ok(self):
        if self._game_over:
            self._new_game()
            return
        if self._turn != P_HUMAN:
            return

        pos = self._cursor

        # Remove mode (after mill)
        if self._remove_mode:
            rem = removable(self._board, P_AI)
            if pos in rem:
                self._board[pos] = P_NONE
                self._remove_mode = False
                self._moves += 1
                if check_win(self._board, P_HUMAN, self._hand_a):
                    self._on_win(P_HUMAN)
                    return
                self._turn = P_AI
                self._update_phase()
                self["w_status"].setText(_("Enigma is thinking..."))
                self._render()
                self._ai_timer.start(600, True)
            else:
                self["w_status"].setText(_("Cannot remove that piece!"))
            self._render()
            return

        # Placement phase
        if self._phase == PHASE_PLACE:
            if self._hand_h <= 0:
                return
            if self._board[pos] != P_NONE:
                self["w_status"].setText(_("Position occupied!"))
                self._render()
                return

            self._board[pos] = P_HUMAN
            self._hand_h -= 1
            self._moves += 1

            if check_mill(self._board, pos, P_HUMAN):
                self._mills = get_mills(self._board, P_HUMAN)
                self._remove_mode = True
                self["w_status"].setText(_("Mill! Remove an Enigma piece."))
                self._render()
                return

            self._after_human_turn()
            return

        # Move/Jump phase
        if self._phase in (PHASE_MOVE, PHASE_JUMP):
            if self._selected is None:
                if self._board[pos] == P_HUMAN:
                    moves = get_moves_for(self._board, pos, P_HUMAN)
                    if moves:
                        self._selected = pos
                        self._valid_moves = moves
                        self["w_status"].setText(_("Piece selected. Choose target."))
                    else:
                        self["w_status"].setText(_("No moves for this piece!"))
                else:
                    self["w_status"].setText(_("Select one of your pieces!"))
            else:
                if pos in self._valid_moves:
                    self._board[pos] = P_HUMAN
                    self._board[self._selected] = P_NONE
                    self._selected = None
                    self._valid_moves = []
                    self._moves += 1
                    if check_mill(self._board, pos, P_HUMAN):
                        self._mills = get_mills(self._board, P_HUMAN)
                        self._remove_mode = True
                        self["w_status"].setText(_("Mill! Remove an Enigma piece."))
                        self._render()
                        return
                    self._after_human_turn()
                elif self._board[pos] == P_HUMAN:
                    moves = get_moves_for(self._board, pos, P_HUMAN)
                    if moves:
                        self._selected = pos
                        self._valid_moves = moves
                        self["w_status"].setText(_("Piece selected. Choose target."))
                    else:
                        self["w_status"].setText(_("No moves for this piece!"))
                else:
                    self["w_status"].setText(_("Invalid move!"))

        self._render()

    def _after_human_turn(self):
        """Actions after human completes a turn."""
        self._selected = None
        self._valid_moves = []
        self._mills = get_mills(self._board, P_HUMAN)

        if check_win(self._board, P_HUMAN, self._hand_a):
            self._on_win(P_HUMAN)
            return

        self._turn = P_AI
        self._update_phase()
        self["w_status"].setText(_("Enigma is thinking..."))
        self._render()
        self._ai_timer.start(600, True)

    def _do_ai_turn(self):
        """Execute AI turn."""
        self._ai_timer.stop()

        if self._phase == PHASE_PLACE and self._hand_a > 0:
            pos = ai_place(self._board, self._hand_a)
            if pos is not None:
                self._board[pos] = P_AI
                self._hand_a -= 1
                self._moves += 1

                if check_mill(self._board, pos, P_AI):
                    rem = ai_remove(self._board)
                    if rem is not None:
                        self._board[rem] = P_NONE
                        self["w_status"].setText(_("Enigma formed a mill and removed your piece!"))
                    else:
                        self["w_status"].setText(_("Enigma formed a mill!"))
                else:
                    self["w_status"].setText(_("Enigma placed a piece. Your turn."))
        else:
            result = ai_move_piece(self._board)
            if result:
                src, tgt = result
                self._board[tgt] = P_AI
                self._board[src] = P_NONE
                self._moves += 1

                if check_mill(self._board, tgt, P_AI):
                    rem = ai_remove(self._board)
                    if rem is not None:
                        self._board[rem] = P_NONE
                        self["w_status"].setText(_("Enigma formed a mill and removed your piece!"))
                    else:
                        self["w_status"].setText(_("Enigma formed a mill!"))
                else:
                    self["w_status"].setText(_("Enigma moved. Your turn."))
            else:
                self["w_status"].setText(_("Enigma has no moves – you win!"))
                self._on_win(P_HUMAN)
                return

        self._mills = get_mills(self._board, P_AI)

        if check_win(self._board, P_AI, self._hand_h):
            self._on_win(P_AI)
            return

        self._turn = P_HUMAN
        self._update_phase()
        self._update_hud()
        self._render()

    def _update_phase(self):
        """Update game phase based on current state."""
        if self._hand_h > 0 or self._hand_a > 0:
            self._phase = PHASE_PLACE
        elif count_pieces(self._board, self._turn) == 3:
            self._phase = PHASE_JUMP
        else:
            self._phase = PHASE_MOVE

    def _on_win(self, winner):
        """Handle win condition."""
        self._game_over = True
        self._ai_timer.stop()
        if winner == P_HUMAN:
            self["w_status"].setText(_("You win! Press OK for new game"))
            if self._highscore == 0 or self._moves < self._highscore:
                self._highscore = self._moves
                self._save_highscore(self._highscore)
        else:
            self["w_status"].setText(_("Enigma wins! Press OK for new game"))
        self._discard = True
        self._render()

    def _render(self):
        """Render the game board."""
        if not self["bg"].instance:
            return
        draw_board_svg(
            self._board,
            self._cursor,
            self._selected,
            self._valid_moves,
            self._mills,
            self._hand_h, self._hand_a,
            self._phase,
            self._remove_mode,
            self._sw, self._sh,
            "/tmp/muehle_board.svg")
        px = LoadPixmap("/tmp/muehle_board.svg")
        if px:
            self["bg"].instance.setPixmap(px)
        self._update_hud()

    def _update_hud(self):
        """Update HUD display."""
        self["w_moves"].setText(str(self._moves))
        if self._highscore > 0:
            self["w_highscore"].setText(str(self._highscore))
        else:
            self["w_highscore"].setText("-")

    def _load_state(self):
        """Load saved game state."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                if "state" not in d:
                    return False
                s = d["state"]
                self._board = s["board"]
                self._hand_h = s["hand_h"]
                self._hand_a = s["hand_a"]
                self._cursor = s.get("cursor", 0)
                self._selected = s.get("selected")
                self._valid_moves = s.get("valid_moves", [])
                self._turn = s["turn"]
                self._phase = s["phase"]
                self._remove_mode = s.get("remove_mode", False)
                self._mills = [m for m in s.get("mills", [])]
                self._moves = s.get("moves", 0)
                self._game_over = s.get("game_over", False)
                if self._turn == P_AI:
                    self._turn = P_HUMAN
                    self._remove_mode = False
                return True
        except Exception:
            pass
        return False

    def _save_state(self):
        """Save current game state."""
        try:
            d = {}
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
            if not self._discard and not self._game_over:
                d["state"] = {
                    "board": self._board,
                    "hand_h": self._hand_h,
                    "hand_a": self._hand_a,
                    "cursor": self._cursor,
                    "selected": self._selected,
                    "valid_moves": self._valid_moves,
                    "turn": self._turn,
                    "phase": self._phase,
                    "remove_mode": self._remove_mode,
                    "mills": self._mills,
                    "moves": self._moves,
                    "game_over": self._game_over,
                }
            elif "state" in d:
                del d["state"]
            with open(SAVE_FILE, "w") as f:
                json.dump(d, f)
        except Exception:
            pass

    def _delete_state(self):
        """Delete saved game state."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                d.pop("state", None)
                with open(SAVE_FILE, "w") as f:
                    json.dump(d, f)
        except Exception:
            pass

    def _load_highscore(self):
        """Load highscore from save file."""
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                return d.get("highscore", 0)
        except Exception:
            pass
        return 0

    def _save_highscore(self, score):
        """Save highscore to save file."""
        try:
            d = {}
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
            d["highscore"] = score
            with open(SAVE_FILE, "w") as f:
                json.dump(d, f)
        except Exception:
            pass

    def _new_game(self):
        """Start a new game."""
        self._ai_timer.stop()
        self._delete_state()
        self._init_game()
        self._render()

    def _exit(self):
        """Exit the game."""
        self._ai_timer.stop()
        self._save_state()
        self.close(False)

    def _cleanup(self):
        """Clean up temporary files."""
        try:
            self._ai_timer.stop()
        except Exception:
            pass

        try:
            if os.path.exists("/tmp/muehle_board.svg"):
                os.remove("/tmp/muehle_board.svg")

            for f in glob.glob("/tmp/muehle_*.svg"):
                try:
                    os.remove(f)
                except Exception:
                    pass
        except Exception:
            pass


def main(session, **kwargs):
    session.open(MuehleScreen, resume=True)


def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return PluginDescriptor(
        name=_("Mill"),
        description=_("Mill (Nine Men's Morris) v.%s") % __version__,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="muehle.svg",
        fnc=main
    )
