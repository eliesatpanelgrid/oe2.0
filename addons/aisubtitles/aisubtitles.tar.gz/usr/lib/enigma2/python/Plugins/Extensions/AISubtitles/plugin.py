_AK='Enter {} API Key'
_AJ='ColorActions'
_AI='SetupActions'
_AH='subtitles'
_AG='#80000000'
_AF='/abertis/'
_AE='127.0.0.1'
_AD='kill_timer'
_AC='capture_timer'
_AB='Afrikaans'
_AA='Icelandic'
_A9='Belarusian'
_A8='Azerbaijani'
_A7='Lithuanian'
_A6='Macedonian'
_A5='Slovenian'
_A4='Bulgarian'
_A3='Norwegian'
_A2='Vietnamese'
_A1='Hungarian'
_A0='Ukrainian'
_z='Indonesian'
_y='Korean'
_x='Japanese'
_w='Chinese'
_v='Russian'
_u='Portuguese'
_t='Spanish'
_s='Romanian'
_r='Italian'
_q='French'
_p='German'
_o='Persian'
_n='Turkish'
_m='English'
_l='config'
_k='OpenAI API Key'
_j='Gemini API Key'
_i='AssemblyAI API Key'
_h='Deepgram API Key'
_g='Groq API Key'
_f='Arabic'
_e='mega'
_d='xlarge'
_c='large'
_b='small'
_a='orange'
_Z='cyan'
_Y='green'
_X='solid'
_W='transparent'
_V='****'
_U='auto'
_T='true'
_S='key_yellow'
_R='status'
_Q='#ffffff'
_P='ar'
_O='medium'
_N='yellow'
_M='white'
_L='semi_transparent'
_K='false'
_J='0.0.0.0'
_I='Regular'
_H=True
_G='gemini'
_F='deepgram'
_E='groq'
_D='assemblyai'
_C='openai'
_B=False
_A=None
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config,ConfigSubsection,ConfigSelection,ConfigText,ConfigYesNo,getConfigListEntry
from enigma import eConsoleAppContainer,eTimer
import os,io,hashlib,struct
try:from urllib import unquote as url_unquote,quote as url_quote
except ImportError:from urllib.parse import unquote as url_unquote;from urllib.parse import quote as url_quote
API_KEY_FILES={_E:'/etc/enigma2/aisubtitles/groq.key',_G:'/etc/enigma2/aisubtitles/gemini.key',_C:'/etc/enigma2/aisubtitles/openai.key',_F:'/etc/enigma2/aisubtitles/deepgram.key',_D:'/etc/enigma2/aisubtitles/assemblyai.key'}
config.plugins.AISubtitles=ConfigSubsection()
config.plugins.AISubtitles.enabled=ConfigSelection(default=_K,choices=[(_K,'Disabled'),(_T,'Enabled')])
config.plugins.AISubtitles.provider=ConfigSelection(default=_U,choices=[(_U,'Auto (All Enabled)'),(_E,'Groq Only'),(_F,'Deepgram Only'),(_D,'AssemblyAI Only'),(_G,'Gemini Only'),(_C,'OpenAI Only')])
config.plugins.AISubtitles.api_key=ConfigText(default='',visible_width=50,fixed_size=_B)
config.plugins.AISubtitles.api_key_gemini=ConfigText(default='',visible_width=50,fixed_size=_B)
config.plugins.AISubtitles.api_key_openai=ConfigText(default='',visible_width=50,fixed_size=_B)
config.plugins.AISubtitles.api_key_deepgram=ConfigText(default='',visible_width=50,fixed_size=_B)
config.plugins.AISubtitles.api_key_assemblyai=ConfigText(default='',visible_width=50,fixed_size=_B)
config.plugins.AISubtitles.enable_groq=ConfigYesNo(default=_H)
config.plugins.AISubtitles.enable_deepgram=ConfigYesNo(default=_B)
config.plugins.AISubtitles.enable_assemblyai=ConfigYesNo(default=_B)
config.plugins.AISubtitles.enable_gemini=ConfigYesNo(default=_B)
config.plugins.AISubtitles.enable_openai=ConfigYesNo(default=_B)
config.plugins.AISubtitles.hidden_key=ConfigSelection(default=_V,choices=[(_V,_V)])
config.plugins.AISubtitles.section_header=ConfigSelection(default='',choices=[('','')])
config.plugins.AISubtitles.background_style=ConfigSelection(default=_L,choices=[(_W,'Transparent'),(_L,'Semi-Transparent'),(_X,'Solid Black')])
config.plugins.AISubtitles.text_color=ConfigSelection(default=_M,choices=[(_M,'White'),(_N,'Yellow'),(_Y,'Green'),(_Z,'Cyan'),(_a,'Orange')])
config.plugins.AISubtitles.text_size=ConfigSelection(default=_O,choices=[(_b,'Small (28)'),(_O,'Medium (34)'),(_c,'Large (42)'),(_d,'X-Large (52)'),(_e,'Mega (62)')])
config.plugins.AISubtitles.font_type=ConfigSelection(default=_I,choices=[(_I,_I)])
def scanAvailableFonts():J='Ubuntu';I='Roboto';H='Button';G='Title';F='Body';E='Replacement';D='Console';C='LCD';B='Italic';A='Bold';K=[(_I,_I),(A,A),(B,B),(C,C),(D,D),(E,E),(F,F),(G,G),(H,H),('HandelGotDBol','Handel Gothic Bold'),('LiberationSans','Liberation Sans'),('OpenSans','Open Sans'),(I,I),(J,J),('DejaVuSans','DejaVu Sans'),('NotoSans','Noto Sans'),('DroidSans','Droid Sans'),('arial','Arial'),('times','Times'),('verdana','Verdana')];return K
config.plugins.AISubtitles.show_keys=ConfigSelection(default=_K,choices=[(_K,'Hidden (****)'),(_T,'Show Keys')])
config.plugins.AISubtitles.target_language=ConfigSelection(default=_P,choices=[(_P,_f),('en',_m),('tr',_n),('fa',_o),('de',_p),('fr',_q),('it',_r),('ro',_s),('es',_t),('pt',_u),('ru',_v),('zh',_w),('ja',_x),('ko',_y),('hi','Hindi'),('ur','Urdu'),('id',_z),('nl','Dutch'),('pl','Polish'),('el','Greek'),('uk',_A0),('cs','Czech'),('sv','Swedish'),('hu',_A1),('th','Thai'),('vi',_A2),('bn','Bengali'),('ms','Malay'),('ku','Kurdish'),('no',_A3),('da','Danish'),('fi','Finnish'),('hr','Croatian'),('sr','Serbian'),('bg',_A4),('sk','Slovak'),('sl',_A5),('mk',_A6),('sq','Albanian'),('bs','Bosnian'),('lt',_A7),('lv','Latvian'),('et','Estonian'),('he','Hebrew'),('az',_A8),('ka','Georgian'),('hy','Armenian'),('be',_A9),('mt','Maltese'),('is',_AA),('ga','Irish'),('cy','Welsh'),('af',_AB),('sw','Swahili'),('tl','Filipino'),('pa','Punjabi'),('ta','Tamil'),('te','Telugu'),('mr','Marathi'),('gu','Gujarati'),('ne','Nepali'),('si','Sinhala'),('my','Myanmar'),('km','Khmer'),('lo','Lao'),('am','Amharic')])
LANGUAGE_NAMES={_P:_f,'en':_m,'tr':_n,'fa':_o,'de':_p,'fr':_q,'it':_r,'ro':_s,'es':_t,'pt':_u,'ru':_v,'zh':_w,'ja':_x,'ko':_y,'hi':'Hindi','ur':'Urdu','id':_z,'nl':'Dutch','pl':'Polish','el':'Greek','uk':_A0,'cs':'Czech','sv':'Swedish','hu':_A1,'th':'Thai','vi':_A2,'bn':'Bengali','ms':'Malay','ku':'Kurdish','no':_A3,'da':'Danish','fi':'Finnish','hr':'Croatian','sr':'Serbian','bg':_A4,'sk':'Slovak','sl':_A5,'mk':_A6,'sq':'Albanian','bs':'Bosnian','lt':_A7,'lv':'Latvian','et':'Estonian','he':'Hebrew','az':_A8,'ka':'Georgian','hy':'Armenian','be':_A9,'mt':'Maltese','is':_AA,'ga':'Irish','cy':'Welsh','af':_AB,'sw':'Swahili','tl':'Filipino','pa':'Punjabi','ta':'Tamil','te':'Telugu','mr':'Marathi','gu':'Gujarati','ne':'Nepali','si':'Sinhala','my':'Myanmar','km':'Khmer','lo':'Lao','am':'Amharic'}
_aisubtitles_service=_A
_aisubtitles_overlay=_A
class AISubtitlesService:
	STAGE_IDLE=0;STAGE_DOWNLOAD=1;STAGE_TRANSCRIBE=3;STAGE_TRANSLATE=4;STAGE_GEMINI=5
	def __init__(A,session):A.session=session;A.is_running=_B;A.api_key_groq=config.plugins.AISubtitles.api_key.value;A.api_key_gemini=config.plugins.AISubtitles.api_key_gemini.value;A.api_key_openai=config.plugins.AISubtitles.api_key_openai.value;A.api_key_deepgram=config.plugins.AISubtitles.api_key_deepgram.value;A.api_key_assemblyai=config.plugins.AISubtitles.api_key_assemblyai.value;A.provider_mode=config.plugins.AISubtitles.provider.value;A.current_provider=_E;A.target_lang_code=config.plugins.AISubtitles.target_language.value;A.target_lang_name=LANGUAGE_NAMES.get(A.target_lang_code,_f);A.enable_groq=config.plugins.AISubtitles.enable_groq.value;A.enable_deepgram=config.plugins.AISubtitles.enable_deepgram.value;A.enable_assemblyai=config.plugins.AISubtitles.enable_assemblyai.value;A.enable_gemini=config.plugins.AISubtitles.enable_gemini.value;A.enable_openai=config.plugins.AISubtitles.enable_openai.value;A.wav_path='/tmp/ai_capture.wav';A.raw_path='/tmp/ai_raw.pcm';A.console=eConsoleAppContainer();A.console.appClosed.append(A.onProcessFinished);A._retry_delay=300;A.stage=A.STAGE_IDLE
	def start(A):
		A.is_running=_H;global _aisubtitles_overlay
		if not _aisubtitles_overlay:_aisubtitles_overlay=A.session.instantiateDialog(AISubtitlesOverlay);_aisubtitles_overlay.show()
		A.startCycle()
	def stop(A):
		A.is_running=_B
		try:
			if hasattr(A,_AC):A.capture_timer.stop()
			if hasattr(A,_AD):A.kill_timer.stop()
			A.console.kill();global _aisubtitles_overlay
			if _aisubtitles_overlay:_aisubtitles_overlay.hide();A.session.deleteDialog(_aisubtitles_overlay);_aisubtitles_overlay=_A
		except:pass
	def updateOverlay(B,text,status=_A):
		global _aisubtitles_overlay
		if _aisubtitles_overlay:from twisted.internet import reactor as A;A.callFromThread(_aisubtitles_overlay.updateText,text,status)
	def getFirstEnabledProvider(A):
		if A.enable_groq:return _E
		elif A.enable_deepgram:return _F
		elif A.enable_assemblyai:return _D
		elif A.enable_gemini:return _G
		elif A.enable_openai:return _C
	def startCycle(A):
		if not A.is_running:return
		if A.provider_mode==_U:A.current_provider=A.getFirstEnabledProvider()
		else:A.current_provider=A.provider_mode
		if not A.current_provider:A.updateOverlay('Enable a provider in settings','No Provider');return
		A.updateOverlay(_A,'Live (%s)'%A.current_provider.upper());A.startCapture()
	def extractIptvUrl(G,sref_str):
		try:
			C=sref_str.split(':')
			if len(C)>=10:
				D=':'.join(C[10:])
				if D:
					A=url_unquote(D);A=A.strip()
					if _J in A:A=A.replace(_J,_AE)
					E=_AF in A or':9999/'in A
					if not E:
						for B in['.ts','.m3u8','.flv','.mp4','.mkv']:
							if B in A:F=A.find(B)+len(B);A=A[:F];break
					if' 'in A:A=A.split(' ')[0]
					if A.startswith('http'):return A
		except:pass
	def startCapture(A):
		L='[AISubtitles] Executing: %s';K='sh -c "timeout 4 gst-launch-1.0 -q uridecodebin uri=\'{}\' ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location=\'{}\'"';H='#'
		if not A.is_running:return
		A.stage=A.STAGE_DOWNLOAD;I=A.session.nav.getCurrentlyPlayingServiceReference()
		if not I:A.updateOverlay(_A,'No Service');A.scheduleRetry(2000);return
		C=I.toString();M=C.startswith('4097:')or C.startswith('5001:')or C.startswith('5002:')or C.startswith('8193:');N=_J in C or _AF in C or':9999/'in C or'%3a9999'in C.lower()
		for J in[A.wav_path,A.raw_path]:
			if os.path.exists(J):
				try:os.remove(J)
				except:pass
		D=_A;F=4000
		if M:
			G=A.extractIptvUrl(C);print('[AISubtitles] IPTV URL: %s'%G)
			if G:A.updateOverlay(_A,'Rec (IPTV)...');D=K.format(G,A.raw_path);F=4000
			else:A.updateOverlay(_A,'No IPTV URL');A.scheduleRetry(1000);return
		elif N:
			A.updateOverlay(_A,'Rec (Relay)...');B=_A;E=C.split(':')
			if len(E)>=11:
				B=url_unquote(E[10].split(H)[0]if H in E[10]else E[10])
				if not B and len(E)>11:B=url_unquote(':'.join(E[10:]).split(H)[0])
			if B and _J in B:B=B.replace(_J,_AE)
			print('[AISubtitles] Relay URL: %s'%B)
			if B:D=K.format(B,A.raw_path);F=4000
			else:A.updateOverlay(_A,'Err: Relay URL');A.scheduleRetry(1000);return
		else:A.updateOverlay(_A,'Rec (DVB)...');B='http://127.0.0.1:8001/'+C;B=B.replace(' ','%20');print('[AISubtitles] DVB URL: %s'%B);D='sh -c "timeout 4 gst-launch-1.0 -q souphttpsrc location=\'{}\' ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location=\'{}\'"'.format(B,A.raw_path);F=4500
		if D:print(L%D);A.console.execute(D);A.capture_timer=eTimer()
		if D:print(L%D);A.console.execute(D);A.capture_timer=eTimer();A.capture_timer.callback.append(A.stopCapturePipe);A.capture_timer.start(F,_H)
	def scheduleRetry(A,delay=1000):A.retry_timer=eTimer();A.retry_timer.callback.append(A.startCycle);A.retry_timer.start(delay,_H)
	def restartLoop(A):A.scheduleRetry(100)
	def stopCapturePipe(A):A.console.sendCtrlC();A.kill_timer=eTimer();A.kill_timer.callback.append(A.forceFinish);A.kill_timer.start(1500,_H)
	def forceFinish(A):A.console.kill();A.onProcessFinished(0)
	def writeWavHeader(H,raw_path,wav_path):
		C='<H';B='<I'
		try:
			with open(raw_path,'rb')as F:D=F.read()
			E=len(D);A=io.BytesIO();A.write(b'RIFF');A.write(struct.pack(B,E+36));A.write(b'WAVE');A.write(b'fmt ');A.write(struct.pack(B,16));A.write(struct.pack(C,1));A.write(struct.pack(C,1));A.write(struct.pack(B,16000));A.write(struct.pack(B,32000));A.write(struct.pack(C,2));A.write(struct.pack(C,16));A.write(b'data');A.write(struct.pack(B,E));A.write(D)
			with open(wav_path,'wb')as G:G.write(A.getvalue())
			return _H
		except:return _B
	def onProcessFinished(A,retval):
		if hasattr(A,_AC):A.capture_timer.stop()
		if hasattr(A,_AD):A.kill_timer.stop()
		if not A.is_running:return
		if A.stage==A.STAGE_DOWNLOAD:
			if not os.path.exists(A.raw_path)or os.path.getsize(A.raw_path)<1024:print('[AISubtitles] Capture failed: File too small or missing');A.updateOverlay(_A,'Err: Stream');A.scheduleRetry(2000);return
			if not A.writeWavHeader(A.raw_path,A.wav_path):A.updateOverlay(_A,'Err: WAV');A.scheduleRetry(1000);return
			A.stage=A.STAGE_TRANSCRIBE
			if A.current_provider==_G:A.doGeminiProcess()
			elif A.current_provider==_C:A.doOpenAIProcess()
			elif A.current_provider==_F:A.doDeepgramProcess()
			elif A.current_provider==_D:A.doAssemblyAIProcess()
			else:A.doGroqTranscribe()
		elif A.stage==A.STAGE_TRANSCRIBE:
			if A.current_provider==_E:A.doGroqTranslate()
			elif A.current_provider==_C:A.doOpenAITranslate()
			elif A.current_provider==_F:A.showResultDeepgram()
			elif A.current_provider==_D:A.showResultAssemblyAI()
			else:A.showResultGemini()
		elif A.stage==A.STAGE_TRANSLATE:
			if A.current_provider==_C:A.showResultOpenAI()
			elif A.current_provider==_D:A.showResultAssemblyAIPoll()
			else:A.showResult()
		elif A.stage==A.STAGE_GEMINI:A.showResultGemini()
	def handleFail(A,msg):A.updateOverlay(_A,msg);A.scheduleRetry(2000)
	def doGroqTranscribe(A):
		A.stage=A.STAGE_TRANSCRIBE;A.updateOverlay(_A,'Transcribing...')
		if not A.api_key_groq.startswith('gsk_'):A.handleFail('Invalid Groq Key');return
		B='https://api.groq.com/openai/v1/audio/transcriptions';C='curl -k -s --max-time 15 -X POST "{}" -H "Authorization: Bearer {}" -F "file=@{}" -F "model=whisper-large-v3" -F "response_format=json" > /tmp/groq_transcribe.json'.format(B,A.api_key_groq.strip(),A.wav_path);A.console.execute(C)
	def doGroqTranslate(A):
		A.stage=A.STAGE_TRANSLATE;A.updateOverlay(_A,'Translating...');import json as D
		try:
			with open('/tmp/groq_transcribe.json','r')as B:E=D.load(B)
			C=E.get('text','').strip()
			if not C or len(C)<2:A.updateOverlay(_A,'No Speech');A.scheduleRetry(500);return
			F='https://api.groq.com/openai/v1/chat/completions';G='Translate this text to {}. Return ONLY the translation: {}'.format(A.target_lang_name,C);H={'model':'llama-3.1-8b-instant','messages':[{'role':'user','content':G}]}
			with open('/tmp/groq_translate_payload.json','w')as B:D.dump(H,B)
			I="curl -k -s --max-time 10 -X POST '{}' -H 'Authorization: Bearer {}' -H 'Content-Type: application/json' -d @/tmp/groq_translate_payload.json > /tmp/groq_translate_result.json".format(F,A.api_key_groq);A.console.execute(I)
		except:A.handleFail('Groq Parse Err')
	def showResult(A):
		A.stage=A.STAGE_IDLE;import json
		try:
			with open('/tmp/groq_translate_result.json','r')as B:C=json.load(B)
			D=C['choices'][0]['message']['content'].strip();A.updateOverlay(A.formatSubtitle(D),'');A.restartLoop()
		except:A.handleFail('Trans Fail')
	def formatSubtitle(G,text,max_chars_per_line=50,max_lines=2):
		F=max_lines;E=max_chars_per_line;B=text
		if G.target_lang_code==_P:
			try:import arabic_reshaper as H;from bidi.algorithm import get_display as I;J=H.reshape(B);return I(J)
			except:pass
		if not B:return''
		B=' '.join(B.split())
		if len(B)<=E:return B
		K=B.split();C=[];A=''
		for D in K:
			if len(A)+len(D)+1<=E:A=(A+' '+D).strip()
			else:
				if A:C.append(A)
				A=D
				if len(C)>=F:break
		if A and len(C)<F:C.append(A)
		return'\n'.join(C)
	def doGeminiProcess(A):A.handleFail('Gemini Disabled')
	def doOpenAIProcess(A):A.handleFail('OpenAI Disabled')
	def doDeepgramProcess(A):A.handleFail('Deepgram Disabled')
	def doAssemblyAIProcess(A):A.handleFail('AssemblyAI Disabled')
	def doOpenAITranslate(A):A.restartLoop()
	def showResultDeepgram(A):A.restartLoop()
	def showResultAssemblyAI(A):A.restartLoop()
	def showResultAssemblyAIPoll(A):A.restartLoop()
	def showResultOpenAI(A):A.restartLoop()
	def showResultGemini(A):A.restartLoop()
class AISubtitlesOverlay(Screen):
	def __init__(A,session):
		C=config.plugins.AISubtitles.background_style.value;D=config.plugins.AISubtitles.text_color.value;E=config.plugins.AISubtitles.text_size.value;F=config.plugins.AISubtitles.font_type.value;G={_M:_Q,_N:'#ffff00',_Y:'#00ff00',_Z:'#00ffff',_a:'#ff8800'};H={_b:28,_O:34,_c:42,_d:52,_e:62};I=G.get(D,_Q);J=H.get(E,34)
		if C==_X:B='#000000'
		elif C==_L:B=_AG
		else:B=_W
		A.skin='\n        <screen name="AISubtitlesOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="-1">\n            <widget name="subtitles" position="50,850" size="1820,200" font="{font_type};{font_size}" halign="center" valign="center" foregroundColor="{fg_color}" backgroundColor="{bg_color}" />\n            <widget name="status" position="5,5" size="200,35" font="Regular;18" foregroundColor="#00ff00" backgroundColor="#80000000" />\n        </screen>\n        '.format(font_type=F,font_size=J,fg_color=I,bg_color=B);Screen.__init__(A,session);A[_AH]=Label('');A[_R]=Label('');global _aisubtitles_overlay;_aisubtitles_overlay=A;A.onLayoutFinish.append(A.startServiceConnection);A.onClose.append(A.cleanup)
	def startServiceConnection(A):
		global _aisubtitles_service
		if _aisubtitles_service and _aisubtitles_service.is_running:A[_R].setText('Connected')
		else:A[_R].setText('Service Stopped')
	def cleanup(A):global _aisubtitles_overlay;_aisubtitles_overlay=_A
	def updateText(A,text=_A,status=_A):
		B=status
		if text is not _A:A[_AH].setText(text)
		if B is not _A:A[_R].setText(B)
class AISubtitlesSettings(ConfigListScreen,Screen):
	skin='\n    <screen name="AISubtitlesSettings" position="center,center" size="800,500" title="AI Subtitles Settings" flags="wfNoBorder" backgroundColor="#99000000">\n        <widget name="version" position="450,10" size="330,40" font="Regular;30" halign="right" valign="center" foregroundColor="#00ddff" backgroundColor="transparent" />\n        <widget name="config" position="20,60" size="760,300" scrollbarMode="showOnDemand" backgroundColor="#40000000" itemHeight="38" />\n        <widget name="credits" position="20,380" size="760,30" font="Regular;20" halign="center" valign="center" foregroundColor="#ffff00" backgroundColor="transparent" />\n        <widget name="key_red" position="20,430" size="185,50" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#cc0000" foregroundColor="white" />\n        <widget name="key_green" position="215,430" size="185,50" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#00aa00" foregroundColor="white" />\n        <widget name="key_yellow" position="410,430" size="185,50" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#ccaa00" foregroundColor="white" />\n        <widget name="key_blue" position="605,430" size="185,50" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#0066cc" foregroundColor="white" />\n    </screen>\n    '
	def __init__(A,session):
		B=session;Screen.__init__(A,B);A.session=B;A.list=[];ConfigListScreen.__init__(A,A.list);A['key_red']=Label('Close');A['key_green']=Label('Save');A[_S]=Label('Start BG');A['key_blue']=Label('Visual Test');A['version']=Label('AISubtitles v2.0');A['credits']=Label('Developed by ammarbary - Background Mode');A.updateFontChoices();A.createConfigList();A['actions']=ActionMap([_AI,_AJ],{'save':A.save,'cancel':A.close,'ok':A.handleOk,_N:A.startOverlay,'red':A.close,'blue':A.visualTest},-2);global _aisubtitles_service
		if _aisubtitles_service and _aisubtitles_service.is_running:A[_S].setText('Stop BG')
		A.editing_config=_A;A.editing_provider=_A
	def updateFontChoices(B):A=scanAvailableFonts();config.plugins.AISubtitles.font_type.setChoices(A,default=_I)
	def createConfigList(A):
		A.list=[];A.list.append(getConfigListEntry('Provider',config.plugins.AISubtitles.provider));A.list.append(getConfigListEntry('Target Language',config.plugins.AISubtitles.target_language));A.list.append(getConfigListEntry('Show API Keys',config.plugins.AISubtitles.show_keys))
		if config.plugins.AISubtitles.show_keys.value==_T:A.list.append(getConfigListEntry(_g,config.plugins.AISubtitles.api_key));A.list.append(getConfigListEntry(_h,config.plugins.AISubtitles.api_key_deepgram));A.list.append(getConfigListEntry(_i,config.plugins.AISubtitles.api_key_assemblyai));A.list.append(getConfigListEntry(_j,config.plugins.AISubtitles.api_key_gemini));A.list.append(getConfigListEntry(_k,config.plugins.AISubtitles.api_key_openai))
		else:A.list.append(getConfigListEntry(_g,config.plugins.AISubtitles.hidden_key));A.list.append(getConfigListEntry(_h,config.plugins.AISubtitles.hidden_key));A.list.append(getConfigListEntry(_i,config.plugins.AISubtitles.hidden_key));A.list.append(getConfigListEntry(_j,config.plugins.AISubtitles.hidden_key));A.list.append(getConfigListEntry(_k,config.plugins.AISubtitles.hidden_key))
		A.list.append(getConfigListEntry('======== PROVIDERS ========',config.plugins.AISubtitles.section_header));A.list.append(getConfigListEntry('Groq',config.plugins.AISubtitles.enable_groq));A.list.append(getConfigListEntry('Deepgram',config.plugins.AISubtitles.enable_deepgram));A.list.append(getConfigListEntry('AssemblyAI',config.plugins.AISubtitles.enable_assemblyai));A.list.append(getConfigListEntry('Gemini',config.plugins.AISubtitles.enable_gemini));A.list.append(getConfigListEntry('OpenAI',config.plugins.AISubtitles.enable_openai));A.list.append(getConfigListEntry('======= APPEARANCE =======',config.plugins.AISubtitles.section_header));A.list.append(getConfigListEntry('Background Style',config.plugins.AISubtitles.background_style));A.list.append(getConfigListEntry('Text Color',config.plugins.AISubtitles.text_color));A.list.append(getConfigListEntry('Text Size',config.plugins.AISubtitles.text_size));A.list.append(getConfigListEntry('Font Type',config.plugins.AISubtitles.font_type));A[_l].setList(A.list)
	def handleOk(B):
		C=B[_l].getCurrent()
		if C:
			D=C[0];A=C[1];E={config.plugins.AISubtitles.api_key:_E,config.plugins.AISubtitles.api_key_gemini:_G,config.plugins.AISubtitles.api_key_openai:_C,config.plugins.AISubtitles.api_key_deepgram:_F,config.plugins.AISubtitles.api_key_assemblyai:_D}
			if A in E:B.showKeyInputChoice(E[A],A);return
			if A==config.plugins.AISubtitles.hidden_key:
				F={_g:(_E,config.plugins.AISubtitles.api_key),_j:(_G,config.plugins.AISubtitles.api_key_gemini),_k:(_C,config.plugins.AISubtitles.api_key_openai),_h:(_F,config.plugins.AISubtitles.api_key_deepgram),_i:(_D,config.plugins.AISubtitles.api_key_assemblyai)}
				if D in F:G,H=F[D];B.showKeyInputChoice(G,H);return
			if A==config.plugins.AISubtitles.section_header:return
			if hasattr(A,'choices')and A.choices:B.showSelectionChoice(D,A);return
		B.save()
	def showSelectionChoice(A,label,config_item):
		B=config_item;A.editing_config=B;C=[]
		for D in B.choices.choices:C.append((D[1],D[0]))
		A.session.openWithCallback(A.selectionChoiceCallback,ChoiceBox,title=label,list=C)
	def selectionChoiceCallback(A,choice):
		B=choice
		if B and A.editing_config:A.editing_config.value=B[1];A.createConfigList()
	def showKeyInputChoice(A,provider,config_item):B=provider;A.editing_config=config_item;A.editing_provider=B;C=[('Import from File (/etc/)','import'),('Manual Entry (Keyboard)','keyboard')];A.session.openWithCallback(A.keyInputChoiceCallback,ChoiceBox,title=_AK.format(B.upper()),list=C)
	def keyInputChoiceCallback(B,choice):
		A=choice
		if A:
			if A[1]=='import':B.importFromFile()
			elif A[1]=='keyboard':B.openKeyboard()
	def importFromFile(A):
		if not A.editing_provider:return
		B=API_KEY_FILES.get(A.editing_provider,'')
		if not B:A.session.open(MessageBox,'No file path defined for {}'.format(A.editing_provider),MessageBox.TYPE_ERROR,timeout=3);return
		if os.path.exists(B):
			try:
				with open(B,'r')as D:
					C=D.read().strip()
					if C:A.editing_config.value=C;A.createConfigList();A.session.open(MessageBox,'Key imported from:\n{}'.format(B),MessageBox.TYPE_INFO,timeout=3)
					else:A.session.open(MessageBox,'File is empty:\n{}'.format(B),MessageBox.TYPE_WARNING,timeout=3)
			except Exception as E:A.session.open(MessageBox,'Error reading file:\n{}'.format(str(E)),MessageBox.TYPE_ERROR,timeout=3)
		else:A.session.open(MessageBox,'File not found:\n{}\n\nCreate this file with your API key.'.format(B),MessageBox.TYPE_ERROR,timeout=5)
	def openKeyboard(A):
		if not A.editing_config:return
		B=A.editing_config.value if A.editing_config.value else'';A.session.openWithCallback(A.keyboardCallback,VirtualKeyBoard,title=_AK.format(A.editing_provider.upper()if A.editing_provider else'API'),text=B)
	def keyboardCallback(A,text):
		if text is not _A and A.editing_config:A.editing_config.value=text;A.createConfigList()
	def save(A):
		for B in A[_l].list:B[1].save()
		config.plugins.AISubtitles.save()
	def startOverlay(A):
		global _aisubtitles_service
		if not _aisubtitles_service:_aisubtitles_service=AISubtitlesService(A.session)
		if _aisubtitles_service.is_running:_aisubtitles_service.stop();A[_S].setText('Start BG')
		else:_aisubtitles_service.start();A[_S].setText('Stop BG');A.close()
	def visualTest(A):A.session.open(AISubtitlesPreview)
class AISubtitlesPreview(Screen):
	def __init__(A,session):
		C=config.plugins.AISubtitles.background_style.value;E=config.plugins.AISubtitles.text_color.value;F=config.plugins.AISubtitles.text_size.value;D=config.plugins.AISubtitles.font_type.value;G={_M:_Q,_N:'#ffff00',_Y:'#00ff00',_Z:'#00ffff',_a:'#ff8800'};H={_b:28,_O:34,_c:42,_d:52,_e:62};I=G.get(E,_Q);J=H.get(F,28)
		if C==_X:B='#000000'
		elif C==_L:B=_AG
		else:B=_W
		A.skin='\n        <screen name="AISubtitlesPreview" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="10">\n            <widget name="preview" position="50,850" size="1820,200" font="{font_type};{font_size}" halign="center" valign="center" foregroundColor="{fg_color}" backgroundColor="{bg_color}" />\n            <widget name="info" position="50,50" size="500,40" font="{font_type};20" foregroundColor="#00aaff" backgroundColor="#80000000" />\n        </screen>\n        '.format(font_type=D,font_size=J,fg_color=I,bg_color=B);Screen.__init__(A,session);A['preview']=Label('Sample Subtitle Preview Text');A['info']=Label('Font: {} - Press EXIT'.format(D));A['actions']=ActionMap([_AI],{'cancel':A.close,'ok':A.close},-2)
def main(session,**A):session.open(AISubtitlesSettings)
def start_direct(session,**B):
	A=session;global _aisubtitles_service
	if not _aisubtitles_service:_aisubtitles_service=AISubtitlesService(A)
	if _aisubtitles_service.is_running:_aisubtitles_service.stop();A.open(MessageBox,'AI Subtitles Stopped',MessageBox.TYPE_INFO,timeout=2)
	else:_aisubtitles_service.start();A.open(MessageBox,'AI Subtitles Started (Background)',MessageBox.TYPE_INFO,timeout=2)
def autostart(reason,**E):
	if reason==0:
		try:
			from Screens.InfoBar import InfoBar as A;B=A.__init__
			def C(self,session):A=session;B(self,A);from Components.ActionMap import ActionMap as C;self['AISubtitlesRedAction']=C([_AJ],{'red':lambda:start_direct(A)},0)
			A.__init__=C
		except Exception as D:print('[AISubtitles] Autostart error: {}'.format(str(D)))
def Plugins(**B):A='Toggle Background Subtitles';return[PluginDescriptor(name='AI Live Subtitles',description='Configure AI Subtitles',where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main),PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART,fnc=autostart),PluginDescriptor(name='AI Subtitles Start/Stop',description=A,where=PluginDescriptor.WHERE_EXTENSIONSMENU,fnc=start_direct),PluginDescriptor(name='AI Subtitles',description=A,where=PluginDescriptor.WHERE_EVENTINFO,fnc=start_direct)]