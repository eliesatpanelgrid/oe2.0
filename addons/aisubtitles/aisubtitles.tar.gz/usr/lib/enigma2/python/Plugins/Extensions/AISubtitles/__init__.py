# AISubtitles Plugin - v2.0
# Developed by ammarbary
