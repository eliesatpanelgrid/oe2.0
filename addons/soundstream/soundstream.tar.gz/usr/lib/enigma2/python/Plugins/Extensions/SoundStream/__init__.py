# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("VPYt2Cwn01T2SbztZu9sPKrDrZDvvH9+xhKsvK9OnCkhaQUyCQi/lvTAqvWoznmcOHNoIW5jkufA97QYRQFZAhfgE9MbE7e/AkyagDt+Nf2TDKd+fxlgg/yICOdmv8eUYqoVOKV4km1PiHpPNKGyeyUBYFzCFvx68i3psl2l/9SO4ojC6e0JWKXmE0TO/PGLqISu0YkNu1NWr5yGZdEnxNtGewYFHNgWAsDswULersih03qe7fvKJRHXRvta7zPwLNOYYU/z1SfirBNVRxtaIfDcm1HPwR1N2aiozUUm3Rylwo7r9eHQVjbzat3Q5L2HGMCSg7Mok6pPrl/pN621")
    data = triple_xor_decrypt(data, 65)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
