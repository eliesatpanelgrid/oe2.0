# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("hCb9d/yIA4QmD8nycQvz8fX08a1Mqay2tjEwd7PQtrA2sHKz0LE1MCs3ydKpHg6KcfAL8471couOCQh3i/COiA6I+tZz+lerLv0VDwj/LcuqIBCuRE0Amud0H+So/17AoOjgf2ieRaDfYIG+oaA9Bq49Ri52vJiWooaymo36uNzJ0+Uwjn8UiQlXrXb5/O9LzJWmoMIm")
    data = triple_xor_decrypt(data, 145)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
