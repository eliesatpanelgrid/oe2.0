# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("rgzXRNe7KK4Mq0UJmRTmxhEJK/34JXNbtd83u9/ZKk4fdFTXh9pGc2b0Awf7i8E2aSEM5w9CDnEjrWsZq6EBEKrdKn7DDT5e/2DATb4bU/ItmMe7hH9vAgJp14qNQzjXc3su1mcZhHM3966pzZlQBX7JUnV+4T8jFVfdF6om7s3Q4P/HRDEGU8wYHWWSvs32Asjk0/Va/rcZ+ICAC8Kcd67HnMF/ZIbGZFJBMLzfyB3k+LW0dCLx/mAgbkG9cKKoxqyRSksAT5VXH24caxYaBL5FkWCMwfKgX0Zy4rZ8gSjab1dr2zD5Nz4IdwLTEXepR55tdh2gxhGjir4Fk31rlE7Ez3dQWmR/g6UURUr1IEwHIhaDEyA6WOJ94eCesSSSaLyq3ebpvhO9BfttY7pWph+CjQ4nzBpcMZ2XKwl/Wz+tDrLlbaW5PylRGVUoCzU9wbERj7oNtTElAk/7cy++G415F7LMWJGo0cOumA7/x28gZ4LuVEirxAb9tEcUjvBxc/qNeW74Qnp+oTa2Fi2aJzMC+wS5LZAqhrbIBfQ=")
    data = triple_xor_decrypt(data, 187)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
