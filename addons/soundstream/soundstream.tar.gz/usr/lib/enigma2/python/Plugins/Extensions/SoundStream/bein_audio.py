# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("xWe8s7hMR8VnIOtg02aLqQNy7s2RbfcmkIbzDxvjAJyQ7519J7/Qi6nNv/4rleYO8deZaJl2z2wdlDfdMg3gsXgroommD9xWa5os00qZhpmYeg9eGCU9OVlcXMqzAk7+Yv1oshZ13sP1xvApdR0HEZnOvNr+SXleOe1cJaw4fiXMJPYwe8C7j/cVqXM3mv77ogfMHIqv8RTDU8v06RVUeCl3APn3i4/U685El1zsqcug8wPzNS04KTTfe3RhIaoE/x3G2dDAmEz+28ELcd2KWq3B363vaf+l3gABlnGQ3pv/WMW2xl20XKiO3Zl/0vW2YkMF4+ThE96Z/qR85yT9Z7vnYCxhSJleRe4wFewK/gL6mR9TrSk4ydifTSUw+wBvFTIN3AjlOth9FdFcehkq+ZNCGWx9FYu2z/3LhiFFriU2tp5t++A832nIAPwyDjlHSuR5xbZW7nJhlVEwUzfswt+AXPRAp/LHN38vkvZSWvHDTcIGzgrbf9rrlxvHXy69yIecsNga3rSvuKiZNa1d5yO5V47kXHFtphSUDJ41Ye08Ck99zgqmx+5MAoHph2CTr922T/NaADhuXklySeBHqxh6ZDZJCkl/8eMaAj1Bv3xJhUCAgD5YuHFjHVGdxiQAP1SkV5eyCUtiDcQvoBgaDpCqxB/xJs+/ZoIYUik8Ub1m6hUmJSmzIRkCG4KnJpgK22bIyKqN6qPIuRYwyGHqN3C3Z6YgbrzpE4uwWON5uRQpCjDWBL8td9g6pUu80v8qsBPqYRId135h3CmKrFZYFJ1cdeUDKf4U7r+pkRDoO7X4emikb1QvLavVl8J7XZmNHtjzeQu0CpMUsb75JPmTYAi7tScoOUFa9fJm5Zxft39Xi9fJvrLSMHwXMq4kzTejBSydXhW3zFqvzHqdr0cQv7cFo7VQ+BxVprQc40JAbc5cu/L1JDb0T4imrhGHN84hAzwpB3UzrVlqxMsloNiSyXfYup1ChIbx8qB6pHaFdMp2M3y+HKfG4ncF5BbI5A9mPiofV0RpXE5yIfmJKlZ2SKcJk5pTeiKYP81gf0F4hgPq0q1SSyBTcKWjLdB7QGvddLZHyYXC7lN7GYjh9c10ZcuVRq7yL772q37Gvh43Si0N+QurKtFZt531edjKaLoNXQ9nvq1qCtF6mk2XrlYrwy7SZBiuGHjoeRS/gPZCdSMWG+3b9sBt8MT1ueXR0iiLATn+EVhJO/culRn52LdFVzWFPym4PA1RVGZZjTOmvrYDGElRlJh1/gjcF++Vp5Cgj7GJ7AJ9JbtqnOpIb2yzCK3oaNr4e/pY3cy2DT3SEYNg5ebCPSiBD5wkDICmDBV5M8zxYGx/qJU8xAbgIDrvumffdmt9qLCEW7U8j/2l4jSzusklm6d/2ZYlQU+FhM38eN7DkkbnQCFK5MogpFg0T6v0GSmJOrKqA2UZ1+/A50DPSEwuCPpWcLgtHVTKTawwy4pcjEK13KUhEqVhiUoRUfKt+5nLHMF9+/CzXiefGJ116OVz6QTwaiMTCb+3vwGwTD/DGMJvCw2TohGWkiWbh80LxJU02FNHovhbfNKoePi5C2feFNuzK3f8mkuo5ADY4uALvENaRv5VyKRBhnTjV5+DQt0up/RESGJuw1FW4rydhbiQaKWyXFKEP3PFs6hCl0C2FH/S028APyvAgV7T2XqeDDkik9c9ExHFn3AkM0NNoL/iYxsSJtWyN3yfi51Ctth9YiwmWsIZ")
    data = triple_xor_decrypt(data, 208)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
