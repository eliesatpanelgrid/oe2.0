# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("uxnCUcCuP7sZtpYerRj1130UkLMvRmYXkl/aG/mgHW35Y9QolsjPc85CdWtFcIfK13ZlC7FS9rKQYCvQr9tFnm/uUdWC8m8eUFN0vkH+Ac1qnPRtwohXu719MDL4hO8KkeKSWfhvn8qZbDGhXUq3gjCljHFH+Y3l21Tt3UwEiz5mHWmUKXZ5QRbG/ymQNnT9lGxT/RDosPoW5KuNLB+GHMws4LNasS/6jfHvQUsG107SHVCKdfRkT8SHU/qYx2fLmilAyrURgaVGz4Hlb6aBgIU1zQFzcfRF9Y1N3kSGS2Rl0fzgMQNkRO9UepikMYXNQZxK/gHcvbilEpXLFny5bm3PHbC2wjz04LeXuN3AoyDJwmbIG+KCgVVDhyetSGxMrwHjnk0sSkG59o7SldQDDlad4D5IZirMNnFQOWCHdlD9wN9kKY6KKmb9kiwDcY60nzE7UwrAV6VX9LY10tXbAzOG2fE9o0/I2i4dAd3h+kmJzaEFqs2/hX1j53eMZW2G4scm0fXl8OSP3DH75uLOIroj5yfzi9vsZ7Y/ocOSreN+RdHdKFa9T4PAA2Mik/yC7S9A9x2BbiwWiEvfZgHlhk9UCojfloFcp5ODK1ne/FRBpm2U8c3kmX7ngSVlldTci1oiKfNSRnKOQCzCFvpvlU5ep3FXGL59J5PfrbXv+cBuARAFbfMj2HS8e7QkLbQbIRwfLUVNPv9IguB7zMRzLI61NKS2/hS/JYM+cboY7wNfUefrh68htsuq7/nEsLBPNXRH49LOqYvBwdewlDflECodDXTgPzb0/Ay5Y1LD45ngrPE5sfOof+hGln6aNBFM6iDYmUwzklgkG4xx4jVtgGoG//qpktwMkxDTs6lU42J2/cauVGJ1RlIhEuUqSAdrsbFOF53X5tq+wzY2tdqfmPU4FK60vCEVU4NgE0aaBa/NRgfnYrWg/eElfTwWJAgd9byapbN4fnLAfiKu8L3HBd6t9O+l2IwuFzaGAp5rdqwk7btM+Gq1YwqtYSJjTNXnUEZjgtp9Wf0eSzbyAzEAbKQDef3Affy+vTezgvBKrRjYiHra3rc3ClOlUX2VPGv8jpMjAIspFaN1Nuv0pY8Y/MoL92X3sERdLqsQClSlj33Dsm8JVa13wbgzuvLs7TeJfmvlZ7lkbRla+CY8Pj0/ahqZgnqMNxBMob/1JkVFTcGSlGA2RGg/VVoSvmEUYOoszaMvPsz6W1NVFDh+Cg==")
    data = triple_xor_decrypt(data, 174)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
