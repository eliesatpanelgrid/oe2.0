import subprocess

def generate_audio_command(stream_url, title, output_dir="bein_audio"):
    os.makedirs(output_dir, exist_ok=True)
    safe_title = "".join(c if c.isalnum() else "_" for c in title)[:50]
    output_file = f"{output_dir}/{safe_title}.mp3"
    
    cmd = [
        'ffmpeg', '-i', stream_url,
        '-vn', '-acodec', 'libmp3lame', '-b:a', '192k',
        '-metadata', f'title={title}',
        '-t', '7200',  # ساعتين (غيرها حسب الحاجة)
        output_file
    ]
    return cmd, output_file