# -*- coding: utf-8 -*-
# SoundStream v4.0 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("ftwHSge1+H7cU1bLTMI2FrjpVQrz1hC8c1sXd6dp52uXlLAVj90iI09DXvAgDP0kU9eFftQhT9nAMgNd4TYf9PvKCeWLUgByXTJMkK7zZFcng10Sro7HmrITlX8vPyGkjLJXTn7YrDwHxUqLD87QMqvPLaC0pkYgQEMWaRDmROySlRs8UkEVNQd6ZtzidJFbrRBlSdOCZOhLJ4UmTukiFVcPikSfNEts1/QuAKozRJYBRqMEgYx3iH69v17biivBMJJ/JRzqobiB1fvS45b04Dr2FJlMWD/40NFFgpL0AGnFAsQjdX+w/cJf2A1JJqOqthrMnBPIsSAaO1ZqzvaYW6tx51rB15aMngeip5kh3Yll+6WfR3q/WKvaDSFmuWphuetdeeqZJrQ5+9d48MmwBf3nphG2W/nuzMi43dH+yWBwF/kx2E+nb5Me0Ejgilmj+LdbHHagWw==")
    data = triple_xor_decrypt(data, 107)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
